"""
aitrust.core.aggregator
=======================

Aggregation strategies translate a *set of validator results*
into a single **decision** for the parent guard.

New features
------------
* Dynamic plug-in registry – register new strategies with ``@register("name")``.
* Built-in strategies:
    • pass_all               – always PASS. (default / fallback)  
    • block_on_any           – BLOCK if _any_ validator fails.  
    • block_on_mandatory     – BLOCK if *mandatory* validator fails, WARN if optional fails.  
    • majority               – PASS if > 50 % of validators pass.  
    • threshold              – PASS if pass-ratio ≥ `guard_settings.threshold` (float 0-1).  
    • weighted_voting        – score by `guard_settings.weights`; positive ⇒ PASS.  
* Uniform helper ``_is_pass`` (case-insensitive).
* Metrics & tracing for every aggregation call.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional
import time

from aitrust.monitoring.logs import logger
from aitrust.monitoring.telemetry import (
    h_sdk_orchestrator_execution_latency as EXECUTION_TIME,
    tracer,
)
from aitrust.models.guard import GuardSettings
from aitrust.models.validator import ValidatorExecutionModel

from .base_aggregator import BaseAggregator  # keeps public import path stable

# --------------------------------------------------------------------------- #
# Registry helpers                                                            #
# --------------------------------------------------------------------------- #
_REGISTRY: Dict[str, type["BaseAggregator"]] = {}


def register(name: str):  # noqa: ANN001
    """Decorator to add an Aggregator subclass to the registry."""

    def _wrap(cls: type["BaseAggregator"]) -> type["BaseAggregator"]:
        key = name.lower()
        _REGISTRY[key] = cls
        return cls

    return _wrap


def _is_pass(res: ValidatorExecutionModel) -> bool:
    """Return True iff validator response.status == 'pass' (case-insensitive)."""
    return bool(res.response and str(res.response.status).lower() == "pass")


# --------------------------------------------------------------------------- #
# Aggregator implementations                                                  #
# --------------------------------------------------------------------------- #
@register("pass_all")
class PassAllAggregator(BaseAggregator):
    """Always returns **PASS**."""

    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings] = None,
    ) -> str:
        return "PASS"


@register("block_on_any")
class BlockOnAnyAggregator(BaseAggregator):
    """BLOCK if **any** validator does not pass."""

    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings] = None,
    ) -> str:
        return "BLOCK" if any(not _is_pass(res) for res in validator_results) else "PASS"


@register("block_on_mandatory")
class BlockOnMandatoryAggregator(BaseAggregator):
    """
    * BLOCK if **mandatory** validator fails
    * WARN if optional fails
    * PASS otherwise
    """

    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings] = None,
    ) -> str:
        mandatory = set(guard_settings.mandatory_validators) if guard_settings else set()

        mandatory_failed = any(
            not _is_pass(res) and res.request.validator_config.name in mandatory
            for res in validator_results
        )
        optional_failed = any(
            not _is_pass(res) and res.request.validator_config.name not in mandatory
            for res in validator_results
        )

        if mandatory_failed:
            return "BLOCK"
        if optional_failed:
            return "WARN"
        return "PASS"


@register("majority")
class MajorityAggregator(BaseAggregator):
    """PASS if > 50 % of validators pass, else BLOCK."""

    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings] = None,
    ) -> str:
        if not validator_results:  # edge-case: empty ⇒ PassAll semantics
            return "PASS"
        passed = sum(1 for res in validator_results if _is_pass(res))
        return "PASS" if passed / len(validator_results) > 0.5 else "BLOCK"


@register("threshold")
class ThresholdAggregator(BaseAggregator):
    """
    PASS if pass-ratio ≥ ``guard_settings.threshold`` (0-1, defaults 1.0).  
    e.g. threshold = 0.8 ⇒ require 80 % passes.
    """

    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings] = None,
    ) -> str:
        if not validator_results:
            return "PASS"
        thr = getattr(guard_settings, "threshold", 1.0) if guard_settings else 1.0
        thr = min(max(float(thr), 0.0), 1.0)  # clamp 0-1
        pass_ratio = sum(_is_pass(r) for r in validator_results) / len(validator_results)
        return "PASS" if pass_ratio >= thr else "BLOCK"


@register("weighted_voting")
class WeightedVotingAggregator(BaseAggregator):
    """
    Each validator contributes a **weight** (positive or negative) defined in
    ``guard_settings.weights`` (dict of validator_name → float).

    * If total weighted score > 0 ⇒ PASS  
    * If == 0 ⇒ WARN  
    * If < 0 ⇒ BLOCK
    """

    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings] = None,
    ) -> str:
        weights = getattr(guard_settings, "weights", {}) if guard_settings else {}
        total = 0.0
        for res in validator_results:
            name = res.request.validator_config.name
            w = float(weights.get(name, 1.0))
            total += w if _is_pass(res) else -w
        if total > 0:
            return "PASS"
        if math.isclose(total, 0.0):
            return "WARN"
        return "BLOCK"


# --------------------------------------------------------------------------- #
# Public factory                                                              #
# --------------------------------------------------------------------------- #
def get_aggregator(strategy: str | None) -> BaseAggregator:
    """
    Return an **instance** of the aggregator matching *strategy*.

    If the name is unknown, *block_on_any* is used to fail-safe.
    """
    key = (strategy or "pass_all").lower()
    agg_cls = _REGISTRY.get(key)
    if agg_cls is None:
        logger.warning("Unknown aggregation strategy '%s' – falling back to block_on_any", key)
        agg_cls = _REGISTRY["block_on_any"]

    aggregator: BaseAggregator = agg_cls()

    # -------- telemetry wrapper -------- #


    # keep a reference to the real implementation
    _orig_aggregate = aggregator.aggregate  # type: ignore[attr-defined]

    def _timed_aggregate(results, settings=None):  
        with tracer.start_as_current_span("aggregate") as span:
            span.set_attribute("strategy", key)
            start = time.perf_counter()
            decision = _orig_aggregate(results, settings)
            elapsed = time.perf_counter() - start
            EXECUTION_TIME.record(elapsed, attributes={"strategy": key})
            return decision

    # override the instance method
    aggregator.aggregate = _timed_aggregate  # type: ignore[attr-defined]
    return aggregator
