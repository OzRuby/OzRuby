"""
base_aggregator.py

Provides the abstract interface for aggregator classes that combine 
multiple validator results into a single guard-level decision (PASS, BLOCK, WARN).
"""

from abc import ABC, abstractmethod
from typing import List, Optional

from aitrust.models.guard import GuardSettings
from aitrust.models.validator import ValidatorExecutionModel


class BaseAggregator(ABC):
    """
    Abstract base class for aggregators which combine a list of validator results
    into a single guard decision: 'PASS', 'BLOCK', or 'WARN'.
    """

    @abstractmethod
    def aggregate(
        self,
        validator_results: List[ValidatorExecutionModel],
        guard_settings: Optional[GuardSettings]
    ) -> str:
        """
        Perform the aggregator's logic.

        Args:
            validator_results: Results from multiple validators.
            guard_settings: Optional guard settings that may define mandatory validators or
                           response_aggregation_strategy, priority, etc.

        Returns:
            A string representing the final aggregated decision: 'PASS', 'BLOCK', or 'WARN'.
        """
        pass