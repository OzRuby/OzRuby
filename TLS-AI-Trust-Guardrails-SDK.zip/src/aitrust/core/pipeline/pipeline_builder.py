"""
pipeline_orchestrator.py
========================

Coordinating end-to-end pipeline execution with built-in concurrency control,
resilient retry logic, and detailed telemetry.

Responsibilities:
  1- **Pipeline orchestration:**
      - Launch, monitor, and finalize pipeline runs
      - Persist execution state and overall decisions
  2- **DAG construction & traversal:**
      - Build a directed acyclic graph of stages once at initialization
      - Execute stages in dependency order, supporting both sequential and asynchronous modes
  3- **Guard & validator dispatch:**
      - Enforce global concurrency limits via a shared semaphore
      - Prioritize and invoke validators with tenacity-powered retries
      - Poll event-based validators until terminal state
  4- **Execution tree & telemetry:**
      - Maintain an in-memory execution tree for structured tracing
      - Record granular latency metrics per guard and per stage
      - Release execution tree after completion to minimize memory footprint
"""


from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Dict, List, Tuple
from uuid import UUID, uuid4

from aitrust.common.config import ConfigLoader
from aitrust.monitoring.logs import logger
from aitrust.models.common_enums import PipelineExecutionModeEnum
from aitrust.models.config import SDKConfigModel
from aitrust.models.guard import GuardConfiguration, GuardExecutionModel
from aitrust.models.pipeline import PipelineExecutionModel, PipelineStageExecutionResult
from aitrust.models.validator import (
    ContentTypeEnum,
    UserPayloadModel,
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorMethodEnum,
    ValidatorRequestModel,
)


# --------------------------------------------------------------------------- #
# Helper: map expected_input_type → ContentTypeEnum                           #
# --------------------------------------------------------------------------- #
_EXPECTED_TO_CONTENT_TYPE = {
    "text": ContentTypeEnum.TEXT,
    "list": ContentTypeEnum.LIST,
    "dict": ContentTypeEnum.DICT,
}


def _content_type_from_params(params: Dict[str, Any] | None) -> ContentTypeEnum:
    expected = (params or {}).get("expected_input_type", "text").lower()
    return _EXPECTED_TO_CONTENT_TYPE.get(expected, ContentTypeEnum.TEXT)


# --------------------------------------------------------------------------- #
# PipelineDocBuilder                                                          #
# --------------------------------------------------------------------------- #
class PipelineDocBuilder:
    """
    Build a :class:`PipelineExecutionModel` with placeholder execution records
    ready for orchestration.
    """

    # ------------------------------------------------------------------ #
    def __init__(self, config_model: SDKConfigModel, pipeline_execution_id: UUID) -> None:
        self._pipeline_execution_id = pipeline_execution_id
        self._config_model = config_model

        # Zones == stage names
        self._zones: List[str] = [stage.name for stage in config_model.pipeline_stages]
        self._zone_execution_modes: Dict[str, PipelineExecutionModeEnum] = {
            stage.name: stage.execution_mode for stage in config_model.pipeline_stages
        }

        # Guards keyed by name
        self._guards_config: Dict[str, GuardConfiguration] = config_model.guards

        # Fix missing fields & validate mandatory lists early
        self._validate_and_fix_guard_defs()

        logger.info(
            "PipelineDocBuilder created (id=%s, zones=%d, guards=%d)",
            self._pipeline_execution_id,
            len(self._zones),
            len(self._guards_config),
        )

    # ------------------------------------------------------------------ #
    # Validation helpers                                                 #
    # ------------------------------------------------------------------ #
    def _validate_and_fix_guard_defs(self) -> None:
        """Ensure each guard has non-empty ``stages`` and ``validators`` lists."""
        for guard_name, guard_cfg in self._guards_config.items():
            if not guard_cfg.stages:
                logger.warning("Guard '%s' missing 'stages'; defaulting to empty list", guard_name)
                guard_cfg.stages = []

            if not guard_cfg.validators:
                logger.warning("Guard '%s' missing 'validators'; defaulting to empty list", guard_name)
                guard_cfg.validators = []

            # Warn for unknown mandatory validators
            mand = getattr(guard_cfg.settings, "mandatory_validators", None)
            if mand:
                known = {v.name for v in guard_cfg.validators}
                unknown = set(mand) - known
                if unknown:
                    logger.warning("Guard '%s' lists unknown mandatory validators: %s", guard_name, unknown)

    # ------------------------------------------------------------------ #
    # Class factories                                                    #
    # ------------------------------------------------------------------ #
    @classmethod
    def from_config_file(cls, path: str, pipeline_execution_id: UUID) -> "PipelineDocBuilder":
        cfg = ConfigLoader(settings_path=path).load_config()
        return cls(cfg, pipeline_execution_id)

    @classmethod
    def from_config_model(cls, cfg: SDKConfigModel) -> "PipelineDocBuilder":
        return cls(cfg, uuid4())

    # ------------------------------------------------------------------ #
    # Convenience getters                                                #
    # ------------------------------------------------------------------ #
    def get_zones(self) -> List[str]:
        return self._zones

    def get_zone_execution_mode(self, zone_name: str) -> PipelineExecutionModeEnum:
        return self._zone_execution_modes.get(zone_name, PipelineExecutionModeEnum.SEQUENTIAL)

    def get_guards_for_zone(self, zone_name: str) -> List[GuardConfiguration]:
        return [g for g in self._guards_config.values() if zone_name in g.stages]

    # ------------------------------------------------------------------ #
    # Main builder                                                       #
    # ------------------------------------------------------------------ #
    def build_pipeline_execution_model(self) -> PipelineExecutionModel:
        now = datetime.now(UTC)
        peid = self._pipeline_execution_id

        stage_exec_results: List[PipelineStageExecutionResult] = []

        for stage in self._config_model.pipeline_stages:
            guard_exec_results: List[GuardExecutionModel] = []

            for guard_cfg in self.get_guards_for_zone(stage.name):
                validator_exec_results: List[ValidatorExecutionModel] = []

                for vconf in guard_cfg.validators:
                    vid = uuid4()  # single UUID reused inside request

                    # Validation method
                    method_str = (vconf.parameters or {}).get("validation_method", "llm").lower()
                    try:
                        method_enum = ValidatorMethodEnum(method_str)
                    except ValueError:
                        method_enum = ValidatorMethodEnum.LLM

                    # Content type
                    content_type = _content_type_from_params(vconf.parameters)

                    # Build execution + nested request
                    user_payload = UserPayloadModel(
                        content_type=content_type,
                        value="",  # filled at runtime
                        metadata={},
                        method=method_enum,
                    )

                    validator_exec_results.append(
                        ValidatorExecutionModel(
                            pipeline_execution_id=peid,
                            validator_execution_id=vid,
                            execution_status=ValidatorExecutionStatusEnum.NOT_STARTED,
                            last_update=now,
                            request=ValidatorRequestModel(
                                validation_method=method_enum,
                                project_name=self._config_model.project_infos.project_name,
                                scope=getattr(self._config_model.project_infos, "scope", None),
                                country_name=getattr(self._config_model.project_infos, "country_name", None),
                                partner_name=getattr(self._config_model.project_infos, "partner_name", None),
                                validator_config=vconf,
                                request_id=uuid4(),
                                conversation_id=None,
                                pipeline_execution_id=peid,
                                validator_execution_id=vid,
                                user_payload=user_payload,
                                config_parameters=vconf.parameters or {},
                                created_at=now,
                            ),
                        )
                    )

                guard_exec_results.append(
                    GuardExecutionModel(
                        guard_execution_id=uuid4(),
                        guard_config=guard_cfg,
                        validators_execution_results=validator_exec_results,
                        final_decision=None,
                        execution_status="not_started",
                        start_time=None,
                        end_time=None,
                        last_update=now,
                    )
                )

                logger.debug(
                    "Stage '%s' – guard '%s' has %d validators",
                    stage.name,
                    guard_cfg.name,
                    len(validator_exec_results),
                )

            stage_exec_results.append(
                PipelineStageExecutionResult(
                    stage_execution_id=uuid4(),
                    stage_name=stage.name,
                    guards_execution_results=guard_exec_results,
                    overall_decision=None,
                    status="not_started",
                    start_time=None,
                    end_time=None,
                    created_at=now,
                )
            )

        exec_model = PipelineExecutionModel(
            id=str(peid),
            revision=getattr(self._config_model, "revision", 1),
            pipeline_execution_id=peid,
            pipeline_definition_id=peid,
            project_infos=self._config_model.project_infos,
            service_settings=self._config_model.service_settings,
            pipeline_stages=self._zones,
            guards_config=self._guards_config,
            stages_execution_results=stage_exec_results,
            status="not_started",
            start_time=now,
            end_time=None,
            last_update=now,
        )

        logger.info(
            "PipelineExecutionModel built (id=%s, stages=%d, guards=%d)",
            peid,
            len(stage_exec_results),
            sum(len(s.guards_execution_results) for s in stage_exec_results),
        )
        return exec_model

    # ------------------------------------------------------------------ #
    # Dunder helpers                                                     #
    # ------------------------------------------------------------------ #
    def __repr__(self) -> str:  # noqa: D401
        return (
            f"<PipelineDocBuilder id={self._pipeline_execution_id!s} "
            f"zones={self._zones!r} guards={list(self._guards_config)!r}>"
        )
