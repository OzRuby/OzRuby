from abc import ABC, abstractmethod
from typing import List, Dict, Any, Tuple
from uuid import UUID
from datetime import datetime

class BasePipeline(ABC):
    """
    Abstract interface for pipeline implementations.

    This class defines the required methods for any pipeline implementation.
    """

    @abstractmethod
    def get_pipeline_id(self) -> UUID:
        """
        Returns the unique identifier of the pipeline.

        Returns:
            UUID: The pipeline identifier.
        """
        pass

    @abstractmethod
    def get_zones(self) -> List[str]:
        """
        Returns a list of zone names in the pipeline.

        Returns:
            List[str]: The zone names.
        """
        pass

    @abstractmethod
    def get_zone_execution_mode(self, zone_name: str) -> str:
        """
        Returns the execution mode (e.g., sequential or asynchronous) for a given zone.

        Args:
            zone_name (str): The zone name.

        Returns:
            str: The execution mode.
        """
        pass

    @abstractmethod
    def get_guards_for_zone(self, zone_name: str) -> List[Any]:
        """
        Returns a list of guards configured for a specific zone.

        Args:
            zone_name (str): The zone name.

        Returns:
            List[Any]: The guard configurations.
        """
        pass

    @abstractmethod
    async def execute_pipeline(self, data: Any) -> Dict[str, Any]:
        """
        Executes the pipeline using the provided data.

        Args:
            data (Any): The input data.

        Returns:
            Dict[str, Any]: The execution results.
        """
        pass

    @abstractmethod
    async def _execute_zone(self, zone_name: str, data: Any) -> Tuple[Any, Any]:
        """
        Executes a single zone of the pipeline.

        Args:
            zone_name (str): The zone name.
            data (Any): The input data.

        Returns:
            Tuple: The zone execution result and its execution tree node.
        """
        pass

    @abstractmethod
    def get_status(self) -> str:
        """
        Returns the current status of the pipeline.

        Returns:
            str: The pipeline status.
        """
        pass

    @abstractmethod
    def set_status(self, new_status: str) -> None:
        """
        Updates the pipeline status.

        Args:
            new_status (str): The new status.
        """
        pass

    @abstractmethod
    def get_config_model(self) -> Any:
        """
        Returns the configuration model used for the pipeline.

        Returns:
            Any: The configuration model.
        """
        pass

    @abstractmethod
    def get_created_at(self) -> datetime:
        """
        Returns the creation timestamp of the pipeline.

        Returns:
            datetime: The creation time.
        """
        pass

    @abstractmethod
    def get_last_update(self) -> datetime:
        """
        Returns the last update timestamp of the pipeline.

        Returns:
            datetime: The last update time.
        """
        pass