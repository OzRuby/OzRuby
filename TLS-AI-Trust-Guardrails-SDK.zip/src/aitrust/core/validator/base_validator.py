from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from aitrust.models.validator import ValidatorConfig, ValidatorExecutionModel

class BaseValidator(ABC):
    """
    Abstract base class for validator implementations.
    
    Concrete implementations must implement the 'validate' method to execute their logic.
    Detailed logging should be included in these implementations to trace the validation process.
    """
    @abstractmethod
    async def validate(self, validator_config: "ValidatorConfig", data: Any) -> "ValidatorExecutionModel":
        """
        Executes the validator logic.

        Args:
            validator_config (ValidatorConfig): The configuration for the validator.
            data (Any): The input data for validation.

        Returns:
            ValidatorExecutionModel: The result of the validation.
        """
        raise NotImplementedError("Subclasses must implement the validate method.")

    @abstractmethod
    def get_name(self) -> str:
        """
        Returns the name of the validator.

        Returns:
            str: The name of the validator.
        """
        raise NotImplementedError("Subclasses must implement the get_name method.")