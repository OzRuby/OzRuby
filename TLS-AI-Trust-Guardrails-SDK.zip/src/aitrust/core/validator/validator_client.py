"""
ValidatorClient
===============

Manages HTTP interactions with validator endpoints, providing reliable, typed responses:

Responsibilities:
  * **Connection pooling & timeouts:**
      - Single shared HTTP session via centralized http module
      - Configurable request timeout via settings
  * **Resilient retries:**
      - Retries & backoff via `request_with_retry`
  * **JSON serialization:**
      - Custom serializer for `UUID`, `datetime`, etc.
      - Fallback on serialization failure
  * **Uniform error handling:**
      - Shaped failure payload for `ValidatorExecutionModel`
  * **Graceful shutdown:**
      - Close underlying HTTP session cleanly
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, date, timezone
from typing import Any, Dict

from aitrust.common.http import request_with_retry, close_http_session, json_serializer
from aitrust.common.settings_config import SETTINGS_CONFIG
from aitrust.models.validator import (
    ValidatorExecutionStatusEnum,
    ValidatorResponseStatusEnum,
)
from aitrust.monitoring.logs import logger

class ValidatorClient:
    """Reusable, performant HTTP client for validator calls."""

    async def send_request(self, service_url: str, body: str | Dict[str, Any]) -> Dict[str, Any]:
        """
        POST *body* (JSON string or dict) to *service_url*, with retries and error shaping.
        """
        # ensure we have a dict for logging/failure-payload
        try:
            payload = json.loads(body) if isinstance(body, str) else body
        except Exception:
            payload = body  # best effort

        try:
            response = await request_with_retry(
                "post",
                service_url,
                data=body if isinstance(body, str) else None,
                json=None if isinstance(body, str) else payload,
                headers={"Content-Type": "application/json"},
            )
            logger.debug("Validator response (%s): %s", service_url, response)
            return response

        except Exception as exc:
            logger.exception("Validator call failed after retries: %s", exc)
            return self._failure_payload(payload, str(exc))

    def _create_failed_payload(self, payload: dict, error_message: str) -> dict:
        """
        Build a minimal ValidatorExecutionModel–shaped dict signaling failure.

        The PipelineRunner will call ValidatorExecutionModel.model_validate(...) on this dict.
        """
        pipeline_id = payload.get("pipeline_execution_id") or str(uuid.uuid4())
        validator_id = payload.get("validator_execution_id") or str(uuid.uuid4())
        now_iso = datetime.datetime.now(UTC).isoformat()

        failed_dict = {
            "pipeline_execution_id": pipeline_id,
            "validator_execution_id": validator_id,
            "execution_status": ValidatorExecutionStatusEnum.ERROR.value,
            "error_message": error_message,
            "start_time": now_iso,
            "end_time": now_iso,
            "last_update": now_iso,
            # include a minimal response block so model_validate can find it
            "response": {
                "status": ValidatorResponseStatusEnum.FAILED.value,
                "have_fix": False,
                "details": {},
                "error_message": error_message,
                "created_at": now_iso,
            },
        }
        logger.debug("Created failed validator payload: %s", failed_dict)
        return failed_dict

    async def close_client(self) -> None:
        """Close the underlying shared HTTP session."""
        await close_http_session()

    @staticmethod
    def _failure_payload(original: Dict[str, Any], msg: str) -> Dict[str, Any]:
        """Return a minimal, error-shaped payload for ValidatorExecutionModel."""
        now_iso = datetime.now(timezone.utc).isoformat()
        return {
            "pipeline_execution_id": original.get("pipeline_execution_id", str(uuid.uuid4())),
            "validator_execution_id": original.get("validator_execution_id", str(uuid.uuid4())),
            "execution_status": ValidatorExecutionStatusEnum.ERROR.value,
            "error_message": msg,
            "start_time": now_iso,
            "end_time": now_iso,
            "last_update": now_iso,
            "response": {
                "status": ValidatorResponseStatusEnum.FAILED.value,
                "have_fix": False,
                "details": {},
                "error_message": msg,
                "created_at": now_iso,
            },
        }
