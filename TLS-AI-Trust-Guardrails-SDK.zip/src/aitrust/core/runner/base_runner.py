"""
base_runner.py

Defines the abstract base interface for a pipeline runner, which can:
  1) Create pipeline records
  2) Update pipeline records
  3) Run (and possibly poll) validators
  4) Manage underlying resources (HTTP clients, etc.)
"""

from abc import ABC, abstractmethod
from typing import Any

class BaseRunner(ABC):
    """
    Abstract base class specifying the operations a pipeline runner must support:
      - create_pipeline_record
      - update_pipeline_record
      - run_validator
      - close
    """

    @abstractmethod
    async def create_pipeline_record(self, pipeline_execution_model: Any) -> None:
        """
        Creates a pipeline record in the remote service (POST /pipeline).
        """
        pass

    @abstractmethod
    async def update_pipeline_record(self, pipeline_execution_model: Any) -> None:
        """
        Updates the pipeline record in the remote service (POST /pipeline/{id}).
        """
        pass

    @abstractmethod
    async def run_validator(
        self,
        data: Any,
        validator_config: Any,
        pipeline_execution_model: Any,
        zone_name: str,
        guard_config: Any,
        validator_exec_model: Any = None
    ) -> "ValidatorExecutionModel":
        """
        Executes a validator, possibly polling for final status if event-based.
        """
        pass

    @abstractmethod
    async def close(self) -> None:
        """
        Closes any resources associated with the runner (e.g. HTTP connections).
        """
        pass