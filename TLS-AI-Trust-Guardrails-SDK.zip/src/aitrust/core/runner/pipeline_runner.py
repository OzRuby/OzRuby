"""
PipelineRunner
==============

Handles communication with the Trust Service and manages validator executions:

Responsibilities:
  * **HTTP communication:**
      - Single shared HTTP session via centralized http module
      - Resilient retries & exponential backoff driven by `request_with_retry`
  * **Pipeline record management:**
      - Create and update pipeline records around each validation run
  * **Validator orchestration:**
      - Build and dispatch validation payloads to HTTP-based or event-based endpoints
      - Track `ValidatorExecutionModel` lifecycle (start, in-progress, end)
  * **Event-based polling:**
      - Tenacity-driven retry on `_poll_once` until terminal state or max attempts
      - Centralized HTTP for poll requests
  * **Async operations & cleanup:**
      - Non-blocking asyncio flows for all network I/O
      - Graceful shutdown via shared HTTP session and validator client
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import uuid4

from tenacity import retry, retry_if_result, stop_after_attempt, wait_fixed

from aitrust.common.http import request_with_retry, close_http_session, json_serializer
from aitrust.common.settings_config import SETTINGS_CONFIG
from aitrust.core.runner.base_runner import BaseRunner
from aitrust.core.validator.validator_client import ValidatorClient
from aitrust.models.guard import GuardConfiguration
from aitrust.models.pipeline import PipelineExecutionModel
from aitrust.models.validator import (
    ContentTypeEnum,
    UserPayloadModel,
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorMethodEnum,
    ValidatorResponseStatusEnum,
    ValidatorTypeEnum,
)
from aitrust.monitoring.logs import logger

# --------------------------------------------------------------------------- #
# Tuning parameters                                                            #
# --------------------------------------------------------------------------- #
POLL_INTERVAL_SECONDS: float = SETTINGS_CONFIG.settings.runner_settings.get("interval", 0.5)
MAX_POLL_ATTEMPTS: int = SETTINGS_CONFIG.settings.runner_settings.get("max_attempts", 10)


class PipelineRunner(BaseRunner):
    """High-level orchestrator for pipelines and validators."""

    def __init__(self, service_base_url: str) -> None:
        self.service_base_url = service_base_url.rstrip("/")
        self.validator_client = ValidatorClient()
        logger.debug("PipelineRunner initialised for base URL: %s", self.service_base_url)

    async def create_pipeline_record(self, model: PipelineExecutionModel) -> dict:
        """
        Create a new pipeline record in the Trust Service.

        Serialises the PipelineExecutionModel using Pydantic’s built-in JSON
        marshaller, then POSTs it to /pipeline.
        """
        url = f"{self.service_base_url}/pipeline"
        json_body = model.model_dump_json()
        logger.debug("Creating pipeline record → %s", json_body)
        resp = await request_with_retry(
            "post",
            url,
            data=json_body,
            headers={"Content-Type": "application/json"},
        )
        logger.info("Pipeline record created (id=%s)", model.pipeline_execution_id)
        return resp

    async def update_pipeline_record(self, model: PipelineExecutionModel) -> dict:
        """
        Update an existing pipeline record in the Trust Service.

        Serialises the PipelineExecutionModel using Pydantic’s JSON marshaller,
        then POSTs it to /pipeline/{id}.
        """
        url = f"{self.service_base_url}/pipeline/{model.pipeline_execution_id}"
        json_body = model.model_dump_json()
        logger.debug("Updating pipeline record → %s", json_body)
        resp = await request_with_retry(
            "post",
            url,
            data=json_body,
            headers={"Content-Type": "application/json"},
        )
        logger.debug("Pipeline record updated (id=%s)", model.pipeline_execution_id)
        return resp

    async def run_validator(
        self,
        data: Any,
        validator_config: ValidatorConfig,
        pipeline_execution_model: PipelineExecutionModel,
        zone_name: str,
        guard_config: GuardConfiguration,
        validator_exec_model: Optional[ValidatorExecutionModel] = None,
    ) -> ValidatorExecutionModel:
        """
        Execute a validator and persist its results.

        - Marks start time & status
        - Builds a ValidatorExecutionModel.request payload
        - Sends to HTTP or event-based endpoint
        - Polls for event-based until completion
        - Persists final status & response
        """
        if validator_exec_model is None:
            raise ValueError("validator_exec_model must be supplied")

        logger.info("Running validator '%s' for zone '%s'", validator_config.name, zone_name)
        now = datetime.now(timezone.utc)
        validator_exec_model.start_time = now
        validator_exec_model.last_update = now
        validator_exec_model.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS

        # Build request payload
        if isinstance(data, dict) and {"value", "metadata"} <= data.keys():
            value, metadata = data["value"], data["metadata"]
            conversation_id = data.get("conversation_id")
        else:
            value, metadata, conversation_id = str(data), {}, None

        method = ValidatorMethodEnum(validator_config.parameters.get("validation_method", "llm"))
        req = validator_exec_model.request or ValidatorExecutionModel.request.model_validate({})
        req.validation_method = method
        req.validator_config = validator_config
        req.request_id = uuid4()
        req.conversation_id = conversation_id
        req.pipeline_execution_id = pipeline_execution_model.pipeline_execution_id
        req.validator_execution_id = validator_exec_model.validator_execution_id
        req.user_payload = UserPayloadModel(
            content_type=ContentTypeEnum.TEXT,
            value=value,
            metadata=metadata,
            method=method,
        )
        req.config_parameters = validator_config.parameters or {}
        req.created_at = now
        validator_exec_model.request = req

        # Dispatch to validator endpoint
        full_url = f"{self.service_base_url}{validator_config.endpoint_url}"
        payload = req.model_dump()
        try:
            body = json.dumps(payload, default=json_serializer)
            logger.debug("POST → %s payload=%s", full_url, body)
            resp = await self.validator_client.send_request(full_url, body)

            if validator_config.validator_type == ValidatorTypeEnum.EVENT_BASED:
                # small grace period before polling
                await asyncio.sleep(1)
                await self._poll_for_event(pipeline_execution_model, validator_exec_model)
            else:
                parsed = ValidatorExecutionModel.model_validate(resp)
                validator_exec_model.response = parsed.response
                validator_exec_model.execution_status = parsed.execution_status

        except Exception as exc:
            logger.error("Validator execution failed: %s", exc, exc_info=True)
            validator_exec_model.execution_status = ValidatorExecutionStatusEnum.ERROR
            if validator_exec_model.response:
                validator_exec_model.response.status = ValidatorResponseStatusEnum.FAILED
            validator_exec_model.error_message = str(exc)

        finally:
            # persist result
            now2 = datetime.now(timezone.utc)
            validator_exec_model.end_time = now2
            validator_exec_model.last_update = now2
            await self.update_pipeline_record(pipeline_execution_model)
            logger.info("Validator execution persisted: %s", validator_exec_model.model_dump())

        return validator_exec_model

    @retry(
        retry=retry_if_result(lambda still: still),
        wait=wait_fixed(POLL_INTERVAL_SECONDS),
        stop=stop_after_attempt(MAX_POLL_ATTEMPTS),
        reraise=False,
    )
    async def _poll_once(self, poll_url: str, model: ValidatorExecutionModel) -> bool:
        """
        Single “ping” to the Trust Service.
        Returns True if still in progress -> retry, False if terminal state.
        """
        resp = await request_with_retry("get", poll_url)
        updated = ValidatorExecutionModel.model_validate(resp)
        model.execution_status = updated.execution_status
        model.response = updated.response
        now = datetime.now(timezone.utc)
        model.last_update = now
        model.end_time = now
        return updated.execution_status in {
            ValidatorExecutionStatusEnum.IN_PROGRESS,
            ValidatorExecutionStatusEnum.NOT_STARTED,
        }

    async def _poll_for_event(
        self,
        pipeline_execution_model: PipelineExecutionModel,
        validator_exec_model: ValidatorExecutionModel,
    ) -> None:
        """
        Poll until the validator moves out of IN_PROGRESS/NOT_STARTED,
        or until MAX_POLL_ATTEMPTS is reached.
        """
        poll_url = (
            f"{self.service_base_url}/pipeline/"
            f"{pipeline_execution_model.pipeline_execution_id}/validator/"
            f"{validator_exec_model.validator_execution_id}"
        )
        timed_out = await self._poll_once(poll_url, validator_exec_model)

        if timed_out:
            validator_exec_model.execution_status = ValidatorExecutionStatusEnum.ERROR
            if validator_exec_model.response:
                validator_exec_model.response.status = ValidatorResponseStatusEnum.FAILED
            validator_exec_model.error_message = (
                f"Polling timeout after {MAX_POLL_ATTEMPTS} attempts"
            )
            now = datetime.now(timezone.utc)
            validator_exec_model.last_update = now
            validator_exec_model.end_time = now
            logger.error(
                "Polling timed-out for validator %s",
                validator_exec_model.validator_execution_id,
            )

    async def close(self) -> None:
        """Release HTTP resources."""
        await self.validator_client.close_client()
        await close_http_session()
        logger.info("PipelineRunner resources closed")
