from abc import ABC, abstractmethod
from typing import Dict, Any

class BaseOrchestrator(ABC):
    """
    Abstract base class for pipeline orchestrators.
    """

    @abstractmethod
    async def execute_pipeline(self, data: Any) -> Dict[str, Any]:
        """
        Runs the pipeline with the provided data, returning 
        final summary results.
        """
        pass

    @abstractmethod
    def get_results(self) -> Dict[str, Any]:
        """
        Retrieves a summary of the pipeline run.
        """
        pass

    @abstractmethod
    def logging(self) -> None:
        """
        Performs any final logging actions if needed.
        """
        pass