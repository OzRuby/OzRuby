"""
pipeline_orchestrator.py
========================

Coordinates the end-to-end execution of a validation pipeline:

* **Global concurrency control:**  
  Shared asyncio.Semaphore limits simultaneous guard executions across all stages.

* **Resilient execution:**  
  Tenacity-powered `_execute_with_retry` wrapper applies exponential-jitter back-off and retry on all transient errors.

* **Single DAG construction:**  
  Pipeline dependency graph is built once in `__init__` (not per run) for efficiency.

* **Configurable stage ordering & parallelism:**  
  Supports both sequential and asynchronous execution at the zone (stage) level, and within each guard runs validators in parallel or in series according to your config.

* **Hookable lifecycle:**  
  Pre- and post-stage hooks let you inject custom logic before or after any stage runs.

* **Execution tree & telemetry:**  
  Maintains a nested `ExecutionTreeNodeModel` for every pipeline, stage, guard and validator; records detailed spans and latencies for observability.

* **Context propagation:**  
  Conversation and pipeline execution IDs flow from your input data through every validator invocation.

* **Graceful finalization:**  
  `complete_pipeline()` flushes statuses, persists final pipeline records asynchronously, and releases the in-memory execution tree for memory safety.
"""


from __future__ import annotations

import asyncio, os
from datetime import UTC, datetime
from typing import Any, Callable, Dict, List, Optional, Tuple
from uuid import UUID

import networkx as nx
from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)

from aitrust.common.settings_config import SETTINGS_CONFIG
from aitrust.core.aggregator import get_aggregator
from aitrust.core.authentification.securegpt_token import generate_securegpt_token
from aitrust.core.orchestration.base_orchestrator import BaseOrchestrator
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.core.runner.pipeline_runner import PipelineRunner
from aitrust.models.common_enums import PipelineExecutionModeEnum
from aitrust.models.guard import GuardConfiguration, GuardExecutionModel
from aitrust.models.orchestrator import (
    ExecutionTreeNodeModel,
    ExecutionTreeNodeType,
    OrchestrationStatusEnum,
    OrchestratorExecutionContextModel,
    OrchestratorModel,
    OrchestratorStageResultModel,
)
from aitrust.models.pipeline import PipelineExecutionModel, PipelineStageExecutionResult
from aitrust.models.validator import (
    ValidatorExecutionModel,
    ValidatorPriorityEnum,
    ValidatorResponseStatusEnum,
)
from aitrust.monitoring.logs import logger, log_data
from aitrust.monitoring.telemetry import (
    tracer,
    SpanAttributeEnum,
    SpanSdkMeterEnum,
    counter_add,
    histogram_record,
    sdk_orchestrator_call,
    sdk_pipeline_error,
    sdk_stage_execution,
    sdk_pipeline_completed,
    h_sdk_orchestrator_execution_latency as EXECUTION_TIME,
    h_sdk_stage_latency,
    h_sdk_guard_latency,)

# ---------------------------------------------------------------------------- #
# Priority ranking for validators                                               #
# ---------------------------------------------------------------------------- #
_PRIORITY_RANK = {
    ValidatorPriorityEnum.P1: 1,
    ValidatorPriorityEnum.P2: 2,
    ValidatorPriorityEnum.P3: 3,
}

# ---------------------------------------------------------------------------- #
# PipelineOrchestrator                                                          #
# ---------------------------------------------------------------------------- #
class PipelineOrchestrator(BaseOrchestrator):
    """Coordinates the end-to-end execution of a Pipeline."""

    def __init__(
        self,
        pipeline_definition: PipelineDocBuilder,
        pipeline_execution_model: PipelineExecutionModel,
        pipeline_runner: PipelineRunner,
    ) -> None:
        """
        Initialize the orchestrator.

        - Reads orchestrator settings once.
        - Builds the execution DAG.
        - Creates a global concurrency semaphore.
        """
        self._pipeline_definition = pipeline_definition
        self._pipeline_execution_model = pipeline_execution_model
        self._runner = pipeline_runner
        self._pipeline_execution_id: UUID = pipeline_execution_model.pipeline_execution_id

        # Load orchestrator settings a single time
        orc_cfg = SETTINGS_CONFIG.settings.orchestrator_settings
        self._max_concurrency: int = orc_cfg.get("max_concurrency", 5)
        self._stage_timeout: int = orc_cfg.get("timeout", 30)
        self._max_retries: int = orc_cfg.get("max_retries", 3)
        self._retry_backoff: float = orc_cfg.get("retry_backoff", 1.0)

        self._final_status: OrchestrationStatusEnum = OrchestrationStatusEnum.NOT_STARTED
        self._execution_tree_root: Optional[ExecutionTreeNodeModel] = None

        self._orchestration_definition = OrchestratorModel(
            pipeline_id=self._pipeline_execution_id,
            context=OrchestratorExecutionContextModel(
                request_id=f"ORCH-{self._pipeline_execution_id}"
            ),
            stages=[],
            status=self._final_status,
            start_time=datetime.now(UTC),
            end_time=None,
            execution_tree=None,
        )

        # Build and cache DAG once
        self._sem = asyncio.Semaphore(self._max_concurrency)
        self._dag: nx.DiGraph = self._build_pipeline_graph()

        # Hook registries
        self._pre_hooks: Dict[str, List[Callable]] = {}
        self._post_hooks: Dict[str, List[Callable]] = {}

        # Authentication context for any downstream calls
        self.securegpt_token = generate_securegpt_token(retry=False)

        self.properties = {
                "project_name": self._pipeline_execution_model.project_infos.project_name,
                "conversation_id": self._pipeline_execution_model.conversation_id,
                "request_id": str(self._orchestration_definition.context.request_id),
                "pipeline_execution_id": str(self._pipeline_execution_id),
                "country_name": self._pipeline_execution_model.project_infos.country_name,
                "partner_name": self._pipeline_execution_model.project_infos.partner_name,
        }

        # Set telemetry attributes for logging and tracing
        SpanAttributeEnum.REQUEST_ID.attribute(str(self._orchestration_definition.context.request_id))
        SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(str(self._pipeline_execution_id))
        # Set CONVERSATIONAL_ID if available
        SpanAttributeEnum.CONVERSATIONAL_ID.attribute(self._pipeline_execution_model.conversation_id)
        # Set project-related attributes if project_infos is available
        SpanAttributeEnum.PROJECT_NAME.attribute(self._pipeline_execution_model.project_infos.project_name)
        SpanAttributeEnum.COUNTRY_NAME.attribute(self._pipeline_execution_model.project_infos.country_name)
        SpanAttributeEnum.CONTRACT_NAME.attribute(self._pipeline_execution_model.project_infos.contract_name)

        logger.info(f"PipelineOrchestrator initialised (pipeline= {self._pipeline_execution_id})")
        log_data(logger.info, "SDK Initialization", self.properties)

    @property
    def logging(self):
        """Concrete logger for BaseOrchestrator abstract API."""
        return logger

    # ------------------------------------------------------------------------- #
    # Hooks                                                                    #
    # ------------------------------------------------------------------------- #
    def register_pre_hook(self, stage_name: str, hook: Callable) -> None:
        """
        Register a coroutine to run before a specific stage executes.

        :param stage_name: The name of the stage.
        :param hook: Async function taking the stage data.
        """
        self._pre_hooks.setdefault(stage_name, []).append(hook)

    def register_post_hook(self, stage_name: str, hook: Callable) -> None:
        """
        Register a coroutine to run after a specific stage completes.

        :param stage_name: The name of the stage.
        :param hook: Async function taking the stage result.
        """
        self._post_hooks.setdefault(stage_name, []).append(hook)

    # ------------------------------------------------------------------------- #
    # Retry wrapper                                                            #
    # ------------------------------------------------------------------------- #
    async def _execute_with_retry(self, func: Callable, *args, **kwargs) -> Any:
        """
        Run `func(*args, **kwargs)` with tenacity retries on any Exception.

        Uses exponential jitter backoff based on settings.
        """
        async for attempt in AsyncRetrying(
            retry=retry_if_exception_type(Exception),
            wait=wait_exponential_jitter(
                initial=self._retry_backoff, max=self._retry_backoff * 8
            ),
            stop=stop_after_attempt(self._max_retries),
            reraise=True,
        ):
            with attempt:
                return await func(*args, **kwargs)

    # ------------------------------------------------------------------------- #
    # Pipeline lifecycle                                                        #
    # ------------------------------------------------------------------------- #
    async def start_pipeline(self) -> None:
        """
        Create the pipeline record, mark status RUNNING, and
        initialize the root of the execution tree.
        """
        if self._final_status is not OrchestrationStatusEnum.NOT_STARTED:
            logger.warning(f"Pipeline already started (status= {self._final_status})")
            # log_data(logger.warning, f"Pipeline already started (status= {self._final_status})")
            return

        # log_data(logger.info, f"Starting pipeline {self._pipeline_execution_id}")
        logger.info(f"Starting pipeline {self._pipeline_execution_id}")
        await self._runner.create_pipeline_record(self._pipeline_execution_model)
        self._pipeline_execution_model.status = OrchestrationStatusEnum.RUNNING.value
        await self._runner.update_pipeline_record(self._pipeline_execution_model)

        self._final_status = OrchestrationStatusEnum.RUNNING
        self._execution_tree_root = ExecutionTreeNodeModel(
            node_type=ExecutionTreeNodeType.PIPELINE,
            name=str(self._pipeline_execution_id),
            status=OrchestrationStatusEnum.RUNNING,
            start_time=datetime.now(UTC),
        )
        self._orchestration_definition.execution_tree = self._execution_tree_root

    async def execute_pipeline(self, pipeline_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute all stages in topological order. Honors each stage’s
        execution_mode (sequential vs asynchronous).
        """
        await self.start_pipeline()
        counter_add(sdk_orchestrator_call, 1)
        stage_results: List[OrchestratorStageResultModel] = []

        for generation in nx.topological_generations(self._dag):
            # fan-out across the current layer
            tasks = [
                self._execute_zone_with_hooks(stage, pipeline_data.get(stage))
                for stage in generation
            ]
            results = await asyncio.gather(*tasks)

            for stage_result, node in results:
                stage_results.append(stage_result)
                self._execution_tree_root.children.append(node)
                if stage_result.status is OrchestrationStatusEnum.BLOCKED:
                    self._final_status = OrchestrationStatusEnum.BLOCKED
                    break
            if self._final_status is OrchestrationStatusEnum.BLOCKED:
                break

        self._finalize_pipeline(stage_results)
        # log_data(logger.info,
        #     f"Pipeline {self._pipeline_execution_id} finished (status= {self._final_status})"
        # )
        logger.info(f"Pipeline {self._pipeline_execution_id} finished (status= {self._final_status})")
        return self.get_results()

    # ------------------------------------------------------------------------- #
    # Zone (stage) execution                                                     #
    # ------------------------------------------------------------------------- #
    async def _execute_zone(
        self,
        zone_name: str,
        data: Any,
        timeout: Optional[int] = None,
    ) -> Tuple[OrchestratorStageResultModel, ExecutionTreeNodeModel]:
        """
        Execute a single stage (zone):
        - Fetch its guards
        - Depending on its PipelineExecutionMode, run guards sequentially or concurrently
        - Aggregate outcomes into a stage_result and build an ExecutionTreeNodeModel
        """
        timeout = timeout or self._stage_timeout

        with tracer.start_as_current_span("execute_zone") as span:
            span.set_attribute("zone_name", zone_name)

            stage_exec = self._get_stage_exec(zone_name)
            stage_result = OrchestratorStageResultModel(
                stage_name=zone_name,
                status=OrchestrationStatusEnum.RUNNING,
                timestamp=datetime.now(UTC),
            )
            zone_node = ExecutionTreeNodeModel(
                node_type=ExecutionTreeNodeType.STAGE,
                name=zone_name,
                status=OrchestrationStatusEnum.RUNNING,
                start_time=datetime.now(UTC),
            )
            stage_exec.status = "running"
            stage_exec.start_time = datetime.now(UTC)

            try:
                guards = self._pipeline_definition.get_guards_for_zone(zone_name)
                mode = self._pipeline_definition.get_zone_execution_mode(zone_name)

                if mode is PipelineExecutionModeEnum.ASYNCHRONOUS:
                    # run all guards in parallel
                    guard_tasks = [
                        self._execute_guard_with_priority(g, data, zone_node, zone_name)
                        for g in guards
                    ]
                    results = await asyncio.wait_for(
                        asyncio.gather(*guard_tasks, return_exceptions=True),
                        timeout=timeout,
                    )
                    self._process_guard_results(results, stage_result, zone_node)
                    if stage_result.status is OrchestrationStatusEnum.RUNNING:
                        stage_result.status = OrchestrationStatusEnum.COMPLETED
                        stage_result.decision = "PASS"

                else:
                    # run guards one-by-one
                    for g in guards:
                        guard_exec = await asyncio.wait_for(
                            self._execute_guard_with_priority(g, data, zone_node, zone_name),
                            timeout=timeout,
                        )
                        stage_result.guard_results.append(guard_exec)
                        if guard_exec.final_decision == "BLOCK":
                            stage_result.status = OrchestrationStatusEnum.BLOCKED
                            stage_result.decision = "BLOCK"
                            break
                    else:
                        stage_result.status = OrchestrationStatusEnum.COMPLETED
                        stage_result.decision = "PASS"

            except asyncio.TimeoutError:
                # log_data(logger.error, f"Zone {zone_name} timed out after {timeout}")
                logger.error(f"Zone {zone_name} timed out after {timeout}")
                stage_result.status = OrchestrationStatusEnum.FAILED
                zone_node.status = OrchestrationStatusEnum.FAILED
            except Exception:
                # log_data(logger.exception, f"Zone {zone_name} execution error")
                logger.exception(f"Zone {zone_name} execution error")
                stage_result.status = OrchestrationStatusEnum.FAILED
                zone_node.status = OrchestrationStatusEnum.FAILED

            self._finalize_stage(stage_exec, stage_result, zone_node)
            return stage_result, zone_node

    # ------------------------------------------------------------------------- #
    # Guard execution                                                             #
    # ------------------------------------------------------------------------- #
    async def _execute_guard_with_priority(
        self,
        guard_cfg: GuardConfiguration,
        data: Any,
        zone_node: ExecutionTreeNodeModel,
        zone_name: str,
    ) -> GuardExecutionModel:
        """
        Executes all validators in a guard—either in parallel or sequentially—
        sorted by priority. Aggregates into the GuardExecutionModel.
        """
        async with self._sem:  # throttle across all zones
            with tracer.start_as_current_span("execute_guard") as span:
                span.set_attribute("guard_name", guard_cfg.name)

                start_time = datetime.now(UTC)
                guard_exec = self._get_guard_exec(zone_name, guard_cfg.name)
                guard_node = ExecutionTreeNodeModel(
                    node_type=ExecutionTreeNodeType.GUARD,
                    name=guard_cfg.name,
                    status=OrchestrationStatusEnum.RUNNING,
                    start_time=start_time,
                )
                zone_node.children.append(guard_node)

                guard_exec.execution_status = "in_progress"
                guard_exec.start_time = guard_exec.last_update = start_time

                # sort validators by priority
                validators = sorted(
                    guard_cfg.validators,
                    key=lambda v: _PRIORITY_RANK.get(
                        v.priority or ValidatorPriorityEnum.P3, 3
                    ),
                )
                vmodels = guard_exec.validators_execution_results

                # run validators per guard_cfg.execution_mode
                if guard_cfg.execution_mode is PipelineExecutionModeEnum.ASYNCHRONOUS:
                    # parallel
                    tasks = [
                        self._execute_with_retry(
                            self._runner.run_validator,
                            data=data,
                            validator_config=vconf,
                            pipeline_execution_model=self._pipeline_execution_model,
                            zone_name=zone_name,
                            guard_config=guard_cfg,
                            validator_exec_model=vmodel,
                        )
                        for vconf, vmodel in zip(validators, vmodels)
                    ]
                    raw = await asyncio.gather(*tasks, return_exceptions=True)
                    validator_results = []
                    for outcome, (vconf, vmodel) in zip(raw, zip(validators, vmodels)):
                        if isinstance(outcome, Exception):
                            # log_data(logger.exception, f"Validator {vconf.name} failed: {outcome}")
                            logger.exception(f"Validator {vconf.name} failed: {outcome}")
                            vmodel.execution_status = "error"
                            vmodel.error_message = str(outcome)
                            vmodel.end_time = vmodel.last_update = datetime.now(UTC)
                            validator_results.append(vmodel)
                        else:
                            validator_results.append(outcome)

                else:
                    # sequential
                    validator_results = []
                    for vconf, vmodel in zip(validators, vmodels):
                        try:
                            res = await self._execute_with_retry(
                                self._runner.run_validator,
                                data=data,
                                validator_config=vconf,
                                pipeline_execution_model=self._pipeline_execution_model,
                                zone_name=zone_name,
                                guard_config=guard_cfg,
                                validator_exec_model=vmodel,
                            )
                            validator_results.append(res)
                            # break early on P1 block
                            if (
                                vconf.priority is ValidatorPriorityEnum.P1
                                and res.response
                                and res.response.status
                                == ValidatorResponseStatusEnum.BLOCK
                            ):
                                break
                        except Exception as exc:
                            # log_data(logger.exception, f"Validator {vconf.name} failed: {exc}")
                            logger.exception(f"Validator {vconf.name} failed: {exc}")
                            vmodel.execution_status = "error"
                            vmodel.error_message = str(exc)
                            vmodel.end_time = vmodel.last_update = datetime.now(UTC)
                            validator_results.append(vmodel)
                            break

                # aggregate final guard decision
                self._aggregate_guard_results(guard_cfg, guard_exec, validator_results)

                guard_node.status = OrchestrationStatusEnum[guard_exec.execution_status.upper()]
                guard_node.end_time = datetime.now(UTC)
                EXECUTION_TIME.record(
                    (guard_node.end_time - start_time).total_seconds(),
                    attributes={"guard_name": guard_cfg.name},
                )
                duration = (guard_node.end_time - start_time).total_seconds()
                self.properties[f"Stage latency for zone {zone_name}"] = duration
                log_data(logger.info, 
                         f"Recording stage latency for zone {zone_name}: {duration}s",
                         self.properties)
                histogram_record(h_sdk_stage_latency, duration)
                histogram_record(EXECUTION_TIME, duration)
                log_data(logger.info, "✅ Emitted stage latency")
                
                return guard_exec

    # ------------------------------------------------------------------------- #
    # Zone wrapper to run hooks                                                   #
    # ------------------------------------------------------------------------- #
    async def _execute_zone_with_hooks(
        self, stage_name: str, data: Any
    ) -> Tuple[OrchestratorStageResultModel, ExecutionTreeNodeModel]:
        """
        Wrap `_execute_zone` with any registered pre- and post- hooks.
        """
        for hook in self._pre_hooks.get(stage_name, []):
            await hook(data)

        result, node = await self._execute_with_retry(self._execute_zone, stage_name, data)

        for hook in self._post_hooks.get(stage_name, []):
            await hook(result)

        return result, node

    # ------------------------------------------------------------------------- #
    # Aggregation & finalization helpers                                          #
    # ------------------------------------------------------------------------- #
    def _process_guard_results(
        self,
        results: List[Any],
        stage_result: OrchestratorStageResultModel,
        zone_node: ExecutionTreeNodeModel,
    ) -> None:
        """
        Normalize a list of guard executions or exceptions into the stage_result.
        """
        for outcome in results:
            if isinstance(outcome, Exception):
                # log_data(logger.error, f"Guard execution raised: {outcome}")
                logger.error(f"Guard execution raised: {outcome}")
                stage_result.status = OrchestrationStatusEnum.FAILED
                zone_node.status = OrchestrationStatusEnum.FAILED
            else:
                guard_exec: GuardExecutionModel = outcome
                stage_result.guard_results.append(guard_exec)
                if guard_exec.final_decision == "BLOCK":
                    stage_result.status = OrchestrationStatusEnum.BLOCKED
                    stage_result.decision = "BLOCK"
                    zone_node.status = OrchestrationStatusEnum.BLOCKED

    def _aggregate_guard_results(
        self,
        guard_cfg: GuardConfiguration,
        guard_exec: GuardExecutionModel,
        validator_results: List[ValidatorExecutionModel],
    ) -> None:
        """
        Combine individual ValidatorExecutionModels into a guard-level decision.
        Immediate P1 failure will block; otherwise use the configured strategy.
        """
        # P1 immediate block
        for res in validator_results:
            if (
                res.request.validator_config.priority is ValidatorPriorityEnum.P1
                and res.response
                and res.response.status != "pass"
            ):
                guard_exec.final_decision = "BLOCK"
                guard_exec.execution_status = "blocked"
                guard_exec.last_update = guard_exec.end_time = datetime.now(UTC)
                return

        # use aggregator strategy for remaining
        strat = guard_cfg.settings.response_aggregation_strategy if guard_cfg.settings else None
        decision = get_aggregator(strat).aggregate(validator_results, guard_cfg.settings)
        guard_exec.final_decision = decision
        guard_exec.execution_status = "blocked" if decision == "BLOCK" else "completed"
        guard_exec.last_update = guard_exec.end_time = datetime.now(UTC)

    # ------------------------------------------------------------------------- #
    # Internal lookup helpers                                                    #
    # ------------------------------------------------------------------------- #
    def _get_stage_exec(self, zone_name: str) -> PipelineStageExecutionResult:
        """
        Return the PipelineStageExecutionResult matching zone_name.
        """
        for stage in self._pipeline_execution_model.stages_execution_results:
            if stage.stage_name == zone_name:
                return stage
        raise ValueError(f"Stage execution not found for '{zone_name}'")

    def _get_guard_exec(self, zone_name: str, guard_name: str) -> GuardExecutionModel:
        """
        Return the GuardExecutionModel for a given zone_name + guard_name.
        """
        stage_exec = self._get_stage_exec(zone_name)
        for guard in stage_exec.guards_execution_results:
            if guard.guard_config.name == guard_name:
                return guard
        raise ValueError(f"Guard execution not found for '{guard_name}' in zone '{zone_name}'")

    # ------------------------------------------------------------------------- #
    # Finalization                                                               #
    # ------------------------------------------------------------------------- #
    def _finalize_stage(
        self,
        stage_exec: PipelineStageExecutionResult,
        stage_result: OrchestratorStageResultModel,
        zone_node: ExecutionTreeNodeModel,
    ) -> None:
        """
        Persist stage_result into the in-memory PipelineStageExecutionResult
        and update the ExecutionTreeNodeModel status/timestamps.
        """
        stage_exec.status = stage_result.status.value
        stage_exec.end_time = datetime.now(UTC)
        stage_exec.overall_decision = stage_result.decision

        zone_node.status = stage_result.status
        zone_node.end_time = datetime.now(UTC)

    def _finalize_pipeline(self, stage_results: List[OrchestratorStageResultModel]) -> None:
        """
        Mark the pipeline final status, update the model,
        fire-and-forget the record update, and drop the in-memory tree.
        """
        if self._final_status not in (
            OrchestrationStatusEnum.BLOCKED,
            OrchestrationStatusEnum.FAILED,
        ):
            self._final_status = OrchestrationStatusEnum.COMPLETED

        self._pipeline_execution_model.status = self._final_status.value
        self._pipeline_execution_model.last_update = datetime.now(UTC)

        self._orchestration_definition.stages = stage_results
        self._orchestration_definition.status = self._final_status
        self._orchestration_definition.end_time = datetime.now(UTC)

        if self._execution_tree_root:
            self._execution_tree_root.status = self._final_status
            self._execution_tree_root.end_time = datetime.now(UTC)

        # async update to storage
        asyncio.create_task(
            self._runner.update_pipeline_record(self._pipeline_execution_model)
        )

        # drop tree to free memory
        self._execution_tree_root = None

    async def complete_pipeline(self) -> None:
        """
        Final persist/update if the orchestrator was running or blocked.
        Call instead of re-running execute_pipeline().
        """
        stages = getattr(self._orchestration_definition, "stages", []) or []
        self._finalize_pipeline(stages)
        await self._runner.update_pipeline_record(self._pipeline_execution_model)

    # ------------------------------------------------------------------------- #
    # Public helpers                                                             #
    # ------------------------------------------------------------------------- #
    def get_results(self) -> Dict[str, Any]:
        """
        Return a summary dict:
        {
          "pipeline_execution_id": str,
          "final_status": "COMPLETED"|...,
          "stage_results_count": int,
          "execution_tree": { ... nested dict ... }
        }
        """
        return {
            "pipeline_execution_id": str(self._pipeline_execution_id),
            "final_status": self._final_status.value,
            "stage_results_count": len(self._orchestration_definition.stages),
            "execution_tree": self.get_execution_tree_dict(),
        }

    def get_execution_tree_dict(self) -> Optional[Dict[str, Any]]:
        """
        Serialize the ExecutionTreeNodeModel to a nested dict, or None if not running.
        """
        if not self._execution_tree_root:
            return None
        return self._node_to_dict(self._execution_tree_root)

    # ------------------------------------------------------------------------- #
    # Internal utility                                                            #
    # ------------------------------------------------------------------------- #
    def _node_to_dict(self, node: ExecutionTreeNodeModel) -> Dict[str, Any]:
        """
        Recursively convert an ExecutionTreeNodeModel to a JSON-friendly dict.
        """
        return {
            "node_id": str(node.node_id),
            "node_type": node.node_type.value,
            "name": node.name,
            "status": node.status.value,
            "start_time": node.start_time.isoformat() if node.start_time else None,
            "end_time": node.end_time.isoformat() if node.end_time else None,
            "results": node.results,
            "children": [self._node_to_dict(ch) for ch in node.children],
        }

    def _build_pipeline_graph(self) -> nx.DiGraph:
        """
        Construct a simple linear DAG of zones in defined order,
        annotating each node with its execution mode.
        """
        dag = nx.DiGraph()
        zones = self._pipeline_definition.get_zones()
        for idx, zone in enumerate(zones):
            dag.add_node(
                zone,
                execution_mode=self._pipeline_definition.get_zone_execution_mode(zone),
            )
            if idx > 0:
                dag.add_edge(zones[idx - 1], zone)
        return dag
