import functools
import asyncio
import logging
from typing import Callable, Any, Awaitable

from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.models.orchestrator import OrchestrationStatusEnum
from aitrust.monitoring.logs import logger

try:
    from colorama import Fore, Style
except ImportError:
    class _NoColor:
        def __getattr__(self, item):
            return ""
    Fore = Style = _NoColor()


def pipeline_zone(stage_name: str, intercept: str = "input"):
    """
    Decorator that executes guards for a specific pipeline stage using a PipelineOrchestrator.

    Args:
        stage_name (str): The name of the stage (e.g., "input", "retrieval", "output") to determine which guards to apply.
        intercept (str): Specifies what data to validate: "input", "output", or "both". Defaults to "input".

    Returns:
        Callable: Decorated function with validation.

    Raises:
        ValueError: If `intercept` is not "input", "output", or "both", or if `orchestrator` is missing/invalid.

    Example:
        @pipeline_zone(stage_name="input", intercept="input")
        async def process_input(query: str, orchestrator: PipelineOrchestrator) -> str:
            return query

        @pipeline_zone(stage_name="retrieval", intercept="output")
        async def process_retrieval(query: str, orchestrator: PipelineOrchestrator) -> list[str]:
            return ["doc1", "doc2"]

    Note:
        - Assumes the first positional argument is the input data for validation.
        - The orchestrator must be passed as a keyword argument 'orchestrator'.
    """
    if intercept not in ["input", "output", "both"]:
        raise ValueError("The 'intercept' parameter must be 'input', 'output', or 'both'")

    def decorator(func: Callable[..., Awaitable[Any]]):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            # Extract orchestrator from kwargs
            orchestrator = kwargs.get("orchestrator")
            if not isinstance(orchestrator, PipelineOrchestrator):
                logger.error(
                    "%s[pipeline_zone] Missing or invalid 'orchestrator' in kwargs%s",
                    Fore.RED, Style.RESET_ALL
                )
                raise ValueError("The 'orchestrator' keyword argument must be a PipelineOrchestrator instance")

            # Start the pipeline if not already started
            if orchestrator.get_pipeline_status() == OrchestrationStatusEnum.NOT_STARTED:
                logger.debug("%s[pipeline_zone] Starting pipeline...%s", Fore.CYAN, Style.RESET_ALL)
                await orchestrator.start_pipeline()

            # Check if pipeline is running
            if orchestrator.get_pipeline_status() != OrchestrationStatusEnum.RUNNING:
                logger.error(
                    "%s[pipeline_zone] Pipeline not running; status: %s%s",
                    Fore.RED, orchestrator.get_pipeline_status(), Style.RESET_ALL
                )
                return None

            # Extract input data (assuming first positional argument)
            input_data = args[0] if args else None

            # Validate input if required
            if intercept in ["input", "both"] and input_data is not None:
                logger.debug("[pipeline_zone] Validating input for stage '%s' with data=%s", stage_name, input_data)
                await orchestrator.execute_stage(stage_name, input_data)
                if orchestrator.get_pipeline_status() != OrchestrationStatusEnum.RUNNING:
                    logger.warning(
                        "%s[pipeline_zone] Input validation for stage '%s' blocked the pipeline%s",
                        Fore.YELLOW, stage_name, Style.RESET_ALL
                    )
                    return None

            # Execute the decorated function
            result = await func(*args, **kwargs)

            # Validate output if required
            if intercept in ["output", "both"] and result is not None:
                logger.debug("[pipeline_zone] Validating output for stage '%s' with data=%s", stage_name, result)
                await orchestrator.execute_stage(stage_name, result)
                if orchestrator.get_pipeline_status() != OrchestrationStatusEnum.RUNNING:
                    logger.warning(
                        "%s[pipeline_zone] Output validation for stage '%s' blocked the pipeline%s",
                        Fore.YELLOW, stage_name, Style.RESET_ALL
                    )
                    return None

            # Log completion
            logger.info(
                "%s[pipeline_zone] Stage '%s' completed for pipeline '%s'%s",
                Fore.GREEN, stage_name, orchestrator._pipeline_execution_id, Style.RESET_ALL
            )
            return result

        return wrapper
    return decorator