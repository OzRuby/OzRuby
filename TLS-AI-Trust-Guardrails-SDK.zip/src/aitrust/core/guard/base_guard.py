from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from aitrust.models.guard import GuardConfiguration, GuardExecutionModel

class BaseGuard(ABC):
    """
    Abstract base class for guard implementations.

    Implementations must provide logic for executing guard checks and returning a structured result
    that indicates whether the overall pipeline execution should be blocked.
    
    Detailed logging should be implemented in concrete subclasses to trace each step of the guard execution.
    """

    @abstractmethod
    async def execute(self, guard_config: "GuardConfiguration", data: Any) -> "GuardExecutionModel":
        """
        Executes the guard logic.

        Args:
            guard_config (GuardConfiguration): The configuration details of the guard.
            data (Any): The input data used for validation.

        Returns:
            GuardExecutionModel: The result of the guard execution, indicating whether to block.
        """
        raise NotImplementedError("Subclasses must implement the execute method.")

    @abstractmethod
    def get_name(self) -> str:
        """
        Returns the unique name of the guard.

        Returns:
            str: The name identifier of the guard.
        """
        raise NotImplementedError("Subclasses must implement the get_name method.")