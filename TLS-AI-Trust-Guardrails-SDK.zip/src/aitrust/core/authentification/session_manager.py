"""aitrust\core\authentification\session_manager.py

Manages authentication sessions for the SDK, supporting API Key and OAuth2.
"""

from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import httpx
import json

from aitrust.models.authentification import AuthenticationDefinitionModel, AuthMethodEnum
from aitrust.monitoring.logs import logger
from aitrust.common.exceptions import SDKServiceError, SDKInternalError



class SessionManager:
    """
    Manages authentication sessions for the SDK, supporting API key and OAuth2 methods.

    Handles retrieval of authentication headers, OAuth2 token management (refresh and caching),
    and session lifecycle for secure communication with the GenAI Trust Service.
    """

    def __init__(self, auth_def: AuthenticationDefinitionModel):
        """
        Initializes the session manager with the provided authentication definition.

        Args:
            auth_def (AuthenticationDefinitionModel):
                The authentication configuration model, defining the authentication method and credentials.
        """
        self.auth_def = auth_def
        self.token_cache: Optional[str] = None
        self.token_expiry: Optional[datetime] = None
        self._oauth_client = httpx.AsyncClient()
        logger.debug(f"SessionManager initialized with auth definition: {auth_def}")

    async def get_auth_header(self) -> Dict[str, str]:
        """
        Returns the HTTP authentication header based on the configured authentication method.

        This method determines the appropriate authentication header based on the `auth_method`
        specified in the AuthenticationDefinitionModel. It supports API Key and OAuth2 methods,
        as well as 'NONE' for cases where no authentication is required.

        Returns:
            Dict[str, str]: A dictionary containing the authentication header (e.g., {'Authorization': 'Bearer <token>'})
                           or an empty dictionary if no authentication is configured or needed.
        """
        auth_method = self.auth_def.method
        logger.debug(f"Retrieving authentication header for method: {auth_method.value}")

        if auth_method == AuthMethodEnum.NONE:
            logger.debug("No authentication method specified; returning empty header.")
            return {}
        elif auth_method == AuthMethodEnum.API_KEY:
            if self.auth_def.api_key:
                header = {"Authorization": f"Bearer {self.auth_def.api_key.get_secret_value()}"}
                logger.debug("Using API Key for authentication. Header: %s", header)
                return header
            else:
                logger.warning("API Key method selected but no API key is configured.")
                return {}
        elif auth_method == AuthMethodEnum.OAUTH2:
            try:
                token = await self._ensure_oauth_token()
                header = {"Authorization": f"Bearer {token}"}
                logger.debug("Using OAuth2 token for authentication. Header: %s", header)
                return header
            except Exception as e:
                logger.error(f"Error retrieving OAuth2 token: {e}", exc_info=True)
                return {}
        else:
            logger.warning(f"Unrecognized authentication method: {auth_method.value}")
            return {}

    async def _ensure_oauth_token(self) -> str:
        """
        Ensures that a valid OAuth2 token is available, using cached token if possible, otherwise refreshes.

        This method checks for a cached OAuth2 token and its expiry. If a valid cached token is found,
        it is returned directly. Otherwise, it triggers a token refresh operation using `_refresh_oauth_token`.

        Returns:
            str: The valid OAuth2 access token.

        Raises:
            Exception: If token refresh fails.
        """
        if self.token_cache and self.token_expiry and self.token_expiry > datetime.utcnow():
            logger.debug(f"Using cached OAuth2 token, expires at {self.token_expiry.isoformat()}")
            return self.token_cache

        logger.info("Cached OAuth2 token missing or expired; initiating token refresh.")
        try:
            new_token_data = await self._refresh_oauth_token()
            new_token = new_token_data.get("access_token")
            expires_in = new_token_data.get("expires_in")
            logger.debug(f"Token refresh response: {new_token_data}")
            if not new_token or not expires_in:
                raise ValueError(f"Token refresh response missing required fields: {new_token_data}")
            self.token_cache = new_token
            self.token_expiry = datetime.utcnow() + timedelta(seconds=int(expires_in))
            logger.info(f"OAuth2 token refreshed successfully; new expiry: {self.token_expiry.isoformat()}")
            return self.token_cache
        except Exception as e:
            logger.error(f"OAuth2 token refresh failed: {e}", exc_info=True)
            self.token_cache = None
            self.token_expiry = None
            raise Exception("Failed to refresh OAuth2 token.") from e

    async def _refresh_oauth_token(self) -> Dict[str, Any]:
        """
        Refreshes the OAuth2 token using the client credentials grant flow.

        This method performs an HTTP POST request to the OAuth2 token endpoint URL,
        using client credentials to obtain a new access token.

        Returns:
            Dict[str, Any]: A dictionary containing the JSON response from the token endpoint,
                           typically including the new access token and its expiry.

        Raises:
            SDKServiceError: If the token refresh request fails due to HTTP errors or invalid JSON response.
            SDKInternalError: For unexpected exceptions during the token refresh process.
        """
        token_url = self.auth_def.oauth_token_url
        client_id = self.auth_def.oauth_client_id
        client_secret = self.auth_def.oauth_client_secret

        if not token_url or not client_id or not client_secret:
            error_msg = "Incomplete OAuth2 configuration: token_url, client_id, or client_secret missing."
            logger.error(error_msg)
            raise ValueError(error_msg)

        logger.debug(f"Requesting OAuth2 token from: {token_url}")
        try:
            data = {"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret}
            response = await self._oauth_client.post(token_url, data=data)
            response.raise_for_status()  # Raise HTTPError for bad status codes
            token_response = response.json()
            logger.debug(f"Received OAuth2 token response: {token_response}")
            return token_response
        except httpx.HTTPError as e:
            logger.error(f"Token refresh request failed: {e}", exc_info=True)
            error_details = {}
            try:
                error_details = e.response.json()
            except json.JSONDecodeError:
                error_details = {"message": "Non-JSON error response", "details": [str(e)]}
            raise SDKServiceError(
                f"OAuth2 token refresh request failed: HTTP error {e}", http_status_code=e.response.status_code, details=error_details
            ) from e
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error during token refresh: {e}", exc_info=True)
            raise SDKServiceError(f"JSON decode error during token refresh: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error during token refresh: {e}", exc_info=True)
            raise SDKInternalError(f"Unexpected error during token refresh: {e}") from e

    async def close_session(self) -> None:
        """Closes the OAuth2 client session."""
        if self._oauth_client:
            await self._oauth_client.aclose()
            logger.debug("OAuth2 client session closed.")

    async def __aenter__(self):
        """Asynchronous context manager enter."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Asynchronous context manager exit."""
        await self.close_session()