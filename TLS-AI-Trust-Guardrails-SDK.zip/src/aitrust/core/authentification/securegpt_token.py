import os
from datetime import UTC, datetime
from typing import Tuple
import requests
from pydantic import SecretStr
from aitrust.common.settings_config import SETTINGS_CONFIG
import logging

logger = logging.getLogger(__name__)

# Cache file for the token
TOKEN_CACHE_FILE = ".tk"
ONE_ACCOUNT = SETTINGS_CONFIG.settings.dependencies.one_account

def read_local_token(retry: bool = False) -> Tuple[str, datetime]:
    """
    Read the cached token and its expiration from a local file.

    Args:
        retry (bool): If True, forces a new token fetch by returning None.

    Returns:
        Tuple[str, datetime]: The cached token and its expiration datetime, or (None, None) if unavailable.
    """
    if retry:
        return None, None

    try:
        if os.path.exists(TOKEN_CACHE_FILE):
            with open(TOKEN_CACHE_FILE, "r") as f:
                token_form = f.read().strip()
                if len(token_form) > 10:  # Basic validation as in SecureGPT
                    access_token, date_expiration = token_form.split("\t")
                    format_str = "%Y-%m-%dT%H:%M:%S.%f"
                    expiration = datetime.strptime(date_expiration, format_str)
                    return access_token, expiration
                else:
                    logger.info("Bad oauth2 token format in cache file")
                    return None, None
        else:
            logger.info("Token cache file not found")
            return None, None
    except Exception as e:
        logger.info(f"Cannot read oauth2 token from cache: {str(e)}")
        return None, None

def write_local_token(token: str, expiration: datetime) -> None:
    """
    Write the token and its expiration to a local cache file.

    Args:
        token (str): The OAuth2 access token.
        expiration (datetime): The expiration datetime of the token.
    """
    try:
        with open(TOKEN_CACHE_FILE, "w") as f:
            expiration_str = expiration.strftime("%Y-%m-%dT%H:%M:%S.%f")
            f.write(f"{token}\t{expiration_str}")
            logger.info("Successfully wrote oauth2 token to cache file.")
    except Exception as e:
        logger.error(f"Failed to write token to cache: {str(e)}")
        raise RuntimeError(f"Failed to write token to cache: {str(e)}")

def generate_securegpt_token(retry: bool = False) -> SecretStr:
    """
    Generate or retrieve a cached securegpt_token using the same technique as SecureGPT.

    Args:
        retry (bool): If True, forces generation of a new token even if a valid one is cached.

    Returns:
        SecretStr: The generated or cached token as a SecretStr object.

    Raises:
        RuntimeError: If token generation fails.
    """
    # Check for cached token first
    access_token, token_expiration = read_local_token(retry)
    if access_token and token_expiration:
        delta = datetime.now(UTC).replace(tzinfo=None) - token_expiration
        if delta.total_seconds() < 300:
            logger.info(f"Using cached oauth2 token: [token={access_token[:19]}...]")
            return SecretStr(access_token)

    # Token is missing, expired, or retry is forced; generate a new one
    one_login_base_url = ONE_ACCOUNT.connexion.one_login_base_url.get_secret_value()
    one_login_url = ONE_ACCOUNT.connexion.one_login_url.get_secret_value()

    payload = {
        "client_id": ONE_ACCOUNT.connexion.client_id.get_secret_value(),
        "client_secret": ONE_ACCOUNT.connexion.client_secret.get_secret_value(),
        "scope": ONE_ACCOUNT.connexion.scope,
        "grant_type": "client_credentials",
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    try:
        response = requests.post(
            f"{one_login_base_url}{one_login_url}",
            data=payload,
            headers=headers,
            verify=SETTINGS_CONFIG.settings.ssl_enabled
        )
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if not access_token:
            #raise ValueError("No access_token in response")
            return None

        token_expiration = datetime.now(UTC)
        write_local_token(access_token, token_expiration)
        logger.info(f"Generated new oauth2 token: [token={access_token[:19]}...]")

        return SecretStr(access_token)
    except Exception as e:
        logger.error(f"Failed to generate securegpt_token: {str(e)}")
        raise RuntimeError(f"Failed to generate securegpt_token: {str(e)}")