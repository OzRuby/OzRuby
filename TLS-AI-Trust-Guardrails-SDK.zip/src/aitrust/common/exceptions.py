class ConfigNotFound(Exception):
    pass

class ConfigBadFormat(Exception):
    pass

class SDKServiceError(Exception):
    """Generic error indicating a service-related issue."""
    def __init__(self, message: str, http_status_code=None, details=None):
        super().__init__(message)
        self.http_status_code = http_status_code
        self.details = details


class SDKValidationError(Exception):
    pass

class SDKInternalError(Exception):
    pass