"""
http.py
=======

Centralized HTTP utilities for aiohttp-based networking:

Responsibilities:
  * **Shared session lifecycle**
      - Singleton aiohttp.ClientSession via async LRU cache
      - Configurable SSL/TLS context and timeouts
      - Detailed request tracing (start/end hooks)
  * **Resilient request execution**
      - Tenacity-powered retries on network errors & 5xx
      - Exponential backoff with jitter
  * **Graceful cleanup**n      - Close shared session cleanly on shutdown
  * **Content negotiation**
      - Automatically parse JSON or raw bytes based on Content-Type
  * **JSON serialization**
      - Serializer for datetime, date, and UUID for model dumping
"""

import asyncio
import ssl
from datetime import datetime, date
from typing import Any, Optional

import certifi

from aiohttp import (
    ClientSession,
    ClientTimeout,
    DummyCookieJar,
    TCPConnector,
    AsyncResolver,
    TraceConfig,
)

from tenacity import (
    AsyncRetrying,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)

from aitrust.common.settings_config import SETTINGS_CONFIG
from aitrust.common.cache import lru_acache
from aitrust.monitoring.logs import logger


# ---------------------------------------------------------------------------- #
# Globals                                                                      #
# ---------------------------------------------------------------------------- #
_cookie_jar: Optional[DummyCookieJar] = None
_session: Optional[ClientSession] = None

# --------------------------------------------------------------------------- #
# Extract configuration from Pydantic model                                  #
# --------------------------------------------------------------------------- #
# Top-level SSL flag
_ssl_enabled: bool = SETTINGS_CONFIG.settings.ssl_enabled

# Nested validator_settings may be None or dict
_validator_cfg: dict = SETTINGS_CONFIG.settings.validator_settings or {}

# HTTP parameters with fallbacks
_timeout_seconds: int = _validator_cfg.get("http_timeout_seconds", 15)
_max_http_retries: int = _validator_cfg.get("max_http_retries", 3)
_retry_backoff: float = _validator_cfg.get("retry_backoff_factor", 0.5)
_http_pool_limit: int = _validator_cfg.get("http_pool_limit_per_host", 100)

# --------------------------------------------------------------------------- #
# Trace hooks for request timing                                             #
# --------------------------------------------------------------------------- #
async def _on_request_start(session: ClientSession, trace_ctx: Any, params: Any) -> None:
    trace_ctx.start = asyncio.get_event_loop().time()
    logger.debug(f"Starting {params.method} {params.url}")

async def _on_request_end(session: ClientSession, trace_ctx: Any, params: Any) -> None:
    elapsed = asyncio.get_event_loop().time() - trace_ctx.start
    logger.debug(f"Completed {params.method} {params.url} in {elapsed:.3f}s")

trace_config = TraceConfig()
trace_config.on_request_start.append(_on_request_start)
trace_config.on_request_end.append(_on_request_end)

# --------------------------------------------------------------------------- #
# Shared aiohttp.ClientSession via async LRU cache                            #
# --------------------------------------------------------------------------- #
async def _aiohttp_cookie_jar() -> DummyCookieJar:
    global _cookie_jar
    if _cookie_jar is None:
        _cookie_jar = DummyCookieJar()
    return _cookie_jar

@lru_acache(maxsize=1)
async def aiohttp_session() -> ClientSession:
    ssl_ctx = ssl.create_default_context(cafile=certifi.where()) if _ssl_enabled else False
    timeout = ClientTimeout(total=_timeout_seconds)
    session = ClientSession(
        auto_decompress=False,
        cookie_jar=await _aiohttp_cookie_jar(),
        timeout=timeout,
        connector=TCPConnector(ssl=ssl_ctx, limit_per_host=_http_pool_limit),
        trace_configs=[trace_config],
    )
    logger.debug(
        "Created shared aiohttp ClientSession(timeout=%ss pool_limit=%s ssl=%s)",
        _timeout_seconds,
        _http_pool_limit,
        _ssl_enabled,
    )
    return session

async def close_http_session() -> None:
    session = await aiohttp_session()
    if not session.closed:
        await session.close()
        logger.debug("Shared aiohttp ClientSession closed")

# --------------------------------------------------------------------------- #
# Tenacity-based resilient HTTP requests                                      #
# --------------------------------------------------------------------------- #
async def request_with_retry(
    method: str, url: str, **kwargs: Any
) -> Any:
    def _should_retry(exc: Exception) -> bool:
        from aiohttp import ClientConnectionError, ClientResponseError
        return isinstance(exc, ClientConnectionError) or (
            isinstance(exc, ClientResponseError) and exc.status >= 500
        )

    async for attempt in AsyncRetrying(
        retry=retry_if_exception(_should_retry),
        wait=wait_exponential_jitter(
            initial=_retry_backoff,
            max=_retry_backoff * 8,
        ),
        stop=stop_after_attempt(_max_http_retries),
        reraise=True,
    ):
        with attempt:
            session = await aiohttp_session()
            async with session.request(method.upper(), url, **kwargs) as resp:
                resp.raise_for_status()
                ct = resp.headers.get("content-type", "")
                if ct.startswith("application/json"):
                    return await resp.json()
                return await resp.read()

# --------------------------------------------------------------------------- #
# JSON serializer                                                             #
# --------------------------------------------------------------------------- #
def json_serializer(obj: Any) -> str:
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    try:
        import uuid
        if isinstance(obj, uuid.UUID):
            return str(obj)
    except ImportError:
        pass
    raise TypeError(f"Type {type(obj)} not serializable")