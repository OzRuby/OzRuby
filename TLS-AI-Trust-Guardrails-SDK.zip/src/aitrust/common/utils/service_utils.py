"""
Module: service_utils.py

This module provides utility functions for the service component. In particular,
it defines a function to update the pipeline execution document by sending an HTTP
POST request to a specified service endpoint. It uses a custom JSON encoder to
handle datetime and UUID types.
"""

from os import environ
import httpx
import json
from datetime import datetime, date
import uuid

from aitrust.models.pipeline import PipelineExecutionModel
from aitrust.monitoring.logs import logger

def default_env():
    """Get default environment

    Returns:
        str: value of ENV environ
    """
    if environ.get("ENV"):
        return environ["ENV"]
    else:
        return "dev"
    
def custom_encoder(obj):
    """
    Custom encoder function for JSON serialization.

    Args:
        obj: The object to encode.

    Returns:
        A serializable representation of the object (ISO format for dates and UUID strings).

    Raises:
        TypeError: If the object type is not serializable.
    """
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, uuid.UUID):
        return str(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

async def update_pipeline_document_in_service(service_base_url: str, pipeline_execution_model: PipelineExecutionModel) -> None:
    """
    Updates the pipeline execution document by sending a POST request to the service.
    
    For demo purposes, this function logs warnings if the update response is not 200
    but does not raise an exception.
    
    Args:
        service_base_url (str): The service base URL.
        pipeline_execution_model (PipelineExecutionModel): The pipeline execution model to update.
    """
    url = f"{service_base_url}/pipeline/{pipeline_execution_model.pipeline_execution_id}"
    doc_data = pipeline_execution_model.model_dump(exclude_none=True)
    try:
        serialized_doc = json.loads(json.dumps(doc_data, default=custom_encoder))
    except Exception as e:
        logger.error("Error serializing pipeline document: %s", e, exc_info=True)
        serialized_doc = doc_data
    logger.debug("Updating pipeline document at %s with payload: %s", url, serialized_doc)
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(url, json=serialized_doc)
            if resp.status_code != 200:
                logger.warning("Pipeline document update returned status %s: %s", resp.status_code, resp.text)
            else:
                logger.debug("Pipeline document updated successfully.")
    except Exception as e:
        logger.error("Error updating pipeline document: %s", e, exc_info=True)
        logger.warning("Simulating successful update for demo purposes.")