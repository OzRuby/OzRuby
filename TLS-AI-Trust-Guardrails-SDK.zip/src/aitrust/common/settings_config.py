from typing import Optional
from pathlib import Path
from aitrust.models.root import MainConfigModel
from os import environ
import yaml
import logging
from pydantic import ValidationError

logger = logging.getLogger(__name__)

class ConfigNotFound(Exception):
    """Exception raised when a configuration file is not found."""
    pass

def load_global_config(config_file_path: Optional[Path] = None) -> MainConfigModel:
    """Load the global configuration from environment variables or a YAML file."""
    config_env = "AITRUST_CONFIG_JSON"
    if config_file_path is None:
        base_path = Path(__file__).resolve().parent.parent.parent.parent  # Navigate to project root
        config_file = base_path / f"configs/settings.{default_env()}.yaml"
    else:
        config_file = config_file_path

    logger.info(f"Loading configuration for environment: {default_env()}")

    # Check if configuration is provided via environment variable
    if config_env in environ:
        logger.info("Attempting to load configuration from environment variable AITRUST_CONFIG_JSON")
        try:
            config = MainConfigModel.model_validate_json(environ[config_env])
            logger.info("Successfully loaded configuration from environment variable")
            return config
        except ValidationError as e:
            logger.error(f"Validation error in environment variable config: {e}")
            raise
        except Exception as e:
            logger.error(f"Failed to load config from environment variable: {str(e)}")
            raise

    # Check if config file exists
    logger.info(f"Looking for configuration file: {config_file}")
    if not config_file.exists():
        logger.error(f"Configuration file not found: {config_file}")
        raise ConfigNotFound(f"Cannot find settings file {config_file}")

    # Load and validate YAML file
    try:
        with open(config_file, "r") as f:
            config_data = yaml.safe_load(f)
        config = MainConfigModel.model_validate(config_data)
        logger.info("Successfully loaded configuration from YAML file")
        return config
    except ValidationError as e:
        logger.error(f"Validation error in YAML config: {e}")
        raise
    except Exception as e:
        logger.error(f"Failed to load YAML config: {str(e)}")
        raise

def default_env():
    return environ.get("ENV", "dev")

SETTINGS_CONFIG = load_global_config()