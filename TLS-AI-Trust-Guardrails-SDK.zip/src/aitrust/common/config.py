import os
import yaml
from pathlib import Path
from typing import Optional
from aitrust.models.config import SDKConfigModel
from aitrust.monitoring.logs import logger

class ConfigLoader:
    """
    Loads and validates the SDK configuration from a YAML file.

    In production, the configuration file path is resolved in this order:
      1. Environment variable 'GUARDCONFIG_PATH' if set.
      2. A settings file (e.g., "configs/settings.dev.yaml") containing 'GUARDCONFIG_PATH'.
    In tests, if `direct_config_path` is provided, it is used directly as the config file.

    Attributes:
        settings_path (Path): Path to the settings YAML file (defaults to "configs/settings.dev.yaml").
        direct_config_path (Optional[Path]): If provided, this path is used directly as the config file.
        guard_config_path (Path | None): Resolved path to the main configuration file.
        config (SDKConfigModel | None): Loaded and validated configuration model.

    Raises:
        ValueError: If the configuration file is invalid, empty, or missing required keys.
        FileNotFoundError: If the settings or configuration file cannot be found.
    """

    def __init__(self, settings_path: Optional[Path] = None, direct_config_path: Optional[Path] = None) -> None:
        """
        Initialize the ConfigLoader with an optional settings file path and direct config path.

        Args:
            settings_path (Path, optional): Path to the settings YAML file. Defaults to "configs/settings.dev.yaml".
            direct_config_path (Optional[Path]): If provided, this path is used directly as the config file.
        """
        self.settings_path = settings_path or Path("configs/settings.dev.yaml")
        self.direct_config_path = direct_config_path
        self.guard_config_path: Optional[Path] = None
        self.config: Optional[SDKConfigModel] = None
        logger.debug(f"Initialized ConfigLoader with settings_path={self.settings_path}, direct_config_path={self.direct_config_path}")

    def _resolve_guard_config_path(self) -> Path:
        """
        Resolves the path to the main configuration file.

        Returns:
            Path: Resolved path to the configuration file.

        Raises:
            ValueError: If the configuration file path cannot be resolved.
            FileNotFoundError: If required files are missing.
        """
        # Use direct_config_path if provided (for tests)
        if self.direct_config_path is not None:
            logger.debug(f"Using direct config path: {self.direct_config_path}")
            return self.direct_config_path

        # Production logic: Check environment variable first
        env_path = os.getenv("GUARDCONFIG_PATH")
        if env_path:
            logger.debug(f"Using 'GUARDCONFIG_PATH' from environment: {env_path}")
            return Path(env_path)

        # Fallback to settings file
        logger.debug(f"No direct path or env var; reading settings file: {self.settings_path}")
        try:
            with open(self.settings_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            if not data or "GUARDCONFIG_PATH" not in data:
                raise ValueError(f"Settings file {self.settings_path} is missing 'GUARDCONFIG_PATH' key")
            resolved_path_str = data["GUARDCONFIG_PATH"]
            config_base_dir = Path(__file__).parent.parent.parent.parent  # Project root
            resolved_path = config_base_dir / resolved_path_str
            logger.debug(f"Resolved config path from settings: {resolved_path}")
            return resolved_path
        except FileNotFoundError as e:
            logger.error(f"Settings file not found: {self.settings_path}", exc_info=True)
            raise FileNotFoundError(f"Settings file not found: {self.settings_path}") from e

    def load_config(self) -> SDKConfigModel:
        """
        Loads and validates the SDK configuration from the resolved YAML file.

        Returns:
            SDKConfigModel: The validated configuration model instance.

        Raises:
            FileNotFoundError: If the configuration file cannot be found.
            ValueError: If the YAML is invalid or fails validation.
        """
        if self.config is None:
            self.guard_config_path = self._resolve_guard_config_path()
            logger.info(f"Loading config from: {self.guard_config_path}")
            try:
                with open(self.guard_config_path, "r", encoding="utf-8") as f:
                    config_dict = yaml.safe_load(f)
                if not config_dict:
                    raise ValueError(f"Config file is empty: {self.guard_config_path}")
                self.config = SDKConfigModel.model_validate(config_dict)
                logger.info("Configuration loaded and validated successfully")
            except FileNotFoundError as e:
                logger.error(f"Config file not found: {self.guard_config_path}", exc_info=True)
                raise FileNotFoundError(f"Config file not found: {self.guard_config_path}") from e
            except yaml.YAMLError as e:
                logger.error(f"Invalid YAML in config: {e}", exc_info=True)
                raise ValueError(f"Error parsing YAML: {e}") from e
            except ValueError as e:
                logger.error(f"Config validation failed: {e}", exc_info=True)
                raise
        return self.config

    def get_config(self) -> SDKConfigModel:
        """
        Retrieves the current configuration, loading it if necessary.

        Returns:
            SDKConfigModel: The active configuration model instance.
        """
        if self.config is None:
            logger.debug("Config not loaded; loading now")
            self.load_config()
        return self.config