from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict, model_serializer


class OrchestrationStatusEnum(str, Enum):
    """
    Enumeration of possible statuses for the orchestration process.
    """
    NOT_STARTED = "not_started"
    RUNNING = "running"
    COMPLETED = "completed"
    BLOCKED = "blocked"
    FAILED = "failed"


class OrchestratorExecutionContextModel(BaseModel):
    """
    Contextual metadata for pipeline execution.
    """
    model_config = ConfigDict(from_attributes=True, arbitrary_types_allowed=True)

    request_id: str = Field(..., description="Unique identifier for the pipeline request.")
    conversation_id: Optional[UUID] = Field(None, description="Conversation identifier.")
    project_id: Optional[str] = Field(None, description="Project identifier.")
    user_id: Optional[str] = Field(None, description="User or application identifier.")
    session_id: Optional[str] = Field(None, description="Session or correlation identifier.")
    custom_data: Dict[str, Any] = Field(default_factory=dict, description="Additional custom data.")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp.")


class GuardResult(BaseModel):
    """
    Result of a single guard execution within a stage, as stored in the OrchestratorModel.
    This is a lightweight version that avoids referencing the entire pipeline or validators.
    """
    model_config = ConfigDict(from_attributes=True, arbitrary_types_allowed=True)

    guard_name: str = Field(..., description="Name of the guard.")
    decision: str = Field(..., description="Guard decision (e.g., 'PASS', 'BLOCK').")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional guard details.")


class OrchestratorStageResultModel(BaseModel):
    """
    Result of a single pipeline stage execution in the orchestrator doc.
    """
    model_config = ConfigDict(from_attributes=True, arbitrary_types_allowed=True)

    stage_name: str = Field(..., description="Stage name.")
    status: OrchestrationStatusEnum = Field(default=OrchestrationStatusEnum.NOT_STARTED, description="Stage status.")
    guard_results: List[GuardResult] = Field(default_factory=list, description="Guard results.")
    decision: Optional[str] = Field(None, description="Stage decision (e.g., 'PASS', 'BLOCK').")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of the result.")


class ExecutionTreeNodeType(str, Enum):
    """
    Enumeration of node types in the execution tree.
    """
    PIPELINE = "pipeline"
    STAGE = "stage"
    GUARD = "guard"


class ExecutionTreeNodeModel(BaseModel):
    """
    Node in the hierarchical execution tree, used for visualization in the orchestrator doc.
    """
    model_config = ConfigDict(
        from_attributes=True,
        arbitrary_types_allowed=True,
    )

    node_id: UUID = Field(default_factory=uuid4)
    node_type: str  # e.g. "stage", "guard", "pipeline"
    name: str
    status: str     # e.g. "running", "blocked", "completed"
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    results: Dict[str, Any] = Field(default_factory=dict)
    children: List["ExecutionTreeNodeModel"] = Field(default_factory=list)

    def to_dict_no_cycles(self, visited=None) -> Dict[str, Any]:
        """
        Custom safe traversal to avoid infinite recursion or cycles.
        """
        if visited is None:
            visited = set()
        if self.node_id in visited:
            return {
                "node_id": str(self.node_id),
                "warning": "Cycle detected - truncated"
            }
        visited.add(self.node_id)

        return {
            "node_id": str(self.node_id),
            "node_type": self.node_type,
            "name": self.name,
            "status": self.status,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "results": self.results,
            "children": [child.to_dict_no_cycles(visited) for child in self.children],
        }

    @model_serializer
    def serialize_model(self) -> Dict[str, Any]:
        """
        Pydantic calls this during model_dump. We override to prevent recursion in nested children.
        """
        return self.to_dict_no_cycles()


class OrchestratorModel(BaseModel):
    """
    Overall orchestration state + execution tree for a pipeline.
    """
    model_config = ConfigDict(from_attributes=True, arbitrary_types_allowed=True)

    pipeline_execution_id: UUID = Field(
        default_factory=uuid4, 
        description="Unique identifier for the pipeline execution."
    )
    conversation_id: Optional[UUID] = Field(None, description="Conversation ID.")
    context: OrchestratorExecutionContextModel = Field(..., description="Execution context model.")
    stages: List[OrchestratorStageResultModel] = Field(default_factory=list, description="Stage results.")
    status: str = Field("not_started", description="Pipeline status.")
    start_time: datetime = Field(default_factory=datetime.utcnow, description="Start timestamp.")
    end_time: Optional[datetime] = Field(None, description="End timestamp.")
    execution_tree: Optional[ExecutionTreeNodeModel] = Field(None, description="Execution tree root node.")

    @model_serializer
    def serialize_model(self) -> Dict[str, Any]:
        """
        Custom serializer that prevents recursion in execution_tree.
        """
        data: Dict[str, Any] = {}
        data["pipeline_execution_id"] = str(self.pipeline_execution_id)
        data["conversation_id"] = str(self.conversation_id) if self.conversation_id else None
        data["context"] = self.context
        # We rely on default Pydantic behavior for self.stages
        # (each OrchestratorStageResultModel is small and references only GuardResult).
        data["stages"] = self.stages
        data["status"] = self.status
        data["start_time"] = self.start_time.isoformat() if self.start_time else None
        data["end_time"] = self.end_time.isoformat() if self.end_time else None

        if self.execution_tree:
            data["execution_tree"] = self.execution_tree.to_dict_no_cycles()
        else:
            data["execution_tree"] = None
        return data
