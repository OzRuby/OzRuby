from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict
from .version import VersionModel
from .infos import InformationsModel
from .monitoring import MonitoringModel
from .settings import SettingsModel
from .privacy import PrivacyPolicyModel
from .security import SecurityPolicyDefinitionModel

class MainConfigModel(BaseSettings):
    """
    Main configuration model for the AI-Trust SDK.

    Assembles all configuration models including version, informations, monitoring, settings, privacy, and security.
    """
    model_config = SettingsConfigDict(
        env_ignore_empty=True,
        env_nested_delimiter="__",
        env_prefix="AITRUST_"
    )

    version: VersionModel
    informations: InformationsModel
    monitoring: MonitoringModel
    settings: SettingsModel
    privacy: PrivacyPolicyModel
    security: SecurityPolicyDefinitionModel

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ):
        return (
            env_settings,          # Prioritize environment variables
            dotenv_settings,       # Then .env files
            file_secret_settings,  # Then secret files
            init_settings,         # Finally, defaults from initialization
        )