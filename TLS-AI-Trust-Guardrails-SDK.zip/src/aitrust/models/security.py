from enum import Enum
from typing import Optional, Dict
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, SecretStr, ConfigDict

class SecurityPolicyEnum(str, Enum):
    STRICT = "strict"
    MODERATE = "moderate"
    LENIENT = "lenient"

class EncryptionAlgorithmEnum(str, Enum):
    AES256 = "aes256"
    RSA2048 = "rsa2048"
    NONE = "none"

class SecurityPolicyDefinitionModel(BaseModel):
    """
    Defines a security policy for the SDK.

    Specifies the security level, encryption algorithm, and whether TLS enforcement is required.
    """
    model_config = ConfigDict(from_attributes=True)
    policy_id: UUID = Field(default_factory=uuid4, frozen=True, description="Unique identifier for the security policy.")
    policy_level: SecurityPolicyEnum = Field(default=SecurityPolicyEnum.MODERATE, description="The security policy level.")
    encryption_algorithm: EncryptionAlgorithmEnum = Field(default=EncryptionAlgorithmEnum.NONE, description="The encryption algorithm to use.")
    enforce_tls: bool = Field(True, description="Indicates whether TLS is enforced.")
    created_at: datetime = Field(default_factory=datetime.utcnow, frozen=True, description="Timestamp when the policy was created.")

class CredentialDefinitionModel(BaseModel):
    """
    Represents credentials for secure service access.

    Contains access keys, tokens, and metadata related to credential management.
    """
    model_config = ConfigDict(from_attributes=True)
    credential_id: UUID = Field(default_factory=uuid4, frozen=True, description="Unique identifier for the credentials.")
    access_key: Optional[SecretStr] = Field(None, description="The access key.")
    token: Optional[SecretStr] = Field(None, description="Authentication token.")
    valid_until: Optional[datetime] = Field(None, description="Expiration timestamp for the credentials.")
    meta: Dict[str, str] = Field(default_factory=dict, description="Additional metadata for the credentials.")
    created_at: datetime = Field(default_factory=datetime.utcnow, frozen=True, description="Timestamp when the credentials were created.")
