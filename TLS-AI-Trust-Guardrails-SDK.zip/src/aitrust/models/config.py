# src/aitrust/models/config.py

from typing import List, Dict, Optional
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict 
from aitrust.models.pipeline import PipelineStageDefinition
from aitrust.models.guard import GuardConfiguration
from aitrust.models.project import ProjectModel, ServiceSettings 
from aitrust.models.common_enums import PipelineExecutionModeEnum


class SDKConfigModel(BaseModel):
    """
    Top-level configuration model for the SDK.
    It is used to validate the user's YAML configuration.
    """
    model_config = ConfigDict(from_attributes=True)

    version: str = Field(..., description="Version of the guardrails configuration")
    project_infos: Optional[ProjectModel] = Field(None, description="Project-level information")
    service_settings: Optional[ServiceSettings] = Field(None, description="Service-level settings")
    pipeline_stages: List[PipelineStageDefinition] = Field(
        ..., description="List of pipeline stage definitions."
    )
    guards: Dict[str, GuardConfiguration] = Field(
        ..., description="Dictionary of guard configurations."
    )
    default_response_aggregator: Optional[str] = Field(
        None, description="Default response aggregation strategy"
    )
    pipeline_execution_mode: PipelineExecutionModeEnum = Field(
        default=PipelineExecutionModeEnum.SEQUENTIAL,
        description="Pipeline-level execution mode."
    )

    @field_validator("version")
    def version_must_be_1_0(cls, v: str) -> str:
        if v != "1.0":
            raise ValueError("Config version must be '1.0'")
        return v

    @model_validator(mode="before")
    def check_required_fields(cls, values: dict) -> dict:
        if not values.get("pipeline_stages"):
            raise ValueError("Configuration must define at least one pipeline stage")
        if not values.get("guards"):
            raise ValueError("Configuration must define at least one guard")
        return values
