import logging
from typing import List, Dict, Optional
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

from aitrust.models.project import ProjectModel, ServiceSettings
from aitrust.models.common_enums import PipelineExecutionModeEnum, PipelineExecutionStatusEnum
from aitrust.models.validator import ValidatorExecutionModel
from aitrust.models.guard import GuardConfiguration, GuardExecutionModel

logger = logging.getLogger(__name__)

class PipelineStageDefinition(BaseModel):
    """
    Defines a single stage in the pipeline.

    Example stages include 'input', 'retrieval', and 'output'.
    """
    model_config = ConfigDict(from_attributes=True)
    name: str = Field(..., description="Name of the pipeline stage (e.g., 'input', 'retrieval', 'output').")
    execution_mode: PipelineExecutionModeEnum = Field(
        default=PipelineExecutionModeEnum.SEQUENTIAL,
        description="Specifies whether the stage runs sequentially or asynchronously."
    )

class PipelineStageExecutionResult(BaseModel):
    """
    Represents the execution result for a specific pipeline stage.

    Aggregates the execution results from all guards in that stage.
    """
    model_config = ConfigDict(from_attributes=True)
    stage_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the stage execution.", frozen=True)
    stage_name: str = Field(..., description="Name of the pipeline stage.")
    guards_execution_results: List[GuardExecutionModel] = Field(
        default_factory=list, description="List of execution results from guards in this stage."
    )
    overall_decision: Optional[str] = Field(None, description="Aggregated decision for the stage.")
    status: str = Field(default="not_started", description="Execution status for the stage.")
    start_time: Optional[datetime] = Field(None, description="Stage execution start time.")
    end_time: Optional[datetime] = Field(None, description="Stage execution end time.")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when the stage record was created.", frozen=True)

class PipelineExecutionModel(BaseModel):
    """
    Model representing the execution of a pipeline.

    Captures all details related to a specific pipeline execution, including the orchestrator model
    with its execution tree for tracking and visualization purposes.
    """
    id: Optional[str] = Field(None, description="Cosmos DB document ID (typically the string representation of pipeline_execution_id).")
    revision: int = Field(1, description="Revision number of the pipeline document.")
    model_config = ConfigDict(from_attributes=True)
    conversation_id: Optional[UUID] = Field(default=None, description="Unique identifier for the conversation.")
    pipeline_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the pipeline execution.", frozen=True)
    pipeline_definition_id: UUID = Field(..., description="Identifier of the pipeline definition.")
    project_infos: Optional[ProjectModel] = Field(None, description="Project-level information.")
    service_settings: Optional[ServiceSettings] = Field(None, description="Service-level settings.")
    pipeline_stages: List[str] = Field(..., description="List of pipeline stage names.")
    guards_config: Dict[str, GuardConfiguration] = Field(..., description="Dictionary of guard configurations keyed by guard name.")
    stages_execution_results: List[PipelineStageExecutionResult] = Field(
        default_factory=list, description="List of execution results for each pipeline stage."
    )
    status: PipelineExecutionStatusEnum = Field(
        default=PipelineExecutionStatusEnum.NOT_STARTED,
        description="Overall pipeline execution status."
    )
    start_time: datetime = Field(default_factory=datetime.utcnow, description="Pipeline execution start time.", frozen=True)
    end_time: Optional[datetime] = Field(None, description="Pipeline execution end time.")
    last_update: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of the last update.")

    def update_stages_execution_results(self, stage_name: str) -> PipelineStageExecutionResult:
        """
        Updates or adds a stage to stages_execution_results.

        Args:
            stage_name (str): Name of the stage to update or add.

        Returns:
            PipelineStageExecutionResult: The updated or newly added stage.
        """
        for stage in self.stages_execution_results:
            if stage.stage_name == stage_name:
                return stage
        new_stage = PipelineStageExecutionResult(stage_name=stage_name, status="in_progress")
        self.stages_execution_results.append(new_stage)
        return new_stage

    def update_guards_execution_results(self, stage_name: str, guard_name: str) -> GuardExecutionModel:
        """
        Updates or adds a guard to the guards_execution_results of a specified stage.

        Args:
            stage_name (str): Name of the stage containing the guard.
            guard_name (str): Name of the guard to update or add.

        Returns:
            GuardExecutionModel: The updated or newly added guard.
        """
        stage = self.update_stages_execution_results(stage_name)
        for guard in stage.guards_execution_results:
            if guard.guard_config.name == guard_name:
                return guard
        guard_config = self.guards_config.get(guard_name, GuardConfiguration(
            name=guard_name,
            stages=[stage_name],
            validators=[]
        ))
        new_guard = GuardExecutionModel(guard_config=guard_config)
        stage.guards_execution_results.append(new_guard)
        return new_guard

    def update_validators(self, updated_validator: ValidatorExecutionModel) -> List[ValidatorExecutionModel]:
        """
        Updates the validators_execution_results within the nested structure using validator_execution_id.

        Args:
            updated_validator (ValidatorExecutionModel): The validator execution result to update.

        Returns:
            List[ValidatorExecutionModel]: The updated list of validators.

        Raises:
            ValueError: If validator_execution_id is not found in the pipeline.
        """
        for stage in self.stages_execution_results:
            for guard in stage.guards_execution_results:
                for i, validator in enumerate(guard.validators_execution_results):
                    if validator.validator_execution_id == updated_validator.validator_execution_id:
                        guard.validators_execution_results[i] = updated_validator
                        return guard.validators_execution_results
        raise ValueError(f"Validator with ID {updated_validator.validator_execution_id} not found in pipeline.")

# Rebuild Forward References
from aitrust.models.validator import ValidatorConfig, ValidatorExecutionModel
from aitrust.models.guard import GuardConfiguration, GuardExecutionModel, GuardSettings

ValidatorConfig.model_rebuild()
ValidatorExecutionModel.model_rebuild()
GuardSettings.model_rebuild()
GuardConfiguration.model_rebuild()
GuardExecutionModel.model_rebuild()
PipelineStageDefinition.model_rebuild()
PipelineStageExecutionResult.model_rebuild()
PipelineExecutionModel.model_rebuild()