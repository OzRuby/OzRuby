from enum import Enum
from typing import Optional, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, SecretStr, ConfigDict # Import ConfigDict

class AuthMethodEnum(str, Enum):
    """Enumeration of supported authentication methods."""
    API_KEY = "api_key"
    OAUTH2 = "oauth2"
    NONE = "none"

class AuthenticationDefinitionModel(BaseModel):
    """
    Configuration for authenticating requests to external or internal services within the SDK.
    Specifies the authentication method and associated credentials.
    """
    model_config = ConfigDict(from_attributes=True) # Use ConfigDict and from_attributes instead of orm_mode

    auth_id: UUID = Field(default_factory=uuid4, description="Unique authentication configuration ID.", frozen=True)
    method: AuthMethodEnum = Field(default=AuthMethodEnum.NONE, description="Authentication method to use.")
    api_key: Optional[SecretStr] = Field(None, description="API key if method is 'api_key'.")
    oauth_token_url: Optional[str] = Field(None, description="OAuth2 token endpoint URL if method is 'oauth2'.")
    oauth_client_id: Optional[str] = Field(None, description="OAuth2 Client ID if method is 'oauth2'.")
    oauth_client_secret: Optional[SecretStr] = Field(None, description="OAuth2 Client Secret if method is 'oauth2'.")
    oauth_scope: Optional[str] = Field(None, description="OAuth2 Scope (optional) if method is 'oauth2'.") # Added oauth_scope
    extra_params: Dict[str, Any] = Field(default_factory=dict, description="Additional authentication parameters (method-specific).") # Changed to Dict[str, Any]
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when this authentication configuration was created.", frozen=True)