from enum import Enum
from pydantic import BaseModel, SecretStr

class LoggingLevelEnum(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class MonitoringEventTypeEnum(str, Enum):
    VALIDATOR_CALL = "validator_call"
    GUARD_EXECUTION = "guard_execution"
    PIPELINE_STAGE = "pipeline_stage"
    SYSTEM = "system"
    OTHER = "other"


class LoggingModel(BaseModel):
    logger_name: str = "ai-trust-SDK"
    app_level: LoggingLevelEnum = LoggingLevelEnum.INFO
    system_level: LoggingLevelEnum = LoggingLevelEnum.WARNING


class MonitoringModel(BaseModel):
    application_insights: SecretStr
    logging: LoggingModel = (
        LoggingModel()
    )  
    tracing_enabled: bool = False