from pydantic import BaseModel, Field, SecretStr
from typing import Dict, Optional, Any


class OneAccountConnexionModel(BaseModel, frozen=True):
    client_id: SecretStr
    client_secret: SecretStr
    one_login_base_url: SecretStr
    one_login_url: SecretStr
    scope: str

class OneAccount(BaseModel, frozen=True):
    connexion: OneAccountConnexionModel

class DependenciesModel(BaseModel, frozen=True):
    one_account: OneAccount

class SettingsModel(BaseModel):
    """
    Model representing settings specific to the AI-Trust SDK.

    Includes guard configuration path, orchestrator settings, polling settings, validator settings, and other SDK-specific configurations.
    """
    guard_config_path: str = Field(..., description="Path to the guard configuration file.")
    orchestrator_settings: Dict[str, Any] = Field(
        default_factory=dict, description="Settings specific to the orchestrator, e.g., timeout, concurrency, retries."
    )
    dependencies: DependenciesModel
    runner_settings: Optional[Dict[str, Any]] = Field(
        None, description="Settings for polling mechanisms, if applicable."
    )
    validator_settings: Optional[Dict[str, Any]] = Field(
        None, description="Settings specific to validators, e.g., http_timeout_seconds."
    )
    other_settings: Optional[Dict[str, Any]] = Field(
        None, description="Additional settings specific to the SDK."
    )
    ssl_enabled: Optional[bool] = Field(
        default=True, description="Enable ssl verification."
    )