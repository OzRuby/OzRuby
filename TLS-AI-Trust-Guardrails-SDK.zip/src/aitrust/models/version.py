from pydantic import BaseModel


class VersionModel(BaseModel, frozen=True):
    package: str
    git_tag: str | None
