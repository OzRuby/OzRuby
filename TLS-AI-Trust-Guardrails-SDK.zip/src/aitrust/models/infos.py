from pydantic import BaseModel, Field, SecretStr

class UserInfoModel(BaseModel, frozen=True):
    name: SecretStr
    email: SecretStr
    affiliation: SecretStr

class InformationsModel(BaseModel, frozen=True):
    id: str = Field(description="")
    name: str = Field(description="")
    contributors: list[UserInfoModel] = Field(description="List of contributors")
    author_info: UserInfoModel = Field(description="")
    use_llm: bool = Field(description="")
    use_ml: bool = Field(description="")
    description: str = Field(description="")
    docs_url: str = Field(description="")
