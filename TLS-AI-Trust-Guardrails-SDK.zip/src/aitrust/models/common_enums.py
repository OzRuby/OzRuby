from enum import Enum

class PipelineExecutionModeEnum(str, Enum):
    SEQUENTIAL = "sequential"
    ASYNCHRONOUS = "asynchronous"

class PipelineExecutionStatusEnum(str, Enum):
    """
    Defines the overall execution status of a pipeline instance.
    """
    NOT_STARTED = "not_started"
    RUNNING = "running"
    COMPLETED = "completed"  # Pipeline finished all stages/guards successfully
    FAILED = "failed"        # Pipeline execution encountered a critical error and stopped
    CANCELLED = "cancelled"  # Pipeline execution was explicitly cancelled