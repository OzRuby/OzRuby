from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime
from uuid import UUID, uuid4

class PrivacyPolicyModel(BaseModel):
    """
    Model representing a privacy policy definition.

    Defines how user data is handled, including data retention and anonymization settings.
    """
    model_config = ConfigDict(from_attributes=True)
    policy_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the privacy policy.")
    policy_name: str = Field(..., description="Name of the privacy policy (e.g., 'GDPR Compliance').")
    data_retention_days: int = Field(30, description="Number of days to retain user data.")
    anonymize: bool = Field(True, description="Flag indicating whether personal data should be anonymized.")
    created_at: datetime = Field(default_factory=datetime.utcnow, frozen=True, description="Timestamp when the privacy policy was created.")

