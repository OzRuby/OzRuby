from typing import Optional, Dict
from pydantic import BaseModel, Field, ConfigDict

class ProjectModel(BaseModel):
    """
    Model representing project-level information.

    Contains details such as the project name, description, and IT owner information.
    """
    model_config = ConfigDict(from_attributes=True)
    contract_name: Optional[str] = Field(None, description="The name of the contract.")
    country_name: Optional[str] = Field(None, description="The name of the country.")
    project_name: Optional[str] = Field(None, description="The name of the project.")
    scope: str | None = Field(default="PROD", description="Current scope ( eg: DEV, PROD)")
    country_name: str | None = Field(default="France", description="Current country ( eg: France)")
    partner_name: str | None = Field(default="PUFFIN", description="Current contract name ( eg: PUFFIN)")   
    description: Optional[str] = Field(None, description="A brief description of the project.")
    itpm_id: Optional[str] = Field(None, description="The ITPM identifier for the project.")
    it_owner_infos: Optional[Dict[str, Optional[str]]] = Field(None, description="Information about the IT owner (e.g., name, email).")

class ServiceSettings(BaseModel):
    """
    Model representing service-level settings.

    Includes details such as the service endpoint and any credentials required.
    """
    model_config = ConfigDict(from_attributes=True)
    slot: Optional[str] = Field(None, description="The service slot (e.g., DEV, PROD).")
    endpoint: Optional[str] = Field(None, description="The service endpoint URL.")
    credential: Optional[Dict[str, Optional[str]]] = Field(None, description="Service credentials (e.g., access key).")
