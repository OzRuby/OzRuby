from enum import Enum
from typing import List, Optional, Any
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

from aitrust.models.common_enums import PipelineExecutionModeEnum
from aitrust.models.validator import ValidatorConfig

class GuardPriorityEnum(str, Enum):
    P1 = "p1"
    P2 = "p2"
    P3 = "p3"

class GuardSettings(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    response_aggregation_strategy: Optional[str] = Field(
        None, description="Strategy to aggregate validator responses."
    )
    priority: Optional[GuardPriorityEnum] = Field(
        None, description="Priority level assigned to the guard."
    )

    # **Fixed** spelling to match your YAML (`mandatory_validators`)
    mandatory_validators: Optional[List[str]] = Field(
        None, description="List of mandatory validator names."
    )
    min_non_mandatory_validators_to_check: Optional[int] = Field(
        None, description="Minimum number of non-mandatory validators required."
    )

class GuardConfiguration(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    guard_id: UUID = Field(
        default_factory=uuid4, description="Unique identifier for the guard.", frozen=True
    )
    name: str = Field(..., description="Name of the guard.")
    settings: Optional[GuardSettings] = Field(
        None, description="Guard-specific settings."
    )
    stages: List[str] = Field(
        ..., description="Pipeline stages where the guard applies."
    )
    validators: List[ValidatorConfig] = Field(
        ..., description="List of validator configurations."
    )
    execution_mode: PipelineExecutionModeEnum = Field(
        default=PipelineExecutionModeEnum.SEQUENTIAL,
        description="Execution mode for validators."
    )

class GuardExecutionModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    guard_execution_id: UUID = Field(
        default_factory=uuid4,
        description="Unique identifier for the guard execution.",
        frozen=True
    )
    guard_config: GuardConfiguration = Field(
        ..., description="Configuration of the guard."
    )
    validators_execution_results: List[Any] = Field(
        default_factory=list,
        description="Execution results for each validator."
    )
    final_decision: Optional[str] = Field(
        None, description="Aggregated final decision (PASS, WARN, BLOCK)."
    )
    execution_status: str = Field(
        default="pending", description="Current execution status of the guard."
    )
    start_time: Optional[datetime] = Field(
        None, description="Timestamp when guard execution started."
    )
    end_time: Optional[datetime] = Field(
        None, description="Timestamp when guard execution ended."
    )
    last_update: datetime = Field(
        default_factory=datetime.utcnow, description="Timestamp of the last update."
    )
