from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os
import base64
import hashlib
import random
import string
from typing import Union

# Generate a strong AES key from a passphrase (password-based key derivation)
def derive_key(passphrase: str, salt: bytes) -> bytes:
    """
    Derives a cryptographic key from the given passphrase and salt.
    Uses PBKDF2 HMAC with SHA256 to derive a 256-bit AES key.
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        salt=salt,
        iterations=100000,
        length=32,
        backend=default_backend()
    )
    return kdf.derive(passphrase.encode())

# Encrypt data using AES encryption
def encrypt_data(data: str, passphrase: str) -> str:
    """Encrypts data using AES (CBC mode) with padding."""
    # Generate a random 16-byte salt and 16-byte IV (Initialization Vector)
    salt = os.urandom(16)
    iv = os.urandom(16)

    # Derive the encryption key from the passphrase and salt
    key = derive_key(passphrase, salt)

    # Pad the data to be a multiple of AES block size (16 bytes)
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data.encode()) + padder.finalize()

    # Create the AES cipher with CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())

    # Encrypt the data
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    # Return encrypted data as base64-encoded string (for safe storage)
    return base64.b64encode(salt + iv + encrypted_data).decode()

# Decrypt data using AES encryption
def decrypt_data(encrypted_data: str, passphrase: str) -> str:
    """Decrypts data encrypted with AES (CBC mode) using the provided passphrase."""
    # Decode the base64-encoded string
    encrypted_data_bytes = base64.b64decode(encrypted_data)

    # Extract salt and IV (the first 32 bytes contain salt and IV)
    salt = encrypted_data_bytes[:16]
    iv = encrypted_data_bytes[16:32]
    encrypted_data_content = encrypted_data_bytes[32:]

    # Derive the decryption key from the passphrase and salt
    key = derive_key(passphrase, salt)

    # Create the AES cipher with CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())

    # Decrypt the data
    decryptor = cipher.decryptor()
    decrypted_padded_data = decryptor.update(encrypted_data_content) + decryptor.finalize()

    # Remove padding
    unpadder = padding.PKCS7(128).unpadder()
    decrypted_data = unpadder.update(decrypted_padded_data) + unpadder.finalize()

    return decrypted_data.decode()

# Masking: Replace with asterisks or placeholders
def mask_data(data: str) -> str:
    """Masks sensitive data with asterisks or placeholders."""
    return "****" * len(data)  # Replace all characters with ****


# Hashing: Create a hash of the data (irreversible)
def hash_data(data: str) -> str:
    """Hashes data using SHA-256 (for pseudonymization)."""
    return hashlib.sha256(data.encode()).hexdigest()


# Dropping: Remove sensitive data
def drop_data(data: str) -> None:
    """Drops the data (i.e., removes it entirely)."""
    return None


def anonymize_field(data: str, method: str, passphrase: str = None) -> Union[str, None]:
    """
    Anonymize a specific field based on the given method.

    Args:
        data (str): The sensitive data to anonymize.
        method (str): The anonymization method ('mask', 'encrypt', 'hash', 'drop').
        passphrase (str, optional): The passphrase for AES encryption (only needed for 'encrypt').

    Returns:
        str or None: The anonymized data (or None if dropped).
    """
    if method == "mask":
        return mask_data(data)
    elif method == "encrypt":
        if passphrase:
            return encrypt_data(data, passphrase)  # AES Encryption
        else:
            raise ValueError("Passphrase is required for encryption")
    elif method == "hash":
        return hash_data(data)
    elif method == "drop":
        return drop_data(data)
    else:
        raise ValueError(f"Unsupported anonymization method: {method}")
