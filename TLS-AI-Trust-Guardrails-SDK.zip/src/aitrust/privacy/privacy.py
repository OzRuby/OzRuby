# main.py
from aitrust.models.privacy import PrivacyPolicyModel, SensitiveDataType, AccessControlModel, ConsentModel
from aitrust.monitoring.logs import logger

def create_privacy_policy():
    # Créer une instance de PrivacyPolicyModel
    privacy_policy = PrivacyPolicyModel(
        policy_name="GDPR Compliance",
        sensitive_data_types=[
            SensitiveDataType.PERSONAL_IDENTIFIABLE_INFORMATION,
            SensitiveDataType.FINANCIAL_DATA,
            SensitiveDataType.HEALTH_DATA
        ],
        access_control=AccessControlModel(
            allowed_roles=["admin", "data_protection_officer"],
            encryption_required=True,
            data_access_logs_enabled=True
        ),
        consent=ConsentModel(
            consent_required=True,
            consent_method="Opt-in",
            consent_duration_days=365
        )
    )

    return privacy_policy

def main():
    # Créer et afficher la politique de confidentialité
    privacy_policy = create_privacy_policy()
    logger.INFO("SecretsManager initialized.", privacy_policy)
    print("Politique de confidentialité créée:")
    print(privacy_policy.json(indent=4))  # Affichage au format JSON
