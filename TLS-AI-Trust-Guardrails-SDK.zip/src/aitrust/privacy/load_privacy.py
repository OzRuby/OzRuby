# main.py
from typing import Optional, Dict, Any
from datetime import datetime
from uuid import uuid4
from pydantic import ValidationError
import logging
from aitrust.models.privacy import AxaPrivacyPolicyModel, GuardrailRule, RetentionPolicy, AccessControlRule
from aitrust.monitoring.logs import logger

from typing import Optional, Dict, Any
from datetime import datetime
from uuid import uuid4
from pydantic import ValidationError
import logging

# logger = logging.getLogger("axa.privacy")


def load_privacy_policy(
    custom_policy: Optional[Dict[str, Any]] = None,
    override_retention_days: Optional[int] = None,
    include_audit_roles: bool = True
) -> AxaPrivacyPolicyModel:
    """
    Loads and returns an AXA LLM privacy policy, optionally customized.

    Args:
        custom_policy (dict): Optional raw policy override (e.g. from DB or JSON file).
        override_retention_days (int): Override all retention periods with a fixed value.
        include_audit_roles (bool): Whether to include audit access control rules.

    Returns:
        AxaPrivacyPolicyModel: A validated policy instance ready for enforcement.
    """
    try:
        if custom_policy:
            logger.info("Loading custom privacy policy...")
            policy = AxaPrivacyPolicyModel(**custom_policy)
        else:
            logger.info("Loading default AXA LLM privacy policy...")
            policy = AxaPrivacyPolicyModel(
                policy_id=uuid4(),
                policy_name="AXA Partners - Default LLM Guardrails",
                created_at=datetime.utcnow(),
                updated_at=None,
                legal_basis="legitimate_interest",
                data_controller="DPO AXA Partners",
                applicable_regulations=["GDPR", "ISO 27701"],
                categories_covered=["conversational", "personal", "metadata"],
                anonymization_enabled=True,
                guardrail_rules=[
                    GuardrailRule(
                        field_name="email",
                        method="mask",
                        apply_during=["input", "storage"],
                        mandatory=True
                    ),
                    GuardrailRule(
                        field_name="ssn",
                        method="encrypt",
                        apply_during=["input", "output"],
                        mandatory=True
                    ),
                    GuardrailRule(
                        field_name="location",
                        method="drop",
                        apply_during=["input"],
                        mandatory=True
                    ),
                ],
                retention=[
                    RetentionPolicy(
                        category="conversational",
                        retention_days=override_retention_days or 30,
                        delete_on_expiry=True
                    ),
                    RetentionPolicy(
                        category="metadata",
                        retention_days=override_retention_days or 90,
                        delete_on_expiry=True
                    ),
                ],
                access_control=[
                    AccessControlRule(role="llm_guard", allowed_actions=["read", "write"]),
                    *(
                        [AccessControlRule(role="DPO", allowed_actions=["audit", "delete"])]
                        if include_audit_roles else []
                    )
                ],
                external_policy_url=" ",
                notes="Default policy used for LLM chat filtering and audit logging."
            )

        logger.info("Privacy policy loaded and validated successfully.")
        return policy

    except ValidationError as e:
        logger.error("Failed to validate privacy policy: %s", e)
        raise
