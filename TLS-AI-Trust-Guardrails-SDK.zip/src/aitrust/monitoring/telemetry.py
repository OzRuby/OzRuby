from enum import Enum
from os import environ

# Copied from https://github.com/microsoft/call-center-ai/blob/main/app/helpers/monitoring.py
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import metrics, trace
from opentelemetry.instrumentation.aiohttp_client import (
  AioHttpClientInstrumentor,
)
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.metrics._internal.instrument import Counter, Gauge, Histogram
from opentelemetry.semconv.attributes import service_attributes
from opentelemetry.trace.span import INVALID_SPAN
from opentelemetry.util.types import AttributeValue
from structlog.contextvars import bind_contextvars, get_contextvars

from ..common.settings_config import SETTINGS_CONFIG
import os

MODULE_NAME = "aitrust.sdk"
VERSION = SETTINGS_CONFIG.version.package if SETTINGS_CONFIG.version else "0.0.0-unknown"

class SpanAttributeEnum(str, Enum):
    """Enumeration of attributes used to enrich spans and logs with SDK execution context."""
    REQUEST_ID = "aitrust.sdk.request.id"
    CONVERSATIONAL_ID = "aitrust.sdk.conversation.id"
    VALIDATOR_NAME = "aitrust.sdk.validator.name"
    VALIDATOR_EXECUTION_ID = "aitrust.sdk.validator.validator_execution.id"
    PROJECT_NAME = "aitrust.sdk.project.name"
    PIPELINE_EXECUTION_ID = "aitrust.sdk.pipeline.execution.id"
    STAGE_NAME = "aitrust.sdk.stage.name"
    COUNTRY_NAME = "aitrust.sdk.country.name"
    CONTRACT_NAME = "aitrust.sdk.contract.name"

    def attribute(
        self,
        value: AttributeValue,
    ) -> None:
        """
        Set an attribute on the current span.
        """
        # Enrich logging
        bind_contextvars(**{self.value: value})

        # Enrich span
        span = trace.get_current_span()
        if span == INVALID_SPAN:
            return span.set_attribute(self.value, value)

class SpanSdkMeterEnum(str, Enum):
    """Enumeration of SDK-specific metrics for monitoring pipeline execution."""
    SDK_ORCHESTRATOR_CALL = "aitrust.sdk.orchestrator.call"
    SDK_PIPELINE_ERROR = "aitrust.sdk.pipeline.errors"
    SDK_STAGE_EXECUTION = "aitrust.sdk.stage.execution"
    SDK_PIPELINE_COMPLETED = "aitrust.sdk.pipeline.completed"
    SDK_ORCHESTRATOR_EXECUTION_LATENCY = "aitrust.sdk.orchestrator.execution_latency"
    SDK_GUARD_LATENCY = "aitrust.sdk.guard.execution_latency"
    SDK_STAGE_LATENCY = "aitrust.sdk.stage.latency"

    def counter(
        self,
        unit: str,
    ) -> Counter:
        """
        Create a counter metric to track a span counter.
        """
        return meter.create_counter(
        description=self.__doc__ or "",
        name=self.value,
        unit=unit,
        )

    def gauge(
        self,
        unit: str,
    ) -> Gauge:
        """
        Create a gauge metric to track a span counter.
        """
        return meter.create_gauge(description=self.__doc__ or "", name=self.value, unit=unit)

    def histogram(
        self,
        unit: str,
    ) -> Histogram:
        """
        Create a histogram metric to track a span counter.
        """
        return meter.create_histogram(description=self.__doc__ or "", name=self.value, unit=unit)


try:
  configure_azure_monitor(logger_name=SETTINGS_CONFIG.monitoring.logging.logger_name)  # Configure Azure Application Insights exporter
  AioHttpClientInstrumentor().instrument()  # Instrument aiohttp
  HTTPXClientInstrumentor().instrument()  # Instrument httpx
except ValueError as e:
  print(  # noqa: T201
    "Azure Application Insights instrumentation failed,",
    "likely due to a missing APPLICATIONINSIGHTS_CONNECTION_STRING",
    " environment variable.",
    e,
  )

# Attributes
_default_attributes = {
  service_attributes.SERVICE_NAME: MODULE_NAME,
  service_attributes.SERVICE_VERSION: VERSION,
}

# Create a tracer and meter that will be used across the application
tracer = trace.get_tracer(
  attributes=_default_attributes,
  instrumenting_module_name=MODULE_NAME,
)
meter = metrics.get_meter(
  name=MODULE_NAME,
)


# Initialize SDK frame metrics
sdk_orchestrator_call = SpanSdkMeterEnum.SDK_ORCHESTRATOR_CALL.counter("frames") #if meter else None
"""Counter for tracking the number of orchestrator calls."""
sdk_pipeline_error = SpanSdkMeterEnum.SDK_PIPELINE_ERROR.counter("frames") #if meter else None
"""Counter for tracking the number of pipeline errors."""
sdk_stage_execution = SpanSdkMeterEnum.SDK_STAGE_EXECUTION.counter("frames") #if meter else None
"""Counter for tracking the number of stage executions."""
sdk_pipeline_completed = SpanSdkMeterEnum.SDK_PIPELINE_COMPLETED.counter("frames") #if meter else None
"""Counter for tracking the number of successfully completed pipelines."""

# Initialize SDK latency metrics
g_sdk_orchestrator_execution_latency = SpanSdkMeterEnum.SDK_ORCHESTRATOR_EXECUTION_LATENCY.gauge("s") 
h_sdk_orchestrator_execution_latency = SpanSdkMeterEnum.SDK_ORCHESTRATOR_EXECUTION_LATENCY.histogram("s") #if meter else None
"""Histogram for tracking total pipeline execution latency in seconds."""
g_sdk_guard_latency = SpanSdkMeterEnum.SDK_GUARD_LATENCY.gauge("s")
h_sdk_guard_latency = SpanSdkMeterEnum.SDK_GUARD_LATENCY.histogram("s") #if meter else None
"""Histogram for tracking guard execution latency in seconds."""
g_sdk_stage_latency = SpanSdkMeterEnum.SDK_STAGE_LATENCY.gauge("s")
h_sdk_stage_latency = SpanSdkMeterEnum.SDK_STAGE_LATENCY.histogram("s") #if meter else None
"""Histogram for tracking stage execution latency in seconds."""


def gauge_set(
  metric: Gauge,
  value: float | int,
):
  """
  Set a gauge metric value with context attributes.
  """
  metric.set(
    amount=value,
    attributes={
      # First, set default attributes
      **_default_attributes,
      # Then, set context attributes, they can override default attributes
      **get_contextvars(),
    },
  )


def histogram_record(
  metric: Histogram,
  value: float | int,
):
  """
  Set a histogram metric value with context attributes.
  """
  metric.record(
    amount=value,
    attributes={
      # First, set default attributes
      **_default_attributes,
      # Then, set context attributes, they can override default attributes
      **get_contextvars(),
    },
  )


def counter_add(
  metric: Counter,
  value: float | int,
):
  """
  Add a counter metric value with context attributes.
  """
  metric.add(
    amount=value,
    attributes={
      # First, set default attributes
      **_default_attributes,
      # Then, set context attributes, they can override default attributes
      **get_contextvars(),
    },
  )

get_contextvars()
