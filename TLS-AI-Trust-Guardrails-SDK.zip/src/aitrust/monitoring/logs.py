import logging
from opencensus.ext.azure.log_exporter import AzureLogHandler
from opencensus.trace import config_integration, execution_context
from opencensus.trace.tracer import Tracer
from ..common.settings_config import SETTINGS_CONFIG, default_env


def init_logging(SETTINGS_CONFIG):
    """
    Initialise le logger avec AzureLogHandler et configure la gestion des logs.
    """
    # Configure OpenCensus to integrate with logging
    config_integration.trace_integrations(["logging"])

    # Set up logging format (this format does not include file/path, function, and line info)
    logging_format = "%(asctime)s | %(levelname)s | %(message)s"  # Simplified format
    logging.basicConfig(format=logging_format, level=logging.INFO)

    logger = logging.getLogger(SETTINGS_CONFIG.monitoring.logging.logger_name)
    logger.setLevel(logging.INFO)

    # Clear existing handlers to prevent duplicate logs
    if logger.hasHandlers():
        logger.handlers.clear()

    # Create a console handler and set level to INFO
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter(logging_format))

    # Adding Azure Log Handler
    azure_handler = AzureLogHandler()

    # Add handlers to logger
    logger.addHandler(console_handler)
    logger.addHandler(azure_handler)

    return logger


def log_data(log, message, custom_properties=None):
    """
    Envoie un message de log avec des propriétés personnalisées et des informations de trace.
    Les propriétés sont envoyées comme dimensions personnalisées dans les logs Azure.
    """
    # Créer un dictionnaire 'extra' sans les informations indésirables (filtrage explicite)
    extra = {}
    if custom_properties:
        extra.update(custom_properties)

    # Récupérer le tracer et le contexte d'exécution actuel
    tracer = execution_context.get_opencensus_tracer()

    # Vérifier si le tracer est un NoopTracer, sinon on crée un span valide
    if isinstance(tracer, Tracer):
        with tracer.span(name="custom_span"):
            if custom_properties:
                # Ajouter des propriétés personnalisées à la trace
                for key, value in custom_properties.items():
                    tracer.add_attribute(key, value)
            # Envoi du message avec les propriétés 'extra' personnalisées
            log(message, extra=extra)
    else:
        # Si pas de tracer, juste loguer sans ajouter des attributs
        log(message, extra=extra)


# Initialisation du logger
logger = init_logging(SETTINGS_CONFIG)