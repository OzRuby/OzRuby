# AITrust SDK

## Introduction

As generative AI applications redefine industries, ensuring the safety, accuracy, and quality of AI-generated outputs is paramount. The **AITrust** system addresses this need with a robust, modular framework that enforces rigorous standards across any stage of a generative AI pipeline. Comprising an SDK and a backend service, **AITrust** empowers developers to build trustworthy AI systems that safeguard users and align with organizational policies.

The **AITrust SDK** is the client-side toolkit designed to integrate seamlessly into your generative AI applications. It provides a flexible and developer-friendly interface to define and manage a validation pipeline, ensuring that AI inputs, retrievals, and outputs meet safety and quality requirements before reaching end users. Working in tandem with the AITrust backend service, the SDK orchestrates the validation process, delivering actionable decisions to protect your application’s integrity.

Here’s how the **AITrust** components collaborate:

- **SDK (Client-Side)**: The SDK enables developers to configure a validation pipeline via a `guard_config` YAML file. This file outlines pipeline stages (e.g., input, retrieval, output), assigns *guards* to each stage, and specifies *validators*—specialized checks for issues like offensive language, hallucinations, or relevance. The SDK reads this configuration, packages the necessary data, and communicates with the backend service to execute validations. Once results are returned, the SDK aggregates them using strategies like PASS, BLOCK, or WARN to determine the AI output’s fate.

- **Service (Backend)**: The backend service executes the validation logic, leveraging a scalable, serverless architecture. It dynamically integrates validators—developed as independent Python packages in a separate repository—installed via `pip` and exposed as HTTP or event-based endpoints. This modularity allows validators to evolve independently, with results stored in Azure Cosmos DB and tasks scaled via Azure Queue Storage.

The `guard_config` YAML file is the heart of the system, serving as the blueprint for your validation pipeline. With it, you can:
- Define pipeline stages tailored to your application.
- Link guards to specific validation rules.
- Select and configure validators with custom parameters (e.g., thresholds).
- Set aggregation strategies to synthesize results into a final decision.

Integrating the **AITrust SDK** is simple:
1. Install the SDK via `pip`.
2. Configure the `guard_config` YAML file to suit your needs.
3. Use the SDK’s APIs to validate data at key points in your AI workflow.

By embedding **AITrust** into your generative AI pipelines, the SDK ensures safety and quality are not afterthoughts but integral to your application’s design—protecting users, enhancing reliability, and enabling confident innovation.

---

## Getting Started

This section walks you through installing and integrating the **AITrust SDK** into your generative AI application.

### 1. Installation Process

#### Prerequisites
- **Python 3.11+**
- An active **AITrust Service** instance (see the [Service README](#) for setup instructions).

#### Steps
1. **Install the SDK**:

to be documented ....

2. **Set Up the Configuration**:
   - Create a `guard_config.yaml` file to define your validation pipeline. A starter template is included with the SDK (e.g., `configs/guard_config.yaml` after cloning the repo or available in the documentation).
   - Customize it to specify stages, guards, validators, and aggregation strategies. Example:

```yaml
version: "1.0"

project_infos:
  project_name: "Mock RAG GenTrust Application"
  description: "DEMO for a mock RAG app"
  itpm_id: "MOCK-0001"
  it_owner_infos:
    name: "Hicham"
    email: "hicham@example.com"

service_settings:
  slot: "DEV"
  endpoint: "http://localhost:8080"
  credential:
    access_key: "dummy-key"

pipeline_execution_mode: sequential

pipeline_stages:
  - name: "input"
    execution_mode: sequential
  - name: "retrieval"
    execution_mode: asynchronous
  - name: "output"
    execution_mode: sequential

guards:
  UserQueryValidation:
    name: "UserQueryValidation"
    stages:
      - "input"
    settings:
      response_aggregation_strategy: "block_on_any"
      priority: "p1"
      mendatory_validators: ["GrammarCheck"]
      min_non_mendatory_validators_to_check: 0
    execution_mode: asynchronous
    validators:
      - name: "GrammarCheck"
        validator_type: "event_based"
        endpoint_url: "/validator/grammar"
        parameters:
          threshold: 0.8
          validation_method: "llm"
        priority: "p1"

  ResponseSafetyAndQuality:
    name: "ResponseSafetyAndQuality"
    stages:
      - "retrieval"
    settings:
      response_aggregation_strategy: "block_on_any"
      priority: "p1"
      mendatory_validators: ["HallucinationDetection"]
      min_non_mendatory_validators_to_check: 0
    execution_mode: asynchronous
    validators:
      - name: "HallucinationDetection"
        validator_type: "event_based"
        endpoint_url: "/validator/hallucination"
        parameters:
          max_length: 4000
        priority: "p1"

  DocumentRelevanceValidation:
    name: "DocumentRelevanceValidation"
    stages:
      - "output"
    settings:
      response_aggregation_strategy: "block_on_any"
      priority: "p1"
      mendatory_validators: ["OffensiveQueryHandling"]
      min_non_mendatory_validators_to_check: 0
    execution_mode: sequential
    validators:
      - name: "OffensiveQueryHandling"
        validator_type: "http_based"
        endpoint_url: "/validator/offensive"
        parameters:
          threshold: 0.8
          validation_method: "ml"
        priority: "p1"

default_response_aggregator: "block_on_any"
```

3. **Integrate the SDK**:
   - Initialize the SDK in your application and connect it to the backend service:
     ```python
    to be completed .....
     ```

### 2. Software Dependencies

The SDK relies on:
- **Python Packages**: Listed in `pyproject.toml`.
- **Backend Service**: An operational AITrust Service instance to execute validators.

Check `pyproject.toml` in the SDK repository for a full dependency list.

### 3. Latest Releases

Releases follow semantic versioning. Visit the [Releases](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-SDK/releases) page for the latest version, changelog, and upgrade notes.

### 4. API References

Detailed API documentation is available in `docs/api.md`. Key methods include:

to be filled .....

---

## Build and Test

### Build the SDK

If contributing to the SDK or using a local copy:
1. **Clone the Repository**:
   ```bash
   git clone https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-SDK
   ```
2. **Install Dependencies**:
   Using `uv` (recommended for consistency with the service):
   ```bash
   uv venv
   uv sync
   ```

### Run Tests

Tests are located in `tests/`, covering unit and integration scenarios.
1. **Activate the Virtual Environment** (if not already active).
2. **Run All Tests**:
   ```bash
   uv run pytest ./tests/unit_tests/
   ```
3. **Run with Coverage**:
   ```bash
   uv run pytest ./tests/unit_tests/ --cov=src/aitrust --cov-report=term-missing   
   ```
4. **Run Specific Tests**:
   - Unit tests: `pytest tests/unit_tests/`
   - Integration tests (requires a service instance): `pytest tests/integration_tests/`

---

## Contribute

We welcome contributions to the **AITrust SDK**—whether it’s enhancing functionality, fixing bugs, or improving docs.

### How to Contribute
1. **Clone the Repository**: Get a local copy.
2. **Create a Feature Branch**: E.g., `feature/add-validator-support`.
3. **Commit Changes**: Use conventional commits (e.g., `feat: add new validation API`).
4. **Run Tests**: Verify all tests pass.
5. **Submit a Pull Request**: Describe your changes clearly.

See [CONTRIBUTING.md](./CONTRIBUTING.md) for detailed guidelines.

---

## Structure & Concepts Diagrams

Visualize the SDK’s role and interactions:
- **SDK Structure**:  
  ![SDK Structure Diagram](docs/figures/sdk-structure.png)

- **SDK Concepts**:  
  ![SDK-Service Interaction Diagram](docs/figures/sdk-concepts.png)
