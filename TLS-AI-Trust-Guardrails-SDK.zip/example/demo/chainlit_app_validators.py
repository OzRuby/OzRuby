import os
import sys
import uuid
import time
from typing import Optional, List, Tuple, Dict, Any
from dotenv import load_dotenv
import asyncio
from datetime import datetime

# Adjust the system path to include the source directory
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../src")))

# Load environment variables from .env file
dotenv_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(dotenv_path=dotenv_path)

import chainlit as cl
from secure_gpt_langchain import SecureGPT
from pdf_processor import load_and_split_pdfs
from vector_store import create_vector_db
from langchain.schema import HumanMessage
from aitrust.monitoring.logs import logger
from aitrust.common.config import ConfigLoader
from aitrust.models.config import SDKConfigModel
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.models.pipeline import PipelineStageExecutionResult
from aitrust.core.runner.pipeline_runner import PipelineRunner
import logging


# Define persistent directory for vector storage
PERSIST_DIRECTORY = os.path.join(os.path.dirname(__file__), "data", "vectors")

# Project name constant
PROJECT_NAME = "Mock RAG GenTrust Application"

# Initialize embedding and chat engines
try:
    embedding_gpt = SecureGPT(deployment_id="text-embedding-ada-002-2", prompt_type="EMBEDDINGS")
    logger.info("Embedding engine initialized.")
except Exception as e:
    logger.error(f"Embedding engine failed to initialize: {str(e)}", exc_info=True)
    raise

try:
    chat_gpt = SecureGPT(deployment_id="gpt-4o-2024-08-06", prompt_type="CHAT_COMPLETIONS")
    logger.info("Chat engine initialized.")
except Exception as e:
    logger.error(f"Chat engine failed to initialize: {str(e)}", exc_info=True)
    raise

def load_config(config_path: str) -> SDKConfigModel:
    """Load SDK configuration from the specified path."""
    loader = ConfigLoader(settings_path=config_path)
    config = loader.load_config()
    logger.info(f"Configuration loaded successfully from {config_path}")
    return config

def setup_orchestrator(config_path: str) -> PipelineOrchestrator:
    """Set up the pipeline orchestrator with the given configuration."""
    config = load_config(config_path)
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_file(config_path, pipeline_id)
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    runner = PipelineRunner(service_base_url=config.service_settings.endpoint)
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=runner
    )
    logger.info(f"Pipeline orchestrator initialized with ID: {pipeline_id}")
    return orchestrator

def get_user_friendly_message(validator_name: str, reason: str, error_spans: Optional[List[Dict]] = None) -> str:
    """Map validator failure reasons to user-friendly messages with specific guidance."""
    if validator_name == "GrammarCheck" and error_spans:
        first_error = error_spans[0]
        text = first_error.get("text", "")
        error_reason = first_error["reason"]
        return f"Your query has a grammatical error: {error_reason} in '{text}'. Please correct it and try again."
    elif validator_name == "PromptInjection":
        return "Your query may contain unsafe content. Please rephrase it to avoid references to external or manipulative content."
    elif validator_name == "RelevanceChunk":
        return f"The retrieved documents are not relevant enough: {reason}. Try a more specific query."
    elif validator_name == "AnswerRelevance":
        return f"The generated answer is not relevant: {reason}. Please try rephrasing your question."
    else:
        return f"Your query does not meet our content guidelines due to: {reason}. Please try rephrasing it accordingly."

async def track_validations(stage_name: str, orchestrator: PipelineOrchestrator, task_list: cl.TaskList, context: Dict[str, Any]) -> Tuple[bool, Optional[str], Optional[str], Optional[str], Optional[List[Dict]]]:
    pipeline_execution_model = orchestrator._pipeline_execution_model
    stage_result = next((s for s in pipeline_execution_model.stages_execution_results if s.stage_name == stage_name), None)
    if not stage_result:
        logger.info(f"No stage result for '{stage_name}'.")
        return False, "Stage not executed", None, None, None

    all_passed = True
    blocking_reason = None
    blocking_guard = None
    blocking_validator = None
    error_spans = None

    for guard_exec in stage_result.guards_execution_results:
        guard_name = guard_exec.guard_config.name
        guard_task = cl.Task(title=f"🛡️ Guard: {guard_name}", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(guard_task)
        await task_list.send()

        if not hasattr(guard_exec, 'validators_execution_results'):
            logger.error(f"GuardExecutionModel for {guard_name} is missing 'validators_execution_results'")
            guard_task.status = cl.TaskStatus.FAILED
            guard_task.title += " (Missing validation results)"
            await task_list.send()
            all_passed = False
            if blocking_reason is None:
                blocking_reason = "Missing validation results"
                blocking_guard = guard_name
                blocking_validator = "N/A"
            continue

        for validator_result in guard_exec.validators_execution_results:
            validator_name = validator_result.request.validator_config.name
            validator_task = cl.Task(title=f"  🔍 Validator: {validator_name}", status=cl.TaskStatus.RUNNING)
            await task_list.add_task(validator_task)
            await task_list.send()

            # # Fix: Use dictionary key access instead of attribute access
            # if validator_result.request and 'project_name' not in validator_result.request:
            #     validator_result.request.project_name = PROJECT_NAME
            #     logger.debug(f"Set missing project_name to '{PROJECT_NAME}' for validator {validator_name}")

            if validator_result.response and validator_result.response.status == "pass":
                validator_task.status = cl.TaskStatus.DONE
                validator_task.title += " (Passed)"
            else:
                reason = validator_result.response.error_message if validator_result.response else validator_result.error_message
                reason = reason or "Validation failed"
                if validator_result.response and "details" in validator_result.response and "errorSpans" in validator_result.response.details:
                    error_spans = validator_result.response.details["errorSpans"]
                    if error_spans:
                        first_error = error_spans[0]
                        reason = f"{first_error['reason']} in '{first_error.get('text', '')}'"
                validator_task.status = cl.TaskStatus.FAILED
                validator_task.title += f" (Failed: {reason})"
                all_passed = False
                if blocking_reason is None:
                    blocking_reason = reason
                    blocking_guard = guard_name
                    blocking_validator = validator_name
            await task_list.send()

        if guard_exec.final_decision == "PASS":
            guard_task.status = cl.TaskStatus.DONE
        else:
            guard_task.status = cl.TaskStatus.FAILED
            if blocking_reason is None:
                blocking_reason = "Guard blocked"
                blocking_guard = guard_name
                blocking_validator = "N/A"
        await task_list.send()

    return all_passed, blocking_reason, blocking_guard, blocking_validator, error_spans

@cl.on_chat_start
async def start():
    """Initialize the chat session and prompt the user to upload a PDF."""
    logger.info("New chat session started.")
    task_list = cl.TaskList(status="Running...")
    await task_list.send()

    task_upload = cl.Task(title="Awaiting PDF Upload", status=cl.TaskStatus.RUNNING)
    await task_list.add_task(task_upload)
    await task_list.send()

    upload_msg = await cl.Message(content="Guardrails DEMO").send()

    start_time = time.time()
    response = await cl.AskFileMessage(
        content="Drop your PDF here to start analyzing it:",
        accept=["application/pdf"],
        max_size_mb=20,
        timeout=180
    ).send()
    end_time = time.time()
    duration = end_time - start_time

    if not response:
        logger.info("No PDF uploaded.")
        task_upload.status = cl.TaskStatus.FAILED
        task_upload.title += f" (Failed in {duration:.2f}s)"
        await task_list.send()
        task_list.status = "Failed"
        await task_list.send()
        await cl.Message(content="No file uploaded. Please try again.").send()
        return

    file = response[0]
    logger.info(f"Processing file: {file.name} at path: {file.path}")
    task_upload.status = cl.TaskStatus.DONE
    task_upload.forId = upload_msg.id
    task_upload.title += f" (Completed in {duration:.2f}s)"
    await task_list.send()

    task_split = cl.Task(title="Splitting PDF into Chunks", status=cl.TaskStatus.RUNNING)
    await task_list.add_task(task_split)
    await task_list.send()

    start_time = time.time()
    pdf_folder = os.path.dirname(file.path)
    chunks = load_and_split_pdfs(pdf_folder)
    total_chunks = len(chunks)
    end_time = time.time()
    duration = end_time - start_time
    logger.info(f"PDF split into {total_chunks} chunks.")

    if not chunks:
        logger.warning("No content extracted from PDF.")
        task_split.status = cl.TaskStatus.FAILED
        task_split.title += f" (Failed in {duration:.2f}s)"
        await task_list.send()
        task_list.status = "Failed"
        await task_list.send()
        await cl.Message(content="No readable content found in the PDF.").send()
        return

    task_split.status = cl.TaskStatus.DONE
    task_split.title += f" (Completed in {duration:.2f}s, {total_chunks} chunks)"
    await task_list.send()

    task_vector = cl.Task(title="Building Vector Database", status=cl.TaskStatus.RUNNING)
    await task_list.add_task(task_vector)
    await task_list.send()

    start_time = time.time()
    try:
        vector_db = await asyncio.to_thread(create_vector_db, chunks, embedding_gpt, PERSIST_DIRECTORY)
        logger.info(f"Vector database created with {total_chunks} chunks.")
        cl.user_session.set("vector_db", vector_db)
        # Initialize conversation_id for the session
        cl.user_session.set("conversation_id", uuid.uuid4())
        end_time = time.time()
        duration = end_time - start_time
        task_vector.status = cl.TaskStatus.DONE
        task_vector.title += f" (Completed in {duration:.2f}s, {total_chunks} chunks)"
    except Exception as e:
        logger.error(f"Error creating vector database: {str(e)}", exc_info=True)
        end_time = time.time()
        duration = end_time - start_time
        task_vector.status = cl.TaskStatus.FAILED
        task_vector.title += f" (Failed in {duration:.2f}s)"
        await task_list.send()
        task_list.status = "Failed"
        await task_list.send()
        await cl.Message(content=f"Error building vector database: {str(e)}").send()
        return
    finally:
        await task_list.send()

    task_list.status = "Done"
    await task_list.send()

    elements = [
        cl.Pdf(name=file.name, display="inline", path=file.path, page=1),
        cl.Pdf(name=file.name, display="side", path=file.path)
    ]
    actions = [
        cl.Action(name="new_pdf", label="Upload Another PDF", payload={}, tooltip="Start a new session"),
        cl.Action(name="clear_session", label="Clear Session", payload={}, tooltip="Reset the chat")
    ]
    await cl.Message(
        content=f"File `{file.name}` processed successfully. {total_chunks} chunks ready. Ask your questions below.",
        elements=elements,
        actions=actions
    ).send()

@cl.action_callback("new_pdf")
async def on_new_pdf(action):
    """Handle the 'Upload Another PDF' action."""
    logger.info("User requested a new PDF upload.")
    await action.remove()
    await start()

@cl.action_callback("clear_session")
async def on_clear_session(action):
    """Handle the 'Clear Session' action."""
    logger.info("Clearing session.")
    cl.user_session.set("vector_db", None)
    cl.user_session.set("conversation_id", None)
    await action.remove()
    await cl.Message(content="Session cleared. Upload a new PDF to start again.").send()
    await start()

@cl.on_message
async def main(message: cl.Message):
    """Process user messages through the pipeline stages with detailed task tracking."""
    logger.info(f"Starting message processing for query: {message.content}")
    vector_db = cl.user_session.get("vector_db")

    if not vector_db:
        logger.error("No vector database available.")
        await cl.Message(content="Please upload a PDF first to start chatting.").send()
        return

    config_path = os.environ.get("GUARDCONFIG_PATH")
    if not config_path:
        logger.error("GUARDCONFIG_PATH not set in environment.")
        await cl.Message(content="Configuration error: GUARDCONFIG_PATH not set.").send()
        return

    try:
        orchestrator = setup_orchestrator(config_path)
        await orchestrator.start_pipeline()

        task_list = cl.TaskList(status="Running...")
        await task_list.send()

        pipeline_start_time = datetime.now()
        context = {}  # External context to store stage outputs
        conversation_id = cl.user_session.get("conversation_id") or uuid.uuid4()
        cl.user_session.set("conversation_id", conversation_id)  # Persist across messages

        # --- Input Stage ---
        task_input = cl.Task(title="Processing Input", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_input)
        await task_list.send()
        start_time = time.time()
        query = message.content
        context["query"] = query
        input_data = {
            "value": query,
            "metadata": {"content_type": "text"},
            "conversation_id": conversation_id
        }
        await orchestrator.execute_stage("input", input_data)
        end_time = time.time()
        duration = end_time - start_time
        task_input.status = cl.TaskStatus.DONE
        task_input.title += f" (Completed in {duration:.2f}s)"
        await task_list.send()
        passed, reason, guard, validator, error_spans = await track_validations("input", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Input Validation Failed: {reason}", status=cl.TaskStatus.FAILED)
            await task_list.add_task(fail_task)
            total_time = (datetime.now() - pipeline_start_time).total_seconds()
            summary_tasks = [
                cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED),
            ]
            for task in summary_tasks:
                await task_list.add_task(task)
            task_list.status = "Failed"
            await task_list.send()
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at input stage for query: {message.content}")
            await orchestrator.complete_pipeline()
            return

        # --- Retrieval Stage ---
        task_retrieval = cl.Task(title="Retrieving Documents", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_retrieval)
        await task_list.send()
        start_time = time.time()
        retrieved_docs = vector_db.similarity_search(query, k=4)
        unique_documents = []
        seen_content = set()
        for doc in retrieved_docs:
            content = doc.page_content
            if content not in seen_content:
                seen_content.add(content)
                unique_documents.append(content)
            if len(unique_documents) >= 2:
                break
        if not unique_documents:
            unique_documents = [doc.page_content for doc in retrieved_docs[:2]]
        context["documents"] = unique_documents
        retrieval_data = {
            "value": query,
            "metadata": {"Chunks": unique_documents},
            "conversation_id": conversation_id
        }
        await orchestrator.execute_stage("retrieval", retrieval_data)
        end_time = time.time()
        duration = end_time - start_time
        task_retrieval.status = cl.TaskStatus.DONE
        task_retrieval.title += f" (Completed in {duration:.2f}s, {len(unique_documents)} chunks)"
        await task_list.send()
        passed, reason, guard, validator, error_spans = await track_validations("retrieval", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Retrieval Validation Failed: {reason}", status=cl.TaskStatus.FAILED)
            await task_list.add_task(fail_task)
            total_time = (datetime.now() - pipeline_start_time).total_seconds()
            summary_tasks = [
                cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED),
            ]
            for task in summary_tasks:
                await task_list.add_task(task)
            task_list.status = "Failed"
            await task_list.send()
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at retrieval stage for query: {message.content}")
            await orchestrator.complete_pipeline()
            return

        # --- Output Stage ---
        task_output = cl.Task(title="Generating Response", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_output)
        await task_list.send()
        start_time = time.time()
        context_str = "\n".join(unique_documents)
        prompt = f"Context: {context_str}\nQuestion: {query}"
        response = chat_gpt._generate([HumanMessage(content=prompt)])
        answer = response.generations[0].message.content
        context["answer"] = answer
        output_data = {
            "value": query,
            "metadata": {"Chunks": unique_documents, "Answer": answer},
            "conversation_id": conversation_id
        }
        await orchestrator.execute_stage("output", output_data)
        end_time = time.time()
        duration = end_time - start_time
        task_output.status = cl.TaskStatus.DONE
        task_output.title += f" (Completed in {duration:.2f}s)"
        await task_list.send()
        passed, reason, guard, validator, error_spans = await track_validations("output", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Output Validation Failed: {reason}", status=cl.TaskStatus.FAILED)
            await task_list.add_task(fail_task)
            total_time = (datetime.now() - pipeline_start_time).total_seconds()
            summary_tasks = [
                cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED),
            ]
            for task in summary_tasks:
                await task_list.add_task(task)
            task_list.status = "Failed"
            await task_list.send()
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at output stage for query: {message.content}")
            await orchestrator.complete_pipeline()
            return

        # Finalize Pipeline
        await orchestrator.complete_pipeline()
        logger.info(f"Pipeline completed successfully for query: {message.content}")

        # Final Validation Summary
        total_time = (datetime.now() - pipeline_start_time).total_seconds()
        summary_tasks = [
            cl.Task(title="Final Validation Summary: Completed Successfully", status=cl.TaskStatus.DONE),
            cl.Task(title=f"Total Time: {total_time:.2f}s", status=cl.TaskStatus.DONE),
        ]
        for task in summary_tasks:
            await task_list.add_task(task)
        task_list.status = "Done"
        await task_list.send()
        actions = [cl.Action(name="clear_session", label="Clear Session", payload={}, tooltip="Reset the chat")]
        await cl.Message(content=answer, actions=actions).send()

    except Exception as e:
        logger.error(f"Error in pipeline execution for query {message.content}: {str(e)}", exc_info=True)
        total_time = (datetime.now() - pipeline_start_time).total_seconds()
        summary_tasks = [
            cl.Task(title="Final Validation Summary: Failed due to unexpected error", status=cl.TaskStatus.FAILED),
            cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
            cl.Task(title=f"Error: {str(e)}", status=cl.TaskStatus.FAILED),
        ]
        for task in summary_tasks:
            await task_list.add_task(task)
        task_list.status = "Failed"
        await task_list.send()
        await cl.Message(content=f"Sorry, an unexpected error occurred: {str(e)}. Please try again later.").send()

if __name__ == "__main__":
    logger.info("Chainlit application launched.")