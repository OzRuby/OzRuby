import os
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from aitrust.monitoring.logs import logger

def load_and_split_pdfs(pdf_folder: str) -> list:
    """
    Load PDF files from a folder and split them into chunks.

    Args:
        pdf_folder (str): Path to the folder containing PDF files.

    Returns:
        list: List of document chunks.
    """
    pdf_files = [os.path.join(pdf_folder, f) for f in os.listdir(pdf_folder) if f.endswith(".pdf")]
    if not pdf_files:
        logger.warning(f"No PDF files found in {pdf_folder}")
        return []

    all_chunks = []
    for pdf_file in pdf_files:
        logger.info(f"Processing PDF: {pdf_file}")
        try:
            loader = PyPDFLoader(pdf_file)
            documents = loader.load()
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
            chunks = text_splitter.split_documents(documents)
            logger.info(f"Split {pdf_file} into {len(chunks)} chunks")
            all_chunks.extend(chunks)
        except Exception as e:
            logger.error(f"Error processing {pdf_file}: {str(e)}")
    return all_chunks