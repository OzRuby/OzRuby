import os
from langchain_community.vectorstores import Chroma
from aitrust.monitoring.logs import logger

def create_vector_db(chunks: list, embeddings, persist_directory: str) -> Chroma:
    """
    Create a vector database from document chunks using embeddings.

    Args:
        chunks (list): List of document chunks.
        embeddings: Embedding function (e.g., SecureGPT instance).
        persist_directory (str): Directory to persist the vector store.

    Returns:
        Chroma: Initialized vector database.

    Raises:
        Exception: If vector database creation fails.
    """
    logger.info("Creating vector database")
    try:
        # Ensure the persist_directory exists
        os.makedirs(persist_directory, exist_ok=True)
        
        vector_db = Chroma.from_documents(
            documents=chunks,
            embedding=embeddings,
            persist_directory=persist_directory
        )
        logger.info("Vector database created successfully")
        return vector_db
    except Exception as e:
        logger.error(f"Error creating vector database: {str(e)}", exc_info=True)
        raise

def load_vector_db(persist_directory: str, embeddings) -> Chroma:
    """
    Load an existing vector database.

    Args:
        persist_directory (str): Directory where the vector store is persisted.
        embeddings: Embedding function (e.g., SecureGPT instance).

    Returns:
        Chroma: Loaded vector database.

    Raises:
        Exception: If vector database loading fails.
    """
    logger.info("Loading vector database")
    try:
        vector_db = Chroma(
            persist_directory=persist_directory,
            embedding_function=embeddings
        )
        logger.info("Vector database loaded successfully")
        return vector_db
    except Exception as e:
        logger.error(f"Error loading vector database: {str(e)}", exc_info=True)
        raise