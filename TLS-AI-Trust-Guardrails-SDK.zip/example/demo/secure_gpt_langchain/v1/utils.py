from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator, Callable, Mapping
from typing import (
  Any,
  cast,
)

from httpx import RequestError, StreamError
from httpx_sse import EventSource, aconnect_sse
from langchain_core.callbacks import (
  AsyncCallbackManagerForLLMRun,
  CallbackManagerForLLMRun,
)
from langchain_core.language_models.llms import create_base_retry_decorator
from langchain_core.messages import (
  AIMessage,
  AIMessageChunk,
  BaseMessage,
  BaseMessageChunk,
  ChatMessage,
  ChatMessageChunk,
  HumanMessage,
  HumanMessageChunk,
  SystemMessage,
  SystemMessageChunk,
)

from ..config import settings


def _convert_delta_to_message_chunk(
  _dict: Mapping[str, Any], default_class: type[BaseMessageChunk]
) -> BaseMessageChunk:
  role = cast(str, _dict.get("role"))
  content = cast(str, _dict.get("content") or "")

  if role == "user" or default_class == HumanMessageChunk:
    return HumanMessageChunk(content=content)
  elif role == "assistant" or default_class == AIMessageChunk:
    return AIMessageChunk(content=content)
  elif role == "system" or default_class == SystemMessageChunk:
    return SystemMessageChunk(content=content)
  elif role or default_class == ChatMessageChunk:
    return ChatMessageChunk(content=content, role=role)
  else:
    return default_class(content=content)  # type: ignore


def _convert_dict_to_message(_dict: Mapping[str, Any]) -> BaseMessage:
  """Convert a dictionary to a LangChain message.

  Args:
      _dict: The dictionary.

  Returns:
      The LangChain message.
  """
  role = _dict.get("role")
  if role == "user":
    return HumanMessage(content=_dict.get("content", ""))
  elif role == "assistant":
    return AIMessage(content=_dict.get("content", ""))
  elif role == "system":
    return SystemMessage(content=_dict.get("content", ""))
  else:
    return ChatMessage(content=_dict.get("content", ""), role=role)


def _convert_message_to_dict(message: BaseMessage) -> dict:
  """Convert a LangChain message to a dictionary.

  Args:
      message: The LangChain message.

  Returns:
      The dictionary.
  """
  message_dict: dict[str, Any]
  if isinstance(message, ChatMessage):
    message_dict = {"role": message.role, "content": message.content}
  elif isinstance(message, HumanMessage):
    message_dict = {"role": "user", "content": message.content}
  elif isinstance(message, AIMessage):
    message_dict = {"role": "assistant", "content": message.content}
  elif isinstance(message, SystemMessage):
    message_dict = {"role": "system", "content": message.content}
  else:
    raise TypeError(f"Got unknown type {message}")
  return message_dict


def _create_retry_decorator(
  max_retries: int = settings.http.max_retries,
  run_manager: AsyncCallbackManagerForLLMRun | CallbackManagerForLLMRun | None = None,
) -> Callable[[Any], Any]:
  """Returns a tenacity retry decorator, pre-configured to handle exceptions"""
  errors = [RequestError, StreamError]
  return create_base_retry_decorator(error_types=errors, max_retries=max_retries, run_manager=run_manager)


async def _aiter_sse(
  event_source_mgr: contextlib.AbstractAsyncContextManager[EventSource],
) -> AsyncIterator[dict]:
  """Iterate over the server-sent events."""
  async with event_source_mgr as event_source:
    async for event in event_source.aiter_sse():
      if event.data == "[DONE]":
        return
      if event.data == "":
        continue
      yield event.json()


async def acompletion_with_retry(
  llm: Any,
  run_manager: AsyncCallbackManagerForLLMRun | None = None,
  **kwargs: Any,
) -> Any:
  """Use tenacity to retry the async completion call."""
  headers = settings.http.basic_headers
  headers["Authorization"] = f"Bearer {await llm.get_access_token_async()}"
  retry_decorator = _create_retry_decorator(llm, run_manager=run_manager)

  @retry_decorator
  async def _completion_with_retry(**kwargs: Any) -> Any:
    if llm.streaming:
      delete_keys = "streaming"
      if delete_keys in kwargs:
        kwargs.pop(delete_keys)

      event_source = aconnect_sse(
        llm.async_client,
        "POST",
        f"{llm.secure_gpt_api_base}/deployments/{llm.deployment_id}/stream/chat/completions",
        json=kwargs,
        headers=headers,
      )

      return _aiter_sse(event_source)
    else:
      response = await llm.async_client.post(
        url=f"{llm.secure_gpt_api_base}/deployments/{llm.deployment_id}/chat/completions",
        json=kwargs,
        headers=headers,
      )
      return response.json()

  return await _completion_with_retry(**kwargs)
