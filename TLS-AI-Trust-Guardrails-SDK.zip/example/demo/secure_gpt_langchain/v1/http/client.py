from urllib.parse import urljoin

from httpx import AsyncClient, Client, HTTPStatusError
from loguru import logger

from ...config import settings


class HttpClient:
  """
  HttpClient provides synchronous and asynchronous methods to make HTTP GET requests.
  """

  def __init__(self, timeout: int = settings.http.timeout):
    self.timeout = timeout

  async def get_async(self, host: str, path: str = "") -> dict | HTTPStatusError:
    """
    Asynchronous GET request.

    Args:
        host (str): The host to make the request to.
        path (str, optional): The path to append to the host URL. Defaults to "".

    Returns:
        dict | HTTPStatusError: The JSON response or an HTTP error.
    """
    url = urljoin(host, path)

    async with AsyncClient(verify=False, timeout=self.timeout) as client:
      try:
        response = await client.get(url)
        response.raise_for_status()
        logger.info(f"[+] Request made. [url={url}] - [status_code={response.status_code}]")
        return response.json()
      except HTTPStatusError as err:
        logger.error(f"[-] HTTP error occurred. [url={url}] - [status_code={err.response.status_code}]")
        return err

  def get(self, host: str, path: str = "") -> dict | HTTPStatusError:
    """
    Synchronous GET request.

    Args:
        host (str): The host to make the request to.
        path (str, optional): The path to append to the host URL. Defaults to "".

    Returns:
        dict | HTTPStatusError: The JSON response or an HTTP error.
    """
    url = urljoin(host, path)

    with Client(verify=False, timeout=self.timeout) as client:
      try:
        response = client.get(url)
        response.raise_for_status()
        logger.info(f"[+] Request made. [url={url}] - [status_code={response.status_code}]")
        return response.json()
      except HTTPStatusError as e:
        logger.error(f"[-] HTTP error occurred. [url={url}] - [status_code={e.response.status_code}]")
        return e

  async def post_async(self):
    pass

  def post(self):
    pass
