import asyncio
import os
from collections.abc import Callable

import httpx
from httpx._client import BaseClient
from langchain_core.embeddings import Embeddings
from langchain_core.pydantic_v1 import BaseModel, Extra, root_validator
from langchain_core.runnables.config import run_in_executor


class SecureGptEmbeddings(BaseModel, Embeddings):
  model_name: str = "text-embedding-ada-002-2"
  endpoint_url: str | None = None
  api_key: str | None = None
  get_access_token: Callable[[], str] | None = None
  httpx_client: BaseClient | None = None
  httpx_async_client: BaseClient | None = None

  class Config:
    """Configuration for this pydantic object."""

    extra = Extra.forbid
    arbitrary_types_allowed = True

  @root_validator(pre=True)
  def validate_environment(cls, values: dict) -> dict:
    if "endpoint_url" not in values:
      raise ValueError("Missing endpoint_url in environment")

    if "httpx_client" not in values:
      cls.httpx_client = httpx.Client(verify=False)

    if "httpx_client" not in values:
      cls.httpx_async_client = httpx.Client(verify=False)

    return values

  def _embedding_func(self, text: str) -> list[float]:
    # replace newlines, which can negatively affect performance.
    text = text.replace(os.linesep, " ")

    # format input body for provider
    model_name = self.model_name
    input_body = {"input": text}

    try:
      # invoke secureGPT API
      api_key = self.api_key
      if self.get_access_token:
        api_key = self.get_access_token()

      response = self.httpx_client.post(
        f"{self.endpoint_url}/deployments/{model_name}/embeddings",
        json=input_body,
        headers={"Authorization": f"Bearer {api_key}"},
      )

      # format output based on provider
      response_body = response.json()
      return response_body.get("data")[0].get("embedding")
    except Exception as e:
      raise ValueError(f"Error raised by inference endpoint: {e}")

  def embed_documents(self, texts: list[str]) -> list[list[float]]:
    """Compute doc embeddings using a Bedrock model.

    Args:
        texts: The list of texts to embed

    Returns:
        List of embeddings, one for each text.
    """
    results = []
    for text in texts:
      response = self._embedding_func(text)
      results.append(response)

    return results

  def embed_query(self, text: str) -> list[float]:
    """Compute query embeddings using a Bedrock model.

    Args:
        text: The text to embed.

    Returns:
        Embeddings for the text.
    """
    embedding = self._embedding_func(text)

    return embedding

  async def aembed_query(self, text: str) -> list[float]:
    """Asynchronous compute query embeddings using a Bedrock model.

    Args:
        text: The text to embed.

    Returns:
        Embeddings for the text.
    """

    return await run_in_executor(None, self.embed_query, text)

  async def aembed_documents(self, texts: list[str]) -> list[list[float]]:
    """Asynchronous compute doc embeddings using a Bedrock model.

    Args:
        texts: The list of texts to embed

    Returns:
        List of embeddings, one for each text.
    """

    result = await asyncio.gather(*[self.aembed_query(text) for text in texts])

    return list(result)
