from datetime import datetime
from typing import Any

from jwskate import ExpiredJwt, InvalidClaim, InvalidJwt, InvalidSignature, Jwt
from pydantic import BaseModel, Field

from ...config import settings
from ..http.client import HttpClient


class AuthenticationSchema(BaseModel):
  """
  Schema representing the authentication response.
  """

  success: bool = Field(..., description="Indicates whether the authentication was successful.")
  error: str = Field("", description="Error message in case of an authentication failure.")
  payload: dict | None = Field(default=None, description="Additional data returned with the authentication response.")


class Authentication:
  """
  Handles authentication processes including fetching and validating JSON Web Keys (JWKs) and tokens.
  """

  def __init__(self, api_audience: str | None = None):
    """
    Initializes the Authentication instance.

    Args:
        api_audience (Optional[str]): The API audience for authentication.
    """
    self.client = HttpClient()

    self.api_audience = api_audience
    self.cache_timestamp = 0
    self.cache_jwks: dict[str, Any] | None = None  # type: ignore
    self.cache_token_endpoint: str | None = None

    self.algorithms = settings.jwt_algorithms
    self.scopes = settings.credentials_scope
    self.issuer = settings.one_account

  async def get_token_endpoint_async(self) -> str | None:
    """
    Asynchronously fetches the token endpoint URL.

    Returns:
        str: The token endpoint URL.
    """
    await self._get_jwks_async()
    return self.cache_token_endpoint  # type: ignore

  def get_token_endpoint(self) -> str | None:
    """
    Synchronously fetches the token endpoint URL.

    Returns:
        str: The token endpoint URL.
    """
    self._get_jwks()
    return self.cache_token_endpoint

  async def validate_async(self, token: str) -> AuthenticationSchema:
    """
    Asynchronously validates a JWT token.

    Args:
        token (str): The JSON Web Token to be validated.

    Returns:
        AuthenticationSchema: The result of the authentication process.
    """
    jwks = await self._get_jwks_async()
    return self._validate_jwk(token, jwks)

  def validate(self, token: str) -> AuthenticationSchema:
    """
    Synchronously validates a JWT token.

    Args:
        token (str): The JSON Web Token to be validated.

    Returns:
        AuthenticationSchema: The result of the authentication process.
    """
    jwks = self._get_jwks()

    return self._validate_jwk(token, jwks)

  def _validate_jwk(self, token: str, jwks: dict) -> AuthenticationSchema:
    """
    Validates a JWT against a set of JWKs and returns the authentication result.

    Args:
        token (str): The JSON Web Token to be validated.
        jwks (dict): The JSON Web Key Set used to validate the JWT.

    Returns:
        AuthenticationSchema: The result of the authentication process.
    """
    try:
      jwt = Jwt(token)

      if jwt.headers["alg"].upper() not in self.algorithms:
        return AuthenticationSchema(success=False, error="Wrong algorithm used.")

      jwk_key = self._find_jwk(jwks, jwt)

      if jwk_key is None:
        return AuthenticationSchema(success=False, error="JWK key not found.")

      for scope in self.scopes:
        if scope not in jwt.claims["scope"].split(" "):
          return AuthenticationSchema(success=False, error="Scope not found.")

      if jwt.validate(jwk_key, issuer=self.issuer, audience=self.api_audience):
        return AuthenticationSchema(success=False, error="Signature verification failed.")

      return AuthenticationSchema(success=True, payload=jwt.claims)
    except (InvalidJwt, InvalidSignature, InvalidClaim, ExpiredJwt, ValueError, KeyError) as err:
      return AuthenticationSchema(success=False, error=str(err))

  def _get_timestamp_and_expiration_seconds(self) -> tuple[float, int]:
    """
    Returns the current timestamp one day seconds.

    Returns:
        tuple(float, int): The current timestamp.
    """
    return datetime.timestamp(datetime.now()), settings.jwt_expiration

  async def _get_jwks_async(self) -> dict[str, Any] | None:
    """
    Asynchronously fetches the JSON Web Key Set (JWKS).

    Returns:
        dict[str, Any]: The JSON Web Key Set.
    """
    timestamp, expiration = self._get_timestamp_and_expiration_seconds()

    if self.cache_timestamp + expiration < timestamp:
      well_know_url = await self.client.get_async(host=self.issuer, path="/.well-known/openid-configuration")

      self.cache_jwks = await self.client.get_async(host=well_know_url["jwks_uri"])
      self.cache_token_endpoint = well_know_url["token_endpoint"]
      self.cache_timestamp = timestamp

    return self.cache_jwks

  def _get_jwks(self) -> dict[str, Any]:
    """
    Synchronously fetches the JSON Web Key Set (JWKS).

    Returns:
        Dict[str, Any]: The JSON Web Key Set.
    """
    timestamp, expiration = self._get_timestamp_and_expiration_seconds()

    if self.cache_timestamp + expiration < timestamp:
      well_know_url = self.client.get(host=self.issuer, path="/.well-known/openid-configuration")

      self.cache_jwks = self.client.get(host=well_know_url["jwks_uri"])
      self.cache_token_endpoint = well_know_url["token_endpoint"]
      self.cache_timestamp = float(timestamp)

    return self.cache_jwks

  def _find_jwk(self, jwks: dict, jwt: Jwt) -> dict | None:
    """
    Finds the JSON Web Key (JWK) that matches the JWT from a JSON Web Key Set (JWKS).

    Args:
        jwks (Dict): The JSON Web Key Set containing the keys.
        jwt (Jwt): The JSON Web Token that needs to be validated.

    Returns:
        dict | None: The matching JWK key if found, otherwise None.
    """
    key = next((key for key in jwks["keys"] if key["kid"] == jwt.headers["kid"]), None)

    return (
      {
        "kty": key["kty"],
        "kid": key["kid"],
        "use": key["use"],
        "alg": key["alg"],
        "n": key["n"],
        "e": key["e"],
      }
      if key
      else None
    )
