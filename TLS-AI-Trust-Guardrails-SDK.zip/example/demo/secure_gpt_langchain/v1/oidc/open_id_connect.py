from requests_oauth2client import OAuth2Client

from ...config import settings
from .authentication import Authentication


class OpenIdConnect:
  """
  OpenIdConnect handles the acquisition and validation of access tokens using OAuth2.
  """

  def __init__(
    self,
    client_id: str = settings.client_id,
    client_secret: str = settings.client_secret,
    api_audience: None | str = None,
  ):
    """
    Initializes the OpenIdConnect instance with client credentials and an authentication handler

    Args:
        client_id (str): The client ID for OAuth2 authentication.
        client_secret (str): The client secret for OAuth2 authentication.
        api_audience (str | None): The expected audience for the access_token.
    """
    self.client_id = client_id
    self.client_secret = client_secret
    self.access_token = settings.access_token
    self.credentials_scope = settings.credentials_scope
    self.auth = Authentication(api_audience=api_audience)

  def get_access_token(self):
    """
    Retrieves a valid access token synchronously.
    If the current token is valid, it returns that token.
    Otherwise, it fetches a new token.

    Returns:
        str: The access token.
    """
    token_endpoint = self.auth.get_token_endpoint()

    if self.access_token:
      validation_result = self.auth.validate(self.access_token)
      if validation_result.success:
        return self.access_token

    self.access_token = self._get_access_token(token_endpoint)
    return self.access_token

  async def get_access_token_async(self):
    """
    Retrieves a valid access token asynchronously.
    If the current token is valid, it returns that token.
    Otherwise, it fetches a new token.

    Returns:
        str: The access token.
    """
    token_endpoint = await self.auth.get_token_endpoint_async()

    if self.access_token:
      validation_result = await self.auth.validate_async(self.access_token)
      if validation_result.success:
        return self.access_token

    return self._get_access_token(token_endpoint)

  def _get_access_token(self, token_endpoint: str):
    """
    Fetches a new access token synchronously using the client credentials.

    Args:
        token_endpoint (str): The endpoint to request the token from.

    Returns:
        str: The new access token.
    """
    oauth2client = OAuth2Client(token_endpoint=token_endpoint, auth=(self.client_id, self.client_secret))
    token = oauth2client.client_credentials(scope=self.credentials_scope)
    self.access_token = token.access_token
    return self.access_token
