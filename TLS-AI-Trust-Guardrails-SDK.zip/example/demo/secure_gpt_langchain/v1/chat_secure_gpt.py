from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import (
  Any,
  cast,
)

from httpx import AsyncClient, Client
from httpx_sse import connect_sse
from langchain_core.callbacks import (
  AsyncCallbackManagerForLLMRun,
  CallbackManagerForLLMRun,
)
from langchain_core.language_models.chat_models import (  # type: ignore
  BaseChatModel,
  agenerate_from_stream,
  generate_from_stream,
)
from langchain_core.messages import (
  AIMessageChunk,
  BaseMessage,
  BaseMessageChunk,
)
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult  # type: ignore
from langchain_core.pydantic_v1 import Extra, root_validator

from ..config import settings
from .oidc import OpenIdConnect
from .utils import (  # type: ignore
  _convert_delta_to_message_chunk,
  _convert_dict_to_message,
  _convert_message_to_dict,
  acompletion_with_retry,
)

GPT_TIMEOUT = 120


class ChatSecureGPT(BaseChatModel):
  secure_gpt_api_base: str
  secure_gpt_access_token: str | None = None
  deployment_id: str
  streaming: bool = False
  timeout: int = GPT_TIMEOUT
  temperature: float = 0.7
  client: Client | None = None
  async_client: AsyncClient | None = None

  access_token_async = OpenIdConnect().get_access_token_async
  access_token = OpenIdConnect().get_access_token

  @property
  def _default_params(self) -> dict[str, Any]:
    """Get the default parameters for calling the API."""
    return {}

  @property
  def _identifying_params(self) -> dict[str, Any]:
    """Get the identifying parameters."""
    return self._default_params

  def _llm_type(self):
    """Return a string identifier of the model."""
    return "SecureGPT-chat"

  @classmethod
  def is_lc_serializable(cls) -> bool:
    """Return whether this model can be serialized by Langchain."""
    return True

  @classmethod
  def get_lc_namespace(cls) -> list[str]:
    """Get the namespace of the langchain object."""
    return ["langchain", "chat_models", "secure_gpt"]

  class Config:
    """Configuration for this pydantic object."""

    extra = Extra.forbid
    arbitrary_types_allowed = True

  async def get_access_token_async(self):
    return await self.access_token_async()

  def get_access_token(self):
    return self.access_token()

  @root_validator(pre=True)
  def validate_environment(cls, values: dict) -> dict:
    headers = settings.http.basic_headers
    if "secure_gpt_access_token" in values:
      headers["Authorization"] = f"Bearer {values['secure_gpt_access_token']}"
    if "timeout" not in values:
      values["timeout"] = GPT_TIMEOUT

    values["client"] = Client(
      base_url=values["secure_gpt_api_base"],
      headers=headers,
      timeout=values["timeout"],
      verify=False,
    )
    values["async_client"] = AsyncClient(
      base_url=values["secure_gpt_api_base"],
      headers=headers,
      timeout=values["timeout"],
      verify=False,
    )
    cls.update_forward_refs(**values)
    return values

  def handle_events(self, event_source):
    for event in event_source.iter_sse():
      if event.data == "":
        continue
      if event.data == "[DONE]":
        return
      yield event.json()

  def completion_with_retry(self, run_manager: CallbackManagerForLLMRun | None = None, **kwargs: Any) -> Any:
    token = self.secure_gpt_access_token
    if not token:
      token = self.get_access_token()

    def _completion_with_retry(**kwargs: Any) -> Any:
      if self.streaming or kwargs.get("streaming"):
        kwargs["headers"] = {"Authorization": f"Bearer {token}"}
        kwargs.pop("streaming")

        def iter_sse() -> Iterator[dict]:
          with connect_sse(
            self.client,
            "POST",
            f"deployments/{self.deployment_id}/stream/chat/completions",
            json=kwargs,
          ) as event_source:
            yield self.handle_events(event_source)

        return iter_sse()
      else:
        return self.client.post(url=f"deployments/{self.deployment_id}/chat/completions", json=kwargs).json()

    return _completion_with_retry(**kwargs)

  def _generate(
    self,
    messages: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: CallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> ChatResult:
    if self.streaming or kwargs.get("streaming"):
      stream_iter = self._stream(messages, run_manager=run_manager, **kwargs)
      return generate_from_stream(stream_iter)
    message_dicts, params = self._create_message_dicts(messages, stop=stop)
    params = {**params, **kwargs}

    response = self.completion_with_retry(messages=message_dicts, run_manager=run_manager, **params)
    return self._create_chat_result(response)

  def _create_chat_result(self, response: dict) -> ChatResult:
    generations = []
    for res in response["choices"]:
      finish_reason = res.get("finish_reason")
      gen = ChatGeneration(
        message=_convert_dict_to_message(res["message"]),
        generation_info={"finish_reason": finish_reason},
      )
      generations.append(gen)
    token_usage = response.get("usage", {})

    llm_output = {"token_usage": token_usage, "model": self.deployment_id}
    return ChatResult(generations=generations, llm_output=llm_output)

  def _create_message_dicts(
    self,
    messages: list[BaseMessage],
    stop: list[str] | None = None,
  ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    params = self._default_params
    if stop is not None:
      params["stop"] = stop
    message_dicts = [_convert_message_to_dict(m) for m in messages]
    return message_dicts, params

  def _stream(
    self,
    messages: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: CallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> Iterator[ChatGenerationChunk]:
    message_dicts, params = self._create_message_dicts(messages, stop=stop)
    params = {**params, **kwargs, "streaming": True}

    default_chunk_class: type[BaseMessageChunk] = AIMessageChunk
    for chunks in self.completion_with_retry(messages=message_dicts, run_manager=run_manager, **params):
      for chunk in chunks:
        if isinstance(chunk, str) or len(chunk.get("choices", [])) == 0:
          continue
        choice = chunk["choices"][0]
        delta = choice["delta"]
        new_chunk = _convert_delta_to_message_chunk(delta, default_chunk_class)
        default_chunk_class = new_chunk.__class__
        finish_reason = choice.get("finish_reason")
        gen_chunk = ChatGenerationChunk(
          message=new_chunk,
          generation_info={"finish_reason": finish_reason} if finish_reason is not None else None,
        )
        if run_manager:
          run_manager.on_llm_new_token(token=cast(str, new_chunk.content), chunk=gen_chunk)
        yield gen_chunk

  async def _astream(
    self,
    messages: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: AsyncCallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> AsyncIterator[ChatGenerationChunk]:
    message_dicts, params = self._create_message_dicts(messages, stop=stop)
    params = {**params, **kwargs, "streaming": True}

    default_chunk_class: type[BaseMessageChunk] = AIMessageChunk

    async for chunk in await acompletion_with_retry(self, messages=message_dicts, run_manager=run_manager, **params):
      if len(chunk["choices"]) == 0:
        continue

      choice = chunk["choices"][0]
      delta = choice["delta"]
      new_chunk = _convert_delta_to_message_chunk(delta, default_chunk_class)
      default_chunk_class = new_chunk.__class__
      finish_reason = choice.get("finish_reason")
      gen_chunk = ChatGenerationChunk(
        message=new_chunk,
        generation_info={"finish_reason": finish_reason} if finish_reason is not None else None,
      )

      if run_manager:
        await run_manager.on_llm_new_token(token=cast(str, new_chunk.content), chunk=gen_chunk)
      yield gen_chunk

  async def _agenerate(
    self,
    messages: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: AsyncCallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> ChatResult:
    if self.streaming or kwargs.get("streaming"):
      stream_iter = self._astream(messages=messages, run_manager=run_manager, **kwargs)
      return await agenerate_from_stream(stream_iter)

    message_dicts, params = self._create_message_dicts(messages, stop=stop)
    params = {**params, **kwargs}
    response = await acompletion_with_retry(self, messages=message_dicts, run_manager=run_manager, **params)

    return self._create_chat_result(response)

  def __str__(self):
    """Provides a string representation of the ChatSecureGPT instance,
    showing the deployment ID.

    Returns:
        str: The string representation of the instance.
    """
    return f"ChatSecureGPT(deployment_id={self.deployment_id})"
