from .base_bapi import PromptType
from .chat_completion_bapi import ChatCompletionBAPI
from .embedding_bapi import EmbeddingBAPI


class SecureGPT(ChatCompletionBAPI, EmbeddingBAPI):
  """
  A class that combines chat completion and embedding functionalities using the SecureGPT BAPI.

  This class inherits from both ChatCompletionBAPI and EmbeddingBAPI, providing methods for generating
  chat completions and embeddings, both synchronously and asynchronously.

  Attributes:
      deployment_id (str): The ID of the model deployment, defaulting to "gpt-35-turbo-0301".
      prompt_type (PromptType): The type of prompt to use, defaulting to "CHAT_COMPLETIONS".
  """

  def __init__(self, deployment_id: str = "gpt-35-turbo-0301", prompt_type: str | PromptType = "CHAT_COMPLETIONS"):
    """
    Initialize the SecureGPT class with deployment ID and prompt type.

    Args:
        deployment_id (str): The ID of the model deployment. Default is "gpt-35-turbo-0301".
        prompt_type (Union[str, PromptType]): The type of prompt to use. Default is "CHAT_COMPLETIONS".
    """
    super().__init__()
    self.deployment_id = deployment_id
    self.prompt_type = prompt_type
