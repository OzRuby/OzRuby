from collections.abc import AsyncIterator, Iterator
from typing import Any, cast

from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.messages import (
  AIMessageChunk,
  BaseMessage,
)
from langchain_core.outputs import ChatGenerationChunk, ChatResult

from .base_bapi import BaseBAPI


class ChatCompletionBAPI(BaseBAPI):
  """
  A class representing a chat completion interface for the SecureGPT BAPI.

  This class provides synchronous and asynchronous methods for generating chat completions,
  streaming chat completions, and identifying model parameters.
  """

  def _generate(
    self,
    prompts: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: CallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> ChatResult:
    """
    Generate a chat completion for the given prompts synchronously.

    Args:
        prompts (list[BaseMessage]): A list of messages to generate a response for.
        stop (list[str] | None): A list of stop words (not used in this implementation).
        run_manager (CallbackManagerForLLMRun | None): A callback manager for managing the run.
        **kwargs (Any): Additional keyword arguments.

    Returns:
        ChatResult: The result of the chat generation.

    Raises:
        ValueError: If stop is not None.
    """
    if stop is not None:
      raise ValueError("stop kwargs are not permitted.")

    payload = [self._parse_bapi_message(prompt) for prompt in prompts]
    response = self.sync_bapi_call(payload)

    return ChatResult(
      generations=self._parse_bapi_chat_generations(response),
      llm_output={"token_usage": response.get("usage", {}), "model": self.deployment_id},
    )

  async def _agenerate(
    self,
    prompts: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: CallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> ChatResult:
    """
    Generate a chat completion for the given prompts asynchronously.

    Args:
        prompts (list[BaseMessage]): A list of messages to generate a response for.
        stop (list[str] | None): A list of stop words (not used in this implementation).
        run_manager (CallbackManagerForLLMRun | None): A callback manager for managing the run.
        **kwargs (Any): Additional keyword arguments.

    Returns:
        ChatResult: The result of the chat generation.

    Raises:
        ValueError: If stop is not None.
    """
    if stop is not None:
      raise ValueError("stop kwargs are not permitted.")

    payload = [self._parse_bapi_message(prompt) for prompt in prompts]
    response = await self.async_bapi_call(payload)

    return ChatResult(
      generations=self._parse_bapi_chat_generations(response),
      llm_output={"token_usage": response.get("usage", {}), "model": self.deployment_id},
    )

  def _stream(
    self,
    prompts: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: CallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> Iterator[ChatGenerationChunk]:
    """
    Stream chat completions for the given prompts synchronously.

    Args:
        prompts (list[BaseMessage]): A list of messages to generate a response for.
        stop (list[str] | None): A list of stop words (not used in this implementation).
        run_manager (CallbackManagerForLLMRun | None): A callback manager for managing the run.
        **kwargs (Any): Additional keyword arguments.

    Yields:
        Iterator[ChatGenerationChunk]: An iterator of chat generation chunks.

    Raises:
        ValueError: If stop is not None.
    """
    if stop is not None:
      raise ValueError("stop kwargs are not permitted.")

    payload = [self._parse_bapi_message(prompt) for prompt in prompts]

    for chunks in self.sync_bapi_stream(payload=payload):
      for chunk in chunks:
        if isinstance(chunk, str) or len(chunk.get("choices", [])) == 0:
          continue

        choice = chunk["choices"][0]
        message_chunk = AIMessageChunk(cast(str, choice["delta"].get("content", "")))

        yield ChatGenerationChunk(
          message=message_chunk,
          generation_info={"finish_reason": choice.get("finish_reason", "")},
        )

  async def _astream(
    self,
    prompts: list[BaseMessage],
    stop: list[str] | None = None,
    run_manager: CallbackManagerForLLMRun | None = None,
    **kwargs: Any,
  ) -> AsyncIterator[ChatGenerationChunk]:
    """
    Stream chat completions for the given prompts asynchronously.

    Args:
        prompts (list[BaseMessage]): A list of messages to generate a response for.
        stop (list[str] | None): A list of stop words (not used in this implementation).
        run_manager (CallbackManagerForLLMRun | None): A callback manager for managing the run.
        **kwargs (Any): Additional keyword arguments.

    Yields:
        AsyncIterator[ChatGenerationChunk]: An asynchronous iterator of chat generation chunks.

    Raises:
        ValueError: If stop is not None.
    """
    if stop is not None:
      raise ValueError("stop kwargs are not permitted.")

    payload = [self._parse_bapi_message(prompt) for prompt in prompts]

    async for chunk in await self.async_bapi_stream(payload=payload):
      if isinstance(chunk, str) or len(chunk.get("choices", [])) == 0:
        continue

      choice = chunk["choices"][0]
      message_chunk = AIMessageChunk(cast(str, choice["delta"].get("content", "")))

      yield ChatGenerationChunk(
        message=message_chunk,
        generation_info={"finish_reason": choice.get("finish_reason", "")},
      )

  @property
  def _identifying_params(self) -> dict[str, Any]:
    """
    Return a dictionary of identifying parameters (model name).

    Returns:
        dict[str, Any]: A dictionary with the model name.
    """
    return {
      "model_name": "SecureGPT",
    }

  @property
  def _llm_type(self) -> str:
    """
    Get the type of language model used by this chat model.
    Used for logging purposes only.

    Returns:
        str: The type of language model.
    """
    return "custom"
