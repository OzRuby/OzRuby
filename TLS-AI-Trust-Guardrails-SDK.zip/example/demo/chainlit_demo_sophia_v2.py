"""
Sophia AI-Trust Chainlit demo – fully async, but 100 % drop-in for the old file.

Key points
----------
* Keeps the src-path injection so imports such as `secure_gpt_langchain` work.
* Loads `.env` from the same folder as the script (or any parent) *before*
  required-var validation.
* All outbound HTTP uses the shared `request_with_retry` (aiohttp + tenacity).
* Token cache uses an asyncio-safe `TokenManager`.
* Guard BLOCK → user can click *Continue anyway*.
* UI shows one compact task per guard.
"""

from __future__ import annotations

# --------------------------------------------------------------------------- #
# Path injection so both ① src/ ② repo-root (libs/) are importable            #
# --------------------------------------------------------------------------- #
import os
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT  = os.path.abspath(os.path.join(SCRIPT_DIR, "../.."))
SRC_DIR    = os.path.join(REPO_ROOT, "src")

for p in (SRC_DIR, REPO_ROOT):
    if p not in sys.path:
        sys.path.insert(0, p)

# --------------------------------------------------------------------------- #
# Standard lib + lightweight third-party imports                              #
# --------------------------------------------------------------------------- #
import asyncio
import json
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import chainlit as cl
from dotenv import load_dotenv, find_dotenv

# --------------------------------------------------------------------------- #
# Load .env before any env-var validation                                     #
# --------------------------------------------------------------------------- #
load_dotenv(find_dotenv(".env", raise_error_if_not_found=False))

# --------------------------------------------------------------------------- #
# Project-internal quick imports                                              #
# --------------------------------------------------------------------------- #
from aitrust.monitoring.logs import logger
# --------------------------------------------------------------------------- #
# Configure logging                                                           #
# --------------------------------------------------------------------------- #

# ── LOCAL HTTP UTILS (aiohttp + tenacity) ────────────────────────────────────
import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential, RetryError

_AIOHTTP_SESSION: aiohttp.ClientSession | None = None


async def aiohttp_session() -> aiohttp.ClientSession:
    global _AIOHTTP_SESSION
    if _AIOHTTP_SESSION is None:
        _AIOHTTP_SESSION = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=60),
            trust_env=True,  # honour proxy / CA env vars
        )
    return _AIOHTTP_SESSION


async def close_session() -> None:
    if _AIOHTTP_SESSION and not _AIOHTTP_SESSION.closed:
        await _AIOHTTP_SESSION.close()


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=0.7, min=0.7, max=6))
async def request_with_retry(method: str, url: str, **kwargs) -> Any:
    """Thin wrapper → JSON on 2xx, else raises; retried by tenacity."""
    sess = await aiohttp_session()
    async with sess.request(method.upper(), url, **kwargs) as resp:
        resp.raise_for_status()
        ct = resp.headers.get("content-type", "")
        if "application/json" in ct:
            return await resp.json()
        return await resp.text()

# --------------------------------------------------------------------------- #
# Environment variables                                                       #
# --------------------------------------------------------------------------- #
REQUIRED = [
    "ONE_LOGIN_URL",
    "BAPI_URL",
    "GUARDCONFIG_PATH",
    "CLIENT_ID",
    "CLIENT_SECRET",
    "CHUNK_SERVICE_URL",
]
_missing = [v for v in REQUIRED if not os.environ.get(v)]
if _missing:
    raise RuntimeError(f"Missing env vars: {', '.join(_missing)}")

ONE_LOGIN_URL = os.environ["ONE_LOGIN_URL"]
BAPI_URL = os.environ["BAPI_URL"]
GUARDCONFIG_PATH = os.environ["GUARDCONFIG_PATH"]
CLIENT_ID = os.environ["CLIENT_ID"]
CLIENT_SECRET = os.environ["CLIENT_SECRET"]
CHUNK_SERVICE_URL = os.environ["CHUNK_SERVICE_URL"]

PROJECT_NAME = "Mock RAG GenTrust Application"
LLM_DEPLOYMENT_ID = "gpt-4o-2024-08-06"

# --------------------------------------------------------------------------- #
# Async token manager                                                         #
# --------------------------------------------------------------------------- #
class TokenManager:
    def __init__(self) -> None:
        self._token: Optional[str] = None
        self._expires_at: float = 0
        self._lock = asyncio.Lock()

    async def get(self) -> str:
        async with self._lock:
            now = time.time()
            if self._token and self._expires_at - now > 30:
                return self._token

            payload = (
                "grant_type=client_credentials"
                f"&client_id={CLIENT_ID}"
                f"&client_secret={CLIENT_SECRET}"
                "&scope=urn%3Agrp%3Achatgpt"
            )
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            url = f"{ONE_LOGIN_URL}/as/token.oauth2"
            resp = await request_with_retry("post", url, data=payload, headers=headers)
            self._token = resp["access_token"]
            self._expires_at = now + int(resp["expires_in"])
            return self._token


TOKEN_MANAGER = TokenManager()

# --------------------------------------------------------------------------- #
# Utility functions (embedding, retrieval)                                    #
# --------------------------------------------------------------------------- #
async def async_embedding(text: str) -> List[float]:
    auth = f"Bearer {await TOKEN_MANAGER.get()}"
    url = f"{BAPI_URL}/deployments/text-embedding-ada-002-2/embeddings"
    body = {"input": text}
    resp = await request_with_retry("post", url, json=body, headers={"Authorization": auth})
    return resp["data"][0]["embedding"]


async def retrieve_chunks(query: str, doc: str = "Puffin Travel Insurance.pdf") -> List[str]:
    payload = {
        "user_id": "user_4",
        "unit_id": "unit_1",
        "message": query,
        "document_name": doc,
    }
    resp = await request_with_retry("post", CHUNK_SERVICE_URL, json=payload)
    return [chunk["text"] for chunk in resp["messages"][0]["sources"][0]["chunks"]]


# --------------------------------------------------------------------------- #
# Orchestrator bootstrap (lazy, cached)                                       #
# --------------------------------------------------------------------------- #
_ORCH: Optional["PipelineOrchestrator"] = None


async def get_orchestrator() -> "PipelineOrchestrator":  # noqa: ANN001
    global _ORCH
    if _ORCH:
        return _ORCH

    from aitrust.common.config import ConfigLoader  # heavy
    from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
    from aitrust.core.runner.pipeline_runner import PipelineRunner
    from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator

    cfg = ConfigLoader(settings_path=GUARDCONFIG_PATH).load_config()
    builder = PipelineDocBuilder.from_config_model(cfg)
    exec_model = builder.build_pipeline_execution_model()
    runner = PipelineRunner(service_base_url=cfg.service_settings.endpoint)

    _ORCH = PipelineOrchestrator(builder, exec_model, runner)
    await _ORCH.start_pipeline()
    return _ORCH


# --------------------------------------------------------------------------- #
# Guard-failure override helper                                               #
# --------------------------------------------------------------------------- #
async def ask_continue(stage: str, reason: str) -> bool:
    msg = await cl.Message(
        content=f"⚠️ **{stage}** blocked: {reason}",
        actions=[
            cl.Action(name="continue", value="continue", label="Continue anyway"),
            cl.Action(name="abort", value="abort", label="Abort"),
        ],
    ).send()

    fut: asyncio.Future[bool] = asyncio.Future()

    @cl.action_callback("continue")
    async def _cont(a: cl.Action):  # noqa: D401
        if a.for_id == msg.id:
            fut.set_result(True)
            await cl.Message(id=msg.id).remove_actions()

    @cl.action_callback("abort")
    async def _abrt(a: cl.Action):
        if a.for_id == msg.id:
            fut.set_result(False)
            await cl.Message(id=msg.id).remove_actions()

    return await fut


# --------------------------------------------------------------------------- #
# Track validations – condensed guard-level view                              #
# --------------------------------------------------------------------------- #
async def track_validations(stage: str, orch, tlist: cl.TaskList) -> Tuple[bool, str | None]:  # noqa: ANN001
    pipe = orch._pipeline_execution_model  # noqa: WPS437
    stage_exec = next(s for s in pipe.stages_execution_results if s.stage_name == stage)

    failed = []
    for g in stage_exec.guards_execution_results:
        decision = g.final_decision or "UNKNOWN"
        icon = "✅" if decision == "PASS" else "❌"
        await tlist.add_task(cl.Task(f"{icon} {g.guard_config.name}: {decision}", status=cl.TaskStatus.DONE))
        if decision == "BLOCK":
            failed.append(g.guard_config.name)
    await tlist.send()

    if stage_exec.overall_decision == "BLOCK":
        return False, ", ".join(failed)
    return True, None


# --------------------------------------------------------------------------- #
# Chainlit hooks                                                              #
# --------------------------------------------------------------------------- #
@cl.on_chat_start
async def _on_start():
    cl.user_session.set("conversation_id", uuid.uuid4())
    await cl.Message("Welcome to **Sophia AI-Trust demo**! Ask a question to begin.").send()


@cl.on_chat_end
async def _on_end():
    await close_session()


# --------------------------------------------------------------------------- #
# Clear-session button handler                                                #
# --------------------------------------------------------------------------- #
@cl.action_callback("clear_session")
async def clear_session(action: cl.Action):
    if action.for_id:
        await cl.Message(id=action.for_id).remove_actions()
    cl.user_session.set("conversation_id", uuid.uuid4())
    await cl.Message("Session reset.").send()


# --------------------------------------------------------------------------- #
# Main message handler                                                        #
# --------------------------------------------------------------------------- #
@cl.on_message
async def handle(msg: cl.Message):
    question = msg.content.strip()
    if not question:
        return

    orch = await get_orchestrator()
    conv_id = cl.user_session.get("conversation_id") or uuid.uuid4()
    cl.user_session.set("conversation_id", conv_id)

    tlist = cl.TaskList(status="Running…")
    await tlist.send()

    # ----------------- INPUT ----------------- #
    await orch.execute_stage(
        "input",
        {
            "value": question,
            "metadata": {"content_type": "text"},
            "conversation_id": str(conv_id),
            "project_name": PROJECT_NAME,
        },
    )
    ok, reason = await track_validations("input", orch, tlist)
    if not ok and not await ask_continue("input", reason):
        await orch.complete_pipeline()
        tlist.status = "Aborted"
        await tlist.send()
        return

    # ----------------- RETRIEVAL ------------- #
    chunks = await retrieve_chunks(question)
    await orch.execute_stage(
        "retrieval",
        {
            "value": question,
            "metadata": {"Chunks": chunks},
            "conversation_id": str(conv_id),
            "project_name": PROJECT_NAME,
        },
    )
    ok, reason = await track_validations("retrieval", orch, tlist)
    if not ok and not await ask_continue("retrieval", reason):
        await orch.complete_pipeline()
        tlist.status = "Aborted"
        await tlist.send()
        return

    # ----------------- OUTPUT ---------------- #
    answer = await _generate_answer(question, chunks)
    await orch.execute_stage(
        "output",
        {
            "value": question,
            "metadata": {"Chunks": chunks, "Answer": answer},
            "conversation_id": str(conv_id),
            "project_name": PROJECT_NAME,
        },
    )
    ok, reason = await track_validations("output", orch, tlist)
    if not ok and not await ask_continue("output", reason):
        await orch.complete_pipeline()
        tlist.status = "Aborted"
        await tlist.send()
        return

    await orch.complete_pipeline()
    tlist.status = "Done"
    await tlist.send()

    await cl.Message(
        content=answer,
        actions=[cl.Action("clear_session", label="Reset", value="clr")],
    ).send()


# --------------------------------------------------------------------------- #
# Answer generation (Sync LangChain wrapped in executor)                      #
# --------------------------------------------------------------------------- #
async def _generate_answer(question: str, context_chunks: List[str]) -> str:
    from secure_gpt_langchain import SecureGPT
    from langchain.schema import HumanMessage

    chat_gpt = SecureGPT(deployment_id=LLM_DEPLOYMENT_ID, prompt_type="CHAT_COMPLETIONS")
    if not getattr(chat_gpt, "api_base_url", None):
        setattr(chat_gpt, "api_base_url", BAPI_URL)

    context_block = "\n".join(context_chunks[:20])
    prompt = f"Context:\n{context_block}\n\nQuestion: {question}"

    loop = asyncio.get_event_loop()
    resp = await loop.run_in_executor(
        None, lambda: chat_gpt._generate([HumanMessage(content=prompt)])
    )
    return resp.generations[0].message.content


# --------------------------------------------------------------------------- #
# Local debug                                                                 #
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    logger.info("Starting Chainlit …")
