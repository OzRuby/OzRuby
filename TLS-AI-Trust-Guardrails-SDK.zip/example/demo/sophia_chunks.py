import json
import requests

with open("Token_SECUREGPT_API/PROD.txt", "r") as file:
    client = file.read().splitlines()

client_id = client[0]
client_secret = client[1]

token_url = "https://onelogin.axa.com/as/token.oauth2"
token_payload = f'grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}&scope=urn%3Agrp%3Achatgpt'
token_headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Cookie': 'PF=BmSXkfcxE5LQraaTWGJgS4'
}

def getToken():
    response = requests.request("POST", token_url, headers=token_headers, data=token_payload)
    return (json.loads(response.text)['access_token'])

auth = "Bearer " + str(getToken())

URL = "https://api.se.axa-go.applications.services.axa-tech.intraxa/ago-m365-securegpt-bapi-v1-vrs/"

def embedding_function(query):

    emd_headers = {'Content-type': 'application/json', 'Authorization': auth}
    emd_url = URL + "deployments/text-embedding-ada-002-2/embeddings"
    emd_data = {"input":  query}

    response = requests.post(emd_url, data=json.dumps(emd_data), headers=emd_headers, verify=False)

    return(json.loads(response.text)['data'][0]['embedding'])

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery

import numpy as np

index_name = "index_demogeneralenquiries-llm"
endpoint = "https://zaasraaporchdvaew1sch01.search.windows.net"
key = "xxxx"

# Create a client
credential = AzureKeyCredential(key)
client = SearchClient(endpoint=endpoint,
                      index_name=index_name,
                      credential=credential)

query = "Puffin Uk Gold Idol- cm want to know if he is cover by the policy. he book the hotel through some online portal, but when cm call the hotel want to check if his booking success. the hotel said they cannot find the booking."

results = client.search(
            search_text="'DocumentName' eq 'Puffin_TC.pdf' ",
            #order_by="search.score desc",
            top=10,
            vector_queries=[
                VectorizedQuery(
                    vector=np.array(
                        embedding_function(query), dtype=np.float32
                    ).tolist(),
                    k_nearest_neighbors=4,
                    fields="Vector",
                )
            ],
            select=[
                f"DocumentName,Content,PageNumber,DocumentUrl"
            ],
            filter=None,# filters,
        )

for result in results:
        print("Search score: {}".format(result['@search.score']))
        print("Content: {}".format(result['Content']))