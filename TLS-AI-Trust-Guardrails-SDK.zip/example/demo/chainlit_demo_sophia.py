# -*- coding: utf-8 -*-
import os
import sys
import uuid
import time
from typing import Optional, List, Tuple, Dict, Any
from dotenv import load_dotenv
import asyncio
from datetime import datetime, timezone # Keep timezone import
import json
import requests # Keep original requests
import numpy as np # Keep original numpy
# Keep original Azure Search imports even if unused by replaced function,
# in case they are needed elsewhere or for future revert.
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
import chainlit as cl
from langchain.schema import HumanMessage # Keep original langchain
import logging

# --- Adjust System Path (Ensure Correct Relative Path) ---
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.abspath(os.path.join(script_dir, "../../src"))
    if src_dir not in sys.path: sys.path.insert(0, src_dir)
    from secure_gpt_langchain import SecureGPT # noqa E402
    from aitrust.monitoring.logs import logger # noqa E402
    from aitrust.common.config import ConfigLoader # noqa E402
    from aitrust.models.config import SDKConfigModel # noqa E402
    from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder # noqa E402
    from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator # noqa E402
    from aitrust.core.runner.pipeline_runner import PipelineRunner # noqa E402
    from aitrust.models.validator import ValidatorExecutionModel, ValidatorResponseStatusEnum # noqa E402
    from aitrust.models.guard import GuardExecutionModel # noqa E402
    from aitrust.models.orchestrator import OrchestrationStatusEnum # noqa E402
except ImportError as e: print(f"Import Error: {e}\nEnsure paths/dependencies correct.\nsys.path: {sys.path}"); sys.exit(1)
except FileNotFoundError: print("Error: Could not determine script directory."); script_dir = os.getcwd(); print(f"Warning: Using CWD: {script_dir}") # Fallback CWD

# --- Load Environment Variables ---
dotenv_path = os.path.join(script_dir, ".env")
if os.path.exists(dotenv_path): load_dotenv(dotenv_path=dotenv_path); logger.info(f"Loaded .env: {dotenv_path}")
else: logger.warning(".env not found. Using system env vars.")

# --- Configure Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(name)s: %(message)s')
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)
logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)
for name in logging.root.manager.loggerDict:
    if "secure_gpt_langchain" in name: logging.getLogger(name).setLevel(logging.WARNING)

# --- Environment Variable Validation ---
required_vars = ["ONE_LOGIN_URL", "BAPI_URL", "GUARDCONFIG_PATH", "AZURE_SEARCH_ENDPOINT", "AZURE_SEARCH_KEY", "CLIENT_ID", "CLIENT_SECRET", "CHUNK_SERVICE_URL"]
missing_vars = [var for var in required_vars if not os.environ.get(var)]
if missing_vars: raise ValueError(f"Missing env vars: {', '.join(missing_vars)}")
logger.info("All required environment variables are set.")

# --- Configuration Constants ---
AZURE_SEARCH_ENDPOINT = os.environ.get("AZURE_SEARCH_ENDPOINT")
AZURE_SEARCH_KEY = os.environ.get("AZURE_SEARCH_KEY")
INDEX_NAME = "index_demogeneralenquiries-llm"
CHUNK_SERVICE_URL = os.environ.get("CHUNK_SERVICE_URL")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")
PROJECT_NAME = "Mock RAG GenTrust Application"
LLM_DEPLOYMENT_ID = "gpt-4o-2024-08-06"
BAPI_URL = os.environ.get("BAPI_URL")
ONE_LOGIN_URL = os.environ.get("ONE_LOGIN_URL")
GUARDCONFIG_PATH = os.environ.get("GUARDCONFIG_PATH")

# --- Initialize Chat Engine ---
try:
    chat_gpt = SecureGPT(deployment_id=LLM_DEPLOYMENT_ID, prompt_type="CHAT_COMPLETIONS")
    secure_gpt_url_attr = 'api_base_url' # <-- **VERIFY/ADJUST THIS ATTRIBUTE NAME**
    if not hasattr(chat_gpt, secure_gpt_url_attr) or not getattr(chat_gpt, secure_gpt_url_attr, None):
        logger.warning(f"SecureGPT missing '{secure_gpt_url_attr}'. Attempting to set.")
        if hasattr(chat_gpt, secure_gpt_url_attr):
            try: setattr(chat_gpt, secure_gpt_url_attr, BAPI_URL); logger.info(f"Set SecureGPT '{secure_gpt_url_attr}'.")
            except Exception as e: logger.error(f"Error setting SecureGPT URL: {e}")
        else: logger.error(f"SecureGPT object missing attribute '{secure_gpt_url_attr}'.")
    logger.info(f"SecureGPT engine initialized: {LLM_DEPLOYMENT_ID}")
except Exception as e: logger.error(f"Chat engine init failed: {e}", exc_info=True); raise

# --- Original Helper Functions (Token, Embedding - Sync/Requests) ---
_token_cache: Dict[str, Any] = {"token": None, "expires_at": 0}
_token_retrieving = False

def get_token():
    """Retrieve an access token using client credentials (Sync). Original Version."""
    global _token_retrieving
    if _token_retrieving: raise Exception("Recursive token retrieval detected.")
    now = time.time()
    if _token_cache.get("token") and _token_cache.get("expires_at", 0) > now + 60: return _token_cache["token"]
    logger.info("Retrieving new access token (sync).")
    token_url = f"{ONE_LOGIN_URL}/as/token.oauth2"
    token_payload = f'grant_type=client_credentials&client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}&scope=urn%3Agrp%3Achatgpt'
    token_headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Cookie': 'PF=BmSXkfcxE5LQraaTWGJgS4'} # Original header
    _token_retrieving = True
    try:
        response = requests.post(token_url, headers=token_headers, data=token_payload, timeout=15)
        response.raise_for_status(); token_data = response.json()
        if 'access_token' not in token_data or 'expires_in' not in token_data: raise ValueError("Token response missing fields")
        _token_cache["token"], _token_cache["expires_at"] = token_data['access_token'], now + int(token_data['expires_in'])
        logger.info("Successfully retrieved/cached token (sync).")
        return _token_cache["token"]
    except requests.exceptions.Timeout: raise Exception("Timeout retrieving token.")
    except requests.exceptions.RequestException as e: raise Exception(f"HTTP error retrieving token: {e}") from e
    except (KeyError, ValueError, TypeError) as e: raise Exception(f"Invalid token response: {e}") from e
    finally: _token_retrieving = False

def embedding_function(query):
    """Generate embeddings for a query using the external API (Sync). Original Version."""
    try:
        auth = "Bearer " + get_token()
        emd_headers = {'Content-type': 'application/json', 'Authorization': auth}
        emd_url = f"{BAPI_URL}/deployments/text-embedding-ada-002-2/embeddings"
        emd_data = {"input": query}
        logger.debug(f"Requesting embedding (sync): '{query[:50]}...'")
        response = requests.post(emd_url, data=json.dumps(emd_data), headers=emd_headers, verify=False, timeout=30)
        response.raise_for_status(); response_data = response.json()
        if not response_data.get('data') or not isinstance(response_data['data'], list) or len(response_data['data']) == 0 or 'embedding' not in response_data['data'][0]: raise ValueError("Invalid embedding response format.")
        embedding = response_data['data'][0]['embedding']; assert isinstance(embedding, list)
        logger.debug(f"Retrieved embedding vector dim {len(embedding)} (sync).")
        return embedding
    except requests.exceptions.Timeout: raise Exception("Timeout getting embeddings.")
    except requests.exceptions.RequestException as e: raise Exception(f"HTTP error getting embeddings: {e}") from e
    except (KeyError, IndexError, ValueError, TypeError, AssertionError) as e: raise Exception(f"Invalid embedding response: {e}") from e
    except Exception as e: raise Exception(f"Embedding error: {e}") from e

# ** REPLACEMENT for search_azure **
def retrieve_chunks_from_endpoint(query: str, document_filter_name: str = "Puffin Travel Insurance.pdf") -> List[str]:
    """Retrieves document chunks from the specified backend endpoint."""
    endpoint_url = CHUNK_SERVICE_URL # Use env var
    if not endpoint_url: raise ValueError("CHUNK_SERVICE_URL environment variable is not set.")
    logger.info(f"Retrieving chunks for query: '{query[:50]}...' from {endpoint_url}")
    user_id, unit_id, document_name = "user_4", "unit_1", document_filter_name
    payload = {"user_id": user_id, "unit_id": unit_id, "message": query, "document_name": document_name}
    try:
        response = requests.post(endpoint_url, json=payload, timeout=60)
        response.raise_for_status(); res = response.json()
        if not isinstance(res, dict) or "messages" not in res or not isinstance(res["messages"], list) or len(res["messages"]) == 0: raise ValueError("Invalid response: 'messages' missing/invalid.")
        message_data = res["messages"][0]
        if not isinstance(message_data, dict) or "sources" not in message_data or not isinstance(message_data["sources"], list) or len(message_data["sources"]) == 0: raise ValueError("Invalid response: 'sources' missing/invalid.")
        source_data = message_data["sources"][0]
        if not isinstance(source_data, dict) or "chunks" not in source_data or not isinstance(source_data["chunks"], list): raise ValueError("Invalid response: 'chunks' missing/invalid.")
        all_chunks_data = source_data['chunks']
        chunk_texts = [chunk["text"] for chunk in all_chunks_data if isinstance(chunk, dict) and "text" in chunk]
        logger.info(f"Retrieved {len(chunk_texts)} chunks from endpoint.")
        return chunk_texts
    except requests.exceptions.Timeout: logger.error(f"Timeout error retrieving chunks from {endpoint_url}"); raise Exception("Timeout during document retrieval.")
    except requests.exceptions.RequestException as e: logger.error(f"HTTP error retrieving chunks from {endpoint_url}: {e}", exc_info=True); raise Exception(f"HTTP error during retrieval: {e}") from e
    except (json.JSONDecodeError, KeyError, IndexError, TypeError, ValueError) as e:
        logger.error(f"Error parsing response or invalid structure from {endpoint_url}: {e}", exc_info=True)
        try: logger.error(f"Response Text (partial): {response.text[:500]}")
        except: pass
        raise Exception(f"Failed to parse retrieval response: {e}") from e
    except Exception as e: logger.error(f"Unexpected error during chunk retrieval: {e}", exc_info=True); raise

# --- Other Helper Functions (Unchanged) ---

def load_config(config_path: str) -> SDKConfigModel:
    """Load SDK configuration from the specified path."""
    logger.info(f"Loading configuration from: {config_path}")
    if not os.path.exists(config_path): raise FileNotFoundError(f"Config file not found: {config_path}")
    try: loader = ConfigLoader(settings_path=config_path); config = loader.load_config(); logger.info("Config loaded."); return config
    except Exception as e: logger.error(f"Failed to load config: {e}", exc_info=True); raise

def setup_orchestrator(config_path: str) -> PipelineOrchestrator:
    """Set up the pipeline orchestrator with the given configuration."""
    logger.info("Setting up pipeline orchestrator...")
    try:
        config = load_config(config_path)
        pipeline_id = uuid.uuid4()
        pipeline_def = PipelineDocBuilder.from_config_file(config_path, pipeline_id)
        pipeline_exec = pipeline_def.build_pipeline_execution_model()
        if not hasattr(config, 'service_settings') or not config.service_settings or not config.service_settings.endpoint: raise ValueError("Service endpoint missing in config.")
        runner = PipelineRunner(service_base_url=config.service_settings.endpoint)
        orchestrator = PipelineOrchestrator(pipeline_definition=pipeline_def, pipeline_execution_model=pipeline_exec, pipeline_runner=runner)
        logger.info(f"Pipeline orchestrator initialized with ID: {pipeline_id}") # Original log
        return orchestrator
    except FileNotFoundError as e: raise e
    except Exception as e: logger.error(f"Failed to set up orchestrator: {e}", exc_info=True); raise

# --- Using Original get_user_friendly_message ---
def get_user_friendly_message(validator_name: str, reason: str, error_spans: Optional[List[Dict]] = None) -> str:
    """Map validator failure reasons to user-friendly messages. Original Version."""
    if validator_name == "GrammarCheck" and error_spans:
        first_error = error_spans[0]; text = first_error.get("text", ""); error_reason = first_error["reason"]
        return f"Your query has a grammatical error: {error_reason} in '{text}'. Please correct it and try again."
    elif validator_name == "PromptInjection": return "Your query may contain unsafe content. Please rephrase it."
    elif validator_name == "RelevanceChunk": return f"The retrieved documents are not relevant enough: {reason}. Try a more specific query."
    elif validator_name == "AnswerRelevance": return f"The generated answer is not relevant: {reason}. Please try rephrasing your question."
    else: return f"Your query does not meet our content guidelines due to: {reason}. Please try rephrasing it."

# --- Using Original track_validations ---
# NOTE: This uses the original simple UI task updates.
# If you want the enhanced nested UI from previous attempts, replace this function.
async def track_validations(stage_name: str, orchestrator: PipelineOrchestrator, task_list: cl.TaskList, context: Dict[str, Any]) -> Tuple[bool, Optional[str], Optional[str], Optional[str], Optional[List[Dict]]]:
    """Original track_validations function."""
    pipeline_execution_model = orchestrator._pipeline_execution_model
    stage_result = next((s for s in pipeline_execution_model.stages_execution_results if s.stage_name == stage_name), None)
    if not stage_result: logger.info(f"No stage result for '{stage_name}'."); return False, "Stage not executed", None, None, None

    all_passed = True; blocking_reason, blocking_guard, blocking_validator, error_spans = None, None, None, None
    guards_results = getattr(stage_result, 'guards_execution_results', []);
    if guards_results is None: guards_results = []
    if not isinstance(guards_results, list): logger.error(f"Invalid guard results for stage '{stage_name}'."); return False, "Invalid guard results", stage_name, "N/A", None

    for guard_exec in guards_results:
        guard_name = getattr(getattr(guard_exec, 'guard_config', None), 'name', 'Unknown Guard')
        guard_task = cl.Task(title=f"🛡️ Guard: {guard_name}", status=cl.TaskStatus.RUNNING); await task_list.add_task(guard_task); await task_list.send()

        validator_results = getattr(guard_exec, 'validators_execution_results', [])
        if validator_results is None: validator_results = []
        if not isinstance(validator_results, list):
            logger.error(f"Invalid validators_execution_results for {guard_name}"); guard_task.status = cl.TaskStatus.FAILED; guard_task.title += " (Invalid validator results)"; await task_list.send(); all_passed = False
            if blocking_reason is None: blocking_reason, blocking_guard, blocking_validator = "Invalid validator results", guard_name, "N/A"
            continue

        for validator_result in validator_results:
            validator_name = getattr(getattr(getattr(validator_result, 'request', None), 'validator_config', None), 'name', 'Unknown Validator')
            validator_task = cl.Task(title=f"  🔍 Validator: {validator_name}", status=cl.TaskStatus.RUNNING); await task_list.add_task(validator_task); await task_list.send()
            val_response = getattr(validator_result, 'response', None); val_status = getattr(val_response, 'status', None)

            if val_status == "pass": validator_task.status = cl.TaskStatus.DONE; validator_task.title += " (Passed)"
            else:
                reason = getattr(val_response, 'error_message', None) if val_response else getattr(validator_result, 'error_message', None); reason = reason or "Validation failed"
                current_error_spans = None
                if val_response and hasattr(val_response, 'details') and isinstance(val_response.details, dict):
                    current_error_spans = val_response.details.get("errorSpans")
                    if current_error_spans and isinstance(current_error_spans, list) and len(current_error_spans) > 0:
                        first_error = current_error_spans[0]; span_reason = first_error.get('reason', 'issue'); span_text = first_error.get('text', '')
                        reason = f"{span_reason}" + (f" in '{span_text}'" if span_text else "");
                        if error_spans is None: error_spans = current_error_spans
                validator_task.status = cl.TaskStatus.FAILED; validator_task.title += f" (Failed: {reason})"
                all_passed = False
                if blocking_reason is None: blocking_reason, blocking_guard, blocking_validator = reason, guard_name, validator_name
            await task_list.send()

        guard_decision = getattr(guard_exec, 'final_decision', 'UNKNOWN')
        if guard_decision == "PASS": guard_task.status = cl.TaskStatus.DONE
        else:
            guard_task.status = cl.TaskStatus.FAILED; all_passed = False
            if blocking_reason is None: blocking_reason, blocking_guard, blocking_validator = "Guard blocked", guard_name, "N/A"
        await task_list.send()

    return all_passed, blocking_reason, blocking_guard, blocking_validator, error_spans


# --- Chainlit Handlers (Original) ---

@cl.on_chat_start
async def start():
    """Initialize the chat session (Original Style)."""
    logger.info("New chat session started.")
    task_list = cl.TaskList(status="Running...")
    await task_list.send()
    task_upload = cl.Task(title="Welcome To Sophia AI trust DEMO", status=cl.TaskStatus.RUNNING)
    await task_list.add_task(task_upload)
    await task_list.send()
    cl.user_session.set("conversation_id", uuid.uuid4())
    task_list.status = "Done"; await task_list.send()

@cl.action_callback("clear_session") # Original action
async def on_clear_session(action: cl.Action):
    logger.info("Clearing session.")
    cl.user_session.set("conversation_id", None)
    if action.for_id:
        try: await cl.Message(id=action.for_id).remove_actions()
        except Exception as e: logger.warning(f"Could not remove actions for message {action.for_id}: {e}")
    await cl.Message(content="Session cleared. Upload a new PDF to start again.").send()
    await start()

# --- on_message using Original Logic + New Retrieval ---

# Utility function to safely send task list updates
async def safe_send_task_list(task_list: Optional[cl.TaskList]):
    """Safely sends task list updates, handling potential file errors."""
    if not task_list: return
    try: await task_list.send()
    except (FileNotFoundError, RuntimeError) as e:
        if ".files" in str(e): logger.warning(f"Caught known file error during task_list send: {e}. UI might not update.")
        else: raise e
    except Exception as e: logger.error(f"Unexpected error during task_list send: {e}", exc_info=True)

@cl.on_message
async def main(message: cl.Message):
    """Process user messages through the pipeline stages with NEW retrieval endpoint."""
    if not message.content: return
    logger.info(f"Starting message processing for query: {message.content[:100]}...")

    config_path = os.environ.get("GUARDCONFIG_PATH")
    if not config_path: logger.error("GUARDCONFIG_PATH not set."); await cl.Message(content="Config error: GUARDCONFIG_PATH not set."); return

    # Use the original UI task setup
    task_list = cl.TaskList(status="Running...")
    await safe_send_task_list(task_list) # Use safe send

    orchestrator: Optional[PipelineOrchestrator] = None
    pipeline_start_time = datetime.now(timezone.utc) # Use timezone aware
    context: Dict[str, Any] = {}
    final_answer: Optional[str] = None

    try:
        orchestrator = setup_orchestrator(config_path)
        # **FIX:** Await async orchestrator methods
        await orchestrator.start_pipeline()

        conversation_id = cl.user_session.get("conversation_id") or uuid.uuid4()
        cl.user_session.set("conversation_id", conversation_id)

        # --- Input Stage (Original Logic + Await Fix) ---
        task_input = cl.Task(title="Processing Input", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_input); await safe_send_task_list(task_list)
        start_time = time.time()
        query = message.content; context["query"] = query
        input_data = {"value": query, "metadata": {"content_type": "text"}, "conversation_id": str(conversation_id), "project_name": PROJECT_NAME}
        await orchestrator._execute_zone("input", input_data) # Await
        duration = time.time() - start_time
        task_input.status = cl.TaskStatus.DONE; task_input.title += f" (Completed in {duration:.2f}s)"; await safe_send_task_list(task_list)

        passed, reason, guard, validator, error_spans = await track_validations("input", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Input Validation Failed: {reason}", status=cl.TaskStatus.FAILED); await task_list.add_task(fail_task)
            total_time = (datetime.now(timezone.utc) - pipeline_start_time).total_seconds()
            summary_tasks = [ cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED), cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED), cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED), cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED), cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED)]
            for task in summary_tasks: await task_list.add_task(task)
            task_list.status = "Failed"; await safe_send_task_list(task_list)
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at input stage."); await orchestrator.complete_pipeline(); return # Await

        # --- Retrieval Stage (Using New Endpoint + Await Fix) ---
        task_retrieval = cl.Task(title="Retrieving Documents", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_retrieval); await safe_send_task_list(task_list)
        start_time = time.time()
        try:
            # Run sync retrieval in executor
            unique_documents = await asyncio.get_event_loop().run_in_executor(None, retrieve_chunks_from_endpoint, query)
            context["documents"] = unique_documents # Store List[str]
            logger.info(f"Retrieved {len(unique_documents)} documents via endpoint.")
            retrieval_data = {"value": query, "metadata": {"Chunks": unique_documents}, "conversation_id": str(conversation_id), "project_name": PROJECT_NAME}
            await orchestrator._execute_zone("retrieval", retrieval_data) # Await
        except Exception as retrieval_e:
            logger.error(f"Retrieval failed: {retrieval_e}", exc_info=True)
            task_retrieval.status = cl.TaskStatus.FAILED; task_retrieval.title += f" (Error: {retrieval_e})"
            await safe_send_task_list(task_list); await cl.Message(content=f"Error retrieving documents: {retrieval_e}").send()
        duration = time.time() - start_time
        task_retrieval.status = cl.TaskStatus.DONE; task_retrieval.title += f" (Completed in {duration:.2f}s, {len(unique_documents)} chunks)"; await safe_send_task_list(task_list)



        passed, reason, guard, validator, error_spans = await track_validations("retrieval", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Retrieval Validation Failed: {reason}", status=cl.TaskStatus.FAILED); await task_list.add_task(fail_task)
            total_time = (datetime.now(timezone.utc) - pipeline_start_time).total_seconds()
            summary_tasks = [ cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED), cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED), cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED), cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED), cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED)]
            for task in summary_tasks: await task_list.add_task(task)
            task_list.status = "Failed"; await safe_send_task_list(task_list)
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at retrieval stage."); await orchestrator.complete_pipeline(); return # Await

        # --- Output Stage (Original Logic + Await Fix) ---
        task_output = cl.Task(title="Generating Response", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_output); await safe_send_task_list(task_list)
        start_time = time.time()
        context_str = "\n".join(context.get("documents", ["No context."]))
        prompt = f"Context: {context_str}\nQuestion: {query}"
        try:
            # Run sync generate in executor
            response = await asyncio.get_event_loop().run_in_executor(None, lambda: chat_gpt._generate([HumanMessage(content=prompt)]))
            if not response or not response.generations or not response.generations[0].message: raise ValueError("Invalid LLM response.")
            final_answer = response.generations[0].message.content; context["answer"] = final_answer
        except Exception as gen_e:
            logger.error(f"LLM Generation failed: {gen_e}", exc_info=True)
            task_output.status = cl.TaskStatus.FAILED; task_output.title += f" (Error: {gen_e})"
            await safe_send_task_list(task_list); await cl.Message(content=f"Error generating response: {gen_e}").send()
        duration = time.time() - start_time
        task_output.status = cl.TaskStatus.DONE; task_output.title += f" (Completed in {duration:.2f}s)"; await safe_send_task_list(task_list)

        # **FIX:** Add "Answer" back to metadata for output validation
        output_data = {"value": query, "metadata": {"Chunks": unique_documents, "Answer": final_answer}, "conversation_id": str(conversation_id), "project_name": PROJECT_NAME}
        await orchestrator._execute_zone("output", output_data) # Await

        # Validation
        passed, reason, guard, validator, error_spans = await track_validations("output", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Output Validation Failed: {reason}", status=cl.TaskStatus.FAILED); await task_list.add_task(fail_task)
            total_time = (datetime.now(timezone.utc) - pipeline_start_time).total_seconds()
            summary_tasks = [ cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED), cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED), cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED), cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED), cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED)]
            for task in summary_tasks: await task_list.add_task(task)
            task_list.status = "Failed"; await safe_send_task_list(task_list)
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at output stage."); await orchestrator.complete_pipeline(); return # Await

        # --- Finalize Pipeline (Original Logic + Await Fix) ---
        await orchestrator.complete_pipeline() # Await
        logger.info(f"Pipeline completed successfully for query: {message.content[:100]}...")

        # Original final summary tasks
        total_time = (datetime.now(timezone.utc) - pipeline_start_time).total_seconds()
        summary_tasks = [
            cl.Task(title="Final Validation Summary: Completed Successfully", status=cl.TaskStatus.DONE),
            cl.Task(title=f"Total Time: {total_time:.2f}s", status=cl.TaskStatus.DONE),
        ]
        for task in summary_tasks: await task_list.add_task(task)
        task_list.status = "Done"; await safe_send_task_list(task_list)

        # Send final answer
        actions = [cl.Action(name="clear_session", label="Clear Session", value="clear", payload={}, tooltip="Reset the chat")]
        final_display_answer = context.get("answer", "Sorry, could not generate an answer.")
        await cl.Message(content=final_display_answer, actions=actions).send()

    # --- Exception Handling (Original Logic) ---
    except Exception as e:
        logger.error(f"Error in pipeline execution for query {message.content[:100]}: {str(e)}", exc_info=True)
        total_time = (datetime.now(timezone.utc) - pipeline_start_time).total_seconds()
        summary_tasks = [
            cl.Task(title="Final Validation Summary: Failed due to unexpected error", status=cl.TaskStatus.FAILED),
            cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
            cl.Task(title=f"Error: {str(e)}", status=cl.TaskStatus.FAILED),
        ]
        # Add tasks to the list created at the start of the try block
        for task in summary_tasks: await task_list.add_task(task)
        task_list.status = "Failed"; await safe_send_task_list(task_list)

        await cl.Message(content=f"Sorry, an unexpected error occurred: {str(e)}. Please try again later.").send()
        if orchestrator:
            try: await orchestrator.complete_pipeline() # Await
            except Exception as complete_e: logger.error(f"Error during pipeline complete after fail: {complete_e}", exc_info=True)

    finally:
        logger.debug("End of message processing.")
        # Clean session state if needed
        # cl.user_session.set("current_task_list", None)


# --- Main Guard ---
if __name__ == "__main__":
    logger.info("Chainlit application launched.")
    if not os.environ.get("CHUNK_SERVICE_URL"):
        print("\nERROR: CHUNK_SERVICE_URL environment variable is missing.\n")
