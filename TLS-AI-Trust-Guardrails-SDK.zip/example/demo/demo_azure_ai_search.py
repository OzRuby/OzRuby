import os
import sys
import uuid
import time
from typing import Optional, List, Tuple, Dict, Any
from dotenv import load_dotenv
import asyncio
from datetime import datetime
import json
import requests
import numpy as np
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery

# Adjust the system path to include the source directory
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../src")))

# Load environment variables from .env file
dotenv_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(dotenv_path=dotenv_path)

import chainlit as cl
from secure_gpt_langchain import SecureGPT
from langchain.schema import HumanMessage
from aitrust.monitoring.logs import logger
from aitrust.common.config import ConfigLoader
from aitrust.models.config import SDKConfigModel
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.core.runner.pipeline_runner import PipelineRunner
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
for name in logging.root.manager.loggerDict:
    if "secure_gpt_langchain" in name:
        logging.getLogger(name).setLevel(logging.WARNING)

# Define required environment variables
required_vars = [
    "ONE_LOGIN_URL", "BAPI_URL", "GUARDCONFIG_PATH",
    "AZURE_SEARCH_ENDPOINT", "AZURE_SEARCH_KEY", "CLIENT_ID", "CLIENT_SECRET"
]
for var in required_vars:
    if not os.environ.get(var):
        logger.error(f"Environment variable '{var}' is missing in .env file.")
        raise ValueError(f"Environment variable '{var}' is not set in the .env file")
logger.info("Environment configuration loaded successfully.")

# Azure Search configuration
AZURE_SEARCH_ENDPOINT = os.environ.get("AZURE_SEARCH_ENDPOINT")
AZURE_SEARCH_KEY = os.environ.get("AZURE_SEARCH_KEY")
INDEX_NAME = "index_demogeneralenquiries-llm"  

# Client credentials for token retrieval
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")

# Project name constant
PROJECT_NAME = "Mock RAG GenTrust Application"

# Initialize chat engine
try:
    chat_gpt = SecureGPT(deployment_id="gpt-4o-2024-08-06", prompt_type="CHAT_COMPLETIONS")
    logger.info("Chat engine initialized.")
except Exception as e:
    logger.error(f"Chat engine failed to initialize: {str(e)}", exc_info=True)
    raise

def get_token():
    """Retrieve an access token using client credentials from environment variables."""
    token_url = "https://onelogin.axa.com/as/token.oauth2"
    token_payload = f'grant_type=client_credentials&client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}&scope=urn%3Agrp%3Achatgpt'
    token_headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': 'PF=BmSXkfcxE5LQraaTWGJgS4'  # Note: This might need dynamic handling
    }
    response = requests.post(token_url, headers=token_headers, data=token_payload)
    return json.loads(response.text)['access_token']

def embedding_function(query):
    """Generate embeddings for a query using the external API."""
    auth = "Bearer " + get_token()
    emd_headers = {'Content-type': 'application/json', 'Authorization': auth}
    emd_url = "https://api.se.axa-go.applications.services.axa-tech.intraxa/ago-m365-securegpt-bapi-v1-vrs/deployments/text-embedding-ada-002-2/embeddings"
    emd_data = {"input": query}
    response = requests.post(emd_url, data=json.dumps(emd_data), headers=emd_headers, verify=False)
    return json.loads(response.text)['data'][0]['embedding']

def search_azure(query, k=4):
    """Perform a vector search using Azure Cognitive Search."""
    credential = AzureKeyCredential(AZURE_SEARCH_KEY)
    client = SearchClient(endpoint=AZURE_SEARCH_ENDPOINT, index_name=INDEX_NAME, credential=credential)
    
    # Generate embedding for the query
    query_embedding = embedding_function(query)
    
    # Perform the search
    results = client.search(
        search_text="'DocumentName' eq 'Puffin_TC.pdf' ",  # Add text search query here if needed
        top=k,
        vector_queries=[
            VectorizedQuery(
                vector=np.array(query_embedding, dtype=np.float32).tolist(),
                k_nearest_neighbors=k,
                fields="Vector",
            )
        ],
        select=["DocumentName", "Content", "PageNumber", "DocumentUrl"],
    )
    logger.info(results)
    # Extract content from results
    documents = [result['Content'] for result in results]
    return documents

def load_config(config_path: str) -> SDKConfigModel:
    """Load SDK configuration from the specified path."""
    loader = ConfigLoader(settings_path=config_path)
    config = loader.load_config()
    logger.info(f"Configuration loaded successfully from {config_path}")
    return config

def setup_orchestrator(config_path: str) -> PipelineOrchestrator:
    """Set up the pipeline orchestrator with the given configuration."""
    config = load_config(config_path)
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_file(config_path, pipeline_id)
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    runner = PipelineRunner(service_base_url=config.service_settings.endpoint)
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=runner
    )
    logger.info(f"Pipeline orchestrator initialized with ID: {pipeline_id}")
    return orchestrator

def get_user_friendly_message(validator_name: str, reason: str, error_spans: Optional[List[Dict]] = None) -> str:
    """Map validator failure reasons to user-friendly messages."""
    if validator_name == "GrammarCheck" and error_spans:
        first_error = error_spans[0]
        text = first_error.get("text", "")
        error_reason = first_error["reason"]
        return f"Your query has a grammatical error: {error_reason} in '{text}'. Please correct it and try again."
    elif validator_name == "PromptInjection":
        return "Your query may contain unsafe content. Please rephrase it to avoid references to external or manipulative content."
    elif validator_name == "RelevanceChunk":
        return f"The retrieved documents are not relevant enough: {reason}. Try a more specific query."
    elif validator_name == "AnswerRelevance":
        return f"The generated answer is not relevant: {reason}. Please try rephrasing your question."
    else:
        return f"Your query does not meet our content guidelines due to: {reason}. Please try rephrasing it accordingly."

async def track_validations(stage_name: str, orchestrator: PipelineOrchestrator, task_list: cl.TaskList, context: Dict[str, Any]) -> Tuple[bool, Optional[str], Optional[str], Optional[str], Optional[List[Dict]]]:
    pipeline_execution_model = orchestrator._pipeline_execution_model
    stage_result = next((s for s in pipeline_execution_model.stages_execution_results if s.stage_name == stage_name), None)
    if not stage_result:
        logger.info(f"No stage result for '{stage_name}'.")
        return False, "Stage not executed", None, None, None

    all_passed = True
    blocking_reason = None
    blocking_guard = None
    blocking_validator = None
    error_spans = None

    for guard_exec in stage_result.guards_execution_results:
        guard_name = guard_exec.guard_config.name
        guard_task = cl.Task(title=f"🛡️ Guard: {guard_name}", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(guard_task)
        await task_list.send()

        if not hasattr(guard_exec, 'validators_execution_results'):
            logger.error(f"GuardExecutionModel for {guard_name} is missing 'validators_execution_results'")
            guard_task.status = cl.TaskStatus.FAILED
            guard_task.title += " (Missing validation results)"
            await task_list.send()
            all_passed = False
            if blocking_reason is None:
                blocking_reason = "Missing validation results"
                blocking_guard = guard_name
                blocking_validator = "N/A"
            continue

        for validator_result in guard_exec.validators_execution_results:
            validator_name = validator_result.request.validator_config.name 
            validator_task = cl.Task(title=f"  🔍 Validator: {validator_name}", status=cl.TaskStatus.RUNNING)
            await task_list.add_task(validator_task)
            await task_list.send()

            # # Fix: Use dictionary key access instead of attribute access
            # if validator_result.request and 'project_name' not in validator_result.request:
            #     validator_result.request['project_name'] = PROJECT_NAME
            #     logger.debug(f"Set missing project_name to '{PROJECT_NAME}' for validator {validator_name}")

            if validator_result.response and validator_result.response.status == "pass":
                validator_task.status = cl.TaskStatus.DONE
                validator_task.title += " (Passed)"
            else:
                reason = validator_result.response.error_message if validator_result.response else validator_result.error_message
                reason = reason or "Validation failed"
                if validator_result.response and "details" in validator_result.response and "errorSpans" in validator_result.response.details:
                    error_spans = validator_result.response.details["errorSpans"]
                    if error_spans:
                        first_error = error_spans[0]
                        reason = f"{first_error['reason']} in '{first_error.get('text', '')}'"
                validator_task.status = cl.TaskStatus.FAILED
                validator_task.title += f" (Failed: {reason})"
                all_passed = False
                if blocking_reason is None:
                    blocking_reason = reason
                    blocking_guard = guard_name
                    blocking_validator = validator_name
            await task_list.send()

        if guard_exec.final_decision == "PASS":
            guard_task.status = cl.TaskStatus.DONE
        else:
            guard_task.status = cl.TaskStatus.FAILED
            if blocking_reason is None:
                blocking_reason = "Guard blocked"
                blocking_guard = guard_name
                blocking_validator = "N/A"
        await task_list.send()

    return all_passed, blocking_reason, blocking_guard, blocking_validator, error_spans


@cl.on_chat_start
async def start():
    """Initialize the chat session and prompt the user to upload a PDF."""
    logger.info("New chat session started.")
    task_list = cl.TaskList(status="Running...")
    await task_list.send()

    task_upload = cl.Task(title="Welcome To Sophia AI trust DEMO", status=cl.TaskStatus.RUNNING)
    await task_list.add_task(task_upload)
    await task_list.send()


    # Assume content is pre-indexed in Azure Search; no splitting or vector DB creation needed
    cl.user_session.set("conversation_id", uuid.uuid4())

    task_list.status = "Done"
    await task_list.send()

@cl.action_callback("new_pdf")
async def on_new_pdf(action):
    """Handle the 'Upload Another PDF' action."""
    logger.info("User requested a new PDF upload.")
    await action.remove()
    await start()

@cl.action_callback("clear_session")
async def on_clear_session(action):
    """Handle the 'Clear Session' action."""
    logger.info("Clearing session.")
    cl.user_session.set("conversation_id", None)
    await action.remove()
    await cl.Message(content="Session cleared. Upload a new PDF to start again.").send()
    await start()

@cl.on_message
async def main(message: cl.Message):
    """Process user messages through the pipeline stages with Azure Search retrieval."""
    logger.info(f"Starting message processing for query: {message.content}")

    config_path = os.environ.get("GUARDCONFIG_PATH")
    if not config_path:
        logger.error("GUARDCONFIG_PATH not set in environment.")
        await cl.Message(content="Configuration error: GUARDCONFIG_PATH not set.").send()
        return

    try:
        orchestrator = setup_orchestrator(config_path)
        await orchestrator.start_pipeline()

        task_list = cl.TaskList(status="Running...")
        await task_list.send()

        pipeline_start_time = datetime.now()
        context = {}
        conversation_id = cl.user_session.get("conversation_id") or uuid.uuid4()
        cl.user_session.set("conversation_id", conversation_id)

        # --- Input Stage ---
        task_input = cl.Task(title="Processing Input", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_input)
        await task_list.send()
        start_time = time.time()
        query = message.content
        context["query"] = query
        input_data = {
            "value": query,
            "metadata": {"content_type": "text"},
            "conversation_id": conversation_id
        }
        await orchestrator.execute_stage("input", input_data)
        end_time = time.time()
        duration = end_time - start_time
        task_input.status = cl.TaskStatus.DONE
        task_input.title += f" (Completed in {duration:.2f}s)"
        await task_list.send()
        passed, reason, guard, validator, error_spans = await track_validations("input", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Input Validation Failed: {reason}", status=cl.TaskStatus.FAILED)
            await task_list.add_task(fail_task)
            total_time = (datetime.now() - pipeline_start_time).total_seconds()
            summary_tasks = [
                cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED),
            ]
            for task in summary_tasks:
                await task_list.add_task(task)
            task_list.status = "Failed"
            await task_list.send()
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at input stage for query: {message.content}")
            await orchestrator.complete_pipeline()
            return

        # --- Retrieval Stage ---
        task_retrieval = cl.Task(title="Retrieving Documents", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_retrieval)
        await task_list.send()
        start_time = time.time()
        unique_documents = search_azure(query, k=4)
        context["documents"] = unique_documents
        retrieval_data = {
            "value": query,
            "metadata": {"Chunks": unique_documents},
            "conversation_id": conversation_id
        }
        await orchestrator.execute_stage("retrieval", retrieval_data)
        end_time = time.time()
        duration = end_time - start_time
        task_retrieval.status = cl.TaskStatus.DONE
        task_retrieval.title += f" (Completed in {duration:.2f}s, {len(unique_documents)} chunks)"
        await task_list.send()
        passed, reason, guard, validator, error_spans = await track_validations("retrieval", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Retrieval Validation Failed: {reason}", status=cl.TaskStatus.FAILED)
            await task_list.add_task(fail_task)
            total_time = (datetime.now() - pipeline_start_time).total_seconds()
            summary_tasks = [
                cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED),
            ]
            for task in summary_tasks:
                await task_list.add_task(task)
            task_list.status = "Failed"
            await task_list.send()
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at retrieval stage for query: {message.content}")
            await orchestrator.complete_pipeline()
            return

        # --- Output Stage ---
        task_output = cl.Task(title="Generating Response", status=cl.TaskStatus.RUNNING)
        await task_list.add_task(task_output)
        await task_list.send()
        start_time = time.time()
        context_str = "\n".join(unique_documents)
        prompt = f"Context: {context_str}\nQuestion: {query}"
        response = chat_gpt._generate([HumanMessage(content=prompt)])
        answer = response.generations[0].message.content
        context["answer"] = answer
        output_data = {
            "value": answer,
            "metadata": {"Chunks": unique_documents, "Answer": answer},
            "conversation_id": conversation_id
        }
        await orchestrator.execute_stage("output", output_data)
        end_time = time.time()
        duration = end_time - start_time
        task_output.status = cl.TaskStatus.DONE
        task_output.title += f" (Completed in {duration:.2f}s)"
        await task_list.send()
        passed, reason, guard, validator, error_spans = await track_validations("output", orchestrator, task_list, context)
        if not passed:
            user_message = get_user_friendly_message(validator, reason, error_spans)
            fail_task = cl.Task(title=f"Output Validation Failed: {reason}", status=cl.TaskStatus.FAILED)
            await task_list.add_task(fail_task)
            total_time = (datetime.now() - pipeline_start_time).total_seconds()
            summary_tasks = [
                cl.Task(title="Final Validation Summary: Failed", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Guard: {guard}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Failed Validator: {validator}", status=cl.TaskStatus.FAILED),
                cl.Task(title=f"Reason: {reason}", status=cl.TaskStatus.FAILED),
            ]
            for task in summary_tasks:
                await task_list.add_task(task)
            task_list.status = "Failed"
            await task_list.send()
            await cl.Message(content=user_message).send()
            logger.info(f"Pipeline failed at output stage for query: {message.content}")
            await orchestrator.complete_pipeline()
            return

        # Finalize Pipeline
        await orchestrator.complete_pipeline()
        logger.info(f"Pipeline completed successfully for query: {message.content}")

        # Final Validation Summary
        total_time = (datetime.now() - pipeline_start_time).total_seconds()
        summary_tasks = [
            cl.Task(title="Final Validation Summary: Completed Successfully", status=cl.TaskStatus.DONE),
            cl.Task(title=f"Total Time: {total_time:.2f}s", status=cl.TaskStatus.DONE),
        ]
        for task in summary_tasks:
            await task_list.add_task(task)
        task_list.status = "Done"
        await task_list.send()
        actions = [cl.Action(name="clear_session", label="Clear Session", payload={}, tooltip="Reset the chat")]
        await cl.Message(content=answer, actions=actions).send()

    except Exception as e:
        logger.error(f"Error in pipeline execution for query {message.content}: {str(e)}", exc_info=True)
        total_time = (datetime.now() - pipeline_start_time).total_seconds()
        summary_tasks = [
            cl.Task(title="Final Validation Summary: Failed due to unexpected error", status=cl.TaskStatus.FAILED),
            cl.Task(title=f"Time Taken: {total_time:.2f}s", status=cl.TaskStatus.FAILED),
            cl.Task(title=f"Error: {str(e)}", status=cl.TaskStatus.FAILED),
        ]
        for task in summary_tasks:
            await task_list.add_task(task)
        task_list.status = "Failed"
        await task_list.send()
        await cl.Message(content=f"Sorry, an unexpected error occurred: {str(e)}. Please try again later.").send()

if __name__ == "__main__":
    logger.info("Chainlit application launched.")