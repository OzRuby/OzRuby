import requests
import json

question = "CMs flight has been delayed by 24 hours  - what can they claim for"

response = requests.post("https://z-aas-soph-atuk-dva-ew1-fas01.z-aas-tran-shrd-rea-ew1-ase03.appserviceenvironment.net/api/conversations?",
                         json={
                            "user_id": "user_4",
                            "unit_id": "unit_1",
                            "message": question,
                            "document_name": "Puffin Travel Insurance.pdf"
                         })

res = json.loads(response.text)

print(res)

all_chunks = res["messages"][0]["sources"][0]['chunks']

for chunk in all_chunks:
    print(chunk["text"])