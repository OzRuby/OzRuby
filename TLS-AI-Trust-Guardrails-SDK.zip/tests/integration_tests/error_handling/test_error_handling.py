import pytest
import uuid
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.core.runner.pipeline_runner import PipelineRunner

@pytest.mark.asyncio
async def test_validator_failure(service_is_running, sdk_config, sample_data):
    """Test pipeline handling of a validator failure."""
    # Modify config to use a non-existent endpoint
    sdk_config.guards["UserQueryValidation"].validators[0].endpoint_url = "/validator/nonexistent"
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_model(sdk_config)
    pipeline_def._pipeline_execution_id = pipeline_id
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    runner = PipelineRunner(service_base_url="http://localhost:8080")
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=runner
    )

    # Act
    await orchestrator.execute_pipeline(sample_data)

    # Assert
    assert orchestrator._final_status in ["failed", "blocked"], "Pipeline should fail or block on validator error"
    for stage_result in orchestrator._orchestration_definition.stage_results:
        if stage_result.stage_name == "input":
            guard_result = stage_result.guard_results[0]
            assert any(v.execution_status == "fail" for v in guard_result.validators_execution_results)