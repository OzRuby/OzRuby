# tests/integration_tests/test_pipeline_execution.py

import pytest
import uuid
import os
import ssl
import certifi
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.models.orchestrator import OrchestrationStatusEnum
import httpx  # Assuming you're using httpx for async requests

# Create a custom SSL context with certifi certificates
ssl_context = ssl.create_default_context(cafile=certifi.where())

# Update httpx client to use the custom SSL context
@pytest.fixture
def http_client():
    return httpx.AsyncClient(verify=ssl_context)


@pytest.mark.asyncio
async def test_block_at_input_stage(pipeline_runner, sdk_config, sample_data_prompt_injection, http_client):
    """Test that the pipeline blocks at the input stage due to prompt injection."""
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_model(sdk_config)
    pipeline_def._pipeline_execution_id = pipeline_id
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=pipeline_runner
    )

    # Execute pipeline stages
    await orchestrator.start_pipeline()
    await orchestrator.execute_stage("input", sample_data_prompt_injection)
    await orchestrator.complete_pipeline()

    # Validate results
    assert orchestrator._final_status == OrchestrationStatusEnum.BLOCKED
    assert len(orchestrator._orchestration_definition.stages) == 1  # Only input executed
    input_stage = orchestrator._orchestration_definition.stages[0]
    assert input_stage.stage_name == "input"
    assert input_stage.status == OrchestrationStatusEnum.BLOCKED
    assert any(guard.final_decision == "BLOCK" for guard in input_stage.guard_results)
    assert "PromptInjection" in [guard.guard_name for guard in input_stage.guard_results if guard.final_decision == "BLOCK"]

@pytest.mark.asyncio
async def test_block_at_retrieval_irrelevant_chunks(pipeline_runner, sdk_config, sample_data_irrelevant_chunks):
    """Test that the pipeline blocks at retrieval due to irrelevant chunks, with output that would fail."""
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_model(sdk_config)
    pipeline_def._pipeline_execution_id = pipeline_id
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=pipeline_runner
    )

    # Execute pipeline stages
    await orchestrator.start_pipeline()
    await orchestrator.execute_stage("input", sample_data_irrelevant_chunks)
    await orchestrator.execute_stage("retrieval", sample_data_irrelevant_chunks)
    await orchestrator.complete_pipeline()

    # Validate results
    assert orchestrator._final_status == OrchestrationStatusEnum.BLOCKED
    assert len(orchestrator._orchestration_definition.stages) == 2  # Input and retrieval executed
    retrieval_stage = orchestrator._orchestration_definition.stages[1]
    assert retrieval_stage.stage_name == "retrieval"
    assert retrieval_stage.status == OrchestrationStatusEnum.BLOCKED
    assert any(guard.final_decision == "BLOCK" for guard in retrieval_stage.guard_results)
    assert "RelevanceChunk" in [guard.guard_name for guard in retrieval_stage.guard_results if guard.final_decision == "BLOCK"]

@pytest.mark.asyncio
async def test_block_at_retrieval_valid_output(pipeline_runner, sdk_config, sample_data_irrelevant_chunks_valid_output):
    """Test that the pipeline blocks at retrieval due to irrelevant chunks, with output that would pass."""
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_model(sdk_config)
    pipeline_def._pipeline_execution_id = pipeline_id
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=pipeline_runner
    )

    # Execute pipeline stages
    await orchestrator.start_pipeline()
    await orchestrator.execute_stage("input", sample_data_irrelevant_chunks_valid_output)
    await orchestrator.execute_stage("retrieval", sample_data_irrelevant_chunks_valid_output)
    await orchestrator.complete_pipeline()

    # Validate results
    assert orchestrator._final_status == OrchestrationStatusEnum.BLOCKED
    assert len(orchestrator._orchestration_definition.stages) == 2  # Input and retrieval executed
    retrieval_stage = orchestrator._orchestration_definition.stages[1]
    assert retrieval_stage.stage_name == "retrieval"
    assert retrieval_stage.status == OrchestrationStatusEnum.BLOCKED
    assert any(guard.final_decision == "BLOCK" for guard in retrieval_stage.guard_results)
    assert "RelevanceChunk" in [guard.guard_name for guard in retrieval_stage.guard_results if guard.final_decision == "BLOCK"]

@pytest.mark.asyncio
async def test_block_at_output_stage(pipeline_runner, sdk_config, sample_data_invalid_output):
    """Test that the pipeline blocks at the output stage due to an irrelevant answer."""
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_model(sdk_config)
    pipeline_def._pipeline_execution_id = pipeline_id
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=pipeline_runner
    )

    # Execute pipeline stages
    await orchestrator.start_pipeline()
    await orchestrator.execute_stage("input", sample_data_invalid_output)
    await orchestrator.execute_stage("retrieval", sample_data_invalid_output)
    await orchestrator.execute_stage("output", sample_data_invalid_output)
    await orchestrator.complete_pipeline()

    # Validate results
    assert orchestrator._final_status == OrchestrationStatusEnum.BLOCKED
    assert len(orchestrator._orchestration_definition.stages) == 3  # All stages executed
    output_stage = orchestrator._orchestration_definition.stages[2]
    assert output_stage.stage_name == "output"
    assert output_stage.status == OrchestrationStatusEnum.BLOCKED
    assert any(guard.final_decision == "BLOCK" for guard in output_stage.guard_results)
    assert "AnswerRelevance" in [guard.guard_name for guard in output_stage.guard_results if guard.final_decision == "BLOCK"]

@pytest.mark.asyncio
async def test_all_stages_pass(pipeline_runner, sdk_config, sample_data_all_pass):
    """Test that the pipeline completes successfully with all stages passing."""
    pipeline_id = uuid.uuid4()
    pipeline_def = PipelineDocBuilder.from_config_model(sdk_config)
    pipeline_def._pipeline_execution_id = pipeline_id
    pipeline_exec = pipeline_def.build_pipeline_execution_model()
    orchestrator = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=pipeline_runner
    )

    # Execute pipeline stages
    await orchestrator.start_pipeline()
    await orchestrator.execute_stage("input", sample_data_all_pass)
    await orchestrator.execute_stage("retrieval", sample_data_all_pass)
    await orchestrator.execute_stage("output", sample_data_all_pass)
    await orchestrator.complete_pipeline()

    # Validate results
    assert orchestrator._final_status == OrchestrationStatusEnum.COMPLETED
    assert len(orchestrator._orchestration_definition.stages) == 3  # All stages executed
    for stage in orchestrator._orchestration_definition.stages:
        assert stage.status == OrchestrationStatusEnum.COMPLETED
        assert all(guard.final_decision == "PASS" for guard in stage.guard_results)