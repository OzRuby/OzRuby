import sys
import os
import pytest
import requests
import httpx
from pathlib import Path
import pytest_asyncio
from unittest.mock import AsyncMock, patch, MagicMock

import uuid

# Add 'src' to sys.path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', ".."))
src_path = os.path.join(project_root, 'src')
if src_path not in sys.path:
    sys.path.insert(0, src_path)

print(f"Adding to sys.path: {src_path}")

from aitrust.core.runner.pipeline_runner import PipelineRunner
from aitrust.common.config import ConfigLoader
from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.models.orchestrator import OrchestrationStatusEnum

import asyncio

@pytest.fixture(autouse=True)
def no_sleep():
    """Fixture to mock asyncio.sleep and remove delays in all tests."""
    with patch("asyncio.sleep", new=AsyncMock()):
        yield


@pytest.fixture
def mock_orchestrator():
    """Provides a mocked PipelineOrchestrator instance for unit tests."""
    orchestrator = MagicMock(spec=PipelineOrchestrator)
    orchestrator._pipeline_execution_id = uuid.uuid4()
    orchestrator.get_pipeline_status = MagicMock(return_value=OrchestrationStatusEnum.NOT_STARTED)
    orchestrator.start_pipeline = AsyncMock()
    orchestrator.execute_stage = AsyncMock()
    return orchestrator

# --- Shared Fixtures (Used by Both Unit and Integration Tests) ---
@pytest.fixture
def known_config_path():
    """Provides the known config file path for tests."""
    return Path("tests/data/guard_config.yaml")

@pytest.fixture
def sample_config_loader(known_config_path):
    """Sample ConfigLoader fixture for testing."""
    return ConfigLoader(direct_config_path=known_config_path)

# --- Unit Test Fixtures ---
@pytest.fixture
def mock_httpx_client():
    """Mocks httpx.AsyncClient for unit tests to avoid real HTTP calls."""
    with patch("httpx.AsyncClient") as mock_client:
        mock_client.return_value.__aenter__.return_value = mock_client.return_value
        mock_client.return_value.__aexit__.return_value = AsyncMock()
        mock_client.return_value.post = AsyncMock(return_value=httpx.Response(200, json={"status": "mocked"}))
        mock_client.return_value.get = AsyncMock(return_value=httpx.Response(200, json={"data": "mocked"}))
        yield mock_client

# --- Integration Test Fixtures ---
@pytest.fixture(scope="session")
def service_is_running():
    """Ensure the service is running before integration tests proceed."""
    try:
        response = requests.get("http://localhost:8080/health/liveness", timeout=5)
        assert response.status_code == 204, "Service liveness check failed"
    except requests.RequestException:
        pytest.skip("Service is not running at http://localhost:8080")

@pytest.fixture(scope="session")
def base_url():
    """Base URL for the service (integration tests)."""
    return "http://localhost:8080"

@pytest_asyncio.fixture(scope="session")
async def integration_http_client():
    """HTTP client for integration tests with a longer timeout."""
    async with httpx.AsyncClient(timeout=60) as client:
        yield client

@pytest_asyncio.fixture
async def pipeline_runner(base_url, integration_http_client):
    """PipelineRunner instance with real HTTP client for integration tests."""
    runner = PipelineRunner(service_base_url=base_url)
    runner._http_client = integration_http_client  # Match attribute used in tests
    yield runner

# --- New Fixtures for Integration Tests ---
@pytest.fixture
def sdk_config(sample_config_loader):
    """Provides the parsed SDK configuration for integration tests."""
    return sample_config_loader.load_config()

@pytest.fixture
def sample_data():
    """Provides sample user input data for testing."""
    return "AXA tst tst user query"