import pytest
import uuid
from datetime import datetime
from unittest.mock import AsyncMock, patch, MagicMock
import asyncio

from aitrust.core.orchestration.pipeline_orchestrator import PipelineOrchestrator
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.common.config import ConfigLoader
from aitrust.models.orchestrator import OrchestrationStatusEnum
from aitrust.models.validator import (
    ValidatorStatusEnum,
    ValidatorResponseModel,
    ValidatorExecutionModel
)
from aitrust.core.aggregator.aggregators import BlockOnAnyAggregator

pytestmark = pytest.mark.asyncio

@pytest.fixture
def orchestrator_instance(known_config_path):
    """
    Provides a PipelineOrchestrator truncated to only the first stage, guard, validator.
    We ensure the validator config name in the pipeline matches our single ValidatorExecutionModel.
    """
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    config = config_loader.load_config()
    pipeline_def = PipelineDocBuilder.from_config_model(config)
    pipeline_exec = pipeline_def.build_pipeline_execution_model()

    runner = AsyncMock()
    runner.create_pipeline_record = AsyncMock(return_value=None)
    runner.update_pipeline_record = AsyncMock(lambda model: setattr(model, "revision", model.revision + 1))

    # Truncate pipeline definition to 1 zone, 1 guard, 1 validator
    pipeline_def._zones = pipeline_def._zones[:1]  # Keep just "input" zone
    pipeline_exec.stages_execution_results = pipeline_exec.stages_execution_results[:1]
    first_stage_exec = pipeline_exec.stages_execution_results[0]
    first_stage_exec.guards_execution_results = first_stage_exec.guards_execution_results[:1]
    first_guard_exec = first_stage_exec.guards_execution_results[0]
    first_guard_cfg = first_guard_exec.guard_config

    # Keep only the first validator in that guard
    first_guard_exec.validators_execution_results = first_guard_exec.validators_execution_results[:1]
    single_validator_exec = first_guard_exec.validators_execution_results[0]

    # Sync the name, type with guard config so aggregator sees them as the same
    if not first_guard_cfg.validators:
        raise RuntimeError("No validators found in first guard config!")
    single_guard_val_cfg = first_guard_cfg.validators[0]
    single_validator_exec.validator_config.name = single_guard_val_cfg.name
    single_validator_exec.validator_config.validator_type = single_guard_val_cfg.validator_type

    # Default pass
    single_validator_exec.response = ValidatorResponseModel(status="pass")

    # Return pass validator by default
    runner.run_validator = AsyncMock(return_value=single_validator_exec)

    orch = PipelineOrchestrator(
        pipeline_definition=pipeline_def,
        pipeline_execution_model=pipeline_exec,
        pipeline_runner=runner
    )

    # Expose references so test can override them
    orch._test_validator_exec_id = single_validator_exec.validator_execution_id
    orch._test_validator_config = single_validator_exec.validator_config
    return orch

async def test_execute_zone_timeout(orchestrator_instance):
    """
    We want the aggregator to see a "block" validator => final stage => BLOCKED.
    Previously we tried 'FAILED', but aggregator doesn't interpret that as block.
    So we do execution_status=BLOCK + response.status="block" => aggregator => BLOCK.
    """
    zone_name = orchestrator_instance._pipeline_definition.get_zones()[0]
    existing_id = orchestrator_instance._test_validator_exec_id
    existing_cfg = orchestrator_instance._test_validator_config

    def mock_run_validator(*args, **kwargs):
        return ValidatorExecutionModel(
            validator_execution_id=existing_id,
            validator_config=existing_cfg,
            execution_status=ValidatorStatusEnum.BLOCK,
            response=ValidatorResponseModel(status="block"),
            error_message="TimeoutError",
            start_time=datetime.now(),
            end_time=datetime.now(),
            last_update=datetime.now(),
        )

    with patch.object(orchestrator_instance._runner, "run_validator", side_effect=mock_run_validator):
        # Force aggregator to interpret "BLOCK" => stage => blocked
        with patch("aitrust.core.aggregator.aggregators.get_aggregator", return_value=BlockOnAnyAggregator()):
            stage_result, zone_node = await orchestrator_instance._execute_zone(zone_name, "fake data")
            assert stage_result.status == OrchestrationStatusEnum.BLOCKED, (
                f"Expected BLOCKED but got {stage_result.status}"
            )
            assert zone_node.status == OrchestrationStatusEnum.BLOCKED, (
                f"Expected BLOCKED but got {zone_node.status}"
            )

# The other tests remain the same, just shown for completeness:

async def test_start_pipeline_success(orchestrator_instance):
    await orchestrator_instance.start_pipeline()
    assert orchestrator_instance._final_status == OrchestrationStatusEnum.RUNNING
    orchestrator_instance._runner.create_pipeline_record.assert_awaited_once()
    orchestrator_instance._runner.update_pipeline_record.assert_awaited_once()

async def test_start_pipeline_already_started(orchestrator_instance):
    orchestrator_instance._final_status = OrchestrationStatusEnum.RUNNING
    await orchestrator_instance.start_pipeline()
    orchestrator_instance._runner.create_pipeline_record.assert_not_awaited()

async def test_execute_pipeline_pass(orchestrator_instance):
    pipeline_data = {stage: "test data" for stage in orchestrator_instance._pipeline_definition.get_zones()}
    await orchestrator_instance.execute_pipeline(pipeline_data)
    assert orchestrator_instance._final_status == OrchestrationStatusEnum.COMPLETED
    assert orchestrator_instance._runner.run_validator.call_count > 0

async def test_execute_pipeline_block(orchestrator_instance):
    mock_val_exec = orchestrator_instance._runner.run_validator.return_value
    mock_val_exec.execution_status = ValidatorStatusEnum.BLOCK
    mock_val_exec.response = ValidatorResponseModel(status="block")
    pipeline_data = {stage: "bad data" for stage in orchestrator_instance._pipeline_definition.get_zones()}
    await orchestrator_instance.execute_pipeline(pipeline_data)
    assert orchestrator_instance._final_status == OrchestrationStatusEnum.BLOCKED

async def test_execute_pipeline_missing_data(orchestrator_instance):
    pipeline_data = {"wrong_stage": "data"}
    await orchestrator_instance.execute_pipeline(pipeline_data)
    assert orchestrator_instance._final_status == OrchestrationStatusEnum.FAILED

async def test_execute_stage_valid(orchestrator_instance):
    await orchestrator_instance.start_pipeline()
    zone_name = orchestrator_instance._pipeline_definition.get_zones()[0]
    await orchestrator_instance.execute_stage(zone_name, "data")
    assert len(orchestrator_instance._orchestration_definition.stages) == 1
    assert orchestrator_instance._execution_tree_root.children

async def test_execute_stage_invalid(orchestrator_instance):
    with pytest.raises(ValueError, match="Stage 'invalid' not found"):
        await orchestrator_instance.execute_stage("invalid", "data")

async def test_execute_zone_async(orchestrator_instance):
    zone_name = orchestrator_instance._pipeline_definition.get_zones()[0]
    orchestrator_instance._pipeline_definition.get_zone_execution_mode = MagicMock(return_value="asynchronous")
    stage_result, _ = await orchestrator_instance._execute_zone(zone_name, "data")
    assert stage_result.status == OrchestrationStatusEnum.COMPLETED

async def test_hooks(orchestrator_instance):
    pre_hook = AsyncMock()
    post_hook = AsyncMock()
    zone_name = orchestrator_instance._pipeline_definition.get_zones()[0]
    orchestrator_instance.register_pre_hook(zone_name, pre_hook)
    orchestrator_instance.register_post_hook(zone_name, post_hook)
    pipeline_data = {zone_name: "data"}
    await orchestrator_instance.execute_pipeline(pipeline_data)
    pre_hook.assert_awaited_once()
    post_hook.assert_awaited_once()

async def test_complete_pipeline_success(orchestrator_instance):
    await orchestrator_instance.start_pipeline()
    for zone in orchestrator_instance._pipeline_definition.get_zones():
        await orchestrator_instance.execute_stage(zone, "data")
    await orchestrator_instance.complete_pipeline()
    assert orchestrator_instance._final_status == OrchestrationStatusEnum.COMPLETED

async def test_complete_pipeline_incomplete(orchestrator_instance):
    await orchestrator_instance.start_pipeline()
    await orchestrator_instance.complete_pipeline()
    assert orchestrator_instance._final_status == OrchestrationStatusEnum.RUNNING

async def test_retry_failure(orchestrator_instance):
    with patch.object(orchestrator_instance._runner, "run_validator", side_effect=Exception("fail")):
        with patch("asyncio.sleep", new=AsyncMock()):
            with patch("aitrust.core.orchestration.pipeline_orchestrator.ERROR_COUNTER", new=MagicMock()) as mock_err_counter:
                mock_err_counter.labels = MagicMock(return_value=MagicMock(inc=MagicMock()))
                with pytest.raises(Exception, match="fail"):
                    await orchestrator_instance._execute_with_retry(
                        orchestrator_instance._runner.run_validator, "data"
                    )
                mock_err_counter.labels.assert_called_once_with(error_type="Exception")
                mock_err_counter.labels().inc.assert_called_once()
