import pytest
from aitrust.security.secrets_manager import SecretsManager
from aitrust.models.authentification import AuthenticationDefinitionModel

def test_retrieve_auth_definition():
    """Tests retrieving an authentication definition."""
    manager = SecretsManager()
    auth_def = manager.retrieve_auth_definition("key")
    assert isinstance(auth_def, AuthenticationDefinitionModel)

def test_store_auth_definition():
    """Tests storing an authentication definition."""
    manager = SecretsManager()
    auth_def = AuthenticationDefinitionModel()
    manager.store_auth_definition(auth_def)  # No-op, just ensure it runs