import pytest
import logging
from unittest.mock import patch, AsyncMock
from datetime import datetime, timedelta
import json
import httpx

from aitrust.core.authentification.session_manager import SessionManager
from aitrust.models.authentification import AuthenticationDefinitionModel, AuthMethodEnum
from aitrust.common.exceptions import SDKServiceError, SDKInternalError

class MockResponse:
    def __init__(self, status_code, json_data):
        self.status_code = status_code
        self.json_data = json_data
    def json(self):
        return self.json_data
    def raise_for_status(self):
        if self.status_code != 200:
            raise Exception("HTTP error")

@pytest.mark.asyncio
async def test_api_key_auth():
    """Tests API key authentication."""
    auth_def = AuthenticationDefinitionModel(method=AuthMethodEnum.API_KEY, api_key="test_key")
    manager = SessionManager(auth_def)
    header = await manager.get_auth_header()
    assert header == {"Authorization": "Bearer test_key"}

@pytest.mark.asyncio
async def test_no_api_key():
    """
    No API key => logs a warning, returns {} 
    """
    auth_def = AuthenticationDefinitionModel(method=AuthMethodEnum.API_KEY)
    manager = SessionManager(auth_def)
    header = await manager.get_auth_header()
    assert header == {}

@pytest.mark.asyncio
async def test_oauth2_auth_cached():
    """Tests OAuth2 with cached token."""
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="https://example.com/token",
        oauth_client_id="client_id",
        oauth_client_secret="client_secret"
    )
    manager = SessionManager(auth_def)
    manager.token_cache = "cached_token"
    manager.token_expiry = datetime.utcnow() + timedelta(seconds=3600)
    header = await manager.get_auth_header()
    assert header == {"Authorization": "Bearer cached_token"}

@pytest.mark.asyncio
async def test_token_expired_refresh():
    """If token expired => calls _refresh_oauth_token"""
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="https://example.com/token",
        oauth_client_id="client_id",
        oauth_client_secret="secret"
    )
    manager = SessionManager(auth_def)
    manager.token_cache = "old_token"
    manager.token_expiry = datetime.utcnow() - timedelta(seconds=10)

    with patch.object(manager, "_refresh_oauth_token", new=AsyncMock(return_value={"access_token": "new123", "expires_in": 360})):
        hdr = await manager.get_auth_header()
        assert hdr == {"Authorization": "Bearer new123"}

@pytest.mark.asyncio
async def test_oauth2_auth_refresh():
    """Tests a normal OAuth2 token refresh -> new token returned."""
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="https://example.com/token",
        oauth_client_id="client_id",
        oauth_client_secret="client_secret"
    )
    manager = SessionManager(auth_def)
    with patch.object(manager._oauth_client, "post", new=AsyncMock(return_value=MockResponse(200, {"access_token": "new_token", "expires_in": 3600}))):
        header = await manager.get_auth_header()
        assert header == {"Authorization": "Bearer new_token"}
        assert manager.token_cache == "new_token"

@pytest.mark.asyncio
async def test_token_missing_fields():
    """
    We call _ensure_oauth_token() directly so we see the final exception "Failed to refresh OAuth2 token."
    If we called get_auth_header(), it would catch & return {} instead.
    """
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="http://mock.url/token",
        oauth_client_id="id",
        oauth_client_secret="secret"
    )
    manager = SessionManager(auth_def)

    # Forcing no cache so it calls _ensure_oauth_token
    manager.token_cache = None
    manager.token_expiry = None

    # missing 'access_token'
    with patch.object(manager, "_refresh_oauth_token", new=AsyncMock(return_value={"expires_in": 999})):
        # Expect the overshadowing "Failed to refresh OAuth2 token." from _ensure_oauth_token
        with pytest.raises(Exception, match="Failed to refresh OAuth2 token"):
            await manager._ensure_oauth_token()

@pytest.mark.asyncio
async def test_incomplete_oauth_config():
    """
    If token_url=None => ValueError from _refresh_oauth_token
    """
    auth_def = AuthenticationDefinitionModel(method=AuthMethodEnum.OAUTH2, oauth_token_url=None)
    manager = SessionManager(auth_def)
    with pytest.raises(ValueError, match="Incomplete OAuth2 configuration"):
        await manager._refresh_oauth_token()

@pytest.mark.asyncio
async def test_oauth2_auth_failure():
    """
    If _refresh_oauth_token raises an exception => get_auth_header logs & returns {}
    """
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="https://example.com/token",
        oauth_client_id="client_id",
        oauth_client_secret="client_secret"
    )
    manager = SessionManager(auth_def)
    with patch.object(manager._oauth_client, "post", side_effect=Exception("refresh failed")):
        # We call get_auth_header, it should catch the error & return {}
        header = await manager.get_auth_header()
        assert header == {}

@pytest.mark.asyncio
async def test_oauth_http_error():
    """
    We test _refresh_oauth_token directly. Code tries to parse e.response => raises SDKServiceError
    Now that your code uses "SDKServiceError(msg, http_status_code=e.response.status_code, details=...)" 
    we define that constructor in your exceptions to accept them. 
    """
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="http://mock.url/token",
        oauth_client_id="id",
        oauth_client_secret="secret"
    )
    manager = SessionManager(auth_def)

    # Build a real 400 response
    fake_resp = httpx.Response(
        status_code=400,
        request=httpx.Request("POST", "http://mock.url/token"),
        json={"error": "invalid_grant"}
    )
    # Make an HTTPStatusError with .response
    exc = httpx.HTTPStatusError("boom", request=fake_resp.request, response=fake_resp)

    with patch.object(manager._oauth_client, "post", side_effect=exc):
        with pytest.raises(SDKServiceError, match="HTTP error"):
            await manager._refresh_oauth_token()

@pytest.mark.asyncio
async def test_oauth_json_decode_error():
    """
    200 response but invalid JSON => json.JSONDecodeError => raises SDKServiceError
    We must call _refresh_oauth_token directly. If we used get_auth_header, it'd overshadow the exception.
    """
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="http://mock.url/token",
        oauth_client_id="id",
        oauth_client_secret="secret"
    )
    manager = SessionManager(auth_def)

    # 200 response, invalid JSON
    invalid_json_response = httpx.Response(
        status_code=200,
        request=httpx.Request("POST", "http://mock.url/token"),
        content=b"{ not valid json"
    )

    post_mock = AsyncMock(return_value=invalid_json_response)
    with patch.object(manager._oauth_client, "post", post_mock):
        with pytest.raises(SDKServiceError, match="JSON decode error during token refresh"):
            await manager._refresh_oauth_token()

@pytest.mark.asyncio
async def test_oauth_unexpected_error():
    """
    Another exception => raises SDKInternalError inside _refresh_oauth_token
    """
    auth_def = AuthenticationDefinitionModel(
        method=AuthMethodEnum.OAUTH2,
        oauth_token_url="http://mock.url/token",
        oauth_client_id="id",
        oauth_client_secret="secret"
    )
    manager = SessionManager(auth_def)
    with patch.object(manager._oauth_client, "post", side_effect=TypeError("unhandled")):
        with pytest.raises(SDKInternalError, match="Unexpected error during token refresh"):
            await manager._refresh_oauth_token()

@pytest.mark.asyncio
async def test_close_session():
    """cover close_session => aclose"""
    auth_def = AuthenticationDefinitionModel(method=AuthMethodEnum.NONE)
    manager = SessionManager(auth_def)
    with patch.object(manager._oauth_client, "aclose", new=AsyncMock()) as mock_aclose:
        await manager.close_session()
        mock_aclose.assert_awaited_once()

@pytest.mark.asyncio
async def test_none_auth():
    """Tests no authentication method."""
    auth_def = AuthenticationDefinitionModel(method=AuthMethodEnum.NONE)
    manager = SessionManager(auth_def)
    header = await manager.get_auth_header()
    assert header == {}
