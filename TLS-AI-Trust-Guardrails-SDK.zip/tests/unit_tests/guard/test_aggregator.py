import pytest
from uuid import uuid4
from aitrust.core.aggregator.aggregators import BlockOnAnyAggregator, BlockOnMandatoryAggregator
from aitrust.common.config import ConfigLoader
from aitrust.models.validator import ValidatorStatusEnum, ValidatorExecutionModel, ValidatorResponseModel
from aitrust.models.guard import GuardSettings

def test_block_on_any_aggregator(known_config_path):
    """Tests BlockOnAnyAggregator using validators from the real config."""
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    config = config_loader.load_config()

    stage_name = config.pipeline_stages[0].name
    guards = [guard for guard in config.guards.values() if stage_name in guard.stages]

    if not guards or not guards[0].validators:
        pytest.skip("No guards or validators found in config for testing")

    validator_config = guards[0].validators[0]

    # Fix: Define response models
    response_pass = ValidatorResponseModel(status="pass")
    response_block = ValidatorResponseModel(status="block")

    test_cases = [
        ([ValidatorStatusEnum.COMPLETED, ValidatorStatusEnum.COMPLETED], "PASS"),
        ([ValidatorStatusEnum.COMPLETED, ValidatorStatusEnum.BLOCK], "BLOCK"),
        ([ValidatorStatusEnum.FAILED, ValidatorStatusEnum.COMPLETED], "BLOCK"),
    ]

    aggregator = BlockOnAnyAggregator()
    for statuses, expected in test_cases:
        validators = [
            ValidatorExecutionModel(
                pipeline_execution_id=uuid4(),
                validator_execution_id=uuid4(),
                validator_config=validator_config,
                execution_status=status,
                # Fix: Set response based on status
                response=response_pass if status == ValidatorStatusEnum.COMPLETED else response_block
            ) for status in statuses
        ]
        assert aggregator.aggregate(validators) == expected, f"Failed for statuses {statuses}"

def test_block_on_mandatory_aggregator(known_config_path):
    """Tests BlockOnMandatoryAggregator with a mandatory validator from the config."""
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    config = config_loader.load_config()

    stage_name = config.pipeline_stages[0].name
    guards = [guard for guard in config.guards.values() if stage_name in guard.stages]

    if not guards or not guards[0].validators:
        pytest.skip("No guards or validators found in config for testing")

    mandatory_validator_config = guards[0].validators[0]
    optional_validator_config = guards[0].validators[1] if len(guards[0].validators) > 1 else mandatory_validator_config

    aggregator = BlockOnMandatoryAggregator()
    settings = GuardSettings(mendatory_validators=[mandatory_validator_config.name])

    # Fix: Define response models
    response_block = ValidatorResponseModel(status="block")
    response_pass = ValidatorResponseModel(status="pass")

    validators = [
        ValidatorExecutionModel(
            pipeline_execution_id=uuid4(),
            validator_execution_id=uuid4(),
            validator_config=mandatory_validator_config,
            execution_status=ValidatorStatusEnum.BLOCK,
            response=response_block  # Fix: Set response
        ),
        ValidatorExecutionModel(
            pipeline_execution_id=uuid4(),
            validator_execution_id=uuid4(),
            validator_config=optional_validator_config,
            execution_status=ValidatorStatusEnum.COMPLETED,
            response=response_pass  # Fix: Set response
        )
    ]
    assert aggregator.aggregate(validators, settings) == "BLOCK"