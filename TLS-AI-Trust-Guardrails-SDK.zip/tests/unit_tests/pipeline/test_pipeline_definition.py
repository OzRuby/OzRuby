import pytest
from aitrust.core.pipeline.pipeline_builder import PipelineDocBuilder
from aitrust.common.config import ConfigLoader
from aitrust.models.common_enums import PipelineExecutionModeEnum

def test_pipeline_doc_builder_from_config_model(known_config_path):
    """Tests building PipelineDocBuilder from the real config model."""
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    config = config_loader.load_config()
    pipeline_def = PipelineDocBuilder.from_config_model(config)
    
    # Validate zones based on the real config
    zones = pipeline_def.get_zones()
    assert "input" in zones, "Expected 'input' zone in config"
    assert "retrieval" in zones, "Expected 'retrieval' zone in config"
    assert "output" in zones, "Expected 'output' zone in config"
    
    # Validate guards for 'input' zone (assuming UserQueryValidation exists)
    input_guards = pipeline_def.get_guards_for_zone("input")
    assert len(input_guards) > 0, "Expected at least one guard in 'input' zone"
    assert any(guard.name == "UserQueryValidation" for guard in input_guards), "Expected 'UserQueryValidation' guard"
    
    # Validate execution mode (assuming retrieval is ASYNCHRONOUS in config)
    assert pipeline_def.get_zone_execution_mode("retrieval") == PipelineExecutionModeEnum.ASYNCHRONOUS, "Expected retrieval to be ASYNCHRONOUS"