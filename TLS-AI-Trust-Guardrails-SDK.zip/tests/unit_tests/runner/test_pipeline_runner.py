import pytest
import uuid
from unittest.mock import patch, AsyncMock, MagicMock
from datetime import datetime

from aitrust.core.runner.pipeline_runner import PipelineRunner
from aitrust.models.pipeline import PipelineExecutionModel
from aitrust.models.guard import GuardConfiguration
from aitrust.models.validator import (
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorStatusEnum,
    ValidatorResponseModel
)

class MockResponse:
    def __init__(self, status_code, json_data=None):
        self.status_code = status_code
        self.json_data = json_data or {}
    def json(self):
        return self.json_data
    def raise_for_status(self):
        if self.status_code != 200:
            raise Exception("HTTP error")

@pytest.mark.asyncio
async def test_create_pipeline_record_success_dict_stages():
    """
    Example test that uses a list of string stage names (which matches the pydantic model)
    and a dictionary for guards_config.
    """
    runner = PipelineRunner("http://mock.url")
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        # The PipelineExecutionModel expects pipeline_stages: List[str]
        pipeline_stages=["input"],
        # The PipelineExecutionModel expects guards_config: Dict[str, GuardConfiguration]
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[
                    ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")
                ],
            )
        },
    )

    with patch.object(runner.http_client, "post", new=AsyncMock(return_value=MockResponse(200))):
        await runner.create_pipeline_record(pipeline_model)

@pytest.mark.asyncio
async def test_update_pipeline_record_success():
    """Tests successful pipeline record update."""
    runner = PipelineRunner("http://mock.url")
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[
                    ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")
                ],
            )
        },
    )
    with patch.object(runner.http_client, "post", new=AsyncMock(return_value=MockResponse(200))):
        await runner.update_pipeline_record(pipeline_model)

@pytest.mark.asyncio
async def test_run_validator_success():
    """Tests successful validator execution."""
    runner = PipelineRunner("http://mock.url")
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")]
            )
        }
    )
    validator_config = ValidatorConfig(
        name="test",
        endpoint_url="/test",
        validator_type="http_based"
    )
    validator_exec = ValidatorExecutionModel(
        validator_config=validator_config,
        execution_status=ValidatorStatusEnum.IN_PROGRESS
    )

    # Patch the validator_client's send_request and the runner's http_client.post
    with patch.object(runner.validator_client, "send_request", new=AsyncMock(return_value=validator_exec)):
        with patch.object(runner.http_client, "post", new=AsyncMock(return_value=MockResponse(200))):
            result = await runner.run_validator(
                "data", validator_config, pipeline_model, "zone", MagicMock(), validator_exec
            )
            assert result.execution_status == ValidatorStatusEnum.IN_PROGRESS

@pytest.mark.asyncio
async def test_run_validator_missing_exec():
    """Tests error when validator_exec_model is missing."""
    runner = PipelineRunner("http://mock.url")
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")]
            )
        },
    )
    validator_config = ValidatorConfig(name="test", endpoint_url="/test", validator_type="http_based")

    with pytest.raises(ValueError, match="Validator execution model is required"):
        await runner.run_validator("data", validator_config, pipeline_model, "zone", MagicMock())

@pytest.mark.asyncio
async def test_poll_event_based():
    """Tests polling for event-based validator."""
    runner = PipelineRunner("http://mock.url")
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[
                    ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="event_based")
                ]
            )
        }
    )
    validator_config = ValidatorConfig(
        name="test",
        endpoint_url="/test",
        validator_type="event_based"
    )
    validator_exec = ValidatorExecutionModel(
        validator_config=validator_config,
        execution_status=ValidatorStatusEnum.IN_PROGRESS
    )

    # Mock response that matches shape of a ValidatorExecutionModel
    mock_response_data = {
        "pipeline_execution_id": str(pipeline_model.pipeline_execution_id),
        "validator_execution_id": str(validator_exec.validator_execution_id),
        "validator_config": validator_config.model_dump(),
        "execution_status": "completed",
        "request": None,
        "response": ValidatorResponseModel(status="pass").model_dump(),
        "error_message": None,
        "start_time": datetime.now().isoformat(),
        "end_time": datetime.now().isoformat(),
        "last_update": datetime.now().isoformat()
    }

    with patch.object(runner.http_client, "get", new=AsyncMock(return_value=MockResponse(200, mock_response_data))):
        await runner._poll_for_event_based_completion(validator_exec, pipeline_model)
        assert validator_exec.execution_status == ValidatorStatusEnum.COMPLETED
