import pytest
import uuid
from unittest.mock import patch, AsyncMock
from datetime import datetime
from aitrust.common.utils.service_utils import update_pipeline_document_in_service, custom_encoder
from aitrust.models.pipeline import PipelineExecutionModel
from aitrust.models.guard import GuardConfiguration
from aitrust.models.validator import ValidatorConfig

class MockResponse:
    def __init__(self, status_code, text=""):
        self.status_code = status_code
        self.text = text
    def raise_for_status(self):
        if self.status_code != 200:
            raise Exception("HTTP error")

@pytest.mark.asyncio
async def test_update_pipeline_document_success():
    """Tests successful pipeline document update."""
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[
                    ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")
                ]
            )
        }
    )
    with patch("httpx.AsyncClient.post", new=AsyncMock(return_value=MockResponse(200))):
        await update_pipeline_document_in_service("http://mock.url", pipeline_model)

@pytest.mark.asyncio
async def test_update_pipeline_document_failure():
    """Tests handling of non-200 response."""
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[
                    ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")
                ]
            )
        }
    )
    with patch("httpx.AsyncClient.post", new=AsyncMock(return_value=MockResponse(500, "error"))):
        await update_pipeline_document_in_service("http://mock.url", pipeline_model)

@pytest.mark.asyncio
async def test_update_pipeline_document_exception():
    """Tests exception handling during update."""
    pipeline_model = PipelineExecutionModel(
        pipeline_execution_id=uuid.uuid4(),
        pipeline_definition_id=uuid.uuid4(),
        status="not_started",
        start_time=datetime.now(),
        pipeline_stages=["input"],
        guards_config={
            "test_guard": GuardConfiguration(
                name="test_guard",
                stages=["input"],
                validators=[
                    ValidatorConfig(name="test_validator", endpoint_url="/test", validator_type="http_based")
                ]
            )
        }
    )
    # Force an exception in the 'post' call
    with patch("httpx.AsyncClient.post", side_effect=Exception("network error")):
        await update_pipeline_document_in_service("http://mock.url", pipeline_model)

def test_custom_encoder_datetime():
    """Tests datetime encoding."""
    dt = datetime(2023, 1, 1)
    assert custom_encoder(dt) == "2023-01-01T00:00:00"

def test_custom_encoder_uuid():
    """Tests UUID encoding."""
    uid = uuid.uuid4()
    assert custom_encoder(uid) == str(uid)

def test_custom_encoder_invalid():
    """Tests error for unserializable object."""
    with pytest.raises(TypeError, match="not JSON serializable"):
        custom_encoder(object())
