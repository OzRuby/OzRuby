import pytest
import uuid
import json
from unittest.mock import patch, AsyncMock
from datetime import datetime
from aitrust.core.validator.validator_client import ValidatorClient
from aitrust.models.validator import ValidatorExecutionModel, ValidatorStatusEnum, ValidatorConfig

class MockResponse:
    def __init__(self, status_code, text=""):
        self.status_code = status_code
        self.text = text
    def json(self):
        return json.loads(self.text) if self.text else {}
    def raise_for_status(self):
        if self.status_code != 200:
            raise Exception("HTTP error")

@pytest.fixture(autouse=True)
def no_sleep():
    """
    Automatically mock asyncio.sleep so any retry logic won't actually wait.
    Applied to all tests in this file because of autouse=True.
    """
    with patch("asyncio.sleep", new=AsyncMock()):
        yield

@pytest.mark.asyncio
async def test_send_request_success():
    """Tests successful validator request."""
    client = ValidatorClient()
    payload = {"data": "test"}
    # Simulate a JSON body that decodes into a completed ValidatorExecutionModel
    mock_response_body = {
        "execution_status": "completed",
        "validator_config": {
            "name": "test",
            "endpoint_url": "/test",
            "validator_type": "http_based"
        },
        "pipeline_execution_id": str(uuid.uuid4()),
        "validator_execution_id": str(uuid.uuid4()),
        "response": {"status": "pass"},
        "start_time": datetime.now().isoformat(),
        "end_time": datetime.now().isoformat()
    }
    mock_response = MockResponse(200, json.dumps(mock_response_body))

    with patch.object(client.http_client, "post", new=AsyncMock(return_value=mock_response)):
        result = await client.send_request("http://mock.url", payload)
        assert result.execution_status == ValidatorStatusEnum.COMPLETED
        assert result.validator_config.name == "test"

@pytest.mark.asyncio
async def test_send_request_http_error():
    """Tests HTTP error with retries."""
    client = ValidatorClient()
    payload = {"data": "test"}
    # Return a 500 error each time
    with patch.object(client.http_client, "post", new=AsyncMock(return_value=MockResponse(500))):
        result = await client.send_request("http://mock.url", payload)
        assert result.execution_status == ValidatorStatusEnum.FAILED

@pytest.mark.asyncio
async def test_send_request_json_error():
    """Tests JSON decode error."""
    client = ValidatorClient()
    payload = {"data": "test"}
    # Return invalid JSON
    with patch.object(client.http_client, "post", new=AsyncMock(return_value=MockResponse(200, "not valid json"))):
        result = await client.send_request("http://mock.url", payload)
        assert result.execution_status == ValidatorStatusEnum.FAILED

@pytest.mark.asyncio
async def test_send_request_serialization_error():
    """Tests payload serialization error."""
    client = ValidatorClient()
    # Payload includes an unserializable object
    payload = {"data": object()}
    # We don't even need a patch here, because the error occurs on serialization
    result = await client.send_request("http://mock.url", payload)
    assert result.execution_status == ValidatorStatusEnum.FAILED
