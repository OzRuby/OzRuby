import pytest
from aitrust.common.exceptions import ConfigNotFound, ConfigBadFormat

def test_config_not_found_exception():
    """Tests raising ConfigNotFound exception."""
    with pytest.raises(ConfigNotFound, match="Config file not found"):
        raise ConfigNotFound("Config file not found")

def test_config_bad_format_exception():
    """Tests raising ConfigBadFormat exception."""
    with pytest.raises(ConfigBadFormat, match="Invalid config format"):
        raise ConfigBadFormat("Invalid config format")