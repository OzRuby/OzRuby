import pytest
from unittest.mock import MagicMock, AsyncMock
from aitrust.core.decorator.zone_decorator import pipeline_zone
from aitrust.models.orchestrator import OrchestrationStatusEnum
from uuid import uuid4

@pytest.mark.asyncio
async def test_pipeline_zone_success_input(known_config_path, monkeypatch, mock_orchestrator):
    """Tests successful input validation with pipeline starting."""
    monkeypatch.setenv("GUARDCONFIG_PATH", str(known_config_path))
    # Define a function to handle multiple calls
    def status_side_effect():
        if not hasattr(status_side_effect, "called"):
            status_side_effect.called = True
            return OrchestrationStatusEnum.NOT_STARTED
        return OrchestrationStatusEnum.RUNNING
    mock_orchestrator.get_pipeline_status.side_effect = status_side_effect
    @pipeline_zone(stage_name="input", intercept="input")
    async def test_function(data, orchestrator):
        return f"Processed: {data}"
    result = await test_function("test input", orchestrator=mock_orchestrator)
    assert result == "Processed: test input"
    mock_orchestrator.start_pipeline.assert_awaited_once()
    mock_orchestrator.execute_stage.assert_awaited_once_with("input", "test input")

@pytest.mark.asyncio
async def test_pipeline_zone_success_output(mock_orchestrator):
    """Tests successful output validation."""
    mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.RUNNING
    @pipeline_zone(stage_name="output", intercept="output")
    async def test_function(data, orchestrator):
        return "output data"
    result = await test_function("input", orchestrator=mock_orchestrator)
    assert result == "output data"
    mock_orchestrator.execute_stage.assert_awaited_once_with("output", "output data")

@pytest.mark.asyncio
async def test_pipeline_zone_success_both(mock_orchestrator):
    """Tests validation of both input and output."""
    mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.RUNNING
    @pipeline_zone(stage_name="both", intercept="both")
    async def test_function(data, orchestrator):
        return "processed"
    result = await test_function("input", orchestrator=mock_orchestrator)
    assert result == "processed"
    assert mock_orchestrator.execute_stage.call_count == 2
    mock_orchestrator.execute_stage.assert_any_await("both", "input")
    mock_orchestrator.execute_stage.assert_any_await("both", "processed")

def test_invalid_intercept_value():
    """Tests error for invalid intercept parameter."""
    with pytest.raises(ValueError, match="The 'intercept' parameter must be 'input', 'output', or 'both'"):
        @pipeline_zone(stage_name="input", intercept="invalid")
        def test_function(data, orchestrator):
            pass

@pytest.mark.asyncio
async def test_missing_orchestrator():
    """Tests error when orchestrator is missing or invalid."""
    @pipeline_zone(stage_name="input", intercept="input")
    async def test_function(data, orchestrator):
        pass
    with pytest.raises(ValueError, match="The 'orchestrator' keyword argument must be a PipelineOrchestrator instance"):
        await test_function("data")
    with pytest.raises(ValueError, match="The 'orchestrator' keyword argument must be a PipelineOrchestrator instance"):
        await test_function("data", orchestrator="not_an_orchestrator")

@pytest.mark.asyncio
async def test_pipeline_not_running(mock_orchestrator):
    """Tests behavior when pipeline is not running."""
    mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.FAILED
    @pipeline_zone(stage_name="input", intercept="input")
    async def test_function(data, orchestrator):
        return "Should not reach here"
    result = await test_function("data", orchestrator=mock_orchestrator)
    assert result is None
    mock_orchestrator.start_pipeline.assert_not_awaited()

@pytest.mark.asyncio
async def test_input_validation_blocks(mock_orchestrator):
    """Tests pipeline blocking on input validation."""
    def block_status(*_):
        mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.BLOCKED
    mock_orchestrator.execute_stage.side_effect = block_status
    mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.RUNNING
    @pipeline_zone(stage_name="input", intercept="input")
    async def test_function(data, orchestrator):
        return "Should not reach here"
    result = await test_function("data", orchestrator=mock_orchestrator)
    assert result is None

@pytest.mark.asyncio
async def test_output_validation_blocks(mock_orchestrator):
    """Tests pipeline blocking on output validation."""
    def block_status(*_):
        mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.BLOCKED
    mock_orchestrator.execute_stage.side_effect = block_status
    mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.RUNNING
    @pipeline_zone(stage_name="output", intercept="output")
    async def test_function(data, orchestrator):
        return "output"
    result = await test_function("data", orchestrator=mock_orchestrator)
    assert result is None

@pytest.mark.asyncio
async def test_no_input_data(mock_orchestrator):
    """Tests behavior with no input data (args empty)."""
    mock_orchestrator.get_pipeline_status.return_value = OrchestrationStatusEnum.RUNNING
    @pipeline_zone(stage_name="input", intercept="input")
    async def test_function(orchestrator):
        return "processed"
    result = await test_function(orchestrator=mock_orchestrator)
    assert result == "processed"
    mock_orchestrator.execute_stage.assert_not_awaited()