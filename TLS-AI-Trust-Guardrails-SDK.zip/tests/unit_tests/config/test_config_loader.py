import os
import pytest
from pathlib import Path
import yaml
from aitrust.common.config import ConfigLoader
from aitrust.models.config import SDKConfigModel, PipelineStageDefinition
from aitrust.models.common_enums import PipelineExecutionModeEnum

# Test loading a valid config from a direct path
def test_config_loader_loads_config(known_config_path):
    """Tests loading a config from a known path."""
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    config = config_loader.load_config()
    assert isinstance(config, SDKConfigModel)
    assert config.version == "1.0"
    assert config.project_infos.project_name == "Mock RAG GenTrust Application"
    assert config_loader.guard_config_path == known_config_path

# Test handling of a missing config file
def test_config_loader_missing_file(tmp_path):
    """Tests error handling for a missing config file with direct_config_path."""
    bad_path = tmp_path / "missing.yaml"
    config_loader = ConfigLoader(direct_config_path=bad_path)
    with pytest.raises(FileNotFoundError, match=r"Config file not found: .*missing.yaml"):
        config_loader.load_config()

# Test handling of invalid YAML
def test_config_loader_invalid_yaml(tmp_path):
    """Tests error handling for invalid YAML in config file."""
    invalid_path = tmp_path / "invalid.yaml"
    invalid_path.write_text("invalid: yaml: : :")
    config_loader = ConfigLoader(direct_config_path=invalid_path)
    with pytest.raises(ValueError, match="Error parsing YAML"):
        config_loader.load_config()

# Test get_config auto-loading behavior
def test_config_loader_get_config_auto_loads(known_config_path):
    """Tests that get_config loads the config if not already loaded."""
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    assert config_loader.config is None
    config = config_loader.get_config()
    assert isinstance(config, SDKConfigModel)
    assert config.version == "1.0"
    assert config_loader.config is not None

# Test parsing of pipeline stages
def test_config_loader_pipeline_stages(known_config_path):
    """Tests correct parsing of pipeline stages."""
    config_loader = ConfigLoader(direct_config_path=known_config_path)
    config = config_loader.load_config()
    assert all(isinstance(stage, PipelineStageDefinition) for stage in config.pipeline_stages)
    assert config.pipeline_stages[0].execution_mode == PipelineExecutionModeEnum.SEQUENTIAL

# Test loading config from environment variable
def test_config_loader_from_env(monkeypatch, tmp_path):
    """Tests loading config from GUARDCONFIG_PATH environment variable."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text("""
version: '1.0'
project_infos:
  project_name: 'Env Test'
pipeline_stages:
  - name: input
    execution_mode: sequential  # Use lowercase enum value
    guards:
      - UserQueryValidation
guards:
  UserQueryValidation:
    name: UserQueryValidation
    description: "Validate user queries"
    stages: ["input"]  # Add required field
    settings:
      response_aggregation_strategy: "BLOCK_ON_ANY"
    validators:
      - name: "ContentSafetyValidator"
        endpoint_url: "/validator/content-safety"
        validator_type: "http_based"
        priority: "p1"
""")
    monkeypatch.setenv("GUARDCONFIG_PATH", str(config_file))
    config_loader = ConfigLoader()
    config = config_loader.load_config()
    assert config.version == "1.0"
    assert config.project_infos.project_name == "Env Test"

# Test loading config from settings file
def test_config_loader_from_settings(tmp_path):
    """Tests loading config path from settings file when no env var is set."""
    settings_file = tmp_path / "settings.yaml"
    config_dir = tmp_path / "configs"
    config_dir.mkdir()
    config_file = config_dir / "config.yaml"
    config_file.write_text("""
version: '1.0'
project_infos:
  project_name: 'Settings Test'
pipeline_stages:
  - name: input
    execution_mode: sequential  # Use lowercase enum value
guards:
  UserQueryValidation:
    name: UserQueryValidation
    description: "Validate user queries"
    stages: ["input"]  # Add required field
    settings:
      response_aggregation_strategy: "BLOCK_ON_ANY"
    validators:
      - name: "ContentSafetyValidator"
        endpoint_url: "/validator/content-safety"
        validator_type: "http_based"
        priority: "p1"
""")
    settings_file.write_text(f"GUARDCONFIG_PATH: {config_dir}/config.yaml")  # Use absolute path
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr("aitrust.common.config.__file__", str(tmp_path / "dummy.py"))
        config_loader = ConfigLoader(settings_path=settings_file)
        config = config_loader.load_config()
        assert config.version == "1.0"
        assert config.project_infos.project_name == "Settings Test"

# Test missing settings file
def test_config_loader_missing_settings_file(tmp_path):
    """Tests error handling when settings file is missing and no env var is set."""
    config_loader = ConfigLoader(settings_path=tmp_path / "nonexistent.yaml")
    with pytest.raises(FileNotFoundError, match="Settings file not found"):
        config_loader.load_config()

# Test settings file missing GUARDCONFIG_PATH key
def test_config_loader_settings_missing_key(tmp_path):
    """Tests error when settings file lacks GUARDCONFIG_PATH."""
    settings_file = tmp_path / "settings.yaml"
    settings_file.write_text("other_key: value")
    config_loader = ConfigLoader(settings_path=settings_file)
    with pytest.raises(ValueError, match="missing 'GUARDCONFIG_PATH' key"):
        config_loader.load_config()

# Test empty config file
def test_config_loader_empty_file(tmp_path):
    """Tests error handling for an empty config file."""
    empty_path = tmp_path / "empty.yaml"
    empty_path.write_text("")
    config_loader = ConfigLoader(direct_config_path=empty_path)
    with pytest.raises(ValueError, match="Config file is empty"):
        config_loader.load_config()

# Test validation failure
def test_config_loader_validation_failure(tmp_path):
    """Tests validation error when config data is invalid."""
    invalid_config_path = tmp_path / "invalid_config.yaml"
    invalid_config_path.write_text("version: 'not_a_valid_version'")
    config_loader = ConfigLoader(direct_config_path=invalid_config_path)
    with pytest.raises(ValueError):
        config_loader.load_config()