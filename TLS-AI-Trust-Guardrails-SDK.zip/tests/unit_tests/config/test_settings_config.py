import os
import json
import pytest
import yaml
from pathlib import Path
from unittest.mock import patch
from pydantic import ValidationError
from aitrust.common.settings_config import load_global_config, ConfigNotFound
from aitrust.models.root import MainConfigModel

SAMPLE_SETTINGS_YAML = {
    "version": {"package": "0.1.0", "git_tag": "v-0.1.0"},
    "informations": {
        "id": "aitrust-SDK-axap",
        "name": "AI-Trust",
        "author_info": {
            "name": "Hicham TAZI (Devoteam)",
            "email": "hicham.tazi.devoteam@axapartners.com",
            "affiliation": "AXA Partners"
        },
        "use_llm": True,
        "use_ml": False,
        "description": "This SDK provides guardrails for AI trustworthiness.",
        "docs_url": "./docs"
    },
    "monitoring": {
        "logging": {"logger_name": "aitrust-SDK", "app_level": "info", "system_level": "warning"}
    },
    "settings": {
        "guard_config_path": "example/configs/guard_config.yaml",
        "orchestrator_settings": {"timeout": 60, "max_concurrency": 5, "max_retries": 3, "retry_backoff": 1.0},
        "polling_settings": {"interval": 5, "max_attempts": 10},
        "other_settings": {"log_level": "debug"}
    },
    "privacy": {
        "policy_id": "550e8400-e29b-41d4-a716-446655440000",
        "policy_name": "GDPR Compliance",
        "data_retention_days": 30,
        "anonymize": True,
        "created_at": "2023-10-01T00:00:00Z"
    },
    "security": {
        "policy_id": "550e8400-e29b-41d4-a716-446655440001",
        "policy_level": "moderate",
        "encryption_algorithm": "none",
        "enforce_tls": True,
        "created_at": "2023-10-01T00:00:00Z"
    }
}

@pytest.fixture
def temp_settings_yaml(tmp_path):
    """Creates a temporary settings.dev.yaml file for testing."""
    yaml_file = tmp_path / "settings.dev.yaml"
    with open(yaml_file, "w") as f:
        yaml.dump(SAMPLE_SETTINGS_YAML, f)
    return yaml_file

def test_load_settings_from_yaml(temp_settings_yaml, monkeypatch):
    monkeypatch.setenv("ENV", "dev")
    monkeypatch.delenv("AITRUST_CONFIG_JSON", raising=False)
    config = load_global_config(config_file_path=temp_settings_yaml)
    assert isinstance(config, MainConfigModel)
    assert config.version.package == "0.1.0"
    assert config.informations.id == "aitrust-SDK-axap"
    assert config.settings.orchestrator_settings["timeout"] == 60

def test_load_settings_from_env(monkeypatch):
    env_config = SAMPLE_SETTINGS_YAML.copy()
    env_config["version"]["package"] = "0.2.0"
    monkeypatch.setenv("AITRUST_CONFIG_JSON", json.dumps(env_config))
    config = load_global_config()
    assert isinstance(config, MainConfigModel)
    assert config.version.package == "0.2.0"
    assert config.informations.id == "aitrust-SDK-axap"
    assert config.settings.orchestrator_settings["timeout"] == 60

def test_missing_settings_file(monkeypatch):
    """Test that an exception is raised when settings.dev.yaml is missing."""
    monkeypatch.setenv("ENV", "dev")
    monkeypatch.delenv("AITRUST_CONFIG_JSON", raising=False)
    with pytest.raises(ConfigNotFound):
        load_global_config(config_file_path=Path("/non/existing/path/settings.dev.yaml"))

def test_invalid_settings_yaml(temp_settings_yaml, monkeypatch):
    """Test that a validation error is raised when settings.dev.yaml is invalid."""
    invalid_yaml = {"version": {"package": "0.1.0"}}  # Missing required fields
    with open(temp_settings_yaml, "w") as f:
        yaml.dump(invalid_yaml, f)
    
    monkeypatch.setenv("ENV", "dev")
    monkeypatch.delenv("AITRUST_CONFIG_JSON", raising=False)
    
    with pytest.raises(ValidationError):
        load_global_config(config_file_path=temp_settings_yaml)

def test_no_config_file_provided_and_no_env(monkeypatch):
    """
    If config_file_path is None, code tries <project-root>/configs/settings.dev.yaml.
    We mock Path.exists() to always return False, ensuring that default file doesn't exist.
    => raises ConfigNotFound
    """
    monkeypatch.delenv("AITRUST_CONFIG_JSON", raising=False)
    monkeypatch.setenv("ENV", "dev")

    def mock_exists(_self):
        return False

    with patch.object(Path, "exists", mock_exists):
        with pytest.raises(ConfigNotFound, match="Cannot find settings file"):
            load_global_config()

def test_env_json_parse_fail(monkeypatch):
    """
    Covers lines 56-58: environment config fails parse => raise error
    """
    monkeypatch.setenv("AITRUST_CONFIG_JSON", '{"invalid: true')
    with pytest.raises(Exception):
        load_global_config()
