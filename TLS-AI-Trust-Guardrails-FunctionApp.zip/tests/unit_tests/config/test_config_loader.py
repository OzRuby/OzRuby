import pytest
from pathlib import Path
from libs.common.config import load_global_config
from libs.models.root import MainConfigModel

@pytest.fixture
def mocked_config_data():
    return {
        "project": {"id": "lhhljkj", "name": "test group"},
        "settings": {
            "database": {
                "db_type": "CosmosDB",
                "cosmos_db": {
                    "api_key": "fake_key",
                    "container": "PipelineExecutionDocs",
                    "database": "AxaGenTrustCosmosDB",
                    "endpoint": "https://z-aas-aitr-shre-dva-ew1-cdb01.documents.azure.com:443/"
                }
            },
            "storage": {
                "endpoint": "https://zaasaitrshredvaew1sto01.blob.core.windows.net"
            },
            "queues": {
                "validator_hallucination_queue_name": "validator-hallucination-queue",
                "validator_grammar_queue_name": "validator-grammar-queue"
            }
        },
        "monitoring": {
            "logging": {"logger_name": "validator_service"}
        }
    }

def test_load_config_default(monkeypatch, mocked_config_data):
    def mock_load_global_config():
        return MainConfigModel.model_validate(mocked_config_data)

    monkeypatch.setattr("libs.common.config.load_global_config", mock_load_global_config)
    config = load_global_config()

    assert config.project.name == "test group"
    assert config.settings.database.cosmos_db.endpoint.get_secret_value() == mocked_config_data["settings"]["database"]["cosmos_db"]["endpoint"]
    assert config.settings.storage.endpoint == mocked_config_data["settings"]["storage"]["endpoint"]
    assert config.monitoring.logging.logger_name == "validator_service"

def test_load_config_from_env(tmp_path, monkeypatch, mocked_config_data):
    settings_file = tmp_path / "settings.dev.yaml"
    settings_file.write_text("""
project:
  id: "lhhljkj"
  name: "temp test group"
  business_lines: ["Travel", "Motor"]
  description: "temp description"
  building_permit: "temp permit"
settings:
  cloud:
    type: "azure"
    resource_group_name: "temp_rg"
  queues:
    orchestrator_queue_name: "orchestrator-queue"
    validator_queue_name: "validator-queue"
    validator_hallucination_queue_name: "validator-hallucination-queue"
    validator_grammar_queue_name: "validator-grammar-queue"
  database:
    db_type: "CosmosDB"
    cosmos_db:
      api_key: "temp-key"
      container: "test"
      database: "TempDB"
      endpoint: "https://temp.documents.azure.com:443/"
  storage:
    account_name: "tempaccount"
    api_key: "temp-blob-key"
    blob_container: "tempdata"
    endpoint: "https://tempaccount.blob.core.windows.net"
  cache:
    redis_host: "localhost"
    redis_port: 6379
    use_ssl: true
  key_vault:
    vault_name: "temp_vault"
    tenant_id: "temp_tenant"
  event_grid:
    topic_endpoint: "https://temp.eventgrid.endpoint"
    topic_key: "temp_topic_key"
monitoring:
  logging:
    logger_name: "temp_logger"
    system_level: "WARNING"
    app_level: "INFO"
""")

    monkeypatch.setenv("ENV", "dev")
    monkeypatch.setenv("CONFIG_JSON", "")
    monkeypatch.setenv("DOTENV_CONFIG", str(settings_file))

    config = load_global_config()

    assert config.project.name == "temp test group"
    assert config.settings.queues.validator_hallucination_queue_name == "validator-hallucination-queue"
    assert config.settings.queues.validator_grammar_queue_name == "validator-grammar-queue"
    assert config.settings.storage.endpoint == "https://tempaccount.blob.core.windows.net"
