# test_client.py

import pytest
from libs.common.utils.client import aiohttp_session, azure_transport, _aiohttp_cookie_jar
from aiohttp import ClientSession
from azure.core.pipeline.transport._aiohttp import AioHttpTransport
from libs.common.utils import client

pytestmark = pytest.mark.asyncio

@pytest.fixture(autouse=True)
async def clear_client_globals():
    client._cookie_jar = None
    client._session = None
    client._transport = None

async def test_aiohttp_cookie_jar_cached():
    jar1 = await _aiohttp_cookie_jar()
    jar2 = await _aiohttp_cookie_jar()
    assert jar1 is jar2, "Cookie jar caching failed."

async def test_aiohttp_session_cached():
    session1 = await aiohttp_session()
    session2 = await aiohttp_session()
    assert session1 is session2, "Client session caching failed."
    assert isinstance(session1, ClientSession)
    assert session1.timeout.total == 60
    assert session1.timeout.connect == 5

async def test_azure_transport_cached():
    transport1 = await azure_transport()
    transport2 = await azure_transport()
    assert transport1 is transport2, "Azure transport caching failed."
    assert isinstance(transport1, AioHttpTransport)
