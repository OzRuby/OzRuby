import pytest
import requests 

def test_health_liveness_success(base_url, requests_mock):
    """Test that the health liveness endpoint returns 204 No Content."""
    requests_mock.get(f"{base_url}/health/liveness", status_code=204, text="")
    response = requests.get(f"{base_url}/health/liveness")
    assert response.status_code == 204, f"Expected 204, got {response.status_code}"
    assert not response.content, "Expected no content in response"