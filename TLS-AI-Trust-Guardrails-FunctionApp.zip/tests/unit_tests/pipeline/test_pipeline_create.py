import pytest
import requests

def test_create_pipeline_success(base_url, valid_pipeline_payload, requests_mock):
    """Test creating a pipeline with a valid payload (Mocked API)."""
    payload, _ = valid_pipeline_payload
    requests_mock.post(
        f"{base_url}/pipeline",
        json={"message": "Pipeline record created.", "pipeline_execution_id": payload["pipeline_execution_id"]},
        status_code=200
    )

    response = requests.post(f"{base_url}/pipeline", json=payload)

    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    data = response.json()
    assert data["message"] == "Pipeline record created."
    assert data["pipeline_execution_id"] == payload["pipeline_execution_id"]

def test_create_pipeline_invalid_payload(base_url, requests_mock):
    """Test creating a pipeline with an invalid payload (Mocked API)."""
    requests_mock.post(
        f"{base_url}/pipeline",
        json={"error": {"message": "Invalid payload format"}},
        status_code=400
    )

    response = requests.post(f"{base_url}/pipeline", data="invalid")

    assert response.status_code == 400, f"Expected 400, got {response.status_code}"
