import pytest
import requests 


def test_update_pipeline_success(base_url, valid_pipeline_payload, requests_mock):
    """Test updating an existing pipeline."""
    payload, _ = valid_pipeline_payload
    pipeline_id = payload["pipeline_execution_id"]
    payload["status"] = "in_progress"
    requests_mock.post(
        f"{base_url}/pipeline/{pipeline_id}",
        json={"message": "Pipeline record updated.", "pipeline_execution_id": pipeline_id},
        status_code=200
    )
    response = requests.post(f"{base_url}/pipeline/{pipeline_id}", json=payload)
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    data = response.json()
    assert data["message"] == "Pipeline record updated."
    assert data["pipeline_execution_id"] == pipeline_id

def test_update_pipeline_invalid_payload(base_url, valid_pipeline_payload, requests_mock):
    """Test updating a pipeline with an invalid payload."""
    payload, _ = valid_pipeline_payload
    pipeline_id = payload["pipeline_execution_id"]
    requests_mock.post(
        f"{base_url}/pipeline/{pipeline_id}",
        json={"error": {"message": "Invalid payload format"}},
        status_code=400  # Assuming app should return 400
    )
    response = requests.post(f"{base_url}/pipeline/{pipeline_id}", data="invalid")
    assert response.status_code == 400, f"Expected 400, got {response.status_code}"