import pytest
from uuid import uuid4
import requests 

def test_get_pipeline_success(base_url, valid_pipeline_payload, requests_mock):
    """Test retrieving an existing pipeline."""
    payload, _ = valid_pipeline_payload
    pipeline_id = payload["pipeline_execution_id"]
    requests_mock.get(
        f"{base_url}/pipeline/{pipeline_id}",
        json={"pipeline_execution_id": pipeline_id},
        status_code=200
    )
    response = requests.get(f"{base_url}/pipeline/{pipeline_id}")
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    data = response.json()
    assert data["pipeline_execution_id"] == pipeline_id

def test_get_pipeline_not_found(base_url, requests_mock):
    """Test retrieving a non-existent pipeline."""
    non_existent_id = str(uuid4())
    requests_mock.get(
        f"{base_url}/pipeline/{non_existent_id}",
        json={"error": {"message": "Pipeline record not found"}},
        status_code=404
    )
    response = requests.get(f"{base_url}/pipeline/{non_existent_id}")
    assert response.status_code == 404, f"Expected 404, got {response.status_code}"
    data = response.json()
    assert "error" in data
    assert data["error"]["message"] == "Pipeline record not found"