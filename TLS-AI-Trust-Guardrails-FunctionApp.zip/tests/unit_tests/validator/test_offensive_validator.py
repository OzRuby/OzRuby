import pytest
from uuid import uuid4
from datetime import datetime
import requests 


def test_offensive_validator_success_clean_text(base_url, requests_mock):
    """Test offensive validator with clean text."""
    payload = {
        "request_id": str(uuid4()),
        "pipeline_execution_id": str(uuid4()),
        "validator_execution_id": str(uuid4()),
        "user_payload": {"content_type": "text", "value": "This is a clean text.", "metadata": {}, "method": "ml"},
        "config_parameters": {"threshold": 0.5, "validation_method": "ml"},
        "created_at": datetime.utcnow().isoformat()
    }
    requests_mock.post(
        f"{base_url}/validator/offensive",
        json={"execution_status": "completed", "response": {"status": "pass"}},
        status_code=200
    )
    response = requests.post(f"{base_url}/validator/offensive", json=payload)
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    data = response.json()
    assert data["execution_status"] == "completed"
    assert "response" in data and data["response"]["status"] == "pass"

def test_offensive_validator_missing_execution_id(base_url, requests_mock):
    """Test offensive validator with missing validator_execution_id."""
    payload = {
        "request_id": str(uuid4()),
        "pipeline_execution_id": str(uuid4()),
        "user_payload": {"content_type": "text", "value": "This is a test.", "metadata": {}, "method": "ml"},
        "config_parameters": {"threshold": 0.5, "validation_method": "ml"},
        "created_at": datetime.utcnow().isoformat()
    }
    requests_mock.post(
        f"{base_url}/validator/offensive",
        json={"error": {"message": "Missing validator_execution_id"}},
        status_code=400  # Assuming app should return 400
    )
    response = requests.post(f"{base_url}/validator/offensive", json=payload)
    assert response.status_code == 400, f"Expected 400, got {response.status_code}"