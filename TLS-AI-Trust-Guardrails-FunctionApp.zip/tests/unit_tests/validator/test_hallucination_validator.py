import pytest
from uuid import uuid4
from datetime import datetime
import requests 


def test_hallucination_validator_success(base_url, valid_pipeline_payload, requests_mock):
    """Test hallucination validator with valid payload."""
    payload, validator_execution_id = valid_pipeline_payload
    pipeline_id = payload["pipeline_execution_id"]
    validator_payload = {
        "request_id": str(uuid4()),
        "pipeline_execution_id": pipeline_id,
        "validator_execution_id": validator_execution_id,
        "user_payload": {"content_type": "text", "value": "Short text.", "metadata": {}, "method": "ml"},
        "config_parameters": {"max_length": 100, "validation_method": "ml"},
        "created_at": datetime.utcnow().isoformat()
    }
    requests_mock.post(
        f"{base_url}/validator/hallucination",
        json={"status": "in_progress", "job_id": "some_job_id"},
        status_code=202
    )
    response = requests.post(f"{base_url}/validator/hallucination", json=validator_payload)
    assert response.status_code == 202, f"Expected 202, got {response.status_code}: {response.text}"
    data = response.json()
    assert data["status"] == "in_progress"
    assert "job_id" in data

def test_hallucination_validator_missing_ids(base_url, requests_mock):
    """Test hallucination validator with missing IDs."""
    payload = {
        "request_id": str(uuid4()),
        "user_payload": {"content_type": "text", "value": "Test text.", "metadata": {}, "method": "ml"},
        "config_parameters": {"max_length": 100, "validation_method": "ml"},
        "created_at": datetime.utcnow().isoformat()
    }
    requests_mock.post(
        f"{base_url}/validator/hallucination",
        json={"error": {"message": "Missing required fields"}},
        status_code=400
    )
    response = requests.post(f"{base_url}/validator/hallucination", json=payload)
    assert response.status_code == 400, f"Expected 400, got {response.status_code}"
    data = response.json()
    assert "error" in data
    assert "Missing required fields" in data["error"]["message"]