import sys
import logging
import pytest
from unittest.mock import AsyncMock, patch
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Setup sys.path
project_root = Path(__file__).parents[2] / "app"
sys.path.insert(0, str(project_root))

from db_operations.cosmos_db import CosmosDbOperations
from libs.models.root import MainConfigModel
from libs.models.settings import (
    SettingsModel, CloudModel, DatabaseModel, CosmosDbModel,
    BlobStorageModel, QueuesModel, CacheModel, KeyVaultModel, EventGridModel
)
from libs.models.project import ProjectModel
from libs.models.monitoring import MonitoringModel, LoggingModel, LoggingLevelEnum

@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"

@pytest.fixture(scope="session")
def base_url():
    """Mock API Base URL for unit tests."""
    return "http://mock-api.local"

@pytest.fixture(scope="session")
def app_config():
    """Provides a mock application config for testing."""
    return MainConfigModel(
        project=ProjectModel(
            name="AXA GenTrust",
            description="AXA GenTrust Project",
            itpm_id="ITPM12345",
            it_owner_infos={"name": "AXA Tech Team", "email": "tech-team@axa.com"}
        ),
        settings=SettingsModel(
            cloud=CloudModel(type="Azure", resource_group_name="axa-resource-group"),
            database=DatabaseModel(
                db_type="cosmosdb",
                cosmos_db=CosmosDbModel(
                    api_key="test-api-key",
                    container="PipelineExecutionDocs",
                    database="AxaGenTrustCosmosDB",
                    endpoint="https://mock-db.local"
                )
            ),
            storage=BlobStorageModel(
                api_key="blob-api-key",
                blob_container="test-container",
                endpoint="https://mock.blob.local",
                account_name="testaccount"
            ),
            queues=QueuesModel(
                validator_hallucination_queue_name="mock-hallucination-queue",
                validator_grammar_queue_name="mock-grammar-queue"
            ),
            cache=CacheModel(redis_host="localhost", redis_port=6379, use_ssl=False),
            key_vault=KeyVaultModel(vault_name="mock-keyvault", tenant_id="mock-tenant-id"),
            event_grid=EventGridModel(topic_endpoint="https://mock.eventgrid.local", topic_key="event-grid-key")
        ),
        monitoring=MonitoringModel(
            logging=LoggingModel(
                logger_name="MOCK-SERVICE-APP",
                app_level=LoggingLevelEnum.DEBUG,
                system_level=LoggingLevelEnum.WARNING
            )
        )
    )

@pytest.fixture
def cosmos_db_ops(app_config):
    """Mocked Cosmos DB Operations."""
    return CosmosDbOperations(config=app_config)

@pytest.fixture
def mock_cosmos_container(mocker):
    """Mock Cosmos DB container (AsyncMock)."""
    container_mock = AsyncMock()

    class AsyncContextManagerMock:
        async def __aenter__(self):
            return container_mock

        async def __aexit__(self, exc_type, exc_val, exc_tb):
            pass

    mocker.patch(
        "db_operations.cosmos_db.CosmosDbOperations._use_client",
        return_value=AsyncContextManagerMock()
    )
    return container_mock

@pytest.fixture
def requests_mock():
    """Provides a mocked requests session."""
    import requests_mock as requests_mock_lib
    with requests_mock_lib.Mocker() as m:
        yield m

@pytest.fixture
def valid_pipeline_payload():
    """Mock valid pipeline payload."""
    return {
        "pipeline_execution_id": "test-pipeline-123",
        "guards_config": {
            "grammar-guard": {
                "execution_mode": "sequential",
                "guard_id": "grammar-123"
            },
            "hallucination-guard": {
                "execution_mode": "parallel",
                "guard_id": "hallucination-123"
            },
            "offensive-guard": {
                "execution_mode": "sequential",
                "guard_id": "offensive-123"
            }
        }
    }, {
        "grammar": "grammar-123",
        "hallucination": "hallucination-123",
        "offensive": "offensive-123"
    }
