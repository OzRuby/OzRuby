import pytest
from uuid import uuid4
from unittest.mock import AsyncMock
from db_operations.cosmos_db import CosmosDbOperations

pytestmark = pytest.mark.asyncio

@pytest.fixture
def cosmos_db_ops(app_config):
    """Mock Cosmos DB operations."""
    return CosmosDbOperations(config=app_config)

class AsyncIterMock:
    """Async iterator for mocking Cosmos DB query results."""
    def __init__(self, items):
        self._iter = iter(items)

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self._iter)
        except StopIteration:
            raise StopAsyncIteration

@pytest.fixture
def mock_cosmos_container(mocker):
    """Mock Cosmos DB container so that query_items returns an AsyncIterMock directly."""
    container = AsyncMock()

    # Default behaviour: return two fake pipeline docs
    container.query_items = lambda *args, **kwargs: AsyncIterMock([
        {
            "pipeline_execution_id": str(uuid4()),
            "id": str(uuid4()),
            "pipeline_definition_id": str(uuid4()),
            "pipeline_stages": [],
            "guards_config": {},
            "created_at": "2024-03-01T00:00:00Z"
        },
        {
            "pipeline_execution_id": str(uuid4()),
            "id": str(uuid4()),
            "pipeline_definition_id": str(uuid4()),
            "pipeline_stages": [],
            "guards_config": {},
            "created_at": "2024-03-02T00:00:00Z"
        }
    ])

    class AsyncContextManager:
        async def __aenter__(self_inner):
            return container
        async def __aexit__(self_inner, exc_type, exc_val, exc_tb):
            pass

    mocker.patch(
        "db_operations.cosmos_db.CosmosDbOperations._use_client",
        return_value=AsyncContextManager()
    )
    return container

async def test_cosmos_db_pipeline_aget_all(cosmos_db_ops, mock_cosmos_container):
    """Should return two pipelines when the DB mock yields two documents."""
    pipelines = await cosmos_db_ops.pipeline_aget_all()
    assert len(pipelines) == 2, f"Expected 2 pipelines, got {len(pipelines)}"

async def test_cosmos_db_pipeline_aget_not_found(cosmos_db_ops, mock_cosmos_container):
    """Should return None when no matching pipeline_execution_id is found."""
    # Override query_items to yield no results
    mock_cosmos_container.query_items = lambda *args, **kwargs: AsyncIterMock([])

    pipeline = await cosmos_db_ops.pipeline_aget(pipeline_execution_id=str(uuid4()))
    assert pipeline is None
