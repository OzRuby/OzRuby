import requests
import pytest
import time

@pytest.mark.asyncio
async def test_pipeline_crud_workflow(base_url, valid_pipeline_payload, cosmos_db_ops):
    payload, _ = valid_pipeline_payload
    pipeline_id = payload["pipeline_execution_id"]
    response = requests.post(f"{base_url}/pipeline", json=payload)
    assert response.status_code == 200

    pipeline = await cosmos_db_ops.pipeline_aget(pipeline_id)
    assert pipeline.status == "not_started"

    payload["status"] = "in_progress"
    response = requests.post(f"{base_url}/pipeline/{pipeline_id}", json=payload)
    assert response.status_code == 200

    time.sleep(2)
    response = requests.get(f"{base_url}/pipeline/{pipeline_id}")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "in_progress"

    pipeline = await cosmos_db_ops.pipeline_aget(pipeline_id)
    assert pipeline.status == "in_progress"
