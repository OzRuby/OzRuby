# conftest.py
"""
Pytest fixtures for integration tests.

Sets up the base URL, Cosmos DB connection, and creates a generic pipeline
record suitable for testing various validators defined in the application.
Uses the project's standard logger.
"""

import sys
import pytest
from dotenv import load_dotenv, find_dotenv
from pathlib import Path
from uuid import uuid4, UUID
from datetime import datetime, timezone
import requests
import time
import json
import asyncio

# --- Load .env ---
dotenv_path = find_dotenv()
if dotenv_path:
    print(f"Loading .env file from: {dotenv_path}")
    load_dotenv(dotenv_path)
else:
    print("Warning: .env file not found.")

# --- Path Setup ---
project_root = Path(__file__).resolve().parents[2] / "app"
if not project_root.is_dir():
     project_root = Path(__file__).resolve().parents[1]
if not project_root.is_dir():
     print(f"Error: Could not determine project root directory. Looked for 'app' under {Path(__file__).resolve().parents[2]} and {Path(__file__).resolve().parents[1]}")
     sys.exit("Project root directory not found.")
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))
    print(f"Added project root to sys.path: {project_root}")

# --- Import Application Modules ---
try:
    from libs.common.logs.logger import logger
    from db_operations.cosmos_db import CosmosDbOperations
    from libs.common.config import CONFIG
    from libs.models.pipeline import PipelineExecutionModel, PipelineStageExecutionResult
    from libs.models.guard import GuardConfiguration, GuardExecutionModel
    from libs.models.validator import (
        ValidatorExecutionModel,
        ValidatorConfig,
        ValidatorTypeEnum
    )
    from libs.models.common_enums import PipelineExecutionModeEnum, PipelineExecutionStatusEnum
except ImportError as e:
    print(f"CRITICAL: Failed to import application modules: {e}")
    print(f"Ensure app modules are accessible. Current sys.path: {sys.path}")
    pytest.exit(f"Module import failed: {e}", 1)


# --- Core Fixtures ---
@pytest.fixture(scope="session")
def anyio_backend() -> str:
    return "asyncio"

@pytest.fixture(scope="session")
def base_url() -> str:
    url = "http://localhost:8080"
    logger.info(f"Using Function App base URL: {url}")
    try:
        liveness_url = f"{url}/health/liveness"
        response = requests.get(liveness_url, timeout=10)
        response.raise_for_status()
        logger.info(f"Liveness check successful at {liveness_url}.")
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
        pytest.fail(f"Connection to Function App failed at {url}: {e}", pytrace=False)
    except requests.exceptions.RequestException as e:
        status_code = e.response.status_code if e.response is not None else "N/A"
        pytest.fail(f"Liveness check failed for {url}: Status {status_code}: {e}", pytrace=False)
    return url

@pytest.fixture(scope="session")
def cosmos_db_ops(request) -> CosmosDbOperations:
    logger.info("Initializing CosmosDbOperations for test session.")
    try:
        ops = CosmosDbOperations(config=CONFIG)
        logger.info("CosmosDbOperations initialized successfully.")
        return ops
    except Exception as e:
        logger.critical(f"Failed to initialize CosmosDbOperations: {e}", exc_info=True)
        pytest.fail(f"CosmosDB connection setup failed: {e}", pytrace=False)


# --- Pipeline Creation Fixtures ---
@pytest.fixture(scope="session")
def generic_validator_configs() -> dict[str, ValidatorConfig]:
    """
    Generates configurations for a standard set of validators.
    Session-scoped as validator definitions are unlikely to change between tests.
    """
    logger.debug("Generating generic validator configurations (session scope).")
    return {
        "grammar": ValidatorConfig(
            name="GrammarCheck",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"threshold": 0.5, "language": "en", "sensibility": "default"},
            endpoint_url="/validator/grammar_checker",
            priority="p1"
        ),
        "answer_relevance": ValidatorConfig(
            name="AnswerRelevance",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"threshold": 0.7},
            endpoint_url="/validator/answer_relevance",
            priority="p1"
        ),
        "chunk_relevance": ValidatorConfig(
            name="ChunkRelevance",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"threshold": 0.6},
            endpoint_url="/validator/chunk_relevance",
            priority="p1"
        ),
        "prompt_injection": ValidatorConfig(
            name="PromptInjection",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"threshold": 0.8},
            endpoint_url="/validator/prompt_injection",
            priority="p1"
        ),
        "calculation_logic": ValidatorConfig(
            name="CalculationLogic",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={},
            endpoint_url="/validator/calculation_logic",
            priority="p1"
        ),
        "format_checker": ValidatorConfig(
            name="FormatChecker",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"expected_format": "json"},
            endpoint_url="/validator/format_checker",
            priority="p1"
        ),
        "keyword_filtering": ValidatorConfig(
            name="KeywordFiltering",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"banned_keywords": ["secret", "internal"]},
            endpoint_url="/validator/keyword_filtering",
            priority="p1"
        ),
        "query_topics": ValidatorConfig(
            name="QueryTopics",
            validator_type=ValidatorTypeEnum.EVENT_BASED.value,
            parameters={"allowed_topics": ["support", "billing"]},
            endpoint_url="/validator/query_topics",
            priority="p1"
        ),
        "language_checker": ValidatorConfig(
            name="language_checker",
            validator_type="http_based", 
            endpoint_url="validator/language_checker", 
            priority= "p1",
            parameters=None
        ),
    }

@pytest.fixture
def valid_pipeline_payload_and_ids(generic_validator_configs) -> tuple[dict, dict[str, UUID]]:
    validator_configs = generic_validator_configs
    pipeline_id = uuid4()
    validator_execution_ids = {name: uuid4() for name in validator_configs.keys()}
    now_utc = datetime.now(timezone.utc)

    pipeline_stages_list = ["input", "retrieval", "output"]
    guards_validators = {
        "UserQueryValidation": ["language_checker", "grammar", "prompt_injection", "query_topics"],
        "ResponseSafetyAndQuality": ["chunk_relevance"],
        "DocumentRelevanceValidation": ["answer_relevance", "calculation_logic", "keyword_filtering"]
    }
    guard_stages = {
        "UserQueryValidation": ["input"],
        "ResponseSafetyAndQuality": ["retrieval"],
        "DocumentRelevanceValidation": ["output"]
    }

    guards_config_dict: dict[str, GuardConfiguration] = {}
    for guard_name, v_names in guards_validators.items():
        configs = [validator_configs[n] for n in v_names if n in validator_configs]
        if not configs:
            continue
        guards_config_dict[guard_name] = GuardConfiguration(
            guard_id=uuid4(),
            name=guard_name,
            stages=guard_stages.get(guard_name, []),
            validators=configs,
            execution_mode=PipelineExecutionModeEnum.SEQUENTIAL
        )

    initial_stages_exec_results: list[PipelineStageExecutionResult] = []
    for stage_name in pipeline_stages_list:
        guard_execs = []
        for guard_name, guard_cfg in guards_config_dict.items():
            if stage_name not in guard_cfg.stages:
                continue
            vals_exec = [
                ValidatorExecutionModel(
                    pipeline_execution_id=pipeline_id,
                    validator_execution_id=validator_execution_ids[v_name]
                )
                for v_name in guards_validators[guard_name]
                if v_name in validator_execution_ids
            ]
            guard_execs.append(GuardExecutionModel(
                guard_execution_id=uuid4(),
                guard_config=guard_cfg,
                validators_execution_results=vals_exec,
                last_update=now_utc
            ))
        initial_stages_exec_results.append(PipelineStageExecutionResult(
            stage_execution_id=uuid4(),
            stage_name=stage_name,
            guards_execution_results=guard_execs,
            created_at=now_utc
        ))

    pipeline_payload_model = PipelineExecutionModel(
        pipeline_execution_id=pipeline_id,
        pipeline_definition_id=UUID("00000000-0000-0000-0000-000000000001"),
        pipeline_stages=pipeline_stages_list,
        guards_config=guards_config_dict,
        stages_execution_results=initial_stages_exec_results,
        status=PipelineExecutionStatusEnum.NOT_STARTED,
        start_time=now_utc,
        last_update=now_utc,
        revision=1
    )

    payload_dict = pipeline_payload_model.model_dump(mode="json")
    payload_dict["id"] = str(pipeline_id)
    return payload_dict, validator_execution_ids

@pytest.fixture
async def create_pipeline(base_url: str, valid_pipeline_payload_and_ids) -> tuple[UUID, dict[str, UUID]]:
    payload_dict, validator_execution_ids = valid_pipeline_payload_and_ids
    create_url = f"{base_url}/pipeline"
    response = requests.post(create_url, json=payload_dict, timeout=10)
    if not response.ok:
        pytest.fail(f"Failed to create pipeline ({response.status_code}): {response.text}", pytrace=False)
    pipeline_id = UUID(response.json()["pipeline_execution_id"])
    get_resp = requests.get(f"{base_url}/pipeline/{pipeline_id}", timeout=10)
    if not get_resp.ok:
        pytest.fail(f"Pipeline not found after creation: {get_resp.status_code}", pytrace=False)
    return pipeline_id, validator_execution_ids

@pytest.fixture
def poll_validator_status(base_url: str, anyio_backend: str):
    async def _poll(pipeline_id: UUID, validator_execution_id: UUID, timeout: int = 120, interval: int = 5) -> dict:
        start = time.time()
        from libs.models.validator import ValidatorExecutionStatusEnum
        terminal = {
            s.value for s in ValidatorExecutionStatusEnum
            if s not in (ValidatorExecutionStatusEnum.NOT_STARTED, ValidatorExecutionStatusEnum.IN_PROGRESS)
        }
        url = f"{base_url}/pipeline/{pipeline_id}/validator/{validator_execution_id}"
        while time.time() - start < timeout:
            resp = requests.get(url, timeout=15)
            if resp.status_code == 404:
                await asyncio.sleep(interval)
                continue
            data = resp.json()
            status = data.get("execution_status")
            if status in terminal:
                return data
            await asyncio.sleep(interval)
        raise TimeoutError(f"Validator {validator_execution_id} did not reach terminal state within {timeout}s.")
    return _poll
