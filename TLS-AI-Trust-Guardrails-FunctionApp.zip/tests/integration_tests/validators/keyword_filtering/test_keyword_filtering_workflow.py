"""
Integration test for the keyword filtering validator workflow via the Function App API.

Verifies the synchronous HTTP endpoint returns the final validation result immediately.
"""
import pytest
from uuid import uuid4, UUID
from datetime import datetime, timezone
import requests
import logging

from libs.models.validator import (
    ValidatorRequestModel,
    UserPayloadModel,
    ContentTypeEnum,
    ValidatorMethodEnum,
    ValidatorExecutionStatusEnum,
    ValidatorResponseStatusEnum,
    ValidatorConfig
)
from libs.common.logs.logger import logger as project_logger

test_logger = logging.getLogger(__name__)

@pytest.mark.asyncio
async def test_keyword_filtering_full_workflow(
    base_url: str,
    create_pipeline: tuple[UUID, dict[str, UUID]],
):
    test_logger.info("--- Starting Test: Keyword Filtering Validator Full Workflow ---")

    # 1. Test Setup
    pipeline_id, validator_execution_ids = create_pipeline
    keyword_filtering_validator_id = validator_execution_ids["keyword_filtering"]
    test_logger.info(
        f"Pipeline ID={pipeline_id}, "
        f"Keyword Filtering Validator Execution ID={keyword_filtering_validator_id}"
    )

    # 2. Prepare Validator Request Payload
    query = "Can you explain the different types of insurance policies available?"
    test_run_id = str(uuid4())

    validator_config = ValidatorConfig(
        name="KeywordFiltering",
        validator_type="event_based",
        parameters={"banned_keywords": ["secret", "internal"]},
        endpoint_url="/validator/keyword_filtering",
        priority="p1"
    )

    user_payload = UserPayloadModel(
        content_type=ContentTypeEnum.TEXT,
        value=query,
        metadata={"test_run_id": test_run_id},
        method=ValidatorMethodEnum.REGEX,
    )
   

    config_parameters = {
        "keywords_filtering": ["Bereavement",
                            "Death",
                            "Death of a close relative",
                            "Pregnancy with complications",
                            "Victims of assault",
                            "sexual assault",
                            "violence",
                            "violence while abroad"
                            "terrorism",
                            "Emergency",
                            "Emergency Assistance"],
        "content_type": "text"
    }
    request_payload = ValidatorRequestModel(
        project_name="Travel General Enquieries",
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        request_id=uuid4(),
        validator_config =  validator_config.model_dump(),
        conversation_id=UUID("479473ce-2fb4-44b0-ab07-00c86be52f2f"),
        validation_method=ValidatorMethodEnum.REGEX,
        pipeline_execution_id=pipeline_id,
        validator_execution_id=keyword_filtering_validator_id,
        user_payload=user_payload,
        config_parameters=config_parameters,
        created_at=datetime.now(timezone.utc),
    )
    test_logger.info("Prepared ValidatorRequestModel payload.")

    # 3. Call the synchronous keyword_filtering endpoint
    endpoint_url = f"{base_url}/validator/keyword_filtering"
    response = requests.post(
        endpoint_url,
        json=request_payload.model_dump(mode="json", exclude_none=True),
        timeout=30
    )
    # This endpoint returns 200 OK with the completed ValidatorExecutionModel
    assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
    test_logger.info("Received HTTP 200 OK with validation result.")

    # 4. Parse and inspect final state
    final_state = response.json()

    # 5. Assert Final Execution Status
    exec_status = final_state.get("execution_status")
    assert exec_status == ValidatorExecutionStatusEnum.COMPLETED.value, \
        f"Expected execution_status 'completed' but got '{exec_status}'"
    test_logger.info(f"Validator execution status: {exec_status}")

    # 6. Check Validator Response Verdict
    response_part = final_state.get("response")
    assert isinstance(response_part, dict), "Missing 'response' in final state"
    verdict = response_part.get("status")
    assert verdict == ValidatorResponseStatusEnum.PASS.value, \
        f"Expected response.status 'pass' but got '{verdict}'"
    test_logger.info(f"Validator verdict: {verdict}")

    # 7. Check Response Details
    details = response_part.get("details", {})
    outcome = details.get("Result", {}).get("outcome")
    assert outcome == "pass", f"Expected details.Result.outcome 'pass' but got '{outcome}'"
    test_logger.info("All assertions passed for Keyword Filtering validator test.")
