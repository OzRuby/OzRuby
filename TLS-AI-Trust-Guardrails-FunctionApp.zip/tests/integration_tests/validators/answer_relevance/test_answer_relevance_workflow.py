"""
Integration test for the answer relevance validator workflow via the Function App API.

Verifies the asynchronous processing from HTTP request initiation, queuing,
execution by the queue trigger, and final status update polling via the API.
"""

import pytest
from uuid import uuid4, UUID
from datetime import datetime, timezone
import requests
import json
import logging
import asyncio

from libs.models.validator import (
    ValidatorRequestModel,
    UserPayloadModel,
    ContentTypeEnum,
    ValidatorMethodEnum,
    ValidatorExecutionStatusEnum,
    ValidatorResponseStatusEnum,
    ValidatorConfig
)
from libs.common.logs.logger import logger as project_logger

test_logger = logging.getLogger(__name__)

TERMINAL_EXECUTION_STATUSES = {
    s.value for s in ValidatorExecutionStatusEnum
    if s not in (
        ValidatorExecutionStatusEnum.NOT_STARTED,
        ValidatorExecutionStatusEnum.IN_PROGRESS
    )
}
SUCCESSFUL_EXECUTION_STATUSES = {
    ValidatorExecutionStatusEnum.COMPLETED.value
}

@pytest.mark.asyncio
async def test_answer_relevance_full_workflow(
    base_url: str,
    create_pipeline: tuple[UUID, dict[str, UUID]],
    poll_validator_status: callable
):
    test_logger.info("--- Starting Test: Answer Relevance Validator Full Workflow ---")

    # 1. Test Setup
    pipeline_id, validator_execution_ids = create_pipeline
    answer_relevance_validator_id = validator_execution_ids["answer_relevance"]
    test_logger.info(
        f"Test Setup: Pipeline ID={pipeline_id}, "
        f"Answer Relevance Validator Execution ID={answer_relevance_validator_id}"
    )

    # 2. Prepare Validator Request Payload
    query = (
        "Economy cm want to know it the flight cancel by the airline and airline "
        "provide a new flight but the flight is very late cm need to take taxi "
        "return home can she make claim on it."
    )
    answer = (
        "This scenario is not likely to be considered. Why? I understand that your flight was canceled by the airline, "
        "and although a new flight was provided, it was very late, necessitating a taxi ride home. Let's break down what "
        "is covered and what is not under your Economy policy. What is covered? 1. Delayed Arrivals and Associated Claims: "
        "Covers reasonable additional accommodation and public transport costs if the arrival is delayed. Special conditions "
        "include seeking compensation from the travel provider and allowing enough time to arrive at the departure point. "
        "Policy Amounts: Missed Departure is insured up to £500 for Economy, with no excess applicable. Travel Delay Benefit "
        "per 12 hours is insured up to £20 for Economy, with a total of up to £200. 2. Disruption or Delay to Travel Plans: "
        "Covers missed departure due to failure of public transport, accidents, breakdowns, or adverse weather conditions. "
        "Mentions the Denied Boarding Regulation (Regulation 261/2004 EC) which may entitle you to compensation from the airline. "
        "What is not covered? 1. Delayed Arrivals and Associated Claims: Excludes costs recoverable from the transportation "
        "provider and any travel costs where the public transport operator has offered reasonable alternative travel arrangements. "
        "Since the airline provided a new flight, this might be considered a reasonable alternative travel arrangement, which "
        "could exclude the taxi fare from being covered. 2. Disruption or Delay to Travel Plans: Does not explicitly cover the "
        "scenario of taking a taxi home after a delayed flight. 3. General Exclusions: Excludes any claim arising from a reason "
        "not listed under What is covered and circumstances known before purchasing the policy. Documents needed to submit the "
        "claim: Proof of flight cancellation and the new flight details provided by the airline. Receipts for any additional "
        "costs incurred, such as the taxi fare. Any correspondence with the airline regarding compensation. Based on the Economy "
        "policy, it appears that your situation may not be covered due to the exclusions related to reasonable alternative travel "
        "arrangements provided by the airline. However, it is recommended to seek compensation directly from the airline for any "
        "additional costs incurred due to the delay. If you have any further questions or need additional assistance, please let me know."
    )
    chunks = [
        "If you are unable to show they have been followed this may affect your ability to claim. 1. You must seek financial "
        "compensation, assistance or a refund of your costs from your travel provider and invoke your rights under EU Air "
        "Passenger Rights legislation in the event of cancellation or delay of flights if applicable. 2. You must allow enough "
        "time to arrive at the departure point and check in for your outward or return journey.",
        "We are covered by the Financial Services Compensation Scheme (FSCS). You may be entitled to compensation from the scheme "
        "in the unlikely event we cannot meet our obligations to you. This depends on the type of insurance and the circumstances "
        "of the claim. Further information about the compensation scheme arrangements is available from the FSCS (www.fscs.org.uk) "
        "or call them on 020 7741 4100.",
        "If you arrive later than planned at your destination due to a delay of public transport we will pay you up to the amounts "
        "shown in the Table of Benefits for each 12 hour period of delay you suffer up to the maximum shown. Special conditions are "
        "important in the event of a claim. If you are unable to show they have been followed this may affect your ability to claim. "
        "1. You must seek financial compensation, assistance or a refund of your costs from your travel provider and invoke your "
        "rights under EU Air Passenger Rights legislation in the event of cancellation or delay of flights if applicable. 2. You "
        "must allow enough time to arrive at the departure point and check in for your outward or return journey.",
        "The amount you pay when you make a claim which is set out in the Table of Benefits. For all sections excluding Section 9 – "
        "Gadget Cover the excess is per person per incident, limited to two excess amounts if more than one insured person is "
        "claiming, per trip. If you use a Reciprocal Health Arrangement or any other arrangement with another country to reduce "
        "your medical expenses, you won’t have to pay an excess.",
        "Any period of restricted movement or isolation, including national lockdowns, within your home area or destination country "
        "imposed on a community or geographic location, such as a county or region, by a government or public authority.",
        "Special conditions are important in the event of a claim. If you are unable to show they have been followed this may affect "
        "your ability to claim. 1. You must seek financial compensation, assistance or a refund of your costs from your travel "
        "provider and invoke your rights under EU Air Passenger Rights legislation in the event of cancellation or delay of flights "
        "if applicable. 2. You must allow enough time to arrive at the departure point and check in for your outward or return journey."
    ]
    test_run_id = str(uuid4())

    validator_config = ValidatorConfig(
        name="AnswerRelevance",
        validator_type="event_based",
        parameters={"threshold": 0.85},
        endpoint_url="/validator/answer_relevance",
        priority="p1"
    )

    user_payload = UserPayloadModel(
        content_type=ContentTypeEnum.TEXT,
        value=query,
        metadata={
            "user_id": 1,
            "session_id": "session_1",
            "Answer": answer,
            "Chunks": chunks,
            "test_run_id": test_run_id
        },
        method=ValidatorMethodEnum.LLM,
    )
    config_parameters = {
        "threshold": 0.85,
        "devise": "cpu",
        "sensibility": 2,
        "language": "french",
        "content_type": "text"
    }
    request_payload = ValidatorRequestModel(
        project_name="Travel General Enquieries",
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        request_id=uuid4(),
        conversation_id=UUID("479473ce-2fb4-44b0-ab07-00c86be52f2f"),
        validator_config=validator_config.model_dump(),
        validation_method=ValidatorMethodEnum.LLM,
        pipeline_execution_id=pipeline_id,
        validator_execution_id=answer_relevance_validator_id,
        user_payload=user_payload,
        config_parameters=config_parameters,
        created_at=datetime.now(timezone.utc),
    )
    test_logger.info("Prepared ValidatorRequestModel payload.")

    # 3. Send Request to Validator Endpoint
    endpoint_url = f"{base_url}/validator/answer_relevance"
    response = requests.post(endpoint_url, json=request_payload.model_dump(mode="json", exclude_none=True), timeout=30)
    assert response.status_code == 202
    test_logger.info("Received HTTP 202 Accepted, task enqueued.")

    # 4. Allow queue trigger to process
    await asyncio.sleep(1)

    # 5. Poll for Final Status via API
    final_state = await poll_validator_status(
        pipeline_id=pipeline_id,
        validator_execution_id=answer_relevance_validator_id,
        timeout=15,
        interval=1
    )
    test_logger.info("Polling complete.")

    # 6. Assert Final Execution Status
    final_exec_status = final_state.get("execution_status")
    assert final_exec_status in TERMINAL_EXECUTION_STATUSES
    assert final_exec_status in SUCCESSFUL_EXECUTION_STATUSES
    test_logger.info(f"Validator execution reached terminal status: {final_exec_status}")

    # 7. Check Validator Response Verdict
    response_part = final_state.get("response")
    assert isinstance(response_part, dict)
    verdict = response_part.get("status")
    assert verdict == ValidatorResponseStatusEnum.PASS.value
    test_logger.info(f"Validator verdict: {verdict}")

    # 8. Check Response Details
    details = response_part.get("details", {})
    assert details.get("Result", {}).get("outcome") == "pass"
    test_logger.info("All assertions passed for Answer Relevance validator test.")
