"""
Integration test for the format checker validator workflow via the Function App API.

Verifies the asynchronous processing from HTTP request initiation, queuing,
execution by the queue trigger, and final status update polling via the API.
"""

import pytest
from uuid import uuid4, UUID
from datetime import datetime, timezone
import requests
import json
import logging
import asyncio

from libs.models.validator import (
    ValidatorRequestModel,
    UserPayloadModel,
    ContentTypeEnum,
    ValidatorMethodEnum,
    ValidatorExecutionStatusEnum,
    ValidatorResponseStatusEnum,
    ValidatorConfig
)
from libs.common.logs.logger import logger as project_logger

test_logger = logging.getLogger(__name__)

TERMINAL_EXECUTION_STATUSES = {
    s.value for s in ValidatorExecutionStatusEnum
    if s not in (
        ValidatorExecutionStatusEnum.NOT_STARTED,
        ValidatorExecutionStatusEnum.IN_PROGRESS
    )
}
SUCCESSFUL_EXECUTION_STATUSES = {
    ValidatorExecutionStatusEnum.COMPLETED.value
}

@pytest.mark.asyncio
async def test_format_checker_full_workflow(
    base_url: str,
    create_pipeline: tuple[UUID, dict[str, UUID]],
    poll_validator_status: callable
):
    test_logger.info("--- Starting Test: Format Checker Validator Full Workflow ---")

    # 1. Test Setup
    pipeline_id, validator_execution_ids = create_pipeline
    format_checker_validator_id = validator_execution_ids["format_checker"]
    test_logger.info(
        f"Test Setup: Pipeline ID={pipeline_id}, "
        f"Format Checker Validator Execution ID={format_checker_validator_id}"
    )

    # 2. Prepare Validator Request Payload
    text = (
        "Economy cm want to know it the flight cancel by the airline and airline provide a new flight "
        "but the flight is very late cm need to take taxi return home can she make claim on it."
    )
    test_run_id = str(uuid4())

    validator_config = ValidatorConfig(
        name="FormatChecker",
        validator_type="event_based",
        endpoint_url="/validator/format_checker",
        priority="p1"
    )

    user_payload = UserPayloadModel(
        content_type=ContentTypeEnum.TEXT,
        value=text,
        metadata={"test_run_id": test_run_id},
        method=ValidatorMethodEnum.LLM,
    )
    config_parameters = {
        "devise": "cpu",
        "language": "english",
        "content_type": "text",
        "sensibility": 2,
        "threshold": 0.85
    }
    request_payload = ValidatorRequestModel(
        project_name="Travel General Enquieries",
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        request_id=uuid4(),
        conversation_id=UUID("479473ce-2fb4-44b0-ab07-00c86be52f2f"),
        validator_config=validator_config.model_dump(),
        validation_method=ValidatorMethodEnum.LLM,
        pipeline_execution_id=pipeline_id,
        validator_execution_id=format_checker_validator_id,
        user_payload=user_payload,
        config_parameters=config_parameters,
        created_at=datetime.now(timezone.utc),
    )
    test_logger.info("Prepared ValidatorRequestModel payload.")

    # 3. Send Request to Validator Endpoint
    endpoint_url = f"{base_url}/validator/format_checker"
    response = requests.post(endpoint_url, json=request_payload.model_dump(mode="json", exclude_none=True), timeout=30)
    assert response.status_code == 202
    test_logger.info("Received HTTP 202 Accepted, task enqueued.")

    # 4. Allow queue trigger to process
    await asyncio.sleep(1)

    # 5. Poll for Final Status via API
    final_state = await poll_validator_status(
        pipeline_id=pipeline_id,
        validator_execution_id=format_checker_validator_id,
        timeout=15,
        interval=1
    )
    test_logger.info("Polling complete.")

    # 6. Assert Final Execution Status
    final_exec_status = final_state.get("execution_status")
    assert final_exec_status in TERMINAL_EXECUTION_STATUSES
    assert final_exec_status in SUCCESSFUL_EXECUTION_STATUSES
    test_logger.info(f"Validator execution reached terminal status: {final_exec_status}")

    # 7. Check Validator Response Verdict
    response_part = final_state.get("response")
    assert isinstance(response_part, dict)
    verdict = response_part.get("status")
    assert verdict == ValidatorResponseStatusEnum.FAILED.value
    test_logger.info(f"Validator verdict: {verdict}")

    # 8. Check Response Details
    details = response_part.get("details", {})
    assert details.get("Result", {}).get("outcome") == "fail"
    assert "error_message" in response_part
    test_logger.info("All assertions passed for Format Checker validator test.")
