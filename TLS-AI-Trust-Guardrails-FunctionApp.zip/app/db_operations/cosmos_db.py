"""
db_operations/cosmos_db.py
==========================

Cosmos DB data-access layer, fully reworked to use:

* one shared :class:`CosmosClient` + :class:`ContainerProxy`
  (lazy-initialised, connection-pooled);
* tenacity-powered retries on **429 (throttling) and 5xx** responses;
* harmonised back-off settings with the rest of the platform;
* rich, structured logging and metrics decorators.

Public API
----------
* ``areadiness()``                 – health probe
* ``pipeline_aget_all(count=200)`` – list pipelines
* ``pipeline_aget(id)``            – fetch single pipeline
* ``pipeline_upsert(model)``       – create / update pipeline
"""

from __future__ import annotations

import json
import os
from typing import List, Optional
from uuid import uuid4

from azure.cosmos import ConsistencyLevel
from azure.cosmos.aio import ContainerProxy, CosmosClient
from azure.cosmos.exceptions import CosmosHttpResponseError
from azure.identity.aio import DefaultAzureCredential
from pydantic import ValidationError
from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential,
)

from libs.common.logs.logger import logger
from libs.common.monitoring import record_db_operation_metrics
from libs.common.utils.client import azure_transport
from libs.models.pipeline import PipelineExecutionModel
from libs.models.readiness import ReadinessEnum
from libs.models.settings import CosmosDbModel

# --------------------------------------------------------------------------- #
# Retry settings (shared with HTTP layer for consistency)                     #
# --------------------------------------------------------------------------- #
MAX_COSMOS_RETRIES: int = 3
BACKOFF_FACTOR: float = 0.8  # seconds


def _retry_predicate(exc: Exception) -> bool:  
    """Retry on 429 (rate-limited) or ≥ 500 (server) errors."""
    return isinstance(exc, CosmosHttpResponseError) and (
        exc.status_code == 429 or exc.status_code >= 500
    )


async def _exec_with_retry(func, *args, **kwargs):
    """
    Run an **async** Cosmos-SDK operation with Tenacity retry/back-off.

    * Retries on 429 (throttling) or any 5xx response (see `_retry_predicate`).
    * Works on both Tenacity 7.x and 8.x – no `.filter()` API required.
    """
    retry_condition = retry_if_exception(_retry_predicate)

    async for attempt in AsyncRetrying(
        retry=retry_condition,
        wait=wait_exponential(multiplier=BACKOFF_FACTOR, min=BACKOFF_FACTOR),
        stop=stop_after_attempt(MAX_COSMOS_RETRIES),
        reraise=True,
    ):
        with attempt:
            return await func(*args, **kwargs)

# --------------------------------------------------------------------------- #
# Main DAO class                                                              #
# --------------------------------------------------------------------------- #
class CosmosDbOperations:
    """High-level façade over Cosmos DB."""

    _client: Optional[CosmosClient] = None
    _container: Optional[ContainerProxy] = None

    # --------------------------------------------------------------------- #
    def __init__(self, config: CosmosDbModel):
        self._cfg = config.settings.database.cosmos_db
        logger.info(
            "[Cosmos] Using endpoint=%s  db=%s  container=%s",
            self._cfg.endpoint,
            self._cfg.database,
            self._cfg.container,
        )

    # --------------------------------------------------------------------- #
    # Lazy initialisation helpers                                           #
    # --------------------------------------------------------------------- #
    async def _get_container(self) -> ContainerProxy:
        """Return the cached container client, creating it lazily."""
        if self._container:
            return self._container

        # ---------- CosmosClient ---------- #
        if not self._client:
            transport = await azure_transport()
            conn_str = os.getenv("CosmosDbConnectionString")

            if conn_str:  # local dev / CICD
                logger.debug("[Cosmos] authenticating via connection string")
                self._client = CosmosClient.from_connection_string(
                    conn_str,
                    consistency_level=ConsistencyLevel.Eventual,
                    connection_timeout=10,
                    retry_backoff_factor=BACKOFF_FACTOR,
                    retry_backoff_max=BACKOFF_FACTOR * 10,
                    retry_total=MAX_COSMOS_RETRIES,
                    transport=transport,
                )
            else:  # production – MSI
                logger.debug("[Cosmos] authenticating via DefaultAzureCredential")
                self._client = CosmosClient(
                    url=self._cfg.endpoint.get_secret_value(),
                    credential=DefaultAzureCredential(),
                    consistency_level=ConsistencyLevel.Eventual,
                    connection_timeout=10,
                    retry_backoff_factor=BACKOFF_FACTOR,
                    retry_backoff_max=BACKOFF_FACTOR * 10,
                    retry_total=MAX_COSMOS_RETRIES,
                    transport=transport,
                )

        db = self._client.get_database_client(self._cfg.database)
        self._container = db.get_container_client(self._cfg.container)
        logger.debug("[Cosmos] Container client created & cached")
        return self._container

    # --------------------------------------------------------------------- #
    # Health probe                                                          #
    # --------------------------------------------------------------------- #
    @record_db_operation_metrics("db_readiness_check")
    async def areadiness(self) -> ReadinessEnum:
        """Write-read-delete a dummy item to verify R/W connectivity."""
        logger.info("====  DATABASE READINESS CHECK: START ====")
        try:
            container = await self._get_container()
            test_id = str(uuid4())
            doc = {"id": test_id, "pipeline_execution_id": test_id, "test": True}

            await _exec_with_retry(container.upsert_item, body=doc)
            await _exec_with_retry(
                container.read_item, item=test_id, partition_key=test_id
            )
            await _exec_with_retry(
                container.delete_item, item=test_id, partition_key=test_id
            )
            logger.info("====  DATABASE READINESS CHECK: OK ====")
            return ReadinessEnum.OK
        except Exception:
            logger.exception("Database readiness check FAILED")
            return ReadinessEnum.FAIL

    # --------------------------------------------------------------------- #
    # Query helpers                                                         #
    # --------------------------------------------------------------------- #
    @record_db_operation_metrics("db_pipeline_aget_all")
    async def pipeline_aget_all(self, count: int = 200) -> List[PipelineExecutionModel]:
        """Return the *latest* ``count`` pipelines (default 200)."""
        container = await self._get_container()
        query = (
            "SELECT * FROM c ORDER BY c.created_at DESC OFFSET 0 LIMIT @cnt"
        )
        items = container.query_items(
            query=query,
            parameters=[{"name": "@cnt", "value": count}],
            enable_cross_partition_query=True,
        )
        results: List[PipelineExecutionModel] = []
        async for raw in items:
            try:
                results.append(PipelineExecutionModel.model_validate(raw))
            except ValidationError:
                logger.warning("[Cosmos] Skipping invalid doc id=%s", raw.get("id"))
        return results

    @record_db_operation_metrics("db_pipeline_aget")
    async def pipeline_aget(self, pipeline_execution_id: str) -> Optional[PipelineExecutionModel]:
        """Fetch one pipeline by its ID (partition key == id)."""
        container = await self._get_container()
        try:
            raw = await _exec_with_retry(
                container.read_item,
                item=pipeline_execution_id,
                partition_key=pipeline_execution_id,
            )
            return PipelineExecutionModel.model_validate(raw)
        except CosmosHttpResponseError as e:
            if e.status_code == 404:
                return None
            raise

    # --------------------------------------------------------------------- #
    # Upsert                                                                #
    # --------------------------------------------------------------------- #
    @record_db_operation_metrics("db_pipeline_upsert")
    async def pipeline_upsert(self, doc: PipelineExecutionModel) -> bool:
        """Create or update a pipeline document (id == partition key)."""
        container = await self._get_container()
        data = doc.model_dump(mode="json", exclude_none=True, by_alias=True)
        data["id"] = str(doc.pipeline_execution_id)

        try:
            await _exec_with_retry(container.upsert_item, body=data)
            logger.debug("[Cosmos] Upsert OK id=%s", data["id"])
            return True
        except Exception:
            logger.exception("[Cosmos] Upsert FAILED id=%s", data["id"])
            return False
