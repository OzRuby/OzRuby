"""
Service validator models.

These models define the configuration and execution details for validators within the service.
They are designed to be consistent with the SDK's validator models where applicable,
especially the BaseValidatorConfig, while remaining focused on the service's needs.
"""

from enum import Enum
from typing import Optional, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict, SecretStr
from guardrails.validator_base import FailResult, PassResult


class ContentTypeEnum(str, Enum):
    """
    Enumeration of input content type.
    ContentTypeEnum to ensure type consistency.
    """
    TEXT = "text"
    LIST = "list"
    DICT = "dict"

class ValidatorTypeEnum(str, Enum):
    """
    Enumeration of validator types within the service.
    Mirrors the SDK's ValidatorTypeEnum to ensure type consistency.
    """
    HTTP_BASED = "http_based"
    EVENT_BASED = "event_based"

class ValidatorPriorityEnum(str, Enum): # Not used in Service core logic, but kept for potential extensions
    """
    Enumeration for validator priority levels (not directly used in service core logic).
    Kept for potential future service-side features or extensions that might utilize priority.
    """
    P1 = "p1"
    P2 = "p2"
    P3 = "p3"

class ValidatorMethodEnum(str, Enum):
    """
    Validation method for validator within the service.
    Mirrors the SDK's ValidatorMethodEnum for consistency.
    """
    ML = "ml"
    LLM = "llm"
    REGEX = "regex"


class ValidatorExecutionStatusEnum(str, Enum):
    """
    Enumeration of validator execution statuses within the service.
    Mirrors the SDK's ValidatorStatusEnum to ensure status consistency across components.
    """
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    PARAMS_ERROR = "params_error"
    ERROR = "error"
    STOPPED = "stopped"

class ValidatorResponseStatusEnum(str, Enum):
    """
    Enumeration of validator execution statuses within the service.
    Mirrors the SDK's ValidatorStatusEnum to ensure status consistency across components.
    """

    SYS_ERROR = "system_error"
    SECUREGPT_ERROR = "securegpt_error"
    PARAMS_ERROR = "params_error"
    FAILED = "fail"
    BLOCK = "block"
    PASS = "pass"
    WARN = "warn"

class BaseValidatorConfig(BaseModel): # BaseValidatorConfig mirrored from SDK for shared model
    """
    Base Configuration model for a validator (shared between SDK and Service).
    This model is a direct mirror of the SDK's BaseValidatorConfig, ensuring
    that the core validator configuration attributes are consistent across both components.
    """
    model_config = ConfigDict(from_attributes=True, validate_assignment=True, use_enum_values=True)
    name: str = Field(..., description="Name of the validator.")
    validator_type: ValidatorTypeEnum = Field(..., description="Type of the validator (HTTP_BASED or EVENT_BASED).")
    parameters: Optional[Dict[str, Any]] = Field(None, description="Optional parameters to configure the validator's behavior.")


class ValidatorConfig(BaseValidatorConfig): # ValidatorConfig now extends BaseValidatorConfig and is SDK-specific
    """
    SDK Configuration model for a validator.
    Extends BaseValidatorConfig to include SDK-specific fields necessary for
    the SDK's operation, such as endpoint URL and priority.
    """
    endpoint_url: str = Field(..., description="URL of the validator service endpoint. Used by the SDK to call the validator service.")
    priority: Optional[ValidatorPriorityEnum] = Field(None, description="Priority level of the validator within a guard. Used for SDK-side orchestration.")



class UserPayloadModel(BaseModel):
    """
    User payload model for validator execution within the service.
    Mirrors the SDK's UserPayloadModel, representing the input data for validation.
    """
    model_config = ConfigDict(
        validate_assignment=True,
        use_enum_values=True
    )
    content_type: ContentTypeEnum = Field(default=ContentTypeEnum.TEXT, description="Content type of the user payload.")
    value: str = Field(default=None, min_length=0, description="Value of content to validate.")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Metadata for content validation.")
    method: ValidatorMethodEnum = Field(default=ValidatorMethodEnum.LLM, description="Validation method used by a runner.")

class ValidatorRequestModel(BaseModel):
    """
    Request model for validator execution within the service.
    Mirrors the SDK's ValidatorRequestModel, defining the expected request structure
    for validator endpoints in the service.
    """
    model_config = ConfigDict(
        from_attributes=True,
        validate_assignment=True,
        use_enum_values=True
    )    
    validation_method: ValidatorMethodEnum = Field(default=ValidatorMethodEnum.LLM, frozen=True, description="Validation method use by the validator.")
    project_name: str | None = Field(..., description="Current Project name (for each use case. eg: TGE)")
    scope: str | None = Field(default="PROD", description="Current scope ( eg: DEV, PROD)")
    country_name: str | None = Field(default="France", description="Current country ( eg: France)")
    partner_name: str | None = Field(default="PUFFIN", description="Current contract name ( eg: PUFFIN)")
    validator_config: ValidatorConfig = Field(..., description="Validator configuration used for this execution. Uses Service ValidatorConfig.") # Using Service ValidatorConfig
    request_id: UUID | None = Field(..., description="Unique identifier for the validation request.")
    conversation_id: UUID | None = Field(default=None, description="Unique identifier for the conversion.")
    pipeline_execution_id: UUID | None = Field(default=None, description="Unique identifier for the pipeline execution.")
    securegpt_token: Optional[SecretStr | None] = Field(default=None, description="SecretStr for validator")
    validator_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the validator execution.")
    user_payload: UserPayloadModel | None = Field(description="User Input data for validation.")
    config_parameters: dict[str, Any] = Field(default_factory=dict, description="Additional configuration parameters.")
    created_at: datetime = Field(default_factory=datetime.now)

class ValidatorResponseModel(BaseModel):
    """
    Response model for validator execution within the service.
    Mirrors the SDK's ValidatorResponseModel, defining the structure of responses
    returned by validator services.
    """
    model_config = ConfigDict(
        from_attributes=True,
        validate_assignment=True,
        use_enum_values=True
    )    
    status: ValidatorResponseStatusEnum = Field(..., description="Validation result status.")
    have_fix: bool = Field(default=False, description="Check if validator have fix")
    details: dict[str, Any]|FailResult|PassResult = Field(default_factory=dict, description="Detailed results of the validation.")
    error_message: str | None = Field(None, description="Error message if validation failed.")
    created_at: datetime = Field(default_factory=datetime.now)

class ValidatorExecutionModel(BaseModel):
    """
    Represents the execution result of a validator within the service.
    Mirrors the SDK's ValidatorExecutionModel, tracking the execution state
    and outcome of a validator within the service context.
    """
    model_config = ConfigDict(
        from_attributes=True,
        validate_assignment=True,
        use_enum_values=True
    )    
    pipeline_execution_id: UUID = Field(default_factory=uuid4, description="Unique pipeline identifier.")
    validator_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the validator execution.")
    execution_status: ValidatorExecutionStatusEnum = Field(default=ValidatorExecutionStatusEnum.NOT_STARTED, description="Current execution status.")
    request: Optional[ValidatorRequestModel] = Field(None, description="The request sent to the validator service.")
    response: Optional[ValidatorResponseModel] = Field(None, description="The response received from the validator service.")
    error_message: Optional[str] = Field(None, description="Error message if execution failed.")
    start_time: Optional[datetime] = Field(None, description="Timestamp when execution started.")
    end_time: Optional[datetime] = Field(None, description="Timestamp when execution ended.")
    last_update: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of the last update.")

    def is_event_based(self) -> bool:
        """
        Determines if the validator is event-based.
        Mirrors the SDK's method for consistency.

        Returns:
            bool: True if the validator type is EVENT_BASED; otherwise, False.
        """
        return self.validator_config.validator_type == ValidatorTypeEnum.EVENT_BASED

# Alias model for validator definitions. This ensures that any import referencing
# ValidatorDefinitionModel will succeed and correctly points to the Service's ValidatorConfig.
class ValidatorDefinitionModel(ValidatorConfig): # ValidatorDefinitionModel now an alias for Service ValidatorConfig
    """
    Alias for ValidatorConfig, representing the definition of a validator within the service.
    Ensures that ValidatorDefinitionModel references the Service's ValidatorConfig,
    maintaining clarity and avoiding confusion with SDK-specific configurations.
    """
    pass

#ValidatorExecutionModel.model_rebuild()