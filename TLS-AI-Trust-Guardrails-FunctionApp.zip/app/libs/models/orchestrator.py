# """
# Module defining orchestrator models.

# These models capture the overall pipeline orchestration process,
# including execution context, stage results, and the execution tree.
# """

# from enum import Enum
# from typing import List, Optional, Dict, Any
# from uuid import UUID, uuid4
# from datetime import datetime
# from pydantic import BaseModel, Field, ConfigDict
# from libs.models.guard import GuardExecutionModel

# class OrchestrationStatusEnum(str, Enum):
#     """Represents the various statuses of pipeline execution."""
#     NOT_STARTED = "not_started"
#     RUNNING = "running"
#     WAITING_ASYNC = "waiting_async"
#     COMPLETED = "completed"
#     BLOCKED = "blocked"
#     FAILED = "failed"

# class OrchestratorExecutionContextDefinitionModel(BaseModel):
#     """
#     Contains contextual data for pipeline execution.

#     Useful for tracking request identifiers, user information, and custom data.
#     """
#     model_config = ConfigDict(from_attributes=True)
#     request_id: str = Field(..., description="Unique identifier for the pipeline execution request.")
#     user_id: Optional[str] = Field(None, description="Identifier for the user or application.")
#     session_id: Optional[str] = Field(None, description="Session or correlation identifier.")
#     custom_data: Dict[str, Any] = Field(default_factory=dict, description="Additional contextual data.")
#     created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when the execution started.", frozen=True)

# class OrchestratorStageResultDefinitionModel(BaseModel):
#     """
#     Represents the result of a single pipeline stage execution.

#     Includes guard results and the overall decision for the stage.
#     """
#     model_config = ConfigDict(from_attributes=True)
#     stage_name: str = Field(..., description="Name of the pipeline stage.")
#     status: OrchestrationStatusEnum = Field(default=OrchestrationStatusEnum.NOT_STARTED, description="Execution status of the stage.")
#     guard_results: List[GuardExecutionModel] = Field(default_factory=list, description="Execution results for each guard in the stage.")
#     overall_decision: Optional[str] = Field(None, description="Aggregated decision (PASS, BLOCK, WARN) for the stage.")
#     created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when the stage result was recorded.", frozen=True)

# class ExecutionTreeNodeType(str, Enum):
#     """Defines types of nodes in the execution tree."""
#     PIPELINE = "pipeline"
#     STAGE = "stage"
#     GUARD = "guard"
#     VALIDATOR = "validator"

# class ExecutionTreeNodeModel(BaseModel):
#     """
#     Represents a node in the execution tree.

#     This is used to capture the hierarchical execution details of the pipeline.
#     """
#     model_config = ConfigDict(from_attributes=True)
#     node_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the node.", frozen=True)
#     node_type: ExecutionTreeNodeType = Field(..., description="Type of the node.")
#     name: str = Field(..., description="Name of the component.")
#     status: OrchestrationStatusEnum = Field(default=OrchestrationStatusEnum.NOT_STARTED, description="Execution status of the node.")
#     start_time: Optional[datetime] = Field(None, description="Timestamp when the node execution started.")
#     end_time: Optional[datetime] = Field(None, description="Timestamp when the node execution ended.")
#     results: Optional[Dict[str, Any]] = Field(None, description="Detailed execution results.")
#     children: List["ExecutionTreeNodeModel"] = Field(default_factory=list, description="Child nodes in the execution tree.")

# # Rebuild to resolve forward references.
# ExecutionTreeNodeModel.model_rebuild()

# class OrchestratorDefinitionModel(BaseModel):
#     """
#     Captures the complete orchestration result for a pipeline.

#     Includes overall context, stage results, final status, and the execution tree.
#     """
#     model_config = ConfigDict(from_attributes=True)
#     pipeline_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the pipeline.", frozen=True)
#     context: OrchestratorExecutionContextDefinitionModel = Field(..., description="Execution context details.")
#     stage_results: List[OrchestratorStageResultDefinitionModel] = Field(default_factory=list, description="List of stage results.")
#     final_status: OrchestrationStatusEnum = Field(default=OrchestrationStatusEnum.NOT_STARTED, description="Final aggregated status.")
#     start_time: datetime = Field(default_factory=datetime.utcnow, description="Orchestration start timestamp.", frozen=True)
#     last_update: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of the last update.")
#     execution_tree: Optional[ExecutionTreeNodeModel] = Field(None, description="Root node of the execution tree.")
#     end_time: Optional[datetime] = Field(None, description="Orchestration end timestamp.")

# # Ensure dependent models are rebuilt.
# from libs.models.guard import GuardExecutionModel
# GuardExecutionModel.model_rebuild()
