"""
Module for project-related models.

Defines the structure for project-level information and service settings.
"""

from typing import Optional, Dict
from pydantic import BaseModel, Field, ConfigDict

class ProjectModel(BaseModel):
    """
    Represents project-level information.

    This model includes the project name, a brief description,
    an ITPM identifier, and details about the IT owner.
    """
    model_config = ConfigDict(from_attributes=True)
    name: Optional[str] = Field(None, description="The name of the project.")
    description: Optional[str] = Field(None, description="A brief description of the project.")
    itpm_id: Optional[str] = Field(None, description="The ITPM identifier.")
    it_owner_infos: Optional[Dict[str, Optional[str]]] = Field(
        None, description="Details about the IT owner (e.g., name, email)."
    )

class ServiceSettings(BaseModel):
    """
    Represents service-level settings.

    Defines parameters such as the service endpoint and any credentials required.
    """
    model_config = ConfigDict(from_attributes=True)
    slot: Optional[str] = Field(None, description="The service slot (e.g., DEV, PROD).")
    endpoint: Optional[str] = Field(None, description="The service endpoint URL.")
    credential: Optional[Dict[str, Optional[str]]] = Field(
        None, description="Service credentials (e.g., access key, token)."
    )
