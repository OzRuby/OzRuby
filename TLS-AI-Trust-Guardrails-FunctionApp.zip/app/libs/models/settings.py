from pydantic import BaseModel, SecretStr

class HttpTimeouts(BaseModel, frozen=True):
    total_seconds: int
    connect_seconds: int

class HttpRetryConfig(BaseModel, frozen=True):
    max_attempts: int
    backoff_factor: float
    max_backoff_multiplier: int

class HttpSettingsModel(BaseModel, frozen=True):
    timeouts: HttpTimeouts
    pool_limit_per_host: int
    trust_env: bool
    retry: HttpRetryConfig


class CosmosDbModel(BaseModel, frozen=True):
    api_key: SecretStr
    container: str
    database: str
    endpoint: SecretStr

class DatabaseModel(BaseModel, frozen=True):
    db_type: str
    cosmos_db: CosmosDbModel

class BlobStorageModel(BaseModel, frozen=True):
    api_key: SecretStr
    blob_container: str
    endpoint: str
    account_name: str

class CloudModel(BaseModel, frozen=True):
    type: str
    resource_group_name: str

class QueuesModel(BaseModel, frozen=True):
    validator_grammar_queue_name: str
    validator_answer_relevance_queue_name: str
    validator_chunk_relevance_queue_name: str 
    validator_prompt_injection_queue_name: str
    validator_calculation_logic_queue_name: str
    validator_format_queue_name: str
    validator_keyword_filtering_queue_name: str
    validator_query_topics_queue_name: str

class CacheModel(BaseModel, frozen=True):
    redis_host: str
    redis_port: int
    use_ssl: bool = True

class KeyVaultModel(BaseModel, frozen=True):
    vault_name: str
    tenant_id: str


class LlmConnexionModel(BaseModel, frozen=True):
    client_id: SecretStr
    client_secret: SecretStr
    one_login_base_url: SecretStr
    one_login_url: SecretStr
    scope: str

class LlmModel(BaseModel, frozen=True):
    connexion: LlmConnexionModel

class DependenciesModel(BaseModel, frozen=True):
    llm: LlmModel

class SettingsModel(BaseModel, frozen=True):
    cloud: CloudModel
    database: DatabaseModel
    storage: BlobStorageModel
    queues: QueuesModel
    cache: CacheModel
    key_vault: KeyVaultModel
    dependencies: DependenciesModel
    http: HttpSettingsModel