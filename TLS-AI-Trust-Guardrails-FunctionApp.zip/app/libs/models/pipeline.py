import logging
from typing import List, Dict, Optional
from uuid import UUID, uuid4
from datetime import datetime, timezone # Use timezone-aware UTC consistently
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

from libs.models.project import ProjectModel, ServiceSettings
# Import the new enum along with the existing one
from libs.models.common_enums import PipelineExecutionModeEnum, PipelineExecutionStatusEnum
from libs.models.validator import ValidatorExecutionModel
from libs.models.guard import GuardConfiguration, GuardExecutionModel

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Shared Pipeline Models
# ---------------------------------------------------------------------------

class PipelineStageDefinition(BaseModel):
    """
    Defines a single stage in the pipeline.

    Example stages include 'input', 'retrieval', and 'output'.
    """
    model_config = ConfigDict(from_attributes=True)
    name: str = Field(..., description="Name of the pipeline stage (e.g., 'input', 'retrieval', 'output').")
    execution_mode: PipelineExecutionModeEnum = Field(
        default=PipelineExecutionModeEnum.SEQUENTIAL,
        description="Specifies whether the stage runs sequentially or asynchronously."
    )

class PipelineStageExecutionResult(BaseModel):
    """
    Represents the execution result for a specific pipeline stage.

    Aggregates the execution results from all guards in that stage.
    """
    model_config = ConfigDict(from_attributes=True)
    stage_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the stage execution.") # Removed frozen=True, IDs usually shouldn't be frozen if set by factory
    stage_name: str = Field(..., description="Name of the pipeline stage.")
    guards_execution_results: List["GuardExecutionModel"] = Field(
        default_factory=list, description="List of execution results from guards in this stage."
    )
    overall_decision: Optional[str] = Field(None, description="Aggregated decision for the stage.")
    # Consider using ValidatorStatusEnum here if stage statuses align with validator statuses
    status: str = Field(default="not_started", description="Execution status for the stage.") # Keeping as str for now unless you want an Enum here too
    start_time: Optional[datetime] = Field(None, description="Stage execution start time.")
    end_time: Optional[datetime] = Field(None, description="Stage execution end time.")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Timestamp when the stage record was created.") # Removed frozen=True


class PipelineExecutionModel(BaseModel):
    id: Optional[str] = Field(None, description="Cosmos DB document ID (typically the string representation of pipeline_execution_id).")
    revision: int = Field(default=1, description="Revision number of the pipeline document.") # Default to 1
    model_config = ConfigDict(from_attributes=True)
    pipeline_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the pipeline execution.") # Removed frozen=True
    pipeline_definition_id: UUID = Field(..., description="Identifier of the pipeline definition.")
    # Make project/service optional if they might not always be present
    project_infos: Optional[ProjectModel] = Field(None, description="Project-level information.")
    service_settings: Optional[ServiceSettings] = Field(None, description="Service-level settings.")
    pipeline_stages: List[str] = Field(..., description="List of pipeline stage names.")
    guards_config: Dict[str, GuardConfiguration] = Field(..., description="Dictionary of guard configurations keyed by guard name.")
    stages_execution_results: List[PipelineStageExecutionResult] = Field(
        default_factory=list, description="List of execution results for each pipeline stage."
    )
    # +++ Use the new Enum for the status field +++
    status: PipelineExecutionStatusEnum = Field(
        default=PipelineExecutionStatusEnum.NOT_STARTED, # Use Enum default
        description="Overall pipeline execution status."
    )
    # +++ Use timezone.utc for default factories +++
    start_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Pipeline execution start time.") # Removed frozen=True
    end_time: Optional[datetime] = Field(None, description="Pipeline execution end time.")
    last_update: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Timestamp of the last update.")


    # --- Methods ---
    # Ensure methods correctly handle or update the status fields if necessary.
    # For example, update_validators might implicitly mean the pipeline `last_update` changes and maybe status becomes IN_PROGRESS if it was NOT_STARTED.

    def update_stages_execution_results(self, stage_name: str) -> PipelineStageExecutionResult:
        """
        Updates or adds a stage to stages_execution_results.
        Sets stage status to in_progress if newly added.

        Args:
            stage_name (str): Name of the stage to update or add.

        Returns:
            PipelineStageExecutionResult: The updated or newly added stage.
        """
        for stage in self.stages_execution_results:
            if stage.stage_name == stage_name:
                return stage
        # If not found, add a new stage
        logger.info(f"Adding new stage execution result for stage: {stage_name}")
        new_stage = PipelineStageExecutionResult(stage_name=stage_name, status="in_progress") # Or use an Enum if defined for stage status
        self.stages_execution_results.append(new_stage)
        self._update_pipeline_status_and_time() # Update pipeline status/time when adding stages
        return new_stage

    def update_guards_execution_results(self, stage_name: str, guard_name: str) -> GuardExecutionModel:
        """
        Updates or adds a guard to the guards_execution_results of a specified stage.
        Sets guard status to in_progress if newly added.

        Args:
            stage_name (str): Name of the stage containing the guard.
            guard_name (str): Name of the guard to update or add.

        Returns:
            GuardExecutionModel: The updated or newly added guard.
        """
        stage = self.update_stages_execution_results(stage_name) # This ensures stage exists
        for guard in stage.guards_execution_results:
            # Ensure guard_config exists before accessing name
            if guard.guard_config and guard.guard_config.name == guard_name:
                return guard

        # If not found, add a new guard
        guard_config = self.guards_config.get(guard_name)
        if not guard_config:
            # Handle case where guard config might be missing - log warning or error?
            logger.warning(f"Guard configuration for '{guard_name}' not found in pipeline config. Cannot add execution result.")
            # Depending on requirements, either raise error or create a default/empty config
            # For now, let's prevent adding a guard without config to avoid inconsistency
            raise ValueError(f"Configuration for guard '{guard_name}' not found in pipeline.")
            # Alternatively, create a default config (less safe):
            # guard_config = GuardConfiguration(name=guard_name, stages=[stage_name], validators=[])

        logger.info(f"Adding new guard execution result for guard: {guard_name} in stage: {stage_name}")
        # Assuming GuardExecutionModel takes guard_config and sets default status
        # Need to import ValidatorStatusEnum if GuardExecutionModel uses it
        from libs.models.validator import ValidatorStatusEnum # Import if needed by GuardExecutionModel
        new_guard = GuardExecutionModel(guard_config=guard_config, execution_status=ValidatorStatusEnum.IN_PROGRESS) # Or appropriate initial status
        stage.guards_execution_results.append(new_guard)
        self._update_pipeline_status_and_time() # Update pipeline status/time
        return new_guard

    def update_validators(self, updated_validator: ValidatorExecutionModel) -> None:
            """
            Updates the validators_execution_results within the nested structure using validator_execution_id.
            Replaces the validator with the same validator_execution_id if found, otherwise raises an error.
            Also updates the pipeline's last_update timestamp and potentially its status.

            Args:
                updated_validator (ValidatorExecutionModel): The validator execution result to update.

            Returns:
                None: Updates the model in place.

            Raises:
                ValueError: If validator_execution_id is not found in the pipeline.
            """
            found = False
            for stage in self.stages_execution_results:
                for guard in stage.guards_execution_results:
                    for i, validator in enumerate(guard.validators_execution_results):
                        if validator.validator_execution_id == updated_validator.validator_execution_id:
                            logger.info(f"Updating validator {updated_validator.validator_execution_id} in guard {guard.guard_config.name}, stage {stage.stage_name}")
                            guard.validators_execution_results[i] = updated_validator
                            return guard.validators_execution_results
            raise ValueError(f"Validator with ID {updated_validator.validator_execution_id} not found in pipeline.")


"""
# ---------------------------------------------------------------------------
# Rebuild Forward References
# ---------------------------------------------------------------------------
# Ensure these are run AFTER all models they depend on are fully defined
from libs.models.validator import ValidatorConfig, ValidatorStatusEnum, ValidatorExecutionModel
from libs.models.guard import GuardConfiguration, GuardExecutionModel, GuardSettings

# It's generally safer to rebuild all related models if structure changes
ValidatorConfig.model_rebuild(force=True)
ValidatorExecutionModel.model_rebuild(force=True)

GuardSettings.model_rebuild()           
GuardConfiguration.model_rebuild()     
GuardExecutionModel.model_rebuild()       
PipelineStageDefinition.model_rebuild()   
PipelineStageExecutionResult.model_rebuild() 
PipelineExecutionModel.model_rebuild()
"""