"""
Module for service readiness models.

This module defines models used to report the readiness and overall health status of the service.
"""

from enum import Enum
from typing import List
from pydantic import BaseModel, Field

class ReadinessEnum(str, Enum):
    """
    Enumeration representing the readiness status.
    
    - FAIL: Indicates that the service or a component is not ready.
    - OK: Indicates that the service or a component is ready.
    """
    FAIL = "fail"
    OK = "ok"

class ReadinessCheckModel(BaseModel):
    """
    Model representing an individual readiness check.

    Attributes:
        id (str): Identifier for the readiness check.
        status (ReadinessEnum): Status of the check.
    """
    id: str = Field(..., description="Identifier for the readiness check.")
    status: ReadinessEnum = Field(..., description="Status of the readiness check.")

class ReadinessModel(BaseModel):
    """
    Aggregated readiness model for the service.

    Contains the overall readiness status and a list of individual checks.
    
    Attributes:
        checks (List[ReadinessCheckModel]): A list of readiness check results.
        status (str): Overall readiness status, e.g. 'ok' or 'fail'.
    """
    checks: List[ReadinessCheckModel] = Field(..., description="List of individual readiness checks.")
    status: str = Field(..., description="Overall readiness status (e.g., 'ok' or 'fail').")
