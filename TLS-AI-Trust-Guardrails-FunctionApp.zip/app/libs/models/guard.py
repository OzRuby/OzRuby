from enum import Enum
from typing import List, Optional, Dict
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

from libs.models.common_enums import PipelineExecutionModeEnum
from libs.models.validator import ValidatorConfig, ValidatorExecutionModel

class GuardPriorityEnum(str, Enum):
    """
    Enumeration representing guard priority levels.
    """
    P1 = "p1"
    P2 = "p2"
    P3 = "p3"

class GuardSettings(BaseModel):
    """
    Settings specific to a guard, such as aggregation strategy and mandatory validators.
    
    These settings determine how validator responses are combined.
    """
    model_config = ConfigDict(from_attributes=True)
    response_aggregation_strategy: Optional[str] = Field(
        None, description="Strategy to aggregate validator responses."
    )
    priority: Optional[GuardPriorityEnum] = Field(
        None, description="Priority level assigned to the guard."
    )
    mendatory_validators: Optional[List[str]] = Field(
        None, description="List of validator names that are mandatory for this guard."
    )
    min_non_mendatory_validators_to_check: Optional[int] = Field(
        None, description="Minimum number of non-mandatory validators required."
    )

class GuardConfiguration(BaseModel):
    """
    Model representing the configuration of a guard.

    Specifies the guard’s name, the pipeline stages where it applies, its settings, 
    and the validators associated with it.
    """
    model_config = ConfigDict(from_attributes=True)
    guard_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the guard.", frozen=True)
    name: str = Field(..., description="Name of the guard.")
    settings: Optional[GuardSettings] = Field(None, description="Guard-specific settings.")
    stages: List[str] = Field(..., description="Pipeline stages where the guard is active.")
    validators: List[ValidatorConfig] = Field(..., description="List of validator configurations for this guard.")  # Forward reference
    execution_mode: PipelineExecutionModeEnum = Field(
        default=PipelineExecutionModeEnum.SEQUENTIAL, description="Execution mode for the validators."
    )

class GuardExecutionModel(BaseModel):
    """
    Represents the result of executing a guard.

    This model contains the results of each validator execution under this guard,
    along with the final aggregated decision.
    """
    model_config = ConfigDict(from_attributes=True)
    guard_execution_id: UUID = Field(default_factory=uuid4, description="Unique identifier for the guard execution.", frozen=True)
    guard_config: GuardConfiguration = Field(..., description="The guard configuration that was executed.")
    validators_execution_results: List["ValidatorExecutionModel"] = Field(
        default_factory=list, description="Execution results for each validator."
    )
    final_decision: Optional[str] = Field(None, description="Final aggregated decision (e.g., PASS, BLOCK, WARN).")
    execution_status: str = Field(default="pending", description="Current execution status of the guard.")
    start_time: Optional[datetime] = Field(None, description="Timestamp when guard execution started.")
    end_time: Optional[datetime] = Field(None, description="Timestamp when guard execution ended.")
    last_update: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of the last update.")

"""
# Import and rebuild forward references (ensure these are rebuilt after the Validator models are defined)
ValidatorConfig.model_rebuild()
ValidatorExecutionModel.model_rebuild()
GuardConfiguration.model_rebuild()
GuardExecutionModel.model_rebuild()
"""