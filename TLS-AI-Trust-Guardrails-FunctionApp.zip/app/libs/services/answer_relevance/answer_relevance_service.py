# libs/services/answer_relevance/answer_relevance_service.py

"""
Answer Relevance Validator Service Module

Processes answer relevance tasks: marks IN_PROGRESS, runs the validator,
and updates the pipeline with ERROR or COMPLETED.
"""
from datetime import datetime, timezone

from ai_trust_validators.validators.answer_relevance import AnswerRelevance

from libs.models.validator import (
    ValidatorRequestModel,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum
)
from libs.common.logs.logger import logger
from libs.common.utils.pipeline_operations import update_pipeline_execution
from db_operations.cosmos_db import CosmosDbOperations


async def process_answer_relevance_validation(
    db_ops: CosmosDbOperations,
    validator_request: ValidatorRequestModel
) -> None:
    pipeline_id = validator_request.pipeline_execution_id
    record = await db_ops.pipeline_aget(str(pipeline_id))
    if not record:
        logger.error("Pipeline record not found: %s", pipeline_id)
        return

    # 1) Mark IN_PROGRESS
    in_progress = ValidatorExecutionModel(
        pipeline_execution_id=pipeline_id,
        validator_execution_id=validator_request.validator_execution_id,
        execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
        request=validator_request,
        start_time=datetime.now(timezone.utc),
        last_update=datetime.now(timezone.utc)
    )
    logger.info("AnswerRelevance %s → IN_PROGRESS", validator_request.validator_execution_id)
    await update_pipeline_execution(db_ops, pipeline=record, validator_exec_update=in_progress)

    try:
        # 2) Execute
        result = await AnswerRelevance(validator_request).validate()
    except Exception as exc:
        # 3a) ERROR
        error_exec = ValidatorExecutionModel(
            pipeline_execution_id=pipeline_id,
            validator_execution_id=validator_request.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.ERROR,
            request=validator_request,
            error_message=str(exc),
            start_time=in_progress.start_time,
            end_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        logger.critical("AnswerRelevance %s → ERROR: %s", validator_request.validator_execution_id, exc, exc_info=True)
        await update_pipeline_execution(db_ops, pipeline=record, validator_exec_update=error_exec)
        return

    # 3b) COMPLETED
    final_exec = result.model_copy(update={
        "pipeline_execution_id": pipeline_id,
        "validator_execution_id": validator_request.validator_execution_id,
        "last_update": datetime.now(timezone.utc)
    })
    logger.info("AnswerRelevance %s → %s", validator_request.validator_execution_id, final_exec.execution_status.value)
    await update_pipeline_execution(db_ops, pipeline=record, validator_exec_update=final_exec)
