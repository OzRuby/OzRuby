"""
Prompt Injection Validator Service Module

This module provides the service logic for handling prompt injection validation tasks,
including asynchronous execution and updating the pipeline with only the necessary
status changes.
"""
from ai_trust_validators.validators.prompt_injection import PromptInjection
from libs.models.validator import (
    ValidatorRequestModel,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum
)
from libs.common.logs.logger import logger
from libs.common.utils.pipeline_operations import update_pipeline_execution
from db_operations.cosmos_db import CosmosDbOperations
from datetime import datetime, timezone

async def process_prompt_injection_validation(
    db_ops: CosmosDbOperations,
    validator_request: ValidatorRequestModel
) -> None:
    """Process a prompt injection validation task with minimal pipeline updates."""
    pipeline_id = validator_request.pipeline_execution_id
    record = await db_ops.pipeline_aget(str(pipeline_id))
    if not record:
        logger.error("Pipeline record not found: %s", pipeline_id)
        return

    # 1) Mark IN_PROGRESS
    in_progress = ValidatorExecutionModel(
        pipeline_execution_id=pipeline_id,
        validator_execution_id=validator_request.validator_execution_id,
        execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
        request=validator_request,
        start_time=datetime.now(timezone.utc),
        last_update=datetime.now(timezone.utc)
    )
    logger.info("Validator %s → IN_PROGRESS", validator_request.validator_execution_id)
    await update_pipeline_execution(db_ops, pipeline=record, validator_exec_update=in_progress)

    try:
        # 2) Run the validator; it returns a ValidatorExecutionModel with its final status
        result: ValidatorExecutionModel = await PromptInjection(validator_request).validate()
    except Exception as exc:
        # 3a) If the validator itself errored, mark ERROR
        error_exec = ValidatorExecutionModel(
            pipeline_execution_id=pipeline_id,
            validator_execution_id=validator_request.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.ERROR,
            request=validator_request,
            error_message=str(exc),
            start_time=in_progress.start_time,
            end_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        logger.critical("Validator %s → ERROR: %s", validator_request.validator_execution_id, exc, exc_info=True)
        await update_pipeline_execution(db_ops, pipeline=record, validator_exec_update=error_exec)
        return

    # 3b) On success, align IDs (in case the validator package set them differently) and upsert
    final_exec = result.model_copy(update={
        "pipeline_execution_id": pipeline_id,
        "validator_execution_id": validator_request.validator_execution_id,
        "last_update": datetime.now(timezone.utc)
    })
    logger.info("Validator %s → %s", 
                validator_request.validator_execution_id, final_exec.execution_status.value.upper())
    await update_pipeline_execution(db_ops, pipeline=record, validator_exec_update=final_exec)
