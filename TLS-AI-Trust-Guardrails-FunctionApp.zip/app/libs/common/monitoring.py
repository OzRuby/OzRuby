# monitoring.py (Corrected)

from enum import Enum
from os import environ
from functools import wraps
from time import perf_counter
from azure.monitor.opentelemetry import configure_azure_monitor
import azure.functions as func
from opentelemetry import metrics, trace
from opentelemetry.instrumentation.aiohttp_client import AioHttpClientInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
# --- Import public types directly ---
from opentelemetry.metrics import Counter, Histogram, Meter
# --- REMOVED internal import ---
from opentelemetry.semconv.attributes import service_attributes
from opentelemetry.trace.span import INVALID_SPAN
from opentelemetry.util.types import AttributeValue
from structlog.contextvars import bind_contextvars, get_contextvars
from typing import Dict, Union

MODULE_NAME = "aitrust.service"
VERSION = environ.get("VERSION", "0.0.0-unknown")

# Configure Azure Monitor and instrument HTTP clients
try:
    configure_azure_monitor()
    AioHttpClientInstrumentor().instrument()
    HTTPXClientInstrumentor().instrument()
except ValueError as e:
    print(
        "Azure Application Insights instrumentation failed,",
        "likely due to a missing APPLICATIONINSIGHTS_CONNECTION_STRING",
        "environment variable.",
        e,
    )

# Default attributes for all spans and metrics
_default_attributes = {
    service_attributes.SERVICE_NAME: MODULE_NAME,
    service_attributes.SERVICE_VERSION: VERSION,
}

# Initialize tracer and meter
tracer = trace.get_tracer(
    attributes=_default_attributes,
    instrumenting_module_name=MODULE_NAME,
)
meter: Meter = metrics.get_meter(name=MODULE_NAME)

# Cache for dynamically created instruments to avoid recreating them
# --- Use public types for hinting ---
_instrument_cache: Dict[str, Union[Counter, Histogram]] = {}

##################################################
# HELPER TO GET/CREATE INSTRUMENTS
##################################################

def _get_or_create_instrument(name: str, instrument_type: type, unit: str, description: str = "") -> Union[Counter, Histogram]:
    """Gets an instrument from cache or creates it if it doesn't exist."""
    if name not in _instrument_cache:
        if instrument_type == Counter:
            _instrument_cache[name] = meter.create_counter(name=name, unit=unit, description=description)
        elif instrument_type == Histogram:
            _instrument_cache[name] = meter.create_histogram(name=name, unit=unit, description=description)
        else:
            raise TypeError(f"Unsupported instrument type: {instrument_type}")
    instrument = _instrument_cache[name]
    if not isinstance(instrument, instrument_type):
         raise TypeError(f"Cached instrument type mismatch for {name}. Expected {instrument_type}, got {type(instrument)}")
    return instrument

##################################################
# SPAN ATTRIBUTE ENUM
##################################################

class SpanAttributeEnum(str, Enum):
    USER_ID = "aitrust.service.user.id"
    CONVERSATION_ID = "aitrust.service.conversation.id"
    PROJECT_NAME = "aitrust.service.project.name"
    PIPELINE_EXECUTION_ID = "aitrust.service.pipeline.execution.id"
    VALIDATOR_EXECUTION_ID = "aitrust.service.validator.execution.id"
    VALIDATOR_NAME = "aitrust.service.validator.name"
    VALIDATION_METHOD = "aitrust.service.validator.validation_method"
    PROJECT_SCOPE = "aitrust.service.project.scope"
    PARTNER_NAME = "aitrust.service.partner.name"
    COUNTRY_NAME = "aitrust.service.country.name"

    def attribute(self, value: AttributeValue) -> None:
        bind_contextvars(**{self.value: value})
        span = trace.get_current_span()
        if span != INVALID_SPAN:
            span.set_attribute(self.value, value)

##################################################
# SERVICE METER ENUM (Retained for static/non-dynamic metrics)
##################################################

class ServiceMeterEnum(str, Enum):
    DB_OPERATION_COUNT = "aitrust.service.db.operation.count"
    DB_OPERATION_LATENCY = "aitrust.service.db.operation.latency"
    DB_OPERATION_FAILURE_COUNT = "aitrust.service.db.operation.failure.count"
    VALIDATOR_INVOCATION_COUNT = "aitrust.service.validator.invocation.count"
    VALIDATOR_REQUEST_LATENCY = "aitrust.service.validator.request.latency"
    PIPELINE_CREATION_COUNT = "aitrust.service.pipeline.creation.count"
    VALIDATOR_USAGE = "aitrust.service.validator.usage"

    def counter(self, unit: str) -> Counter:
        return _get_or_create_instrument(self.value, Counter, unit, self.__doc__ or "")
    def histogram(self, unit: str) -> Histogram:
        return _get_or_create_instrument(self.value, Histogram, unit, self.__doc__ or "")

##################################################
# CREATE STATIC METRICS (Using the Enum)
##################################################
db_operation_count = ServiceMeterEnum.DB_OPERATION_COUNT.counter("1")
db_operation_latency = ServiceMeterEnum.DB_OPERATION_LATENCY.histogram("s")
db_operation_failure_count = ServiceMeterEnum.DB_OPERATION_FAILURE_COUNT.counter("1")
validator_invocation_count = ServiceMeterEnum.VALIDATOR_INVOCATION_COUNT.counter("1")
validator_request_latency = ServiceMeterEnum.VALIDATOR_REQUEST_LATENCY.histogram("s")
pipeline_creation_count = ServiceMeterEnum.PIPELINE_CREATION_COUNT.counter("1")
validator_usage = ServiceMeterEnum.VALIDATOR_USAGE.counter("1")

##################################################
# HELPERS FOR ADDING METRICS
##################################################
def counter_add(metric: Counter, value: float | int, extra_attributes: dict = None):
    attributes = {**_default_attributes, **get_contextvars()}
    if extra_attributes:
        attributes.update({k: v for k, v in extra_attributes.items() if v is not None})
    metric.add(amount=value, attributes=attributes)

def histogram_record(metric: Histogram, value: float | int, extra_attributes: dict = None):
    attributes = {**_default_attributes, **get_contextvars()}
    if extra_attributes:
        attributes.update({k: v for k, v in extra_attributes.items() if v is not None})
    metric.record(amount=value, attributes=attributes)

##################################################
# DECORATOR FOR HTTP REQUEST METRICS (FIXED)
##################################################

def record_request_metrics(func_name: str):
    """
    Decorator to record metrics and spans for HTTP endpoints.
    Creates specific metrics like 'aitrust.service.<func_name>.count'.
    """
    metric_name_count = f"aitrust.service.{func_name}.count"
    metric_name_latency = f"aitrust.service.{func_name}.latency"
    metric_name_failure_count = f"aitrust.service.{func_name}.failure.count"

    request_count_instrument = _get_or_create_instrument(
        metric_name_count, Counter, "1", f"Counts requests for {func_name}")
    request_latency_instrument = _get_or_create_instrument(
        metric_name_latency, Histogram, "s", f"Measures latency for {func_name}")
    request_failure_count_instrument = _get_or_create_instrument(
        metric_name_failure_count, Counter, "1", f"Counts failures for {func_name}")

    # --- RENAME 'func' parameter to 'original_func' ---
    def decorator(original_func):
        # --- Use 'original_func' here ---
        @wraps(original_func)
        async def wrapper(*args, **kwargs):
            span_name = f"aitrust.service.{func_name}"
            with tracer.start_as_current_span(span_name):
                start_time = perf_counter()
                req = None
                # --- Use the MODULE 'func' here ---
                if args and isinstance(args[0], func.HttpRequest):
                    req = args[0]
                # --- Use the MODULE 'func' here ---
                elif "req" in kwargs and isinstance(kwargs["req"], func.HttpRequest):
                    req = kwargs["req"]

                status_code = 200
                status = "success"
                error_type = None
                response = None # Initialize response

                try:
                    # --- Call the RENAMED 'original_func' ---
                    response = await original_func(*args, **kwargs)
                    # --- Use the MODULE 'func' here ---
                    if isinstance(response, func.HttpResponse) and hasattr(response, "status_code"):
                        status_code = response.status_code
                        if not (200 <= status_code < 300):
                            status = "failure"
                            counter_add(
                                request_failure_count_instrument,
                                1.0,
                                extra_attributes={"status_code": status_code}
                            )
                    elif response is not None:
                         status_code = 200
                         status = "success"

                except Exception as e:
                    status_code = 500
                    status = "failure"
                    error_type = type(e).__name__
                    counter_add(
                        request_failure_count_instrument,
                        1.0,
                        extra_attributes={"status_code": status_code,
                                          "error_type": error_type}
                    )
                    try:
                        from libs.common.logs.logger import logger
                        logger.exception(f"Unhandled exception in {func_name}", exc_info=e)
                    except ImportError:
                         print(f"ERROR in {func_name}: {e}")

                    try:
                        from libs.common.utils.http_utils import internal_server_error
                         # --- Use the MODULE 'func' here ---
                        response = internal_server_error(e, f"Unhandled error in {func_name}")
                    except ImportError:
                         response = func.HttpResponse("Internal Server Error", status_code=500)
                    except Exception as response_e:
                         print(f"ERROR creating error response for {func_name}: {response_e}")
                          # --- Use the MODULE 'func' here ---
                         response = func.HttpResponse("Internal Server Error", status_code=500)

                finally:
                    duration = perf_counter() - start_time
                    common_attributes = {
                        "status": status,
                        "status_code": status_code,
                        **({"error_type": error_type} if error_type else {})
                    }
                    counter_add(
                        request_count_instrument,
                        1.0,
                        extra_attributes=common_attributes
                    )
                    histogram_record(
                        request_latency_instrument,
                        duration,
                        extra_attributes=common_attributes
                    )

                if response is None:
                     print(f"WARNING: Function {func_name} completed without returning a response.")
                      # --- Use the MODULE 'func' here ---
                     return func.HttpResponse(status_code=200)

                return response

        return wrapper
    return decorator


##################################################
# DECORATOR FOR QUEUE TRIGGER METRICS (FIXED)
##################################################

def record_queue_metrics(func_name: str):
    """
    Decorator to record metrics and spans for queue triggers.
    Creates specific metrics like 'aitrust.service.<func_name>.message.count'.
    """
    metric_name_message_count = f"aitrust.service.{func_name}.message.count"
    metric_name_latency = f"aitrust.service.{func_name}.processing.latency"
    metric_name_failure_count = f"aitrust.service.{func_name}.processing.failure.count"

    queue_message_count_instrument = _get_or_create_instrument(
        metric_name_message_count, Counter, "1", f"Counts messages processed by {func_name}")
    queue_processing_latency_instrument = _get_or_create_instrument(
        metric_name_latency, Histogram, "s", f"Measures processing latency for {func_name}")
    queue_processing_failure_count_instrument = _get_or_create_instrument(
        metric_name_failure_count, Counter, "1", f"Counts processing failures for {func_name}")

    # --- RENAME 'original_func' parameter to avoid clash if it was named 'func' before ---
    def decorator(original_func):
        # --- Use 'original_func' here ---
        @wraps(original_func)
        # --- Need to check the type of msg argument using MODULE 'func' ---
        async def wrapper(msg: func.QueueMessage): # Type hint uses module 'func' correctly
            span_name = f"aitrust.service.{func_name}"
            with tracer.start_as_current_span(span_name):
                start_time = perf_counter()
                status = "success"
                error_type = None
                try:
                    # --- Call the RENAMED 'original_func' ---
                    await original_func(msg)
                except Exception as e:
                    status = "failure"
                    error_type = type(e).__name__
                    counter_add(
                        queue_processing_failure_count_instrument,
                        1.0,
                        extra_attributes={"error_type": error_type}
                    )
                    try:
                         from libs.common.logs.logger import logger
                         if logger:
                              logger.exception(f"Exception in queue trigger {func_name}", exc_info=e)
                         else:
                              print(f"ERROR in queue trigger {func_name} (logger not available): {e}")
                    except ImportError:
                         print(f"ERROR in queue trigger {func_name} (logger import failed): {e}")
                    raise
                finally:
                    duration = perf_counter() - start_time
                    common_attributes = {
                        "status": status,
                        **({"error_type": error_type} if error_type else {})
                    }
                    counter_add(
                        queue_message_count_instrument,
                        1.0,
                        extra_attributes=common_attributes
                    )
                    histogram_record(
                        queue_processing_latency_instrument,
                        duration,
                        extra_attributes=common_attributes
                    )
            return None
        return wrapper
    return decorator

# ... (record_db_operation_metrics and invoke_validator remain the same) ...

##################################################
# DECORATOR FOR DB OPERATION METRICS (Unchanged, uses dimension approach)
##################################################

def record_db_operation_metrics(operation_name: str):
    """
    Decorator to record metrics and spans for database operations.
    Uses generic DB metrics + 'metric_name' dimension.
    """
    def decorator(func): # 'func' here is fine, doesn't clash inside this scope
        @wraps(func)
        async def wrapper(*args, **kwargs):
            metric_base = f"aitrust.service.db.{operation_name}"
            metric_attr_base = f"aitrust.service.db.{operation_name}"

            with tracer.start_as_current_span(metric_base):
                start_time = perf_counter()
                status = "success"
                error_type = None
                try:
                    result = await func(*args, **kwargs)
                    return result
                except Exception as e:
                    status = "failure"
                    error_type = type(e).__name__
                    counter_add(
                        db_operation_failure_count, # Generic instrument
                        1.0,
                        extra_attributes={
                            "metric_name": f"{metric_attr_base}.failure.count", # Dimension
                            "error_type": error_type
                        }
                    )
                    raise
                finally:
                    duration = perf_counter() - start_time
                    attributes = {
                        "metric_name": metric_attr_base, # Dimension for splitting
                        "status": status,
                        **({"error_type": error_type} if error_type else {})
                    }
                    counter_add(db_operation_count, 1.0, extra_attributes=attributes)
                    histogram_record(db_operation_latency, duration, extra_attributes=attributes)
        return wrapper
    return decorator

##################################################
# Example usage in service code (Unchanged, uses dimension approach)
##################################################

def invoke_validator(validator_name, *args, **kwargs):
    """
    Simulate a validator call, track metrics with 'aitrust.service.*' naming.
    Uses generic validator metrics + 'validator_name' dimension.
    """
    start_time = perf_counter()
    status = "success"
    error_type = None
    try:
        result = None
        return result
    except Exception as e:
        status = "failure"
        error_type = type(e).__name__
        raise
    finally:
        duration = perf_counter() - start_time
        attributes = {
            "validator_name": validator_name, # Dimension for splitting
            "status": status,
            **({"error_type": error_type} if error_type else {})
            }
        counter_add(validator_invocation_count, 1, extra_attributes=attributes)
        histogram_record(validator_request_latency, duration, extra_attributes=attributes)