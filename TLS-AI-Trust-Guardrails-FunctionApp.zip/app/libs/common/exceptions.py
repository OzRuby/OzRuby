class ConfigNotFound(Exception):
    """Exception raised when a configuration file is not found."""
    pass

class ConfigBadFormat(Exception):
    """Exception raised when a configuration file is badly formatted."""
    pass

class SDKServiceError(Exception):
    """
    Generic error indicating a service-related issue.
    Accepts optional http_status_code and details if you want them in your logs/tests.
    """
    def __init__(self, message: str, http_status_code=None, details=None):
        super().__init__(message)
        self.http_status_code = http_status_code
        self.details = details

class SDKValidationError(Exception):
    """Validation error for user input or config data."""
    pass

class SDKInternalError(Exception):
    """Internal error representing unexpected conditions in the SDK."""
    pass
