from pathlib import Path
import yaml
from os import environ
from typing import Optional
from dotenv import find_dotenv
from pydantic import ValidationError

from libs.common.exceptions import ConfigNotFound
from libs.models.root import MainConfigModel
#from libs.common.common import find_base_path


def default_env():
    if environ.get("ENV"):
        return environ["ENV"]
    else:
        return "dev"

def load_global_config():
    config: Optional[MainConfigModel] = None
    config_env = "CONFIG_JSON"
    
    # Check if CONFIG_JSON env variable is set.
    if config_env in environ and environ[config_env].strip():
        try:
            config = MainConfigModel.model_validate_json(environ[config_env])
            return config
        except Exception as e:
            raise e

    # Use DOTENV_CONFIG environment variable if set; otherwise, use default file path.
    dotenv_config = environ.get("DOTENV_CONFIG")
    if dotenv_config:
        config_file = dotenv_config
    else:
        base_path = f"{Path(__file__).parent.parent.parent.parent}\\configs"
        config_file = f"{base_path}\\settings.{default_env()}.yaml"

    config_path = find_dotenv(filename=config_file)
    if not config_path:
        raise ConfigNotFound(f"Cannot find settings file {config_file}")

    try:
        with open(encoding="utf-8", file=config_path, mode="r") as r:
            data = yaml.safe_load(r)
        config = MainConfigModel.model_validate(data)
        return config
    except ValidationError as e:
        raise e
    except Exception as e:
        print(str(e))
        raise e

CONFIG = load_global_config()
