# Copied from https://github.com/microsoft/call-center-ai/blob/main/app/helpers/logging.py

from logging import Logger, _nameToLevel, basicConfig

from structlog import (
    configure_once,
    get_logger as structlog_get_logger,
    make_filtering_bound_logger,
)
from structlog.contextvars import merge_contextvars
from structlog.dev import ConsoleRenderer
from structlog.processors import (
    CallsiteParameter,
    CallsiteParameterAdder,
    JSONRenderer,
    StackInfoRenderer,
    TimeStamper,
    UnicodeDecoder,
    add_log_level,
    format_exc_info,
)
from structlog.stdlib import PositionalArgumentsFormatter

from libs.common.config import CONFIG, default_env


# Default logging level for all the dependencies
basicConfig(
    encoding='utf-8',
    level=CONFIG.monitoring.logging.system_level.upper()
)
# Configure application console logging
configure_once(
    cache_logger_on_first_use=True,
    context_class=dict,
    wrapper_class=make_filtering_bound_logger(
        _nameToLevel[CONFIG.monitoring.logging.app_level.value]
    ),
    processors=[
        # Add logger name support
        #add_logger_name,
        # Add contextvars support
        merge_contextvars,
        # Add log level
        add_log_level,
        # Add callsite parameters.
        CallsiteParameterAdder(
            {
                CallsiteParameter.FILENAME,
                CallsiteParameter.FUNC_NAME,
                CallsiteParameter.LINENO
            }
        ),
        # Enable %s-style formatting
        PositionalArgumentsFormatter(),
        # Add timestamp
        TimeStamper(fmt="iso", utc=True),
        # Add exceptions info
        StackInfoRenderer(),
        # Add format Error
        format_exc_info,
        # Decode Unicode to str
        UnicodeDecoder(),
        # Pretty printing in a terminal session
        ConsoleRenderer(colors=True) if default_env() == "dev" else JSONRenderer(sort_keys=True),
    ],
)

# Framework does not exactly expose Logger, but that's easier to work with
logger: Logger = structlog_get_logger(CONFIG.monitoring.logging.logger_name)
