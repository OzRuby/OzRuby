"""
HTTP Utilities Module

This module provides functions for generating standardized HTTP responses, such as error responses and formatted validator results. It also includes a default serializer for handling complex objects in JSON responses.
"""

import json
from http import HTTPStatus
from typing import Optional, List, Any
from datetime import datetime
from uuid import UUID

import azure.functions as func
from pydantic import ValidationError

from libs.common.logs.logger import logger


def default_serializer(o: Any) -> Any:
    """
    Serialize complex objects to JSON-compatible formats.

    This function handles the serialization of objects like datetime, UUID, and Pydantic models to ensure they can be included in JSON responses.

    Args:
        o (Any): The object to serialize.

    Returns:
        Any: A JSON-serializable representation of the object (e.g., string, dict).

    Examples:
        >>> default_serializer(datetime(2023, 1, 1))
        '2023-01-01T00:00:00'
        >>> default_serializer(UUID('123e4567-e89b-12d3-a456-426614174000'))
        '123e4567-e89b-12d3-a456-426614174000'
    """
    if isinstance(o, datetime):
        return o.isoformat()
    if isinstance(o, UUID):
        return str(o)
    if hasattr(o, "dict") and callable(o.dict):
        try:
            return o.dict()
        except Exception:
            pass
    try:
        return o.__dict__
    except Exception:
        try:
            return dict(o)
        except Exception:
            return str(o)


def validation_error(e: Exception) -> func.HttpResponse:
    """
    Generate a 400 Bad Request response for validation errors.

    This function creates a standardized HTTP response for validation errors, typically from Pydantic ValidationError instances.

    Args:
        e (Exception): The exception containing validation error details.

    Returns:
        func.HttpResponse: A 400 Bad Request response with error details in JSON format.

    Examples:
        >>> from pydantic import ValidationError
        >>> e = ValidationError.from_exception_data("test", [{"msg": "Invalid input"}])
        >>> resp = validation_error(e)
        >>> resp.status_code
        400
    """
    details = e.errors() if isinstance(e, ValidationError) else [str(e)]
    resp = {"error": {"message": "Validation error", "details": details}}
    logger.debug("Returning 400 validation error: %s", resp)
    return func.HttpResponse(
        status_code=HTTPStatus.BAD_REQUEST,
        body=json.dumps(resp, default=default_serializer),
        mimetype="application/json"
    )


def internal_server_error(e: Exception, message: str) -> func.HttpResponse:
    """
    Generate a 500 Internal Server Error response.

    This function creates a standardized HTTP response for unexpected server errors, including a custom message and exception details.

    Args:
        e (Exception): The exception that caused the error.
        message (str): A custom message describing the error.

    Returns:
        func.HttpResponse: A 500 Internal Server Error response with error details in JSON format.

    Examples:
        >>> resp = internal_server_error(Exception("Database failure"), "Server error occurred")
        >>> resp.status_code
        500
    """
    resp = {"error": {"message": message, "details": [str(e)]}}
    logger.debug("Returning 500 internal server error: %s", resp)
    return func.HttpResponse(
        status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        body=json.dumps(resp, default=default_serializer),
        mimetype="application/json"
    )


def not_found(message: str) -> func.HttpResponse:
    """
    Generate a 404 Not Found response.

    This function creates a standardized HTTP response for resources that cannot be found.

    Args:
        message (str): A message describing what was not found.

    Returns:
        func.HttpResponse: A 404 Not Found response with the provided message in JSON format.

    Examples:
        >>> resp = not_found("Resource not found")
        >>> resp.status_code
        404
    """
    resp = {"error": {"message": message, "details": [message]}}
    logger.debug("Returning 404 not found: %s", resp)
    return func.HttpResponse(
        status_code=HTTPStatus.NOT_FOUND,
        body=json.dumps(resp, default=default_serializer),
        mimetype="application/json"
    )


def bad_request(message: str, details: Optional[List[str]] = None) -> func.HttpResponse:
    """
    Generate a 400 Bad Request response with optional details.

    This function creates a standardized HTTP response for invalid client requests, optionally including additional details.

    Args:
        message (str): A message describing the bad request.
        details (Optional[List[str]]): Optional list of additional details about the error. Defaults to None.

    Returns:
        func.HttpResponse: A 400 Bad Request response with the provided message and details in JSON format.

    Examples:
        >>> resp = bad_request("Invalid input", ["Missing required field"])
        >>> resp.status_code
        400
    """
    resp = {"error": {"message": message, "details": details or []}}
    logger.debug("Returning 400 bad request: %s", resp)
    return func.HttpResponse(
        status_code=HTTPStatus.BAD_REQUEST,
        body=json.dumps(resp, default=default_serializer),
        mimetype="application/json"
    )
