from datetime import datetime, UTC

from pydantic import SecretStr


def current_datetime():
    return datetime.now(UTC)

def make_secret(text):
    return SecretStr(text)