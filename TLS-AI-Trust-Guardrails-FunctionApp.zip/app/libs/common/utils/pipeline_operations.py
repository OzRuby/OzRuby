# libs/common/utils/pipeline_operations.py

import asyncio
from datetime import datetime, timezone
from uuid import UUID

from ..logs.logger import logger
from ...models.pipeline import PipelineExecutionModel
from ...models.validator import ValidatorExecutionModel, ValidatorExecutionStatusEnum
from libs.models.common_enums import PipelineExecutionStatusEnum


async def update_pipeline_execution(
    db_ops: "CosmosDbOperations",
    pipeline: PipelineExecutionModel,
    validator_exec_update: ValidatorExecutionModel
) -> bool:
    """
    Replace a single validator execution, then recompute guard & stage statuses
    (in‐progress until _all_ children are done).
    """
    if not pipeline or not validator_exec_update:
        logger.error("Must provide both pipeline and validator_exec_update.")
        return False

    target_pipeline_id = pipeline.pipeline_execution_id
    try:
        target_validator_id = UUID(str(validator_exec_update.validator_execution_id))
    except Exception:
        logger.error(
            f"Invalid UUID for validator: {validator_exec_update.validator_execution_id}"
        )
        return False

    logger.info(f"--- START update for pipeline {target_pipeline_id}, validator {target_validator_id}")
    found = False

    # 1) Find & replace
    for stage in pipeline.stages_execution_results:
        for guard in stage.guards_execution_results:
            for idx, existing in enumerate(guard.validators_execution_results):
                if UUID(str(existing.validator_execution_id)) == target_validator_id:
                    guard.validators_execution_results[idx] = validator_exec_update
                    found = True

                    # 2) Recompute this guard:
                    if any(
                        v.execution_status
                        in (ValidatorExecutionStatusEnum.NOT_STARTED,
                            ValidatorExecutionStatusEnum.IN_PROGRESS)
                        for v in guard.validators_execution_results
                    ):
                        guard.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS.value
                    else:
                        guard.execution_status = ValidatorExecutionStatusEnum.COMPLETED.value

                    # 3) Recompute this stage:
                    if any(
                        g.execution_status
                        in (ValidatorExecutionStatusEnum.NOT_STARTED.value,
                            ValidatorExecutionStatusEnum.IN_PROGRESS.value)
                        for g in stage.guards_execution_results
                    ):
                        stage.status = ValidatorExecutionStatusEnum.IN_PROGRESS.value
                    else:
                        stage.status = ValidatorExecutionStatusEnum.COMPLETED.value

                    logger.debug(
                        f"Guard '{guard.guard_config.name}' → {guard.execution_status}, "
                        f"Stage '{stage.stage_name}' → {stage.status}"
                    )
                    break
            if found:
                break
        if found:
            break

    if not found:
        logger.error(f"Validator {target_validator_id} not found in pipeline structure.")
        return False

    # 4) Bump the pipeline last_update and flip to RUNNING if it was never started
    pipeline.last_update = datetime.now(timezone.utc)
    if pipeline.status == PipelineExecutionStatusEnum.NOT_STARTED:
        pipeline.status = PipelineExecutionStatusEnum.RUNNING
        logger.info(f"Pipeline {target_pipeline_id} → RUNNING")

    # 5) Persist
    try:
        ok = await db_ops.pipeline_upsert(pipeline)
        if ok:
            logger.info(f"Pipeline {target_pipeline_id} upserted successfully.")
        else:
            logger.error(f"CosmosDB upsert failed for pipeline {target_pipeline_id}.")
        return ok
    except Exception as e:
        logger.error(f"Exception during pipeline upsert: {e}", exc_info=True)
        return False
    finally:
        logger.info(f"--- END update for pipeline {target_pipeline_id}, validator {target_validator_id} ---")
