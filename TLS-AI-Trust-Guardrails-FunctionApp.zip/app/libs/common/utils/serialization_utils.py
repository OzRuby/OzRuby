from guardrails.validators import PassResult
from libs.models.validator import ValidatorExecutionModel

def fix_pass_result_serialization(execution_result: ValidatorExecutionModel) -> None:
    """
    Fixes serialization issues in ValidatorExecutionModel by ensuring PassResult.value_override is serializable.
    
    Args:
        execution_result (ValidatorExecutionModel): The execution result to modify in place.
    """
    if execution_result.response and isinstance(execution_result.response.details, dict):
        result = execution_result.response.details.get("Result")
        if isinstance(result, PassResult) and isinstance(result.value_override, type):
            result.value_override = None  # Set to None to make it serializable