# libs/common/utils/telemetry_utils.py

import json
from opentelemetry.trace import get_current_span
from libs.models.validator import ValidatorRequestModel
from libs.common.monitoring import SpanAttributeEnum

def attach_all_validator_ot_attributes(validator_req: ValidatorRequestModel) -> None:
    """
    Safely attach all relevant OpenTelemetry attributes from the ValidatorRequestModel,
    JSON‑stringifying any dict/list so we only pass primitives or strings to the SDK.
    """
    span = get_current_span()

    def _safe_set(enum_key: SpanAttributeEnum, val):
        # Skip None entirely
        if val is None:
            return

        # If it’s a dict or list, JSON‑encode it
        if isinstance(val, (dict, list)):
            safe_val = json.dumps(val, default=str)
        else:
            safe_val = val

        # Now set it as an attribute (key is the enum’s .value)
        span.set_attribute(enum_key.value, safe_val)

    # 1. user.id
    _safe_set(
        SpanAttributeEnum.USER_ID,
        validator_req.user_payload.metadata.get("user_id")
    )

    # 2. conversation.id
    _safe_set(
        SpanAttributeEnum.CONVERSATION_ID,
        str(validator_req.conversation_id)
    )

    # 3. project.name
    _safe_set(
        SpanAttributeEnum.PROJECT_NAME,
        validator_req.project_name
    )

    # 4. pipeline.execution.id
    _safe_set(
        SpanAttributeEnum.PIPELINE_EXECUTION_ID,
        str(validator_req.pipeline_execution_id)
    )

    # 5. validator.execution.id
    _safe_set(
        SpanAttributeEnum.VALIDATOR_EXECUTION_ID,
        str(validator_req.validator_execution_id)
    )

    # 6. validator.name
    _safe_set(
        SpanAttributeEnum.VALIDATOR_NAME,
        validator_req.validator_config.name
    )

    # 7. validation_method
    method = getattr(validator_req.validation_method, "value", validator_req.validation_method)
    _safe_set(SpanAttributeEnum.VALIDATION_METHOD, method)

    # 8. project.scope
    _safe_set(SpanAttributeEnum.PROJECT_SCOPE, validator_req.scope)

    # 9. contract.name
    _safe_set(SpanAttributeEnum.PARTNER_NAME, validator_req.partner_name)

    # 10. country.name
    _safe_set(SpanAttributeEnum.COUNTRY_NAME, validator_req.country_name)
