# libs/common/http_service.py

from __future__ import annotations

import asyncio
from typing import Optional

from aiohttp import (
    ClientSession,
    ClientTimeout,
    DummyCookieJar,
    TCPConnector,
    AsyncResolver,
    TraceConfig,
)
from azure.core.pipeline.transport._aiohttp import AioHttpTransport
from tenacity import (
    AsyncRetrying,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)
from libs.common.logs.logger import logger
from .cache import lru_acache
from libs.common.config import CONFIG  # your Pydantic SettingsModel

# ---------------------------------------------------------------------------- #
# Globals                                                                      #
# ---------------------------------------------------------------------------- #
_cookie_jar: Optional[DummyCookieJar] = None
_session: Optional[ClientSession] = None
_transport: Optional[AioHttpTransport] = None

# ---------------------------------------------------------------------------- #
# Config (CONFIG from YAML)                                                    #
# ---------------------------------------------------------------------------- #
# Pull HTTP settings from the Pydantic model at CONFIG.settings.http
_HTTP = CONFIG.settings.http

# ---------------------------------------------------------------------------- #
# Helpers                                                                      #
# ---------------------------------------------------------------------------- #
async def on_request_start(session: ClientSession, trace_config_ctx: Any, params: Any):
    trace_config_ctx.start = asyncio.get_event_loop().time()
    logger.info("Starting request %s %s", params.method, params.url)

async def on_request_end(session: ClientSession, trace_config_ctx: Any, params: Any):
    elapsed = asyncio.get_event_loop().time() - trace_config_ctx.start
    logger.info("Request took %.3fs %s %s", elapsed, params.method, params.url)

trace_config = TraceConfig()
trace_config.on_request_start.append(on_request_start)
trace_config.on_request_end.append(on_request_end)

async def _aiohttp_cookie_jar() -> DummyCookieJar:
    """Return a singleton dummy cookie jar (stateless)."""
    global _cookie_jar
    if _cookie_jar is None:
        _cookie_jar = DummyCookieJar()
    return _cookie_jar

@lru_acache()
async def aiohttp_session() -> ClientSession:
    """
    Return a singleton aiohttp.ClientSession configured from CONFIG.settings.http.
    """
    global _session
    if _session is None or _session.closed:
        timeout = ClientTimeout(
            total=_HTTP.timeouts.total_seconds,
            connect=_HTTP.timeouts.connect_seconds,
        )
        _session = ClientSession(
            auto_decompress=False,
            cookie_jar=await _aiohttp_cookie_jar(),
            timeout=timeout,
            connector=TCPConnector(limit_per_host=_HTTP.pool_limit_per_host),
            trust_env=False,
            trace_configs=[trace_config]
        )
        logger.info(
            "Created global aiohttp ClientSession(total=%ss connect=%ss pool=%s)",
            _HTTP.timeouts.total_seconds,
            _HTTP.timeouts.connect_seconds,
            _HTTP.pool_limit_per_host,
        )
    return _session

async def azure_transport() -> AioHttpTransport:
    """
    Return a singleton AioHttpTransport using the shared aiohttp session.
    """
    global _transport
    if _transport is None:
        _transport = AioHttpTransport(session_owner=False, session=await aiohttp_session())
        logger.info("Created global AioHttpTransport")
    return _transport


async def close_session():
    """Close the shared aiohttp.ClientSession (call at app shutdown)."""
    global _session
    if _session and not _session.closed:
        await _session.close()
        logger.info("Global aiohttp ClientSession closed")
