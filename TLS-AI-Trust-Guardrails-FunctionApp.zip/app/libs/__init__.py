import nest_asyncio


# Apply nest_asyncio to allow nested event loops
nest_asyncio.apply()