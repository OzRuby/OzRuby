"""
Entry point for the Azure Functions service.

This module defines the HTTP endpoints and queue triggers for the service. It handles requests for pipeline management and validator execution, delegating the actual processing to utility and service modules.

Exposed Endpoints:
  - GET /health/liveness: Health check endpoint.
  - POST /pipeline: Create a new pipeline record.
  - GET /pipeline/{pipeline_execution_id}: Retrieve a pipeline record by ID.
  - POST /pipeline/{pipeline_execution_id}: Update an existing pipeline record.
  - GET /pipeline/{pipeline_execution_id}/validator/{validator_execution_id}: Retrieve a specific validator execution record within a pipeline.
  - POST /validator/offensive: Run the offensive content validator synchronously.
  - POST /validator/hallucination: Enqueue a hallucination validation task for asynchronous processing.
  - POST /validator/grammar: Enqueue a grammar validation task for asynchronous processing.
  - POST /validator/answer_relevance: Enqueue an answer relevance validation task for asynchronous processing.
  - POST /validator/chunk_relevance: Enqueue a chunk relevance validation task for asynchronous processing.
  - POST /validator/prompt_injection: Enqueue a prompt injection validation task for asynchronous processing.

Queue Triggers:
  - HallucinationCheckQueueTrigger: Process hallucination validation tasks from the queue.
  - GrammarCheckQueueTrigger: Process grammar validation tasks from the queue.
  - AnswerRelevanceCheckQueueTrigger: Process answer relevance validation tasks from the queue.
  - ChunkRelevanceCheckQueueTrigger: Process chunk relevance validation tasks from the queue.
  - PromptInjectionCheckQueueTrigger: Process prompt injection validation tasks from the queue.
"""

import sys
import json
import time

start = time.perf_counter()  # Start timing

# Ensure UTF-8 encoding for stdout and stderr
if sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")
if sys.stderr.encoding.lower() != "utf-8":
    sys.stderr.reconfigure(encoding="utf-8")

logger = None
try:
    from libs.common.logs.logger import logger
    import azure.functions as func
    from dotenv import find_dotenv, load_dotenv
    from pydantic import ValidationError
    dotenv_path = find_dotenv()
    load_dotenv(dotenv_path)
    # Import common modules and utilities
    from datetime import datetime, timezone
    from libs.common.config import CONFIG
    from libs.common.utils.http_utils import validation_error, internal_server_error, not_found, bad_request
    from libs.common.utils.telemetry_utils import attach_all_validator_ot_attributes
    from libs.common.utils.pipeline_operations import update_pipeline_execution
    from db_operations.cosmos_db import CosmosDbOperations
    from libs.models.validator import (
    ValidatorExecutionStatusEnum,
    ValidatorRequestModel, 
    ValidatorExecutionModel
    )
    from libs.models.pipeline import PipelineExecutionModel
    # monitoring imports
    from libs.common.monitoring import (
        record_request_metrics,
        record_queue_metrics,
    )

    # Initialize database and transport managers
    db_ops = CosmosDbOperations(CONFIG)
    # Create the FunctionApp instance
    app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

except Exception as e:
    if logger:
        logger.exception("Exception during function_app.py startup", exc_info=e)
    else:
        print(f"Exception during function_app.py startup: {e}")
    raise

# Create the FunctionApp instance
app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

###############################################
# Common Endpoints
###############################################

@app.route(
    route="health/liveness",
    methods=[func.HttpMethod.GET]
)
@record_request_metrics("health_liveness_get")
async def health_liveness_get(req: func.HttpRequest) -> func.HttpResponse:
    """
    Health check endpoint to verify the service is running.

    This endpoint returns a 200 OK response if the service is operational, serving as a liveness probe.

    Args:
        req (func.HttpRequest): The incoming HTTP request.

    Returns:
        func.HttpResponse: A 200 OK response if successful, or a 500 error response if an exception occurs.
    """
    logger.info("==== HEALTH LIVENESS CHECK: START ====")
    try:
        logger.debug("Liveness check: no input required.")
        return func.HttpResponse(status_code=200)
    except Exception as e:
        logger.error("Health check error", exc_info=True)
        return internal_server_error(e, "Health check failed.")
    finally:
        logger.info("==== HEALTH LIVENESS CHECK: END ====")

@app.route(
    route="pipeline",
    methods=[func.HttpMethod.POST]
)
@record_request_metrics("create_pipeline_record")
async def create_pipeline_record(req: func.HttpRequest) -> func.HttpResponse:
    """
    Create a new pipeline execution record.

    This endpoint accepts a JSON payload representing a PipelineExecutionModel, validates it, and upserts it into the database.

    Args:
        req (func.HttpRequest): The incoming HTTP request containing the pipeline data in JSON format.

    Returns:
        func.HttpResponse: A 200 OK response with the created pipeline's ID, or an error response (400, 500) on failure.
    """
    logger.info("==== CREATE PIPELINE RECORD: START ====")

    try:
        raw_data = req.get_json()
        logger.debug("Received pipeline create payload: %s", raw_data)
        if not isinstance(raw_data, dict):
            return bad_request("Invalid request payload", details=["Expected JSON dictionary"])

        pipeline_doc = PipelineExecutionModel.model_validate(raw_data)
        success = await db_ops.pipeline_upsert(pipeline_doc)
        if not success:
            return internal_server_error(Exception("CosmosDB upsert failed"), "Failed to create pipeline record.")

        logger.info("Pipeline record created successfully: %s", pipeline_doc.pipeline_execution_id)
        return func.HttpResponse(
            status_code=200,
            body=json.dumps({"message": "Pipeline record created.", "pipeline_execution_id": str(pipeline_doc.pipeline_execution_id)}),
            mimetype="application/json"
        )
    except ValidationError as ve:
        return validation_error(ve)
    except Exception as e:
        return internal_server_error(e, "Error creating pipeline record")
    finally:
        logger.info("==== CREATE PIPELINE RECORD: END ====")

@app.route(
    route="pipeline/{pipeline_execution_id}",
    methods=[func.HttpMethod.GET]
)
@record_request_metrics("get_pipeline_record")
async def get_pipeline_record(req: func.HttpRequest) -> func.HttpResponse:
    """
    Retrieve a pipeline execution record by its ID.

    This endpoint fetches the pipeline record from the database using the provided pipeline_execution_id from the route parameters.

    Args:
        req (func.HttpRequest): The incoming HTTP request with pipeline_execution_id in the route.

    Returns:
        func.HttpResponse: A 200 OK response with the pipeline data, or a 404/400/500 error response on failure.
    """
    logger.info("==== GET PIPELINE RECORD: START ====")
    try:
        pipeline_execution_id = req.route_params.get("pipeline_execution_id")
        if not pipeline_execution_id:
            return bad_request("Missing pipeline_execution_id in route parameters")

        record = await db_ops.pipeline_aget(pipeline_execution_id)
        if not record:
            return not_found(f"Pipeline record not found for ID: {pipeline_execution_id}")

        return func.HttpResponse(
            status_code=200,
            body=record.model_dump_json(),
            mimetype="application/json"
        )
    except Exception as e:
        return internal_server_error(e, "Error retrieving pipeline record")
    finally:
        logger.info("==== GET PIPELINE RECORD: END ====")

@app.route(
    route="pipeline/{pipeline_execution_id}",
    methods=[func.HttpMethod.POST]
)
@record_request_metrics("update_pipeline_record")
async def update_pipeline_record(req: func.HttpRequest) -> func.HttpResponse:
    """
    Update an existing pipeline execution record.

    This endpoint accepts a JSON payload representing an updated PipelineExecutionModel and upserts it into the database.

    Args:
        req (func.HttpRequest): The incoming HTTP request containing the updated pipeline data in JSON format.

    Returns:
        func.HttpResponse: A 200 OK response with the updated pipeline's ID, or an error response (400, 500) on failure.
    """
    logger.info("==== UPDATE PIPELINE RECORD: START ====")
    try:
        raw_data = req.get_json()
        if not isinstance(raw_data, dict):
            return bad_request("Invalid request payload", details=["Expected JSON dictionary"])

        pipeline_doc = PipelineExecutionModel.model_validate(raw_data)
        success = await db_ops.pipeline_upsert(pipeline_doc)
        if not success:
            return internal_server_error(Exception("CosmosDB upsert failed"), "Failed to update pipeline record.")

        return func.HttpResponse(
            status_code=200,
            body=json.dumps({"message": "Pipeline record updated.", "pipeline_execution_id": str(pipeline_doc.pipeline_execution_id)}),
            mimetype="application/json"
        )
    except ValidationError as ve:
        return validation_error(ve)
    except Exception as e:
        return internal_server_error(e, "Error updating pipeline record")
    finally:
        logger.info("==== UPDATE PIPELINE RECORD: END ====")

@app.route(
    route="pipeline/{pipeline_execution_id}/validator/{validator_execution_id}", 
    methods=[func.HttpMethod.GET]
)
@record_request_metrics("get_validator_execution_record")
async def get_validator_execution_record(req: func.HttpRequest) -> func.HttpResponse:
    """Retrieve a specific validator execution record within a pipeline.

    This endpoint fetches the validator execution record from the pipeline's stages and guards using the provided IDs.

    Args:
        req (func.HttpRequest): The incoming HTTP request with pipeline_execution_id and validator_execution_id in the route.

    Returns:
        func.HttpResponse: A 200 OK response with the validator execution data, or a 404/400/500 error response on failure.
    """
    logger.info("==== GET VALIDATOR EXECUTION RECORD: START ====")
    try:
        pipeline_execution_id = req.route_params.get("pipeline_execution_id")
        validator_execution_id = req.route_params.get("validator_execution_id")
        if not pipeline_execution_id or not validator_execution_id:
            return bad_request("Missing pipeline_execution_id or validator_execution_id in route parameters")

        pipeline_record = await db_ops.pipeline_aget(pipeline_execution_id)
        if not pipeline_record:
            return not_found(f"Pipeline record not found for ID: {pipeline_execution_id}")

        validator_exec_result = None
        for stage in pipeline_record.stages_execution_results:
            for guard in stage.guards_execution_results:
                for validator in guard.validators_execution_results:
                    if str(validator.validator_execution_id) == validator_execution_id:
                        validator_exec_result = validator
                        break
                if validator_exec_result:
                    break
            if validator_exec_result:
                break

        if not validator_exec_result:
            return not_found(f"Validator record not found for ID: {validator_execution_id} in pipeline {pipeline_execution_id}")

        return func.HttpResponse(
            status_code=200,
            body=validator_exec_result.model_dump_json(),
            mimetype="application/json"
        )
    except Exception as e:
        return internal_server_error(e, "Error retrieving validator execution record")
    finally:
        logger.info("==== GET VALIDATOR EXECUTION RECORD: END ====")


######################################################
# Validator Endpoints and Triggers
######################################################


@app.route(route="validator/grammar_checker", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue",
    queue_name=CONFIG.settings.queues.validator_grammar_queue_name,
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_grammar_validator")
async def run_grammar_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    logger.info("==== RUN GRAMMAR VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")

        in_progress = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(db_ops, pipeline=pipeline_record, validator_exec_update=in_progress)
        logger.info(
            "Validator %s → IN_PROGRESS in pipeline %s",
            validator_req.validator_execution_id,
            validator_req.pipeline_execution_id
        )

        jobQueue.set(validator_req.model_dump_json())
        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )

    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running grammar validator")
    finally:
        logger.info("==== RUN GRAMMAR VALIDATOR: END ====")


@app.function_name("GrammarCheckQueueTrigger") # Explicit function name for Azure portal
@app.queue_trigger(
    arg_name="msg", # Name used to access the message in the function signature
    queue_name=CONFIG.settings.queues.validator_grammar_queue_name, # Queue name from config
    connection="AzureWebJobsStorage" # Connection string name
)
@record_queue_metrics("grammar_check_queue_trigger") # Decorator for monitoring queue processing metrics
async def grammar_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Azure Function triggered by messages on the grammar validation queue.

    This function parses the incoming queue message (expected to be a JSON string
    representing a `ValidatorExecutionModel`), validates it, and delegates the
    actual processing (running the validator, updating the final state in the DB
    with retries) to the `process_grammar_validation` service function.

    Args:
        msg: The incoming Azure Functions queue message object. Contains message body,
             ID, dequeue count, etc.
    """
    from libs.services.grammar_checker.grammar_service import process_grammar_validation

    logger.info(f"==== GRAMMAR CHECK QUEUE TRIGGER: START (MsgId: {msg.id}, DequeueCount: {msg.dequeue_count}) ====")
    try:
        # 1. Decode and Validate Queue Message Body
        try:
            message_body = msg.get_body().decode("utf-8")
            # Parse the JSON string from the queue into the expected Pydantic model.
            validator_req = ValidatorRequestModel.model_validate_json(message_body)
            logger.info(f"Received and validated grammar task from queue for validator "
                        f"{validator_req.conversation_id}")
        except json.JSONDecodeError as json_err:
            # Handle malformed JSON - unlikely if `run_grammar_validator` works correctly.
            logger.error(f"Invalid JSON in queue message {msg.id}: {json_err}. Body(start): "
                         f"{msg.get_body().decode('utf-8', errors='ignore')[:200]}...", exc_info=False)
            # Message will likely be dead-lettered by Azure Functions host after retries. No action needed here.
            return
        except ValidationError as ve:
            # Handle case where JSON is valid but doesn't match the expected model schema.
            logger.error(f"Schema validation failed for queue message {msg.id}: {ve.errors()}. Body(start): "
                         f"{msg.get_body().decode('utf-8', errors='ignore')[:200]}...", exc_info=False)
            # Message will likely be dead-lettered.
            return
        except UnicodeDecodeError as ude:
            logger.error(f"Cannot decode queue message {msg.id} as UTF-8: {ude}", exc_info=False)
            # Message will likely be dead-lettered.
            return

        # 2. Delegate to Service Layer for Processing
        # This function handles the core logic: running the validator and saving the final state.
        # It includes its own error handling and DB retry logic.
        await process_grammar_validation(db_ops, validator_req)

        logger.info(f"Successfully finished processing grammar task for validator "
                    f"{validator_req.conversation_id} (MsgId: {msg.id}).")

    except Exception as e:
        # Catch unexpected errors *outside* of `process_grammar_validation`
        # (e.g., during initial message parsing, dependency issues).
        # Errors *inside* `process_grammar_validation` should be handled there,
        # potentially resulting in a SYS_ERROR status saved to the DB.
        logger.exception(f"Unexpected error in grammar_check_queue_trigger itself (MsgId: {msg.id}): {e}")
        # Allow the Azure Functions host to handle retries/dead-lettering based on its settings.
        # Re-raising the exception signals failure to the host.
        raise e
    finally:
        logger.info(f"==== GRAMMAR CHECK QUEUE TRIGGER: END (MsgId: {msg.id}) ====")

@app.route(route="validator/answer_relevance", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue",
    queue_name=CONFIG.settings.queues.validator_answer_relevance_queue_name,
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_answer_relevance_validator")
async def run_answer_relevance_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    logger.info("==== RUN ANSWER RELEVANCE VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")

        in_progress = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(db_ops, pipeline=pipeline_record, validator_exec_update=in_progress)
        logger.info(
            "Validator %s → IN_PROGRESS in pipeline %s",
            validator_req.validator_execution_id,
            validator_req.pipeline_execution_id
        )

        jobQueue.set(validator_req.model_dump_json())
        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )

    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running answer relevance validator")
    finally:
        logger.info("==== RUN ANSWER RELEVANCE VALIDATOR: END ====")


@app.function_name("AnswerRelevanceCheckQueueTrigger")
@app.queue_trigger(
    arg_name="msg",
    queue_name=CONFIG.settings.queues.validator_answer_relevance_queue_name,
    connection="AzureWebJobsStorage"
)
@record_queue_metrics("answer_relevance_check_queue_trigger")
async def answer_relevance_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Process an answer relevance validation task from the queue.
    This trigger function processes the enqueued answer relevance validation task and updates the pipeline with the result.

    Args:
        msg (func.QueueMessage): The queue message containing the ValidatorExecutionModel in JSON format.

    Returns:
        None: This function does not return a value; it updates the database directly.

    Notes:
        - Exceptions are logged but not raised, ensuring the queue trigger does not fail the message unnecessarily.
    """
    from libs.services.answer_relevance.answer_relevance_service import process_answer_relevance_validation
    logger.info("==== ANSWER RELEVANCE CHECK QUEUE TRIGGER: START ====")
    try:
        message_body = msg.get_body().decode("utf-8")
        validator_req = ValidatorRequestModel.model_validate_json(message_body)
        logger.info(f"Received and validated answer relevance task from queue for validator "
                        f"{validator_req.conversation_id}")
        await process_answer_relevance_validation(db_ops, validator_req)
    except Exception as e:
        logger.exception("Exception in answer_relevance_check_queue_trigger: %s", str(e))
        return internal_server_error(e, "Error running answer relevance validator")
    finally:
        logger.info("==== ANSWER RELEVANCE CHECK QUEUE TRIGGER: END ====")

@app.route(route="validator/chunk_relevance", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue",
    queue_name=CONFIG.settings.queues.validator_chunk_relevance_queue_name,
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_chunk_relevance_validator")
async def run_chunk_relevance_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    logger.info("==== RUN CHUNK RELEVANCE VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")

        in_progress = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(db_ops, pipeline=pipeline_record, validator_exec_update=in_progress)
        logger.info(
            "Validator %s → IN_PROGRESS in pipeline %s",
            validator_req.validator_execution_id,
            validator_req.pipeline_execution_id
        )

        jobQueue.set(validator_req.model_dump_json())
        logger.info(
            f"Enqueued chunk-relevance task to queue "
            f"'{CONFIG.settings.queues.validator_chunk_relevance_queue_name}' "
            f"for validator_execution_id={validator_req.validator_execution_id}"
        )

        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )

    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running chunk relevance validator")
    finally:
        logger.info("==== RUN CHUNK RELEVANCE VALIDATOR: END ====")


@app.function_name("ChunkRelevanceCheckQueueTrigger")
@app.queue_trigger(
    arg_name="msg",
    queue_name=CONFIG.settings.queues.validator_chunk_relevance_queue_name,
    connection="AzureWebJobsStorage"
)
@record_queue_metrics("chunk_relevance_check_queue_trigger")
async def chunk_relevance_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Process a chunk relevance validation task from the queue.
    This trigger function processes the enqueued chunk relevance validation task and updates the pipeline with the result.

    Args:
        msg (func.QueueMessage): The queue message containing the ValidatorExecutionModel in JSON format.

    Returns:
        None: This function does not return a value; it updates the database directly.

    Notes:
        - Exceptions are logged but not raised, ensuring the queue trigger does not fail the message unnecessarily.
    """
    from libs.services.chunks_relevance.chunk_relevance_service import process_chunk_relevance_validation
    logger.info("==== CHUNK RELEVANCE CHECK QUEUE TRIGGER: START ====")
    try:
        message_body = msg.get_body().decode("utf-8")
        validator_req = ValidatorRequestModel.model_validate_json(message_body)
        await process_chunk_relevance_validation(db_ops, validator_req)
    except Exception as e:
        logger.exception("Exception in chunk_relevance_check_queue_trigger: %s", str(e))
    finally:
        logger.info("==== CHUNK RELEVANCE CHECK QUEUE TRIGGER: END ====")

@app.route(route="validator/prompt_injection", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue",
    queue_name=CONFIG.settings.queues.validator_prompt_injection_queue_name,
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_prompt_injection_validator")
async def run_prompt_injection_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    """Enqueue a prompt injection validation task for asynchronous processing.
    This endpoint prepares the validation task, updates the pipeline, enqueues the task in a queue, and returns a 202 Accepted response.

    Args:
        req (func.HttpRequest): The incoming HTTP request with the validator request data in JSON format.
        jobQueue (func.Out[str]): The queue output binding to enqueue the task.

    Returns:
        func.HttpResponse: A 202 Accepted response with the initial execution model, or an error response (400, 404, 500) on failure.
    """
    logger.info("==== RUN PROMPT INJECTION VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request("Missing required fields", 
                               details=["pipeline_execution_id and validator_execution_id are required"])
          # --- Update pipeline: mark this validator IN_PROGRESS ---
        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")

        in_progress_exec = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(
            db_ops,
            pipeline=pipeline_record,
            validator_exec_update=in_progress_exec
        )
        logger.info(
            f"Validator {validator_req.validator_execution_id} set to IN_PROGRESS in pipeline {validator_req.pipeline_execution_id}"
        )

        jobQueue.set(validator_req.model_dump_json())
        logger.info(
            f"Enqueued prompt‑injection task to queue "
            f"'{CONFIG.settings.queues.validator_prompt_injection_queue_name}' "
            f"for validator_execution_id={validator_req.validator_execution_id}"
        )
        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )
    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running prompt injection validator")
    finally:
        logger.info("==== RUN PROMPT INJECTION VALIDATOR: END ====")

@app.function_name("PromptInjectionCheckQueueTrigger")
@app.queue_trigger(
    arg_name="msg",
    queue_name=CONFIG.settings.queues.validator_prompt_injection_queue_name,
    connection="AzureWebJobsStorage"
)
@record_queue_metrics("prompt_injection_check_queue_trigger")
async def prompt_injection_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Process a prompt injection validation task from the queue.
    This trigger function processes the enqueued prompt injection validation task and updates the pipeline with the result.

    Args:
        msg (func.QueueMessage): The queue message containing the ValidatorExecutionModel in JSON format.

    Returns:
        None: This function does not return a value; it updates the database directly.

    Notes:
        - Exceptions are logged but not raised, ensuring the queue trigger does not fail the message unnecessarily.
    """
    from libs.services.prompt_injection.prompt_injection_service import process_prompt_injection_validation
    logger.info("==== PROMPT INJECTION CHECK QUEUE TRIGGER: START ====")
    try:
        message_body = msg.get_body().decode("utf-8")
        validator_req = ValidatorRequestModel.model_validate_json(message_body)
        await process_prompt_injection_validation(db_ops, validator_req)
    except Exception as e:
        logger.exception("Exception in prompt_injection_check_queue_trigger: %s", str(e))
    finally:
        logger.info("==== PROMPT INJECTION CHECK QUEUE TRIGGER: END ====")


@app.route(route="validator/calculation_logic", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue",
    queue_name=CONFIG.settings.queues.validator_calculation_logic_queue_name,
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_calculation_logic_validator")
async def run_calculation_logic_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    logger.info("==== RUN CALCULATION LOGIC VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")

        in_progress = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(db_ops, pipeline=pipeline_record, validator_exec_update=in_progress)
        logger.info(
            "Validator %s → IN_PROGRESS in pipeline %s",
            validator_req.validator_execution_id,
            validator_req.pipeline_execution_id
        )

        jobQueue.set(validator_req.model_dump_json())
        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )

    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running calculation logic validator")
    finally:
        logger.info("==== RUN CALCULATION LOGIC VALIDATOR: END ====")



@app.function_name("CalculationLogicCheckQueueTrigger")
@app.queue_trigger(
    arg_name="msg", 
    queue_name=CONFIG.settings.queues.validator_calculation_logic_queue_name,
    connection="AzureWebJobsStorage"
)
@record_queue_metrics("calculation_logic_check_queue_trigger")
async def calculation_logic_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Process a calculation logic validation task from the queue.
    This trigger function processes the enqueued calculation logic validation task and updates the pipeline with the result.

    Args:
        msg (func.QueueMessage): The queue message containing the ValidatorExecutionModel in JSON format.

    Returns:
        None: This function does not return a value; it updates the database directly.
    """
    from libs.services.calculation_logic.calculation_logic_service import process_calculation_logic_validation
    logger.info("==== CALCULATION LOGIC CHECK QUEUE TRIGGER: START ====")
    try:
        message_body = msg.get_body().decode("utf-8")
        validator_req = ValidatorRequestModel.model_validate_json(message_body)
        await process_calculation_logic_validation(db_ops, validator_req)
    except Exception as e:
        logger.exception("Exception in calculation_logic_check_queue_trigger: %s", str(e))
    finally:
        logger.info("==== CALCULATION LOGIC CHECK QUEUE TRIGGER: END ====")


@app.route(route="validator/format_checker", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue",
    queue_name=CONFIG.settings.queues.validator_format_queue_name,
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_format_validator")
async def run_format_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    logger.info("==== RUN FORMAT VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")

        in_progress = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(db_ops, pipeline=pipeline_record, validator_exec_update=in_progress)
        logger.info(
            "Validator %s → IN_PROGRESS in pipeline %s",
            validator_req.validator_execution_id,
            validator_req.pipeline_execution_id
        )

        jobQueue.set(validator_req.model_dump_json())
        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )

    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running format validator")
    finally:
        logger.info("==== RUN FORMAT VALIDATOR: END ====")



@app.function_name("FormatCheckQueueTrigger")
@app.queue_trigger(
    arg_name="msg", 
    queue_name=CONFIG.settings.queues.validator_format_queue_name, 
    connection="AzureWebJobsStorage"
)
@record_queue_metrics("format_check_queue_trigger")
async def format_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Process a format validation task from the queue.

    This trigger function processes the enqueued format validation task and updates the pipeline with the result.

    Args:
        msg (func.QueueMessage): The queue message containing the ValidatorExecutionModel in JSON format.

    Returns:
        None: This function does not return a value; it updates the database directly.
    """
    from libs.services.format_checker.format_service import process_format_validation
    logger.info("==== FORMAT CHECK QUEUE TRIGGER: START ====")
    try:
        message_body = msg.get_body().decode("utf-8")
        validator_req = ValidatorRequestModel.model_validate_json(message_body)
        await process_format_validation(db_ops, validator_req)
    except Exception as e:
        logger.exception("Exception in format_check_queue_trigger: %s", str(e))
    finally:
        logger.info("==== FORMAT CHECK QUEUE TRIGGER: END ====")


@app.route(route="validator/keyword_filtering", methods=[func.HttpMethod.POST])
@record_request_metrics("run_keyword_filtering_validator")
async def run_keyword_filtering_validator(
    req: func.HttpRequest,
) -> func.HttpResponse:
    """
    Synchronous HTTP endpoint for keyword filtering validation.
    Processes the request inline, updates the pipeline, runs the validator,
    and returns the final ValidatorExecutionModel JSON.
    """
    logger.info("==== RUN KEYWORD FILTERING VALIDATOR (HTTP): START ====")
    try:
        raw = req.get_body()
        body = json.loads(raw)
        validator_req = ValidatorRequestModel.model_validate(body)

        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        # Delegate to service (updates DB and returns final exec model)
        from libs.services.keyword_filtering.keyword_filtering_service import process_keyword_filtering_validation
        final_exec = await process_keyword_filtering_validation(db_ops, validator_req)

        return func.HttpResponse(
            status_code=200,
            body=final_exec.model_dump_json(),
            mimetype="application/json"
        )

    except json.JSONDecodeError as je:
        return bad_request("Invalid JSON format in request body.")
    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running keyword filtering validator")
    finally:
        logger.info("==== RUN KEYWORD FILTERING VALIDATOR (HTTP): END ====")

@app.route(route="validator/language_checker", methods=[func.HttpMethod.POST])
@record_request_metrics("run_language_checker_validator")
async def run_language_checker_validator(
    req: func.HttpRequest,
) -> func.HttpResponse:
    """
    Synchronous HTTP endpoint for language checker validation.
    Processes the request inline, updates the pipeline, runs the validator,
    and returns the final ValidatorExecutionModel JSON.
    """
    logger.info("==== RUN LANGUAGE CHECKER VALIDATOR (HTTP): START ====")
    try:
        raw = req.get_body()
        body = json.loads(raw)
        validator_req = ValidatorRequestModel.model_validate(body)

        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request(
                "Missing required fields",
                details=["pipeline_execution_id and validator_execution_id are required"]
            )

        # Delegate to service (updates DB and returns final exec model)
        from libs.services.language_checker.language_checker_service import process_language_checker_validation
        final_exec = await process_language_checker_validation(db_ops, validator_req)

        return func.HttpResponse(
            status_code=200,
            body=final_exec.model_dump_json(),
            mimetype="application/json"
        )

    except json.JSONDecodeError as je:
        return bad_request("Invalid JSON format in request body.")
    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running language checker validator")
    finally:
        logger.info("==== RUN LANGUAGE CHECKER VALIDATOR (HTTP): END ====")


@app.route(route="validator/query_topics", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name="jobQueue", 
    queue_name=CONFIG.settings.queues.validator_query_topics_queue_name, 
    connection="AzureWebJobsStorage"
)
@record_request_metrics("run_query_topics_validator")
async def run_query_topics_validator(req: func.HttpRequest, jobQueue: func.Out[str]) -> func.HttpResponse:
    logger.info("==== RUN QUERY TOPICS VALIDATOR: START ====")
    try:
        body = json.loads(req.get_body())
        validator_req = ValidatorRequestModel.model_validate(body)
        if not validator_req.pipeline_execution_id or not validator_req.validator_execution_id:
            return bad_request("Missing required fields", 
                               details=["pipeline_execution_id and validator_execution_id are required"])

        # ——— new block copied from chunk_relevance ———
        pipeline_record = await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id))
        if not pipeline_record:
            return not_found(f"Pipeline {validator_req.pipeline_execution_id} not found.")
        in_progress = ValidatorExecutionModel(
            pipeline_execution_id=validator_req.pipeline_execution_id,
            validator_execution_id=validator_req.validator_execution_id,
            execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
            request=validator_req,
            start_time=datetime.now(timezone.utc),
            last_update=datetime.now(timezone.utc)
        )
        await update_pipeline_execution(db_ops, pipeline=pipeline_record, validator_exec_update=in_progress)
        logger.info(
            f"Validator {validator_req.validator_execution_id} → IN_PROGRESS in pipeline {validator_req.pipeline_execution_id}"
        )

        jobQueue.set(validator_req.model_dump_json())
        logger.info(f"Enqueued query‐topics task for validator_execution_id={validator_req.validator_execution_id}")
        return func.HttpResponse(
            status_code=202,
            body=validator_req.model_dump_json(),
            mimetype="application/json"
        )
    except ValidationError as ve:
        return validation_error(ve)
    except ValueError as ve:
        return not_found(str(ve))
    except Exception as e:
        return internal_server_error(e, "Error running query topics validator")
    finally:
        logger.info("==== RUN QUERY TOPICS VALIDATOR: END ====")

@app.function_name("QueryTopicsCheckQueueTrigger")
@app.queue_trigger(
    arg_name="msg", 
    queue_name=CONFIG.settings.queues.validator_query_topics_queue_name, 
    connection="AzureWebJobsStorage"
)
@record_queue_metrics("query_topics_check_queue_trigger")
async def query_topics_check_queue_trigger(msg: func.QueueMessage) -> None:
    """Process a query topics validation task from the queue.

    This trigger function processes the enqueued query topics validation task and updates the pipeline with the result.

    Args:
        msg (func.QueueMessage): The queue message containing the ValidatorExecutionModel in JSON format.

    Returns:
        None: This function does not return a value; it updates the database directly.
    """
    from libs.services.query_topics.query_topics_service import process_query_topics_validation
    logger.info("==== QUERY TOPICS CHECK QUEUE TRIGGER: START ====")
    try:
        message_body = msg.get_body().decode("utf-8")
        validator_req = ValidatorRequestModel.model_validate_json(message_body)
        await process_query_topics_validation(db_ops, validator_req)
    except Exception as e:
        logger.exception("Exception in query_topics_check_queue_trigger: %s", str(e))
    finally:
        logger.info("==== QUERY TOPICS CHECK QUEUE TRIGGER: END ====")

