# Introduction

As generative AI applications redefine industries, ensuring the safety, accuracy, and quality of AI-generated outputs has become a critical priority for organizations. Without proper oversight, AI responses can introduce risks such as harmful content, misinformation, or poor-quality results, undermining user trust and organizational credibility. **AITrust** delivers a robust, modular solution designed to enforce rigorous safety and quality standards across any stage of a generative AI pipeline, empowering developers to build trustworthy AI systems with confidence.

**AITrust** consists of two seamlessly integrated components: an SDK and a backend service. Together, they provide a flexible framework to intercept, validate, and refine AI-generated data—whether at the input, retrieval, or output phase—ensuring adherence to ethical, legal, and operational policies.

- **SDK (Client-Side)**: The SDK is a developer-friendly toolkit that integrates effortlessly into any generative AI application. It enables developers to define a validation pipeline through a customizable `guard_config` YAML file, which outlines pipeline stages (e.g., input, retrieval, output), assigns *guards* to each stage, and configures *validators*—specialized checks targeting issues like offensive language, hallucinations, or relevance. The SDK orchestrates the pipeline, packages data and configurations, and communicates with the backend service to execute validations. Upon receiving results, it aggregates them using defined strategies (e.g., PASS, BLOCK, or WARN) to determine the AI output’s final disposition.

- **Service (Backend)**: The backend service, built on a scalable, serverless architecture, executes the validation logic requested by the SDK. A defining feature of the service is its ability to dynamically integrate *validators*, which are developed as independent Python packages in a separate repository. These packages are installed into the service via `pip`, allowing the service to automatically discover and expose them as HTTP or event-based endpoints. This modular approach ensures validators can be developed, updated, or extended independently of the core system. Leveraging Azure Cosmos DB for result persistence and Azure Queue Storage for task scalability, the service delivers efficient, reliable validation, returning outcomes to the SDK for aggregation and decision-making.

The **AITrust** is treating the validators as standalone, pluggable components. Developed in a separate repository, these validators enable focused, agile development cycles. Once complete, they are packaged and installed into the service using `pip`, where the service dynamically builds and exposes their endpoints. This design decouples validator development from the core system, offering  flexibility.

The system’s adaptability is anchored by the `guard_config` YAML file, which acts as the validation pipeline’s blueprint. This configuration file allows developers to specify pipeline stages, link guards to validation rules, and select validators with customizable parameters (e.g., thresholds, execution modes). It also defines aggregation strategies to synthesize validator results into a cohesive decision, ensuring AI outputs align with organizational standards. A starter template simplifies onboarding, enabling developers to tailor stages and guards to their application’s unique needs.

Integrating **AITrust** into a generative AI application is straightforward: the app loads the `guard_config` YAML file, which the SDK uses to construct the validation pipeline and trigger the service’s execution of validators via their dynamically generated endpoints. This plug-and-play approach ensures that any generative AI system—be it a chatbot, content generator, or retrieval-augmented model—can adopt **AITrust** to enforce guardrails without disrupting its core functionality.

In essence, **AITrust** equips AXA teams to deploy generative AI responsibly and reliably. The SDK provides intuitive tools for pipeline configuration and orchestration, the service ensures scalable execution through dynamically integrated validator packages, and the `guard_config` YAML file delivers precision and control. By embedding safety and quality directly into the AI pipeline, **AITrust** safeguards users, enhances output reliability, and empowers businesses to innovate confidently in an AI-driven landscape.


---

# Getting Started

This section guides you through setting up the **AITrust Service** project on your own system, covering installation, dependencies, releases, and API references.

### 1. Installation Process

To run the project locally, follow these steps:

#### Prerequisites
- **Python 3.11+**
- **Azure Functions Core Tools**
- **uv**
- **Azure CLI**

#### Steps
1. **Clone the Repository**:
   ```bash
   git clone https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-FunctionApp
   ```

2. **Create a Virtual Environment**:
   ```bash
   uv venv
   ```
   **Note**: The virtual environment is created inside the `app` directory to keep the project self-contained and avoid conflicts with other projects.

3. **Activate the Virtual Environment**:
   - **macOS/Linux**:
     ```bash
     source .venv/bin/activate
     ```
   - **Windows**:
     ```bash
     .venv\\Scripts\\activate
     ```

4. **Sync Dependencies**:
   ```bash
   uv sync
   ```

5. **Configure Local Settings**:
   - Update `configs/settings.prod.yaml` and `configs/validators` yaml files with needed credentials and params (update also env variables in `app/local.settings.json` for development).

6. **Run the Function App Locally**:
   ```bash
   uv run func start --python --script-root app
   ```

7. **Test the Liveness Endpoint**:
   ```bash
   curl http://localhost:8080/health/liveness
   ```

### 2. Software Dependencies

The project relies on the following:
- **Python Packages**: Managed via `pyproject.toml`, including `azure-functions`, `pydantic`, and `pytest`.
- **Azure Services**:
  - **Azure Functions**: For serverless execution.
  - **Cosmos DB**: For storing execution data.
  - **Queue Storage**: For event-based validator processing.

Refer to `pyproject.toml` for a complete dependency list.

### 3. Latest Releases

The project adheres to semantic versioning. Visit the [Releases](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-FunctionApp/releases) page for the latest version, changelog, and upgrade instructions.

### 4. API References

Detailed API documentation is available in `docs/api.md`. The following endpoints are exposed by the Azure Functions app:

- **GET /health/liveness**: Checks if the service is alive (returns 204 No Content on success).
- **POST /pipeline**: Creates a new pipeline execution record in Cosmos DB.
- **GET /pipeline/{pipeline_execution_id}**: Retrieves a pipeline execution record by its ID.
- **POST /pipeline/{pipeline_execution_id}**: Updates an existing pipeline execution record.
- **GET /pipeline/{pipeline_execution_id}/validator/{validator_execution_id}**: Retrieves a specific validator execution record within a pipeline.
- **POST /validator/offensive**: Runs the offensive content validator synchronously and returns the result.
- **POST /validator/hallucination**: Enqueues a hallucination validation task for asynchronous processing (triggers `HallucinationCheckQueueTrigger`).
- **POST /validator/grammar**: Enqueues a grammar validation task for asynchronous processing (triggers `GrammarCheckQueueTrigger`).

**Note**: Asynchronous validators (`hallucination` and `grammar`) return a 202 Accepted response with the initial execution model, while the actual validation occurs via queue triggers.

---

# Build and Test

This section outlines how to prepare the project for execution and run tests to verify functionality and quality.

### Build the Project

The project uses `uv` for dependency management, follow these steps to prepare the environment:

1. **Sync Dependencies**:

   Add Validators package with a git url to the [tool.uv.sources] in pyproject.toml:
   ```toml
    [tool.uv.sources]
    ai-trust-validators = { git = "https://aasolutions.visualstudio.com/DefaultCollection/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators", branch = "develop" }
   
   ```
   This installs the dependencies specified in `pyproject.toml` into the virtual environment located in `app/.venv`, keeping the project isolated from other Python environments on your system.


2. **Sync Dependencies**:
   ```bash
   uv sync
   ```
   This installs the dependencies specified in `pyproject.toml` into the virtual environment located in `app/.venv`, keeping the project isolated from other Python environments on your system.


### Run Tests

Tests are located in the `tests/` directory, split into unit and integration categories.

1. **Activate the Virtual Environment** (if not already active).
2. **Run All Tests**:
   ```bash
   uv run pytest tests
   ```

## 🛠️ Integrating a New Validator

AITrust treats validators as fully-pluggable components. To add your own, follow these steps:

### 1. Implement the Service Module
Create a new file `libs/services/<validator_name>/<validator_name>_service.py` and define the core processing function:

```python
# libs/services/<validator_name>/<validator_name>_service.py

from datetime import datetime, timezone
from ai_trust_validators.validators.<validator_name> import <ValidatorName>
from libs.common.utils.pipeline_operations import update_pipeline_execution
from libs.models.validator import (
    ValidatorRequestModel,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum
)
from db_operations.cosmos_db import CosmosDbOperations
from libs.common.logs.logger import logger

async def process_<validator_name>_validation(
    db_ops: CosmosDbOperations,
    validator_req: ValidatorRequestModel
) -> None:
    # 1) Mark IN_PROGRESS
    in_progress = ValidatorExecutionModel(
        pipeline_execution_id=validator_req.pipeline_execution_id,
        validator_execution_id=validator_req.validator_execution_id,
        execution_status=ValidatorExecutionStatusEnum.IN_PROGRESS,
        request=validator_req,
        start_time=datetime.now(timezone.utc),
        last_update=datetime.now(timezone.utc)
    )
    await update_pipeline_execution(
        db_ops,
        pipeline=await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id)),
        validator_exec_update=in_progress
    )

    try:
        # 2) Execute the validator
        result = await <ValidatorName>(validator_req).validate()
    except Exception as exc:
        # 3a) On error
        error_exec = in_progress.model_copy(update={
            \"execution_status\": ValidatorExecutionStatusEnum.ERROR,
            \"error_message\": str(exc),
            \"end_time\": datetime.now(timezone.utc),
            \"last_update\": datetime.now(timezone.utc)
        })
        await update_pipeline_execution(
            db_ops,
            pipeline=await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id)),
            validator_exec_update=error_exec
        )
        logger.critical(
            \"Validator %s → ERROR: %s\",
            validator_req.validator_execution_id,
            exc,
            exc_info=True
        )
        return

    # 3b) On success
    final_exec = result.model_copy(update={
        \"pipeline_execution_id\": validator_req.pipeline_execution_id,
        \"validator_execution_id\": validator_req.validator_execution_id,
        \"last_update\": datetime.now(timezone.utc)
    })
    await update_pipeline_execution(
        db_ops,
        pipeline=await db_ops.pipeline_aget(str(validator_req.pipeline_execution_id)),
        validator_exec_update=final_exec
    )
    logger.info(
        \"Validator %s → %s\",
        validator_req.validator_execution_id,
        final_exec.execution_status.value
    )
```

### 2. Add the HTTP Trigger
In `function_app.py`, expose a POST endpoint that enqueues the task:

```python
@app.route(route=\"validator/<validator_name>\", methods=[func.HttpMethod.POST])
@app.queue_output(
    arg_name=\"jobQueue\",
    queue_name=CONFIG.settings.queues.validator_<validator_name>_queue_name,
    connection=\"AzureWebJobsStorage\"
)
@record_request_metrics(\"run_<validator_name>_validator\")
async def run_<validator_name>_validator(
    req: func.HttpRequest,
    jobQueue: func.Out[str]
) -> func.HttpResponse:
    # Validate payload
    body = json.loads(req.get_body())
    validator_req = ValidatorRequestModel.model_validate(body)
    # Mark IN_PROGRESS & enqueue
    jobQueue.set(validator_req.model_dump_json())
    return func.HttpResponse(
        status_code=202,
        body=validator_req.model_dump_json(),
        mimetype=\"application/json\"
    )
```

### 3. Define the Queue Trigger
Add the corresponding queue-trigger function:

```python
@app.function_name(\"<ValidatorName>CheckQueueTrigger\")
@app.queue_trigger(
    arg_name=\"msg\",
    queue_name=CONFIG.settings.queues.validator_<validator_name>_queue_name,
    connection=\"AzureWebJobsStorage\"
)
@record_queue_metrics(\"<validator_name>_check_queue_trigger\")
async def <validator_name>_check_queue_trigger(msg: func.QueueMessage) -> None:
    message_body = msg.get_body().decode(\"utf-8\")
    validator_req = ValidatorRequestModel.model_validate_json(message_body)
    await process_<validator_name>_validation(db_ops, validator_req)
```

### 4. Provision the Azure Queue
1. In Azure Storage, create a queue named e.g. `validator-<validator_name>-queue`.
2. In `configs/settings.prod.yaml` and `local.settings.json`, add:

```yaml
settings:
  queues:
    validator_<validator_name>_queue_name: \"validator-<validator_name>-queue\"
```

### 5. Extend the Pydantic Settings Model
In `libs/models/settings.py`, add:

```python
class QueuesModel(BaseModel):
    # … existing queues …
    validator_<validator_name>_queue_name: str
```

### 6. Wire into `guard_config.yaml`
Configure your validator in the pipeline blueprint:

```yaml
stages:
  - name: output
    guards:
      - name: <your_guard_name>
        validators:
          - name: <validator_name>
            settings:
              # custom parameters
```

### 7. Validate End-to-End

- **HTTP**: `POST /validator/<validator_name>` → `202 Accepted`.
- **Queue**: Verify message in Storage Queue and trigger invocation.
- **Cosmos DB**: Confirm pipeline stages transition through IN_PROGRESS → COMPLETED/ERROR.
- **Logs**: Inspect Application Insights for traces."

### 8. Add Integration Tests for Your Validator  

To ensure end-to-end correctness, add an integration test under `tests/integration_tests/validators/` and update your `conftest.py` pipeline fixtures.  

**8.1. Create the Test File**  
Create `tests/integration_tests/validators/test_<validator_name>_workflow.py` with content similar to:

```python
\"\"\"
Integration test for the <validator_name> validator workflow via the Function App API.
Verifies HTTP enqueue → queue trigger → status polling.
\"\"\"

import pytest
from uuid import uuid4, UUID
from datetime import datetime, timezone
import requests
import json
import asyncio

from libs.models.validator import (
    ValidatorRequestModel,
    UserPayloadModel,
    ContentTypeEnum,
    ValidatorMethodEnum,
    ValidatorExecutionStatusEnum,
    ValidatorResponseStatusEnum,
    ValidatorConfig
)

TERMINAL_STATUSES = {
    s.value for s in ValidatorExecutionStatusEnum
    if s not in (ValidatorExecutionStatusEnum.NOT_STARTED, ValidatorExecutionStatusEnum.IN_PROGRESS)
}
SUCCESS_STATUSES = {ValidatorExecutionStatusEnum.COMPLETED.value}

@pytest.mark.asyncio
async def test_<validator_name>_full_workflow(
    base_url: str,
    create_pipeline: tuple[UUID, dict[str, UUID]],
    poll_validator_status: callable
):
    pipeline_id, validator_ids = create_pipeline
    vid = validator_ids[\"<validator_key>\"]

    # Prepare request payload
    request_payload = ValidatorRequestModel(
        # ... fill in required fields ...
        pipeline_execution_id=pipeline_id,
        validator_execution_id=vid,
        # other fields ...
    )

    # 1) Enqueue
    resp = requests.post(
        f\"{base_url}/validator/<validator_endpoint>\",
        json=request_payload.model_dump(), timeout=30
    )
    assert resp.status_code == 202

    # 2) Wait for queue trigger
    await asyncio.sleep(1)

    # 3) Poll final status
    final = await poll_validator_status(
        pipeline_id=pipeline_id,
        validator_execution_id=vid,
        timeout=20,
        interval=1
    )
    status = final.get(\"execution_status\")
    assert status in TERMINAL_STATUSES
    assert status in SUCCESS_STATUSES

    # 4) Verify verdict
    verdict = final.get(\"response\", {}).get(\"status\")
    assert verdict in {
        ValidatorResponseStatusEnum.PASSED.value,
        ValidatorResponseStatusEnum.FAILED.value
    }
```  

**8.2. Update `conftest.py`**  
In your `tests/conftest.py`, ensure `generic_validator_configs` and `valid_pipeline_payload_and_ids` include your new validator key and endpoint:  

```python
# in generic_validator_configs fixture:
\"<validator_key>\": ValidatorConfig(
    name=\"<ValidatorName>\",
    validator_type=ValidatorTypeEnum.EVENT_BASED.value,
    parameters={ /* ... */ },
    endpoint_url=\"/validator/<validator_endpoint>\",
    priority=\"p1\"
),

# in valid_pipeline_payload_and_ids fixture:
validator_execution_ids = { **existing_ids, \"<validator_key>\": uuid4() }
# and include that key in the guards_config mapping for the appropriate stage.
```  

With this in place, running:

```bash
uv run pytest tests/integration_tests/validators
```

will verify your new validator’s HTTP → queue → processing → final status workflow."  


---

# Contribute

We encourage contributions to improve the **AITrust Service** project, whether through bug fixes, code optimisation, or documentation enhancements.

### How to Contribute

1. **clone the Repository**: clone a local copy of the project.
2. **Create a Feature Branch**: Use a descriptive name (e.g., `feature/new-validator`).
3. **Commit Changes**: Follow conventional commit messages (e.g., `feat: add grammar validator documentation`).
4. **Run Tests**: Ensure all tests pass.
5. **Submit a Pull Request**: Include a clear description of your changes.

For detailed guidelines, see [CONTRIBUTING.md](./CONTRIBUTING.md).

---

# Structure & Concepts Diagrams

Visualize the system structure and interactions with these diagrams:

- **High-level Structure**:  
  ![Workflow Diagram](docs/figures/Service-structure.png)

- **Component Interaction**:  
  ![Component Interaction Diagram](docs/figures/Service-concepts.png)

