"""
Service validator models.

These models define the configuration and execution details for validators within the service.
They are designed to be consistent with the SDK's validator models where applicable,
especially the BaseValidatorConfig, while remaining focused on the service's needs.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import UUID, uuid4

from guardrails.validator_base import FailResult, PassResult  # type: ignore
from pydantic import BaseModel, ConfigDict, Field, SecretStr


class ContentTypeEnum(str, Enum):
  """
  Enumeration of input content type.
  ContentTypeEnum to ensure type consistency.
  """
  TEXT = "text"
  LIST = "list"
  DICT = "dict"


class ValidatorTypeEnum(str, Enum):
  """
  Enumeration of validator types within the service.
  Mirrors the SDK's ValidatorTypeEnum to ensure type consistency.
  """

  HTTP_BASED = "http_based"
  EVENT_BASED = "event_based"


class ValidatorPriorityEnum(str, Enum):  # Not used in Service core logic, but kept for potential extensions
  """
  Enumeration for validator priority levels (not directly used in service core logic).
  Kept for potential future service-side features or extensions that might utilize priority.
  """

  P1 = "p1"
  P2 = "p2"
  P3 = "p3"


class ValidatorMethodEnum(str, Enum):
  """
  Validation method for validator within the service.
  Mirrors the SDK's ValidatorMethodEnum for consistency.
  """

  ML = "ml"
  LLM = "llm"
  REGEX = "regex"


class ValidatorExecutionStatusEnum(str, Enum):
    """
    Enumeration of validator execution statuses within the service.
    Mirrors the SDK's ValidatorStatusEnum to ensure status consistency across components.
    """
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    PARAMS_ERROR = "params_error"
    ERROR = "error"
    STOPPED = "stopped"

class ValidatorResponseStatusEnum(str, Enum):
    """
    Enumeration of validator execution statuses within the service.
    Mirrors the SDK's ValidatorStatusEnum to ensure status consistency across components.
    """

    SYS_ERROR = "system_error"
    SECUREGPT_ERROR = "securegpt_error"
    PARAMS_ERROR = "params_error"
    FAILED = "fail"
    BLOCK = "block"
    PASS = "pass"
    WARN = "warn"


class BaseValidatorConfig(BaseModel):  # BaseValidatorConfig mirrored from SDK for shared model
  """
  Base Configuration model for a validator (shared between SDK and Service).
  This model is a direct mirror of the SDK's BaseValidatorConfig, ensuring
  that the core validator configuration attributes are consistent across both components.
  """

  model_config = ConfigDict(from_attributes=True, validate_assignment=True)
  name: str = Field(..., max_length=100, description="Name of the validator.")
  validator_type: ValidatorTypeEnum = Field(..., description="Type of the validator (HTTP_BASED or EVENT_BASED).")
  parameters: dict[str, Any] | None = Field(
    None, description="Optional parameters to configure the validator's behavior."
  )


class ValidatorConfig(BaseValidatorConfig):  # Service ValidatorConfig now extends BaseValidatorConfig
  """
  Service Configuration model for a validator.
  Extends BaseValidatorConfig for service-specific use. Currently, it doesn't add
  any service-specific fields, but it's structured to allow for future extensions
  if the service needs to store or manage additional validator-specific data.
  """
  endpoint_url: str | None = Field(None, description="URL of the validator service endpoint. Used by the SDK to call the validator service.")
  priority: ValidatorPriorityEnum | None = Field(None, description="Priority level of the validator within a guard. Used for SDK-side orchestration.")


class UserPayloadModel(BaseModel):
  """
  User payload model for validator execution within the service.
  Mirrors the SDK's UserPayloadModel, representing the input data for validation.
  """

  model_config = ConfigDict(validate_assignment=True)
  content_type: ContentTypeEnum = Field(default=ContentTypeEnum.TEXT, description="Content type of the user payload.")
  value: str = Field(default=None, min_length=1, description="Value of content to validate.")
  value: str = Field(default=None, min_length=1, description="Value of content to validate.")
  metadata: dict = Field(default={}, description="Metadata for content validation.")
  method: ValidatorMethodEnum = Field(
    default=ValidatorMethodEnum.LLM, description="Validation method used by a runner."
  )


class ValidatorRequestModel(BaseModel):
  """
  Request model for validator execution within the service.
  Mirrors the SDK's ValidatorRequestModel, defining the expected request structure
  for validator endpoints in the service.
  """

  model_config = ConfigDict(from_attributes=True, validate_assignment=True)
  validation_method: ValidatorMethodEnum = Field(
    default=ValidatorMethodEnum.LLM, frozen=True, description="Validation method use by the validator."
  )
  project_name: str | None = Field(..., description="Current Project name (for each use case. eg: TGE)")
  scope: str | None = Field(default="PROD", description="Current scope ( eg: DEV, PROD)")
  country_name: str | None = Field(default="France", description="Current country ( eg: France)")
  partner_name: str | None = Field(default="PUFFIN", description="Current partner name ( eg: PUFFIN)")
  request_id: UUID | None = Field(..., description="Unique identifier for the validation request.")
  pipeline_execution_id: UUID | None = Field(default=None, description="Unique identifier for the pipeline execution.")
  securegpt_token: SecretStr | None = Field(default=None, description="SecretStr for validator")
  conversation_id: UUID | None = Field(default=None, description="Unique identifier for the conversion.")
  validator_execution_id: UUID = Field(
    default_factory=uuid4, frozen=True, description="Unique identifier for the validator execution."
  )
  user_payload: UserPayloadModel | None = Field(description="User Input data for validation.")
  # move this to validator request
  validator_config: ValidatorConfig = Field(
    ..., description="Validator configuration used for this execution. Uses Service ValidatorConfig."
  )  # Using Service ValidatorConfig
  config_parameters: dict[str, Any] = Field(default_factory=dict, description="Additional configuration parameters.")
  created_at: datetime = Field(default_factory=datetime.now)


class ValidatorResponseModel(BaseModel):
  """
  Response model for validator execution within the service.
  Mirrors the SDK's ValidatorResponseModel, defining the structure of responses
  returned by validator services.
  """

  model_config = ConfigDict(from_attributes=True, validate_assignment=True)
  status: ValidatorResponseStatusEnum = Field(..., description="Validation result status.")
  have_fix: bool = Field(default=False, description="Check if validator have fix")
  details: dict[str, Any] | FailResult | PassResult = Field(
    default_factory=dict, description="Detailed results of the validation."
  )
  error_message: str | None = Field(None, description="Error message if validation failed.")
  created_at: datetime = Field(default_factory=datetime.now)


class ValidatorExecutionModel(BaseModel):
  """
  Represents the execution result of a validator within the service.
  Mirrors the SDK's ValidatorExecutionModel, tracking the execution state
  and outcome of a validator within the service context.
  """

  model_config = ConfigDict(from_attributes=True, validate_assignment=True)
  pipeline_execution_id: UUID = Field(default_factory=uuid4, description="Unique pipeline identifier.", frozen=False)
  validator_execution_id: UUID = Field(
    default_factory=uuid4, description="Unique identifier for the validator execution."
  )
  execution_status: ValidatorExecutionStatusEnum = Field(
    default=ValidatorExecutionStatusEnum.NOT_STARTED, description="Current execution status."
  )
  request: ValidatorRequestModel | None = Field(None, description="The request sent to the validator service.")
  response: ValidatorResponseModel | None = Field(None, description="The response received from the validator service.")
  error_message: str | None = Field(None, description="Error message if execution failed.")
  start_time: datetime | None = Field(None, description="Timestamp when execution started.")
  end_time: datetime | None = Field(None, description="Timestamp when execution ended.")
  last_update: datetime = Field(default_factory=datetime.now, description="Timestamp of the last update.")

  def is_event_based(self) -> bool:
    """
    Determines if the validator is event-based.
    Mirrors the SDK's method for consistency.

    Returns:
        bool: True if the validator type is EVENT_BASED; otherwise, False.
    """
    return self.validator_config.validator_type == ValidatorTypeEnum.EVENT_BASED


# Alias model for validator definitions. This ensures that any import referencing
# ValidatorDefinitionModel will succeed and correctly points to the Service's ValidatorConfig.
class ValidatorDefinitionModel(ValidatorConfig):  # ValidatorDefinitionModel now an alias for Service ValidatorConfig
  """
  Alias for ValidatorConfig, representing the definition of a validator within the service.
  Ensures that ValidatorDefinitionModel references the Service's ValidatorConfig,
  maintaining clarity and avoiding confusion with SDK-specific configurations.
  """

  pass
