from enum import Enum

from pydantic import BaseModel, Field, SecretStr


class ZoneEnums(str, Enum):
    user_input: str = "UserInput"
    search_input: str = "SearchInput"
    search_output: str = "SearchOutput"
    llm_input: str = "LlmInput"
    llm_output: str = "LlmOutput"
    prompt_input: str = "PromptInput"
    prompt_output: str = "PromptOutput"

class HttpTimeouts(BaseModel, frozen=True):
    total_seconds: int = Field(default=1.5)
    connect_seconds: int = Field(default=1.5)

class HttpRetryConfig(BaseModel, frozen=True):
    max_attempts: int = Field(default=5, description="Number of retry attempts")
    min_wait: int = Field(default=2, description="Minimum wait time in seconds")
    max_wait: int = Field(default=10, description="Maximum wait time in seconds")
    max_backoff_multiplier: int = Field(default=1, description="Initial wait time in seconds")

class WaitExponentialModel(BaseModel, frozen=True):
    multiplier: int = Field(default=1, description="Initial wait time in seconds")
    min_wait: int = Field(default=2, description="Minimum wait time in seconds")
    max_wait: int = Field(default=10, description="Maximum wait time in seconds")

class TenacityModel(BaseModel, frozen=True):
    stop_after_attempts: int = Field(default=5, description="Number of retry attempts")
    stop_after_delay: int = Field(default=5, description="Stop after certain time of delay")
    wait_exponential: WaitExponentialModel = Field(default=WaitExponentialModel())

class HttpSettingsModel(BaseModel, frozen=True):
    timeouts: HttpTimeouts = Field(default=HttpTimeouts())
    pool_limit_per_host: int = Field(default=5)
    trust_env: bool = Field(default=False)

class LlmConnexionModel(BaseModel, frozen=True):
    grant_type: SecretStr
    client_id: SecretStr
    client_secret: SecretStr
    one_login_base_url: SecretStr
    one_login_url: SecretStr
    api_base_url: SecretStr
    deployment_id: str
    api_version: str
    provider_name: str
    api_type: str
    scope: str = Field(
        default="urn:grp:chatgpt",
        min_length=5,
    )

class LlmParametersModel(BaseModel):
    max_tokens: int = Field(description="")
    temperature: float = Field(description="")
    top_p: float = Field(description="")
    api_timeout: float = Field(description="")

class PromptsModel(BaseModel, frozen=True):
    system: str
    user: str

class LlmModel(BaseModel, frozen=True):
    connexion: LlmConnexionModel
    parameters: LlmParametersModel | None = Field(default=None)
    prompts: PromptsModel | None = Field(default=None)

class ComosDbModel(BaseModel, frozen=True):
    api_key: SecretStr
    container: str = Field(description="")
    database_name: str = Field(description="")
    endpoint: str = Field(description="")

class UsageModel(BaseModel, frozen=True):
    constraint: list[ZoneEnums | None]
    input_format: dict | None = Field(default={})
    output_format: dict | None = Field(default={})

class RepositoriesModel(BaseModel, frozen=True):
    type: str = Field(description="")
    name: str = Field(description="")
    url: str = Field(description="")

class DependenciesModel(BaseModel, frozen=True):
    llm: LlmModel
    aiohttp: HttpSettingsModel = Field(default=HttpSettingsModel())
    tenacity: TenacityModel = Field(default=TenacityModel())

class SettingsModel(BaseModel, frozen=True):
    usage: UsageModel
    repositories: list[RepositoriesModel]
    dependencies: DependenciesModel
