import difflib
from functools import WRAPPER_ASSIGNMENTS, wraps
from os import environ
from pathlib import Path
from re import IGNORECASE
from re import compile as re_compile

# Remove HTML tags
html_compiler = re_compile(r"<.*?>")
script_compiler = re_compile(r"(script|iframe|on\w+)", flags=IGNORECASE)
# Adjusted to keep certain punctuation and characters
caracter_compiler = re_compile(r'[^a-zA-Z0-9\s.,?!\'"-=]')

# Regex to detect common command injection patterns in user input
bash_command_compiler = re_compile(r"(\b(?:;|&&|\|\||`|>|<|\$)\b)", flags=IGNORECASE)


def default_env():
    """Get default environment

    Returns:
        str: value of ENV environ
    """
    if environ.get("ENV"):
        return environ["ENV"]
    else:
        return "dev"


def ignore_unhashable(func):
    """Ignore unhashable data

    Args:
      func (function): input function

    Returns:
      wrapper: output function
    """
    uncached = func.__wrapped__
    attributes = WRAPPER_ASSIGNMENTS + ("cache_info", "cache_clear")

    @wraps(func, assigned=attributes)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except TypeError as error:
            if "unhashable type" in str(error):
                return uncached(*args, **kwargs)
            raise

    wrapper.__uncached__ = uncached
    return wrapper


def sanitize_input(user_input) -> str:
    """
    Sanitizes the provided user input by removing unwanted HTML tags and scripts.

      This method uses regular expressions to filter out HTML tags, script elements,
      specific unwanted special characters, and common Bash command patterns.

      Parameters:
          user_input (str): The input string provided by the user that needs to be sanitized.

    Returns:
        str: The sanitized input string with special characters removed.
    """
    # Remove HTML tags
    sanitized_input = html_compiler.sub("", user_input)
    # Remove any scripts
    if "<" in sanitized_input or ">" in sanitized_input:
        sanitized_input = script_compiler.sub("", sanitized_input)
    # Remove any disallowed special characters but keep specific ones
    sanitized_input = caracter_compiler.sub("", sanitized_input)

    # Remove common Bash command injection patterns
    sanitized_input = bash_command_compiler.sub("", sanitized_input)

    # Strip leading and trailing whitespace
    sanitized_input = sanitized_input.strip()

    return sanitized_input


def find_base_path(file_name: Path | str = "pyproject.toml") -> Path:
    """Searches for the base path of the project based on the presence of a unique file.

    Args:
        file_name (Path | str, optional): The name of the file to search for.
        Defaults to "pyproject.toml".

    Returns:
        Path | None: The base path of the project, or None if not found.
    """

    current_path = Path(__file__).resolve().parent
    # Stop when reaching the root directory
    while current_path != current_path.parent:
        if (current_path / file_name).is_file():
            return current_path
        current_path = current_path.parent

    return current_path


def is_greeting(value: str) -> bool:
    """Check if the input value is a greeting in any language, handling errors in writing and abbreviations."""
    greetings = {
        "en": ["hello", "hi", "good morning", "good evening", "good night"],  # English
        "es": ["hola", "buenos días", "buenas tardes", "buenas noches"],  # Spanish
        "fr": ["bonjour", "salut", "bonsoir", "bonne nuit"],  # French
        "de": ["hallo", "guten Morgen", "guten Abend", "gute Nacht"],  # German
        "it": ["ciao", "buongiorno", "buonasera", "buonanotte"],  # Italian
        "pt": ["olá", "bom dia", "boa tarde", "boa noite"],  # Portuguese
        "ar": ["مرحبا", "السلام عليكم", "صباح الخير", "مساء الخير", "تصبح على خير"],  # Arabic
        "zh": ["你好", "早上好", "下午好", "晚上好"],  # Chinese (Simplified)
        "ja": ["こんにちは", "おはようございます", "こんばんは", "おやすみなさい"],  # Japanese
        "ff": ["jaaraama", "bisimillah", "barka da zuwa"],  # Pular
        "ha": ["sannu", "barka da safiya", "barka da yamma", "barka da dare"],  # Hausa
        "ew": ["mboa", "nɔ́ŋ", "mɔ́bɔ"],  # Ewondo
        "ru": ["привет", "здравствуй", "доброе утро", "добрый вечер", "спокойной ночи"],  # Russian
        "ko": ["안녕하세요", "좋은 아침입니다", "좋은 저녁입니다", "안녕히 주무세요"],  # Korean
        "wo": ["jaam nga am", "nanga def", "ba beneen yoon"],  # Wolof
        "la": ["salve", "bonum mane", "bonum vesperum", "bonam noctem"],  # Latin
        "rm": ["bun di", "buna saira", "buna notg"],  # Romansh
        "nl": ["hallo", "goede morgen", "goede avond", "goede nacht"],  # Dutch (Neerlandais)
    }

    # Normalize the input value for comparison
    normalized_value = value.strip().lower()
    # Check if the normalized value is in any of the greeting lists
    for lang, greeting_list in greetings.items():
        if normalized_value in greeting_list:
            return True

    # If no exact match, use fuzzy matching to allow for small errors
    for lang, greeting_list in greetings.items():
        # Find close matches using difflib
        close_matches = difflib.get_close_matches(normalized_value, greeting_list, n=1, cutoff=0.8)
        if close_matches:
            return True

    # If no matches found, return False
    return False
