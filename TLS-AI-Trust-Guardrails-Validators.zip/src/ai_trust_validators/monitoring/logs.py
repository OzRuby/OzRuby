import logging

from opencensus.ext.azure.log_exporter import AzureLogHandler
from opencensus.trace import config_integration
#from opencensus.trace.samplers import AlwaysOnSampler
#from opencensus.trace.tracer import Tracer


def init_logging(CONFIG):
   # Configure OpenCensus to integrate with logging
  config_integration.trace_integrations(["logging"])

  # Set up logging format
  logging_format = "%(asctime)s | %(levelname)s | %(message)s"
  logging.basicConfig(format=logging_format, level=logging.INFO) 
  
  logger = logging.getLogger(CONFIG.monitoring.logging.logger_name)
  

  logger.setLevel(logging.INFO)
  # Clear existing handlers to prevent duplicate logs
  if logger.hasHandlers():
      logger.handlers.clear()
  
  # Create a console handler and set level to INFO
  console_handler = logging.StreamHandler()
  console_handler.setLevel(logging.INFO)
  console_handler.setFormatter(logging.Formatter(logging_format))
  # Adding Azure Log Handler
  azure_handler = AzureLogHandler()
  
  # Add handlers to logger
  logger.addHandler(console_handler)
  logger.addHandler(azure_handler)

  return logger
