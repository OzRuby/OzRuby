from enum import Enum
from os import environ

# Copied from https://github.com/microsoft/call-center-ai/blob/main/app/helpers/monitoring.py
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import metrics, trace
from opentelemetry.instrumentation.aiohttp_client import (
  AioHttpClientInstrumentor,
)
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.metrics._internal.instrument import Counter, Gauge, Histogram
from opentelemetry.semconv.attributes import service_attributes
from opentelemetry.trace.span import INVALID_SPAN
from opentelemetry.util.types import AttributeValue
from structlog.contextvars import bind_contextvars, get_contextvars

MODULE_NAME = "aitrust.validators"
VERSION = environ.get("VERSION", "0.1.0")


class SpanAttributeEnum(str, Enum):
  """
  OpenTelemetry attributes.

  These attributes are used to track a validator execution in the logs and metrics.
  """

  CONVERSATION_ID = "aitrust.validator.conversation.id"
  """Technical Conversational id: UUID4 """
  VALIDATOR_NAME = "aitrust.validator.name"
  """Validator Executor identifier: UUID4"""
  VALIDATOR_EXECUTION_ID = "aitrust.validator.validator_execution.id"
  """Validator Executor identifier: UUID4"""
  PIPELINE_EXECUTION_ID = "aitrust.validator.pipeline_execution.id"
  """Pipeline Executor identifier: UUID4 """
  REQUEST_ID = "aitrust.validator.request.id"
  """Request identifier: UUID4 """
  VALIDATION_METHOD = "aitrust.validator.validation_method"
  """Validation method: llm, ml, regex"""
  PROJECT_NAME = "aitrust.project.name"
  """Technical project name: str"""
  PROJECT_SCOPE = "project.scope"
  """Project scope: str"""
  PARTNER_NAME = "aitrust.partner.name"
  """Partner name: str"""
  COUNTRY_NAME = "aitrust.country.name"
  """Country name: str"""

  def attribute(
    self,
    value: AttributeValue,
  ) -> None:
    """
    Set an attribute on the current span.
    """
    # Enrich logging
    bind_contextvars(**{self.value: value})

    # Enrich span
    span = trace.get_current_span()
    if span == INVALID_SPAN:
      return
    span.set_attribute(self.value, value)


class SpanValidatorMeterEnum(str, Enum):
  # Frames metrics
  VALIDATOR_CALL = "validator.call"
  """Validator call frames."""
  VALIDATOR_PASSRESULT = "validator.result.pass"
  """Validator pass result frames"""
  VALIDATOR_FAILRESULT = "validator.result.fail"
  """Validator fail result frames"""
  VALIDATOR_MAKEFIX = "validator.result.fix"
  """Validator fix result frames"""
  VALIDATOR_CONFIG_ERROR = "validator.config.error"
  """Validator config error result frames"""
  VALIDATOR_LLM_RESPONSE_FORMAT_ERROR = "validator.llm.secure_gpt.response_format.error"
  """Validator Secure GPT error result frames"""
  VALIDATOR_LLM_EXECUTION_ERROR = "validator.llm.secure_gpt.execution.error"
  """Validator Secure GPT error result frames"""
  VALIDATOR_EXCEPTION = "validator.exception"
  """Validator exception result frames"""
  # Latency metrics
  VALIDATOR_EXECUTION_LATENCY = "validator.execution.latency"
  """Validator execution latency in seconds"""
  SECUREGPT_LATENCY = "validator.llm.secure_gpt.latency"
  """SecureGpt latency in seconds."""
  ML_LATENCY = "validator.ml.latency"
  """ML latency in seconds."""
  REGEX_LATENCY = "validator.regex.latency"
  """Regex latency in seconds."""
  # Business metrics
  VALIDATOR_LLM_INPUT_TOKEN = "validator.llm.secure_gpt.input_token"
  """SecureGPT result input token frames"""
  VALIDATOR_LLM_OUTPUT_TOKEN = "validator.llm.secure_gpt.output_token"
  """SecureGPT result output token frames"""

  def counter(
    self,
    unit: str,
  ) -> Counter:
    """
    Create a counter metric to track a span counter.
    """
    return meter.create_counter(
      description=self.__doc__ or "",
      name=self.value,
      unit=unit,
    )

  def gauge(
    self,
    unit: str,
  ) -> Gauge:
    """
    Create a gauge metric to track a span counter.
    """
    return meter.create_gauge(description=self.__doc__ or "", name=self.value, unit=unit)

  def histogram(
    self,
    unit: str,
  ) -> Histogram:
    """
    Create a histogram metric to track a span counter.
    """
    return meter.create_histogram(description=self.__doc__ or "", name=self.value, unit=unit)


try:
  configure_azure_monitor()  # Configure Azure Application Insights exporter
  AioHttpClientInstrumentor().instrument()  # Instrument aiohttp
  HTTPXClientInstrumentor().instrument()  # Instrument httpx
except ValueError as e:
  print(  # noqa: T201
    "Azure Application Insights instrumentation failed,",
    "likely due to a missing APPLICATIONINSIGHTS_CONNECTION_STRING",
    " environment variable.",
    e,
  )

# Attributes
_default_attributes = {
  service_attributes.SERVICE_NAME: MODULE_NAME,
  service_attributes.SERVICE_VERSION: VERSION,
}

# Create a tracer and meter that will be used across the application
tracer = trace.get_tracer(
  attributes=_default_attributes,
  instrumenting_module_name=MODULE_NAME,
)
meter = metrics.get_meter(
  name=MODULE_NAME,
)

# Init validator latency metrics
g_validator_execution_latency = SpanValidatorMeterEnum.VALIDATOR_EXECUTION_LATENCY.gauge("s")
g_securegpt_latency = SpanValidatorMeterEnum.SECUREGPT_LATENCY.gauge("s")
g_ml_latency = SpanValidatorMeterEnum.ML_LATENCY.gauge("s")
g_regex_latency = SpanValidatorMeterEnum.REGEX_LATENCY.gauge("s")
h_validator_execution_latency = SpanValidatorMeterEnum.VALIDATOR_EXECUTION_LATENCY.histogram("s")
h_securegpt_latency = SpanValidatorMeterEnum.SECUREGPT_LATENCY.histogram("s")
h_ml_latency = SpanValidatorMeterEnum.ML_LATENCY.histogram("s")
h_regex_latency = SpanValidatorMeterEnum.REGEX_LATENCY.histogram("s")
# Init validator frames metrics
validator_config_error = SpanValidatorMeterEnum.VALIDATOR_CONFIG_ERROR.counter("frames")
validator_call = SpanValidatorMeterEnum.VALIDATOR_CALL.counter("frames")
validator_llm_response_format_error = SpanValidatorMeterEnum.VALIDATOR_LLM_RESPONSE_FORMAT_ERROR.counter("frames")
validator_llm_execution_error = SpanValidatorMeterEnum.VALIDATOR_LLM_EXECUTION_ERROR.counter("frames")
validator_passresult = SpanValidatorMeterEnum.VALIDATOR_PASSRESULT.counter("frames")
validator_failresult = SpanValidatorMeterEnum.VALIDATOR_FAILRESULT.counter("frames")
validator_makefix = SpanValidatorMeterEnum.VALIDATOR_MAKEFIX.counter("frames")
validator_exception = SpanValidatorMeterEnum.VALIDATOR_EXCEPTION.counter("frames")
validator_llm_input_token = SpanValidatorMeterEnum.VALIDATOR_LLM_INPUT_TOKEN.counter("frames")
validator_llm_output_token = SpanValidatorMeterEnum.VALIDATOR_LLM_OUTPUT_TOKEN.counter("frames")


def gauge_set(
  metric: Gauge,
  value: float | int,
):
  """
  Set a gauge metric value with context attributes.
  """
  metric.set(
    amount=value,
    attributes={
      # First, set default attributes
      **_default_attributes,
      # Then, set context attributes, they can override default attributes
      **get_contextvars(),
    },
  )


def histogram_record(
  metric: Histogram,
  value: float | int,
):
  """
  Set a histogram metric value with context attributes.
  """
  metric.record(
    amount=value,
    attributes={
      # First, set default attributes
      **_default_attributes,
      # Then, set context attributes, they can override default attributes
      **get_contextvars(),
    },
  )


def counter_add(
  metric: Counter,
  value: float | int,
):
  """
  Add a counter metric value with context attributes.
  """
  metric.add(
    amount=value,
    attributes={
      # First, set default attributes
      **_default_attributes,
      # Then, set context attributes, they can override default attributes
      **get_contextvars(),
    },
  )
