import json
import time  # Importing the time module for measuring execution time
from collections.abc import Callable
from datetime import UTC, datetime
from functools import lru_cache
from typing import Any

from guardrails.validators import (
    FailResult,
    PassResult,
    Validator,
    register_validator,
)
from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import ValidationError

from ai_trust_validators.base_validator import AiTrustValidatorBase
from ai_trust_validators.monitoring.telemetry import (
    SpanAttributeEnum,
    counter_add,
    # g_securegpt_latency,
    # g_validator_execution_latency,
    # gauge_set,
    h_securegpt_latency,
    h_validator_execution_latency,
    histogram_record,
    tracer,
    validator_call,
    validator_exception,
    validator_failresult,
    validator_llm_execution_error,
    validator_llm_input_token,
    validator_llm_output_token,
    validator_llm_response_format_error,
    validator_makefix,
    validator_passresult,
)
from ai_trust_validators.secure_gpt_langchain.v2.secure_gpt import SecureGPT
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorMethodEnum,
    ValidatorRequestModel,
    ValidatorResponseModel,
    ValidatorResponseStatusEnum,
)
from ai_trust_validators.utils import ignore_unhashable, is_greeting, sanitize_input

from ...src import init_logging
from ..models.input_output import LlmOutputModel, ValidateMetadataModel
from ..utils.config import CONFIG

logger = init_logging(CONFIG)


@register_validator(name="aitrust/calculation_logic", data_type="string")
class CalculationLogic(Validator, AiTrustValidatorBase):
    """A validator class for assess the calculation logic of an LLM.

    This class utilizes  LLM (Language Model) validate the calculation logic for a given output.
    It logs the validation process and maintains detailed execution information.

    Parameters:
        request_params (ValidatorRequestModel): Validator parameters
        on_fail (Optional[Callable]): Callback function to invoke on failure.
        **kwargs: Additional keyword arguments for the base class.
    """

    def __init__(
        self, request_params: ValidatorRequestModel, on_fail: Callable | None = None, **kwargs
    ):
        """
        Initializes the CalculationLogic validator validator.

        Parameters:
            validation_method (str): The validation method to use (default is 'llm').
            on_fail (Optional[Callable]): Callback function to invoke on failure.
            **kwargs: Additional keyword arguments for the base class.
        """
        super().__init__(
            on_fail=on_fail, validation_method=request_params.validation_method, **kwargs
        )

        self._validation_method = request_params.validation_method
        if self.use_local:
            self._model = ""  # type: ignore
        self.validator_request = request_params

        self.properties = {
            "custom_dimensions": {
                "validator": CONFIG.informations.name,
                "project_name": request_params.project_name,
                "conversation_id": request_params.conversation_id,
                "logging.scope": CONFIG.monitoring.logging.scope,
                "request_id": request_params.request_id,
                "validation_method": request_params.validation_method,
                "validator_execution_id": request_params.validator_execution_id,
                "pipeline_execution_id": request_params.pipeline_execution_id,
                "country_name": request_params.country_name,
                "partner_name": request_params.partner_name,
            }
        }

        self.validator_execution = None
        self.execution_status = ValidatorExecutionStatusEnum.NOT_STARTED
        self.validator_config = ValidatorConfig(
            name=CONFIG.informations.name,
            validator_type="event_based",
            endpoint_url="validator/calculation_logic",
        )
        logger.info(" Validation initialization")
        # logging attributes: AppInsights
        SpanAttributeEnum.VALIDATOR_NAME.attribute(CONFIG.informations.name)
        SpanAttributeEnum.CONVERSATION_ID.attribute(str(request_params.conversation_id))
        SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(str(request_params.pipeline_execution_id))
        SpanAttributeEnum.VALIDATION_METHOD.attribute(request_params.validation_method)
        SpanAttributeEnum.REQUEST_ID.attribute(str(request_params.request_id))
        SpanAttributeEnum.VALIDATOR_EXECUTION_ID.attribute(
            str(request_params.validator_execution_id)
        )
        SpanAttributeEnum.PROJECT_NAME.attribute(request_params.project_name)
        SpanAttributeEnum.PROJECT_SCOPE.attribute(CONFIG.monitoring.logging.scope)
        SpanAttributeEnum.PARTNER_NAME.attribute(request_params.partner_name)
        SpanAttributeEnum.COUNTRY_NAME.attribute(request_params.country_name)

    @tracer.start_as_current_span("run_system_prompt_template")
    def _system_prompt_template(self):
        """Get system from config

        Returns:
            str: system prompt
        """
        sys_prompt = CONFIG.settings.dependencies.llm.prompts.system
        logger.info(f" | LLM | Getting system prompt: {sys_prompt}")
        return sys_prompt

    @tracer.start_as_current_span("run_user_prompt_template")
    def _user_prompt_template(self, user_query, chunks, answer):
        """Get user prompt from config

        Args:
            user_query (str): input text from user
            chunks (str): A list of text chunks relevant to the query.
            answer (str): The answer provided by an LLM.

        Returns:
            str: prompt template formatted
        """
        template = CONFIG.settings.dependencies.llm.prompts.user.format(
            user_query=user_query, chunks=chunks, answer=answer
        )
        logger.info(f" | LLM | Getting user prompt: {template}", extra=self.properties)
        return template

    @tracer.start_as_current_span("run_generate_verification_prompt")
    def generate_verification_prompt(self, answer: str, user_query: str, chunks: list[str]) -> str:
        """
        Constructs a prompt for the language model to assess the relevancy of the answer
        with respect to the user query and chunks.

        Parameters:
            answer (str): The answer provided by an LLM.
            user_query (str): The user query that the answer is intended to address.
            chunks (List[str]) : A list of text chunks relevant to the query.

        Returns:
            str: A formatted prompt for the LLM to analyze the relevancy of the answer.
        """
        logger.debug("Generating verification prompt for provided answer", extra=self.properties)

        # Joining content chunks into a single string for better readability
        chunks_formatted = "\n".join(f"- {chunk}" for chunk in chunks)

        prompt = [
            # build system prompt
            SystemMessage(content=self._system_prompt_template()),
            # build user prompt
            HumanMessage(content=self._user_prompt_template(user_query, chunks_formatted, answer)),
        ]
        return prompt

    @tracer.start_as_current_span("run_format_response")
    def _format_response(self, response, metadata):
        """Format final response

        Args:
            response (dict): result for service execution
            metadata (dict): metadata of input request

        Returns:
            FailResult|PassResult: result for validator
        """
        pass

    @tracer.start_as_current_span("run_apply_validator_execution")
    def _apply_validator_execution(self, results, metadata):
        """Validator formatting

        Args:
            results (FailResult|PassResult): result type from execution
            metadata (dict): metadata of input request

        Returns:
            ValidatorExecutionModel: model result for validation
        """
        pass

    @tracer.start_as_current_span("run_validate_with_corpus_process")
    def _validate_with_corpus(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with corpus service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from corpus service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                f"The Corpus validation process is not implemented yet\n\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        )

    @tracer.start_as_current_span("run_validate_with_ml_process")
    def _validate_with_ml(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with ml service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from ml service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                f"The ML validation process is not implemented yet\n\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        )

    # Function to get the answer from the metadata
    @tracer.start_as_current_span("run_get_answer")
    def get_answer(self, metadata: dict) -> str:
        """
        Retrieve the answer from the metadata dictionary.

        Parameters:
        metadata (dict): A dictionary containing user session data, including an answer.

        Returns:
        str: The answer associated with the 'Answer' key in the metadata dictionary.
            If the key does not exist, returns 'Answer not found.'.
        """
        return metadata.get("Answer", "Answer not found.")

    @tracer.start_as_current_span("run_get_chunks")
    def get_chunks(self, metadata) -> list[str]:
        """
        Retrieve chunks from the metadata.

        Parameters:
        metadata (dict): A dictionary containing user session data, including an answer and chunks.

        Returns:
        List[str]: The chunks associated with the 'Chunks' key in the metadata dictionary.
                If the key does not exist, returns an empty list.
        """
        return metadata.get("Chunks", [])  # Return an empty list if 'chunks' is not found

    @tracer.start_as_current_span("run_validate_with_llm_process")
    async def _validate_with_llm(
        self, value: Any, metadata: dict[str, Any] | ValidateMetadataModel
    ):
        """Validation of execution with llm service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from llm service
        """
        start_time = datetime.now(UTC)
        logger.info(f"Getting user request: {value}", extra=self.properties)
        llm_service = SecureGPT(prompt_type="CHAT_COMPLETIONS")
        llm_config = CONFIG.settings.dependencies.llm
        http_config = CONFIG.settings.dependencies.aiohttp
        http_tenacity = CONFIG.settings.dependencies.tenacity

        llm_service.one_login_base_url = llm_config.connexion.one_login_base_url.get_secret_value()
        llm_service.one_login_url = llm_config.connexion.one_login_url.get_secret_value()
        llm_service.client_id = llm_config.connexion.client_id.get_secret_value()
        llm_service.client_secret = llm_config.connexion.client_secret.get_secret_value()
        llm_service.api_base_url = llm_config.connexion.api_base_url.get_secret_value()
        llm_service.api_version = llm_config.connexion.api_version
        llm_service.deployment_id = llm_config.connexion.deployment_id
        llm_service.provider_name = llm_config.connexion.provider_name
        llm_service.api_timeout = llm_config.parameters.api_timeout
        llm_service.api_type = llm_config.connexion.api_type
        llm_service.external_securegpt_token = self.validator_request.securegpt_token
        # aiohttp config
        llm_service.http_total_seconds = http_config.timeouts.total_seconds
        llm_service.http_connect_seconds = http_config.timeouts.connect_seconds
        llm_service.http_pool_limit_per_host = http_config.pool_limit_per_host
        # retry config
        llm_service.nb_attempt = http_tenacity.stop_after_attempts
        llm_service.min_wait = http_tenacity.wait_exponential.min_wait
        llm_service.max_wait = http_tenacity.wait_exponential.max_wait
        llm_service.multiplier = http_tenacity.wait_exponential.multiplier

        prompt = value
        logger.info(
            f"Getting generation response from llm service with: {llm_config.parameters}",
            extra=self.properties,
        )
        # run prompt onf llm service
        try:
            response = await llm_service.ainvoke(
                prompt,
                temperature=llm_config.parameters.temperature,
                top_p=llm_config.parameters.top_p,
            )
            token_usage = response.to_json()["kwargs"]["response_metadata"]["token_usage"]
            counter_add(validator_llm_input_token, token_usage["prompt_tokens"])
            counter_add(validator_llm_output_token, token_usage["completion_tokens"])
            final_time = datetime.now(UTC) - start_time
            histogram_record(h_securegpt_latency, final_time.total_seconds())
            return response.content
        except Exception as e:
            counter_add(validator_llm_execution_error, 1)
            logger.error(f" {str(e)}", extra=self.properties)
            return FailResult(
                metadata=metadata,
                error_message=(f"The following error has been found: \n\n{str(e)}"),
                fix_value="",
                error_spans=[],
            )

    @tracer.start_as_current_span("run_validate")
    @ignore_unhashable
    @lru_cache(maxsize=128, typed=True)  # noqa: B019
    async def validate(
        self, value: str | None = None, metadata: dict[str, Any] | None = None
    ) -> ValidatorExecutionModel:
        """
        Validates the calculation logic that leads to the value provided by considering the user query and chunks.

        This asynchronous method performs a validation process to determine
        whether the the calculation logic is consistent or not. It utilizes a
        language model service to verify the consistency  and logs the validation
        process. The method captures execution details, including timestamps,
        errors, and validation results.

        Parameters:
            value (str): The answer or response to be validated.
            metadata (Dict): A dictionary containing additional data
                            related to the validation context, such as user session data, answer and chunks.

        Returns:
            ValidatorExecutionModel: An instance containing the results of
                                    the validation process, including the execution
                                    status, response details, and any error messages.
        """
        counter_add(validator_call, 1)

        self.validator_config.parameters = self.validator_request.config_parameters
        self.validator_execution = ValidatorExecutionModel()

        if isinstance(metadata, ValidateMetadataModel):
            self.validator_request.config_parameters = metadata.model_dump()

        self.validator_execution.start_time = datetime.now(UTC)
        if not self.validator_request.user_payload:
            try:
                self.validator_request.user_payload = {
                    "content_type": "text",
                    "value": sanitize_input(value),
                    "method": self._validation_method,
                    "metadata": metadata,
                }
            except Exception as e:
                counter_add(validator_exception, 1)
                error_message = f"Value parameter cannot be empty or len(value) <= 1: {str(e)}"
                self.validator_execution.execution_status = (
                    ValidatorExecutionStatusEnum.PARAMS_ERROR
                )
                self.validator_execution.error_message = error_message
                self.validator_execution.end_time = datetime.now(UTC)
                self.validator_execution.last_update = datetime.now(UTC)
                self.validator_execution.response = ValidatorResponseModel(
                    status=self.validator_execution.execution_status,
                    details=FailResult(metadata=metadata, error_message=error_message),
                    error_message=self.validator_execution.error_message,
                )
                self.properties["custom_dimensions"]["error_message"] = str(error_message)
                logger.error(error_message, extra=self.properties)
                return self.validator_execution
        else:
            logger.info(
                f" Try to sanitize input value: {self.validator_request.user_payload.value}, ",
                extra=self.properties,
            )
            self.validator_request.user_payload.value = sanitize_input(
                self.validator_request.user_payload.value
            )
        # Get user request to validate
        value_to_validate = self.validator_request.user_payload.value
        metadata_to_validate = self.validator_request.user_payload.metadata
        metadata_to_validate.update(metadata if metadata else {})

        self.validator_execution.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS
        self.validator_execution.request = self.validator_request.model_dump()
        logger.info(
            f" Starting validation process with status: {self.validator_execution.execution_status}",
            extra=self.properties,
        )
        # Check if the value_to_validate is a greeting
        if is_greeting(value_to_validate):
            counter_add(validator_passresult, 1)
            self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
            self.validator_execution.end_time = datetime.now(UTC)
            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_response = ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.PASS,
                details={"Result": PassResult(metadata=metadata).to_dict()},
                error_message="None",
            )
            self.validator_execution.response = self.validator_response
            logger.info("Greeting has been detected.", extra=self.properties)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time
            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
            self.properties["custom_dimensions"]["Explanation"] = "Greeting has been detected"
            logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)
            return self.validator_execution

        if self._validation_method == ValidatorMethodEnum.LLM:
            logger.info(
                f" Initiate the validation with: {value_to_validate}", extra=self.properties
            )
            # get chunks from metadata
            answer = self.get_answer(metadata_to_validate)
            chunks = self.get_chunks(metadata_to_validate)
            prompt = self.generate_verification_prompt(answer, value_to_validate, chunks)
            # validate with llm
            results = await self._validate_with_llm(prompt, metadata_to_validate)
            # Check if results is an instance of FailResult
            if isinstance(results, FailResult):
                counter_add(validator_llm_execution_error, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["error_message"] = str(results.error_message)
                logger.error(
                    f"Validation failed with error: {results.error_message}", extra=self.properties
                )
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.ERROR
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.SECUREGPT_ERROR,
                    details={"Result": results},
                    error_message=results.error_message,
                )
                self.validator_execution.response = self.validator_response
                self.validator_execution.end_time = datetime.now(UTC)
                return self.validator_execution

            try:
                results = json.loads(results)
                validated_result = LlmOutputModel.model_validate(results)
                logger.info(" Data results is valid", extra=self.properties)
            except ValidationError as e:
                counter_add(validator_llm_response_format_error, 1)
                error_message = f"Data results is not valid: {e}"
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["error_message"] = str(error_message)
                logger.error(f" Data results is not valid: {e}", extra=self.properties)

            consistency = validated_result.Consistency
            confidence = validated_result.Confidence
            explanation = validated_result.Explanation
            fix = validated_result.Fix
            have_fix = False

            if validated_result.Fix != "Nothing":
                counter_add(validator_makefix, 1)
                have_fix = True

            if consistency == "Consistent":
                counter_add(validator_passresult, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["confidence"] = float(confidence)
                self.properties["custom_dimensions"]["Explanation"] = str(explanation)
                logger.info(
                    f" The calculation logic is consistent for the user query. "
                    f"Validation confidence : {confidence}. Explanation: {explanation}",
                    extra=self.properties,
                )
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.PASS,
                    details={
                        "Result": PassResult(metadata=metadata).to_dict(),
                        "Confidence": confidence,
                        "Reason": explanation,
                    },
                    have_fix=have_fix,
                    error_message="",
                )
                self.validator_execution.response = self.validator_response
                self.validator_execution.end_time = time.time()
                self.validator_execution.last_update = datetime.now(UTC)  # time.time()
                logger.info(
                    f" Validation passed with status: {self.validator_execution.execution_status}",
                    extra=self.properties,
                )

            elif consistency == "Not Consistent":
                counter_add(validator_failresult, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["confidence"] = float(confidence)
                self.properties["custom_dimensions"]["Explanation"] = str(explanation)
                logger.warning(
                    f" Validation failed: the calculation logic is not coherent. Validation confidence. Validation confidence : {confidence}. Explanation: {explanation} ",
                    extra=self.properties,
                )
                error_message = "The calculation logic is not coherent."
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.FAILED,
                    details={
                        "Result": FailResult(
                            metadata=metadata, error_message=error_message, fix_value=fix
                        ).to_dict(),
                        "Confidence": confidence,
                        "Reason": explanation,
                    },
                    error_message=error_message,
                )
                self.validator_execution.response = self.validator_response

            # execution latency
            self.validator_execution.end_time = datetime.now(UTC)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time
            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            # gauge_set(g_validator_execution_latency, time_passed.total_seconds())
            self.validator_execution.last_update = datetime.now(UTC)
            logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)
            return self.validator_execution
