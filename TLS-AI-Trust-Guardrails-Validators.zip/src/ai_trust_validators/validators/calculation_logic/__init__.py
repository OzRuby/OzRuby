import argparse
import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import ValidatorRequestModel, ValidatorConfig, ValidatorPriorityEnum
from ai_trust_validators.validators.calculation_logic.src.models.input_output import ValidateMetadataModel

from .src.libs.process import CalculationLogic

__all__ = ["CalculationLogic", "start_app"]


def start_app():
    parser = argparse.ArgumentParser(description="Start the app")
    parser.add_argument("--input", type=str, help="user input")
    parser.add_argument("--answer", type=str, help="chatbot response")
    parser.add_argument("--chunks", type=str, help="relevant chunks")
    parser.add_argument("--devise", default="CPU", type=str, help="devise")
    parser.add_argument("--language", default="english", type=str, help="language")
    parser.add_argument("--validation_method", default="llm", type=str, help="validation_method of LLM")
    parser.add_argument("--project_name", default="Travel General Enquieries", type=str, help="Project name")
    parser.add_argument("--partner_name", default="PUFFIN", type=str, help="Contract name")
    parser.add_argument("--country_name", default="France", type=str, help="Country name")

    args = parser.parse_args()
    print(f"Validator started with params {args.params}")

    args = parser.parse_args()
    # Metadata with chunks and chatbot response
    metadata = {"content_type": "text", "Answer": args.answer, "Chunks": args.chunks}

    
    #config parameters
    config_parameters = ValidateMetadataModel(devise=args.devise, language=args.language)
    # Validator config
    validator_configuration= ValidatorConfig(
            name="calculation_logic", validator_type="event_based", endpoint_url="validator/calculation_logic", priority= ValidatorPriorityEnum.P1,
        )


    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name=args.country_name,
        partner_name=args.partner_name,
        project_name=args.project_name,
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=args.validation_method,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    async def validate_calcul_logic(input_request, metadata):
      # Initialize the CalculationLogic validator
      logic = CalculationLogic(validator_request)
      results = await logic.validate(input_request, metadata=metadata)
      return results

    results = asyncio.run(validate_calcul_logic, args.input, metadata)

    print(f"\n\nValidator started with config: {args} \n Results: {results}")
