from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any  # noqa: UP035

from guardrails.validator_base import FailResult, PassResult, ValidationResult, Validator, register_validator
from langchain_core.messages import HumanMessage, SystemMessage

from ai_trust_validators.base_validator import AiTrustValidatorBase
from ai_trust_validators.monitoring.telemetry import (
  SpanAttributeEnum,
  counter_add,
  h_securegpt_latency,
  h_validator_execution_latency,
  histogram_record,
  tracer,
  validator_call,
  validator_exception,
  validator_failresult,
  validator_llm_execution_error,
  validator_llm_input_token,
  validator_llm_output_token,
  validator_llm_response_format_error,
  validator_passresult,
)
from ai_trust_validators.secure_gpt_langchain import SecureGPT
from ai_trust_validators.share_models.validator import (
  ValidatorConfig,
  ValidatorExecutionModel,
  ValidatorExecutionStatusEnum,
  ValidatorMethodEnum,
  ValidatorPriorityEnum,
  ValidatorRequestModel,
  ValidatorResponseModel,
  ValidatorResponseStatusEnum,
)
from ai_trust_validators.utils import is_greeting, sanitize_input

from ...src import logger
from ..models.input_output import LlmOutputModel, ValidateMetadataModel
from ..utils.config import CONFIG


@register_validator(name="aitrust/hallucinations", data_type="string", has_guardrails_endpoint=True)
class HallucinationsValidator(Validator, AiTrustValidatorBase):
  """This validator use LLM model to detect hallucinations errors from
  input content. It validates that the input content respect hallucinations rules.
  """

  def __init__(
    self,
    request_params: ValidatorRequestModel,
    on_fail: Callable[..., Any] | None = None,
    **kwargs,
  ):
    super().__init__(
      on_fail=on_fail,
      # threshold=request_params.config_parameters["threshold"],
      validation_method=request_params.validation_method,
      **kwargs,
    )
    # self._threshold = float(request_params.config_parameters["threshold"])
    self._validation_method = request_params.validation_method
    if self.use_local:
      self._model = ""  # type: ignore
    self.validator_request = request_params
    self.validator_execution = None
    self.execution_status = ValidatorExecutionStatusEnum.NOT_STARTED
    self.validator_config = ValidatorConfig(
      name="hallucinations",
      validator_type="event_based",
      endpoint_url="validator/hallucinations",
      priority=ValidatorPriorityEnum.P1,
    )

    self.properties = {
      "custom_dimensions": {
        "validator": CONFIG.informations.name,
        "project_name": request_params.project_name,
        "conversation_id": request_params.conversation_id,
        "logging.scope": CONFIG.monitoring.logging.scope,
        "request_id": request_params.request_id,
        "validation_method": request_params.validation_method,
        "validator_execution_id": request_params.validator_execution_id,
        "pipeline_execution_id": request_params.pipeline_execution_id,
        "country_name": request_params.country_name,
        "partner_name": request_params.partner_name,
      }
    }
    logger.info("HallucinationValidator: initialization")
    # logging attributes: AppInsights
    SpanAttributeEnum.VALIDATOR_NAME.attribute(CONFIG.informations.name)
    SpanAttributeEnum.CONVERSATION_ID.attribute(request_params.conversation_id)
    SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(request_params.pipeline_execution_id)
    SpanAttributeEnum.VALIDATION_METHOD.attribute(request_params.validation_method)
    SpanAttributeEnum.REQUEST_ID.attribute(request_params.request_id)
    SpanAttributeEnum.VALIDATOR_EXECUTION_ID.attribute(request_params.validator_execution_id)
    SpanAttributeEnum.PROJECT_NAME.attribute(request_params.project_name)
    SpanAttributeEnum.PROJECT_SCOPE.attribute(CONFIG.monitoring.logging.scope)

  @tracer.start_as_current_span("run_validate_with_llm_process")
  async def _validate_with_llm(self, value: Any, metadata: dict[str, Any] | ValidateMetadataModel):
    """Validation of execution with llm service

    Args:
        value (Any): input text
        metadata (dict[str, Any]): metadata of the input text

    Returns:
        dict|FailResult: Result from llm service
    """
    start_time = datetime.now(UTC)
    logger.info(f"Getting user request: {value}")

    llm_service = SecureGPT(prompt_type="CHAT_COMPLETIONS")
    llm_config = CONFIG.settings.dependencies.llm
    http_config = CONFIG.settings.dependencies.aiohttp
    http_tenacity = CONFIG.settings.dependencies.tenacity

    llm_service.one_login_base_url = llm_config.connexion.one_login_base_url.get_secret_value()
    llm_service.one_login_url = llm_config.connexion.one_login_url.get_secret_value()
    llm_service.client_id = llm_config.connexion.client_id.get_secret_value()
    llm_service.client_secret = llm_config.connexion.client_secret.get_secret_value()
    llm_service.api_base_url = llm_config.connexion.api_base_url.get_secret_value()
    llm_service.api_version = llm_config.connexion.api_version
    llm_service.deployment_id = llm_config.connexion.deployment_id
    llm_service.provider_name = llm_config.connexion.provider_name
    llm_service.api_timeout = llm_config.parameters.api_timeout
    llm_service.api_type = llm_config.connexion.api_type
    llm_service.external_securegpt_token = self.validator_request.securegpt_token
    # aiohttp config
    llm_service.http_total_seconds = http_config.timeouts.total_seconds
    llm_service.http_connect_seconds = http_config.timeouts.connect_seconds
    llm_service.http_pool_limit_per_host = http_config.pool_limit_per_host
    # retry config
    llm_service.nb_attempt = http_tenacity.stop_after_attempts
    llm_service.min_wait = http_tenacity.wait_exponential.min_wait
    llm_service.max_wait = http_tenacity.wait_exponential.max_wait
    llm_service.multiplier = http_tenacity.wait_exponential.multiplier

    logger.info(f"Prompt messages built: {value}")
    logger.info(f"Getting generation response from llm service with: {llm_config.parameters}")
    # run prompt onf llm service

    try:
      response = await llm_service.ainvoke(
        value, temperature=llm_config.parameters.temperature, top_p=llm_config.parameters.top_p
      )
      final_time = datetime.now(UTC) - start_time
      histogram_record(h_securegpt_latency, final_time.total_seconds())
      # gauge_set(g_securegpt_latency, final_time.total_seconds())
      return response.to_json()
    except Exception as e:
      logger.error(f"{str(e)}")
      self.properties["custom_dimensions"]["user_query"] = str(value)
      self.properties["custom_dimensions"]["error_message"] = str(e)

      counter_add(validator_llm_execution_error, 1)
      return FailResult(
        metadata=metadata,
        error_message=(f"The following error has been found: \n\n{str(e)}"),
        fix_value="",
        error_spans=[],
      )

  @tracer.start_as_current_span("run_user_prompt_template")
  def _user_prompt_template(self, question, chunks, answer):
    """Get user prompt from config

    Args:
        question (str): input text from user

    Returns:
        str: prompt template formatted
    """
    template = CONFIG.settings.dependencies.llm.prompts.user.format(
      question=question,
      chunks=chunks,
      answer=answer,
    )
    logger.info(f"LLM | Getting User prompt: {template}")
    return template

  @tracer.start_as_current_span("run_system_prompt_template")
  def _system_prompt_template(self):
    """Get system from config

    Returns:
        str: system prompt
    """
    sys_prompt = CONFIG.settings.dependencies.llm.prompts.system
    logger.info(f"LLM | Getting system prompt: {sys_prompt}")
    return sys_prompt

  @tracer.start_as_current_span("run_format_response")
  def _format_response(self, response, metadata):
    """Format final response

    Args:
        response (dict): result for service execution
        metadata (dict): metadata of input request

    Returns:
        FailResult|PassResult: result for validator
    """
    logger.info(f"Formatted LLM response: {response['kwargs']['content']}")
    try:
      formatted_resp = LlmOutputModel.model_validate_json(response["kwargs"]["content"])
      token_usage = response["kwargs"]["response_metadata"]["token_usage"]
      counter_add(validator_llm_input_token, token_usage["prompt_tokens"])
      counter_add(validator_llm_output_token, token_usage["completion_tokens"])
    except Exception as e:
      counter_add(validator_llm_response_format_error, 1)
      return FailResult(
        metadata=metadata,
        error_message=(f"_format_response: the following error has been found: \n\n{str(e)}"),
        fix_value="",
        error_spans=[],
      )
    if formatted_resp.error_found:
      counter_add(validator_failresult, 1)
      # if formatted_resp.corrected_text:
      #     counter_add(validator_makefix, 1)
      return FailResult(
        metadata=metadata, error_message=(f"{formatted_resp.error_description}\n"), fix_value="", error_spans=[]
      )
    else:
      counter_add(validator_passresult, 1)
      updateMedata = {
        "response": formatted_resp,
        "response_metadata": response["kwargs"]["response_metadata"],
        "type": response["kwargs"]["type"],
        "run_id": response["kwargs"]["id"],
        **metadata,
      }
      return PassResult(metadata=updateMedata)

  @tracer.start_as_current_span("run_apply_validator_execution")
  def _apply_validator_execution(self, results, metadata):
    """Validator formatting

    Args:
        results (FailResult|PassResult): result type from execution
        metadata (dict): metadata of input request

    Returns:
        ValidatorExecutionModel: model result for validation
    """
    if isinstance(results, FailResult):
      self.validator_execution.end_time = datetime.now(UTC)
      self.validator_execution.execution_status = ValidatorExecutionStatusEnum.ERROR

      self.validator_execution.last_update = datetime.now(UTC)
      self.validator_execution.error_message = str(results)
      self.validator_execution.response = ValidatorResponseModel(
        status=ValidatorResponseStatusEnum.SECUREGPT_ERROR,
        details={"Result": results.to_dict()},
        have_fix=False,
        error_message=self.validator_execution.error_message,
      )
      return self.validator_execution
    # format final response: PassResult | FailResult
    response = self._format_response(results, metadata)
    # apply change on model
    error_message = response.error_message if isinstance(response, FailResult) else None
    self.validator_execution.end_time = datetime.now(UTC)
    self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
    self.validator_execution.last_update = datetime.now(UTC)
    self.validator_execution.error_message = error_message
    self.validator_execution.response = ValidatorResponseModel(
      status=response.outcome,
      details=response,
      have_fix=True if isinstance(response, FailResult) else False,
      error_message=error_message,
    )
    return self.validator_execution

  @tracer.start_as_current_span("run_validate_with_corpus_process")
  def _validate_with_corpus(self, value: Any, metadata: dict[str, Any]):
    """Validation of execution with corpus service

    Args:
        value (Any): input text
        metadata (dict[str, Any]): metadata of the input text

    Returns:
        dict|FailResult: Result from corpus service
    """
    return FailResult(
      metadata=metadata,
      error_message=(f"The Corpus validation process is not implemented yet\n\nCan't process this input: {value}"),
      fix_value="To be implemented later!",
      error_spans=[],
    )

  @tracer.start_as_current_span("run_validate_with_ml_process")
  def _validate_with_ml(self, value: Any, metadata: dict[str, Any]):
    """Validation of execution with ml service

    Args:
        value (Any): input text
        metadata (dict[str, Any]): metadata of the input text

    Returns:
        dict|FailResult: Result from ml service
    """
    return FailResult(
      metadata=metadata,
      error_message=(f"The ML validation process is not implemented yet\n\nCan't process this input: {value}"),
      fix_value="To be implemented later!",
      error_spans=[],
    )

  # Function to get the chunks from the metadata
  @tracer.start_as_current_span("run_get_chunks")
  def get_chunks(self, metadata) -> list[str]:
    """
    Retrieve chunks from the metadata.

    Parameters:
    metadata (dict): A dictionary containing data such as user session data and chunks.

    Returns:
    List[str]: The chunks associated with the 'Chunks' key in the metadata dictionary.
                If the key does not exist, returns an empty list.
    """

    return metadata.get("Chunks", [])  # Return an empty list if 'chunks' is not found

  @tracer.start_as_current_span("run_get_answer")
  def get_answer(self, metadata: dict) -> str:
    """
    Retrieve the answer from the metadata dictionary.

    Parameters:
    metadata (dict): A dictionary containing user session data, including an answer.

    Returns:
    str: The answer associated with the 'Answer' key in the metadata dictionary.
        If the key does not exist, returns 'Answer not found.'.
    """
    return metadata.get("Answer", "Answer not found.")

  @tracer.start_as_current_span("run_generate_verification_prompt")
  def generate_verification_prompt(self, user_query: str, chunks: list[str], answer: str) -> str:
    """
    Constructs a prompt for the language model to assess the relevancy of chunks
    with respect to the user query.

    Parameters:
        user_query (str): The user query.
        chunks (List[str]) : A list of text chunks relevant to the query.

    Returns:
        str: A formatted prompt for the LLM to analyze the relevancy of chunks.
    """
    logger.debug("Generating verification prompt for provided chunks")

    # Joining content chunks into a single string for better readability
    chunks_formatted = "\n".join(f"- {chunk}" for chunk in chunks)

    prompt = [
      # build system prompt
      SystemMessage(content=self._system_prompt_template()),
      # build user prompt
      HumanMessage(content=self._user_prompt_template(user_query, chunks_formatted, answer)),
    ]
    return prompt

  @tracer.start_as_current_span("run_validate_process")
  async def validate(self, value: str, metadata: dict[str, Any] | ValidateMetadataModel) -> ValidationResult:
    """Validation method for the hallucinations validator.

    Args:
        value (str): input query
        metadata (dict[str, Any]): metadata from query

    Returns:
        ValidationResult: can be PassResult or FailResult
    """
    counter_add(validator_call, 1)
    self.validator_config.parameters = self.validator_request.config_parameters
    self.validator_execution = ValidatorExecutionModel(validator_config=self.validator_config)
    if isinstance(metadata, ValidateMetadataModel):
      self.validator_request.config_parameters = metadata.model_dump()
    self.validator_execution.start_time = datetime.now(UTC)
    try:
      self.validator_request.user_payload = {
        "content_type": "text",
        "value": sanitize_input(value),
        "method": self._validation_method,
        "metadata": metadata,
      }
    except Exception as e:
      counter_add(validator_exception, 1)
      error_message = f"Value parameter cannot be empty or len(value) <= 1: {str(e)}"
      self.validator_execution.execution_status = ValidatorExecutionStatusEnum.PARAMS_ERROR
      self.validator_execution.error_message = error_message
      self.validator_execution.end_time = datetime.now(UTC)
      self.validator_execution.last_update = datetime.now(UTC)
      self.validator_execution.response = ValidatorResponseModel(
        status=self.validator_execution.execution_status,
        details=FailResult(metadata=metadata, error_message=error_message),
        error_message=self.validator_execution.error_message,
      )
      logger.error(f"{error_message} : {str(e)}")
      return self.validator_execution
    # Get user request to validate
    value_to_validate = self.validator_request.user_payload.value
    metadata_to_validate = self.validator_request.user_payload.metadata
    metadata_to_validate.update(metadata if metadata else {})

    self.validator_execution.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS
    self.validator_execution.request = self.validator_request
    logger.info(f"Starting validation process with status: {self.validator_execution.execution_status}")

    # Check if the value_to_validate is a greeting
    if is_greeting(value_to_validate):
      counter_add(validator_passresult, 1)
      self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
      self.validator_execution.end_time = datetime.now(UTC)
      self.validator_execution.last_update = datetime.now(UTC)
      self.validator_response = ValidatorResponseModel(
        status=ValidatorResponseStatusEnum.PASS,
        details={"Result": PassResult(metadata=metadata).to_dict()},
        error_message="None",
      )
      self.validator_execution.response = self.validator_response
      logger.info("Greeting has been detected.", extra=self.properties)
      time_passed = self.validator_execution.end_time - self.validator_execution.start_time
      histogram_record(h_validator_execution_latency, time_passed.total_seconds())
      self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
      self.properties["custom_dimensions"]["Explanation"] = "Greeting has been detected"
      logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)
      return self.validator_execution

    if self._validation_method == ValidatorMethodEnum.LLM:
      self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
      logger.info(f"Initiate the validation with: {value_to_validate}", extra=self.properties)
      # get chunks from metadata
      chunks = self.get_chunks(metadata)
      answer = self.get_answer(metadata)

      prompt = self.generate_verification_prompt(value_to_validate, chunks, answer)
      logger.info(f"PROMPT: {prompt}")

      # validate with llm
      results = await self._validate_with_llm(prompt, metadata)
      logger.info(f"Ending validation with: {value_to_validate}")
      # apply validation results to the output format
      exec_result_format = self._apply_validator_execution(results, metadata)
      # execution latency
      self.validator_execution.end_time = datetime.now(UTC)
      time_passed = self.validator_execution.end_time - self.validator_execution.start_time
      histogram_record(h_validator_execution_latency, time_passed.total_seconds())
      # gauge_set(g_validator_execution_latency, time_passed.total_seconds())
      self.validator_execution.last_update = datetime.now(UTC)
      logger.info(f"Ending validation in: {time_passed} seconds")
      return exec_result_format

    elif self._validation_method == ValidatorMethodEnum.ML:
      logger.info(f"Initiate the validation with: {value_to_validate}")
      # execute input to ML engine
      results = await self._validate_with_ml(value_to_validate, metadata)
      logger.info(f"Ending validation with: {value_to_validate}")
      # apply validation results to the output format
      self.validator_execution.last_update = datetime.now(UTC)
      exec_result_format = self._apply_validator_execution(results, metadata)
      # execution latency
      self.validator_execution.end_time = datetime.now(UTC)
      time_passed = self.validator_execution.end_time - self.validator_execution.start_time
      histogram_record(h_validator_execution_latency, time_passed.total_seconds())
      # gauge_set(g_validator_execution_latency, time_passed.total_seconds())
      self.validator_execution.last_update = datetime.now(UTC)
      logger.info(f"Ending validation in: {time_passed} seconds")
      return exec_result_format

    elif self._validation_method == ValidatorMethodEnum.REGEX:
      logger.info("Initiate the validation: execution")
      # execute input to corpus engine
      results = await self._validate_with_corpus(value_to_validate, metadata)
      logger.info("Ending validation: execution")
      # apply validation results to the output format
      self.validator_execution.last_update = datetime.now(UTC)
      exec_result_format = self._apply_validator_execution(results, metadata)
      logger.info(f"Ending validation: {results}")
      # execution latency
      self.validator_execution.end_time = datetime.now(UTC)
      time_passed = self.validator_execution.end_time - self.validator_execution.start_time
      histogram_record(h_validator_execution_latency, time_passed.total_seconds())
      # gauge_set(g_validator_execution_latency, time_passed.total_seconds())
      self.validator_execution.last_update = datetime.now(UTC)
      logger.info(f"Ending validation in: {time_passed} seconds")
      return exec_result_format
