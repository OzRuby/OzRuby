from pydantic import BaseModel, Field

from ai_trust_validators.share_models.settings import (
  HttpSettingsModel,
  LlmModel,
  RepositoriesModel,
  TenacityModel,
  ZoneEnums,
)


class DependenciesModel(BaseModel, frozen=True):
  llm: LlmModel
  aiohttp: HttpSettingsModel = Field(default=HttpSettingsModel())
  tenacity: TenacityModel = Field(default=TenacityModel())

class UsageModel(BaseModel, frozen=True):
  constraint: list[ZoneEnums | None]
  input_format: dict | None = Field(default={})
  output_format: dict | None = Field(default={})

class SettingsModel(BaseModel, frozen=True):
  usage: UsageModel
  repositories: list[RepositoriesModel]
  dependencies: DependenciesModel
