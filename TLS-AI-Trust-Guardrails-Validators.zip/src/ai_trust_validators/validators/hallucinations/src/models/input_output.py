from enum import Enum

from pydantic import BaseModel, Field


class LlmOutputModel(BaseModel):
  input_text: str = Field(description="Input text from user")
  error_found: bool = Field(description="Does input text contain a hallucination ?")
  confidence: float = Field(description="Confidence score for hallucination detection")
  error_description: str = Field(description="Error decription when validator fail")


class ValidateMetadataModel(BaseModel):
  content_type: str = Field(default="text", description="Input type format")
