import argparse
import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import ValidatorRequestModel

from .src.libs.process import HallucinationsValidator
from .src.models.input_output import ValidateMetadataModel

__all__ = ["HallucinationsValidator", "start_app"]


def start_app():
  parser = argparse.ArgumentParser(description="Start the validator app")
  parser.add_argument("--input", type=str, help="User input")
  parser.add_argument("--threshold", type=float, default=0.4, help="threshold")
  parser.add_argument("--devise", type=dict, default="cpu", help="devise type to use")
  parser.add_argument("--sensibility", type=int, default=4, help="sensibility of LLM")
  parser.add_argument("--language", type=str, help="language of LLM")
  parser.add_argument("--validation_method", default="llm", type=str, help="validation_method of LLM")
  parser.add_argument("--project_name", default="Travel General Enquieries", type=str, help="Project name")

  args = parser.parse_args()

  metadata = {
    "content_type": "text",
  }

  validator_config = ValidateMetadataModel(
    threshold=args.threshold, devise=args.devise, sensibility=args.sensibility, language=args.language, **metadata
  )

  validator_request = ValidatorRequestModel(
    request_id=uuid4(),
    pipeline_execution_id=uuid4(),
    validation_method=args.validation_method,
    user_payload=None,
    conversation_id=uuid4(),
    project_name=args.project_name,
    config_parameters=validator_config.model_dump(),
  )

  async def validate_hallucination(input_request, metadata):
    hallucination = HallucinationsValidator(validator_request)
    results = await hallucination.validate(input_request, metadata)
    return results

  results = asyncio.run(validate_hallucination, args.input, {})

  print(f"\n\nValidator started with config: {args} \n Results: {results}")
