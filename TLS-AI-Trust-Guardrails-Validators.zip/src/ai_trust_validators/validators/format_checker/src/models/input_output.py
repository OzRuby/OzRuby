
from enum import Enum

from pydantic import BaseModel, Field


class DeviseEnum(str, Enum):
    """
    Devise type used to process
    """
    CPU = "cpu"
    GPU = "gpu"

class LanguageEnum(str, Enum):
    """
    Devise type used to process
    """
    FRENCH = "french"
    ENGLISH = "english"
    SPANISH = "spanish"
    MULTILINGUAL = "multilingual"

class LlmOutputErrorSpanModel(BaseModel):
    word: str = Field(description="Word in error")
    start: int = Field(description="Start position of word")
    end: int = Field(description="End position of word")
    reason: str = Field(description="Explication of error")

class LlmOutputModel(BaseModel):
    input_text: str = Field(description="Input text from user")
    error_found: bool = Field(description="Is input text contain grammatical error ?")
    confidence: float = Field(description="Confidence score for grammaticality of input text")
    language: str = Field(description="Language detected for input text")
    corrected_text: str = Field(description="Corrected version of validator error")
    simplified_text: str = Field(description="Simplified version of validator error")
    error_description: str = Field(description="Error decription when validator fail")
    error_keys: list[LlmOutputErrorSpanModel] = Field(default=[], description="Error found in validator processing")

class ValidateMetadataModel(BaseModel):
    content_type: str = Field(default="text", description="Input type format")
    threshold: float = Field(default=0.5, le=1, description="Threshold of sensibility")
    devise: DeviseEnum = Field(default=DeviseEnum.CPU, description="Type of devise used")
    sensibility: int = Field(default=2, le=5, description="Sensibility of LLM during thier analysis")
    language: LanguageEnum = Field(default=LanguageEnum.MULTILINGUAL, description="Language used")
