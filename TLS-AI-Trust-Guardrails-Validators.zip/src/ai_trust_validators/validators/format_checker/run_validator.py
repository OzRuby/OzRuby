import asyncio
from uuid import uuid4

import nest_asyncio


from ai_trust_validators.validators.format_checker import FormatValidator
from ai_trust_validators.validators.format_checker.src.models.input_output import (
    ValidateMetadataModel,
)
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorPriorityEnum,
    ValidatorMethodEnum, 
    ValidatorRequestModel)


nest_asyncio.apply()


input_request = "Economy cm want to know it the flight cancel by the airline and airline provide a new flight but the flight is very late cm need to take taxi return home can she make claim on it."  # noqa: E501


metadata = {
    "content_type": "text",
}

#config parameters
config_parameters =  ValidateMetadataModel(
    threshold=0.4, devise="cpu", sensibility=2, language="english", **metadata
)
# Validator config
validator_configuration= ValidatorConfig(
        name="validator_name", validator_type="event_based", endpoint_url="validator/format_checker", priority= ValidatorPriorityEnum.P1,
    )

# Initialize the ValidatorRequestModel
validator_request = ValidatorRequestModel(
    request_id=uuid4(),
    pipeline_execution_id=uuid4(),
    scope="DEV",
    country_name="France",
    partner_name="PUFFIN",
    project_name="Travel General Enquiries",
    conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
    validator_execution_id=uuid4(),
    validator_config=validator_configuration,
    validation_method=ValidatorMethodEnum.LLM,
    user_payload=None,
    config_parameters=config_parameters.model_dump(),
)

async def validate_format():
    format = FormatValidator(validator_request)
    results = await format.validate(input_request, metadata)
    return results


data = asyncio.run(validate_format())
print(data)
