import argparse
import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import ValidatorRequestModel, ValidatorMethodEnum, ValidatorConfig, ValidatorPriorityEnum

from .src.libs.process import GrammarValidator
from .src.models.input_output import ValidateMetadataModel

__all__ = ["GrammarValidator", "start_app"]


def start_app():
    parser = argparse.ArgumentParser(description="Start the validator app")
    parser.add_argument("--input", type=str, help="User input")
    parser.add_argument("--threshold", type=float, default=0.4, help="threshold")
    parser.add_argument("--devise", type=dict, default="cpu", help="devise type to use")
    parser.add_argument("--sensibility", type=int, default=4, help="sensibility of LLM")
    parser.add_argument("--language", type=str, help="language of LLM")
    parser.add_argument("--validation_method", default="llm", type=str, help="validation_method of LLM")
    parser.add_argument("--project_name", default="Travel General Enquieries", type=str, help="Project name")
    parser.add_argument("--partner_name", default="PUFFIN", type=str, help="Contract name")
    parser.add_argument("--country_name", default="France", type=str, help="Country name")

    args = parser.parse_args()

    metadata = {
        "content_type": "text",
    }

    #config parameters
    config_parameters = ValidateMetadataModel(
        threshold = args.threshold,
        devise = args.devise,
        sensibility = args.sensibility,
        language = args.language,
        **metadata
    )

    
    # Validator config
    validator_configuration= ValidatorConfig(
            name="grammar_checker", validator_type="event_based", endpoint_url="validator/grammar_checker", priority= ValidatorPriorityEnum.P1,
        )


    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name=args.country_name,
        partner_name=args.partner_name,
        project_name=args.project_name,
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.LLM,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    async def validate_grammar(input_request, metadata):
        grammar = GrammarValidator(validator_request)
        results = await grammar.validate(input_request, metadata)
        return results

    results = asyncio.run(validate_grammar, args.input, {})

    print(f"\n\nValidator started with config: {args} \n Results: {results}")
