# Importing the time module for measuring execution time
from collections.abc import Callable
from datetime import UTC, datetime
from functools import lru_cache
from typing import Any

from guardrails.validator_base import (
    ErrorSpan,
    FailResult,
    PassResult,
    #ValidationResult,
    Validator,
    register_validator,
)
from langchain_core.messages import HumanMessage, SystemMessage

from ai_trust_validators.base_validator import AiTrustValidatorBase
from ai_trust_validators.monitoring.telemetry import (
    SpanAttributeEnum,
    counter_add,
    # g_securegpt_latency,
    # g_validator_execution_latency,
    # gauge_set,
    h_securegpt_latency,
    h_validator_execution_latency,
    histogram_record,
    tracer,
    validator_call,
    validator_exception,
    validator_failresult,
    validator_llm_execution_error,
    validator_llm_input_token,
    validator_llm_output_token,
    validator_llm_response_format_error,
    validator_makefix,
    validator_passresult,
)
from ai_trust_validators.secure_gpt_langchain.v2.secure_gpt import SecureGPT
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorMethodEnum,
    ValidatorRequestModel,
    ValidatorResponseModel,
    ValidatorResponseStatusEnum,
)
from ai_trust_validators.utils import ignore_unhashable, is_greeting, sanitize_input

from ...src import init_logging
from ..models.input_output import LlmOutputModel, ValidateMetadataModel
from ..utils.config import CONFIG

logger = init_logging(CONFIG)


@register_validator(
    name="aitrust/grammar_checker", data_type="string", has_guardrails_endpoint=True
)
class GrammarValidator(Validator, AiTrustValidatorBase):
    """This validator use LLM model to detect grammatical errors from
    input content. It validates that the input content respect grammatical rules.
    """

    def __init__(
        self,
        request_params: ValidatorRequestModel,
        on_fail: Callable[..., Any] | None = None,
        **kwargs,
    ):
        super().__init__(
            on_fail=on_fail,
            threshold=request_params.config_parameters["threshold"],
            validation_method=request_params.validation_method,
            **kwargs,
        )
        self._threshold = float(request_params.config_parameters["threshold"])
        self._validation_method = request_params.validation_method
        if self.use_local:
            self._model = ""  # type: ignore
        self.validator_request = request_params
        self.properties = {
            "custom_dimensions": {
                "validator": CONFIG.informations.name,
                "project_name": request_params.project_name,
                "conversation_id": request_params.conversation_id,
                "logging.scope": CONFIG.monitoring.logging.scope,
                "request_id": request_params.request_id,
                "validation_method": request_params.validation_method,
                "validator_execution_id": request_params.validator_execution_id,
                "pipeline_execution_id": request_params.pipeline_execution_id,
                "country_name": request_params.country_name,
                "partner_name": request_params.partner_name,
            }
        }

        self.validator_execution = None
        self.execution_status = ValidatorExecutionStatusEnum.NOT_STARTED
        self.validator_config = ValidatorConfig(
            name=CONFIG.informations.name,
            validator_type="event_based",
            endpoint_url="validator/grammar_checker",
        )
        logger.info("GrammarValidator: initialization")
        # logging attributes: AppInsights
        SpanAttributeEnum.VALIDATOR_NAME.attribute(CONFIG.informations.name)
        SpanAttributeEnum.CONVERSATION_ID.attribute(request_params.conversation_id)
        SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(request_params.pipeline_execution_id)
        SpanAttributeEnum.VALIDATION_METHOD.attribute(request_params.validation_method)
        SpanAttributeEnum.REQUEST_ID.attribute(request_params.request_id)
        SpanAttributeEnum.VALIDATOR_EXECUTION_ID.attribute(request_params.validator_execution_id)
        SpanAttributeEnum.PROJECT_NAME.attribute(request_params.project_name)
        SpanAttributeEnum.PROJECT_SCOPE.attribute(CONFIG.monitoring.logging.scope)
        SpanAttributeEnum.PARTNER_NAME.attribute(request_params.partner_name)
        SpanAttributeEnum.COUNTRY_NAME.attribute(request_params.country_name)

    @tracer.start_as_current_span("run_validate")
    @ignore_unhashable
    @lru_cache(maxsize=128, typed=True)  # noqa: B019
    async def validate(
        self,
        value: str | None = None,
        metadata: dict[str, Any] | ValidateMetadataModel | None = None,
    ) -> ValidatorExecutionModel:
        """
        Full GrammarValidator.validate with the same flow as PromptInjection:
         1) Telemetry & init
         2) Sanitize & populate user_payload
         3) Mark IN_PROGRESS with a dictified request
         4) Dispatch to LLM / ML / REGEX
         5) On LLM‐error update custom_dimensions & return ERROR
         6) Apply Pass/FailResult via _apply_validator_execution
        """
        # 1) Telemetry
        counter_add(validator_call, 1)

        # 2) Init execution model
        self.validator_config.parameters = self.validator_request.config_parameters
        self.validator_execution = ValidatorExecutionModel()
        if isinstance(metadata, ValidateMetadataModel):
            self.validator_request.config_parameters = metadata.model_dump()
        self.validator_execution.start_time = datetime.now(UTC)

        # 2a) Populate or sanitize user_payload
        if not self.validator_request.user_payload:
            try:
                self.validator_request.user_payload = {
                    "content_type": "text",
                    "value": sanitize_input(value),
                    "method": self._validation_method,
                    "metadata": metadata,
                }
            except Exception as e:
                counter_add(validator_exception, 1)
                msg = f"Invalid parameters: {e}"
                self.validator_execution.execution_status = (
                    ValidatorExecutionStatusEnum.PARAMS_ERROR
                )
                self.validator_execution.error_message = msg
                self.validator_execution.response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.PARAMS_ERROR,
                    details=FailResult(metadata=metadata, error_message=msg),
                    error_message=msg,
                )
                self.validator_execution.end_time = datetime.now(UTC)
                self.validator_execution.last_update = datetime.now(UTC)
                self.properties["custom_dimensions"]["error_message"] = str(msg)
                logger.error(msg, extra=self.properties)
                return self.validator_execution
        else:
            logger.info(
                f"Try to sanitize input value: {self.validator_request.user_payload.value}",
                extra=self.properties,
            )
            self.validator_request.user_payload.value = sanitize_input(
                self.validator_request.user_payload.value
            )

        # 2b) Extract for validation
        value_to_validate = self.validator_request.user_payload.value
        metadata_to_validate = self.validator_request.user_payload.metadata or {}
        if metadata:
            metadata_to_validate.update(metadata)

        # 3) Mark IN_PROGRESS
        self.validator_execution.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS
        # store only primitives so Pydantic won’t reject UUIDs
        self.validator_execution.request = self.validator_request.model_dump()
        logger.info(
            f"GrammarValidator {self.validator_request.validator_execution_id} → IN_PROGRESS",
            extra=self.properties,
        )

        # Check if the value_to_validate is a greeting
        if is_greeting(value_to_validate):
            counter_add(validator_passresult, 1)
            self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
            self.validator_execution.end_time = datetime.now(UTC)
            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_response = ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.PASS,
                details={"Result": PassResult(metadata=metadata).to_dict()},
                error_message="None",
            )
            self.validator_execution.response = self.validator_response
            logger.info("Greeting has been detected.", extra=self.properties)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time
            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
            self.properties["custom_dimensions"]["Explanation"] = "Greeting has been detected"
            logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)
            return self.validator_execution

        # 4) Dispatch
        if self._validation_method == ValidatorMethodEnum.LLM:
            logger.info(f"Initiate LLM validation with: {value_to_validate}", extra=self.properties)
            results = await self._validate_with_llm(value_to_validate, metadata_to_validate)

            # 5) On LLM‐service error, update custom_dimensions & return
            if isinstance(results, FailResult):
                counter_add(validator_llm_execution_error, 1)
                # add context for logging
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["error_message"] = str(results.error_message)
                logger.error(f"LLM execution error: {results.error_message}", extra=self.properties)
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.ERROR
                self.validator_execution.response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.SECUREGPT_ERROR,
                    details={"Result": results.to_dict()},
                    error_message=results.error_message,
                )
                self.validator_execution.end_time = datetime.now(UTC)
                self.validator_execution.last_update = datetime.now(UTC)
                return self.validator_execution

        elif self._validation_method == ValidatorMethodEnum.ML:
            results = self._validate_with_ml(value_to_validate, metadata_to_validate)
        else:  # REGEX
            results = self._validate_with_corpus(value_to_validate, metadata_to_validate)

        # 6) Format & finish
        final_exec = self._apply_validator_execution(results, metadata_to_validate)
        final_exec.last_update = datetime.now(UTC)
        final_exec.end_time = datetime.now(UTC)
        elapsed = final_exec.end_time - final_exec.start_time
        histogram_record(h_validator_execution_latency, elapsed.total_seconds())
        logger.info(f" Ending validation in: {elapsed} seconds", extra=self.properties)

        return final_exec

    @tracer.start_as_current_span("run_validate_with_llm_process")
    async def _validate_with_llm(
        self, value: Any, metadata: dict[str, Any] | ValidateMetadataModel
    ):
        """Validation of execution with llm service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from llm service
        """
        start_time = datetime.now(UTC)
        logger.info(f"Getting user request: {value}", extra=self.properties)
        llm_service = SecureGPT(prompt_type="CHAT_COMPLETIONS")
        llm_config = CONFIG.settings.dependencies.llm
        http_config = CONFIG.settings.dependencies.aiohttp
        http_tenacity = CONFIG.settings.dependencies.tenacity

        llm_service.one_login_base_url = llm_config.connexion.one_login_base_url.get_secret_value()
        llm_service.one_login_url = llm_config.connexion.one_login_url.get_secret_value()
        llm_service.client_id = llm_config.connexion.client_id.get_secret_value()
        llm_service.client_secret = llm_config.connexion.client_secret.get_secret_value()
        llm_service.api_base_url = llm_config.connexion.api_base_url.get_secret_value()
        llm_service.api_version = llm_config.connexion.api_version
        llm_service.deployment_id = llm_config.connexion.deployment_id
        llm_service.provider_name = llm_config.connexion.provider_name
        llm_service.api_timeout = llm_config.parameters.api_timeout
        llm_service.api_type = llm_config.connexion.api_type
        llm_service.external_securegpt_token = self.validator_request.securegpt_token
        # aiohttp config
        llm_service.http_total_seconds = http_config.timeouts.total_seconds
        llm_service.http_connect_seconds = http_config.timeouts.connect_seconds
        llm_service.http_pool_limit_per_host = http_config.pool_limit_per_host
        # retry config
        llm_service.nb_attempt = http_tenacity.stop_after_attempts
        llm_service.min_wait = http_tenacity.wait_exponential.min_wait
        llm_service.max_wait = http_tenacity.wait_exponential.max_wait
        llm_service.multiplier = http_tenacity.wait_exponential.multiplier

        # build messages prompts
        messages = [
            # build system prompt
            SystemMessage(content=self._system_prompt_template()),
            # build user prompt
            HumanMessage(content=self._user_prompt_template(value)),
        ]
        logger.info(f"Prompt messages built: {messages}", extra=self.properties)
        logger.info(
            f"Getting generation response from llm service with: {llm_config.parameters}",
            extra=self.properties
        )
        # run prompt onf llm service
        try:
            response = await llm_service.ainvoke(
                messages,
                temperature=llm_config.parameters.temperature,
                top_p=llm_config.parameters.top_p,
            )
            final_time = datetime.now(UTC) - start_time
            histogram_record(h_securegpt_latency, final_time.total_seconds())
            # gauge_set(g_securegpt_latency, final_time.total_seconds())
            return response.to_json()
        except Exception as e:
            logger.error(f"{str(e)}", extra=self.properties)
            counter_add(validator_llm_execution_error, 1)
            return FailResult(
                metadata=metadata,
                error_message=(f"The following error has been found: \n\n{str(e)}"),
                fix_value="",
                error_spans=[],
            )

    @tracer.start_as_current_span("run_user_prompt_template")
    def _user_prompt_template(self, question):
        """Get user prompt from config

        Args:
            question (str): input text from user

        Returns:
            str: prompt template formatted
        """
        template = CONFIG.settings.dependencies.llm.prompts.user.format(
            question=question,
            threshold=self.validator_request.config_parameters["threshold"],
            language=self.validator_request.config_parameters["language"].value,
            sensibility=self.validator_request.config_parameters["sensibility"]
        )
        logger.info("LLM | Getting user prompt", extra=self.properties)
        return template

    @tracer.start_as_current_span("run_system_prompt_template")
    def _system_prompt_template(self):
        """Get system from config

        Returns:
            str: system prompt
        """
        sys_prompt = CONFIG.settings.dependencies.llm.prompts.system
        logger.info("LLM | Getting system prompt", extra=self.properties)
        return sys_prompt

    @tracer.start_as_current_span("run_format_response")
    def _format_response(self, response, metadata):
        """Format final response

        Args:
            response (dict): result for service execution
            metadata (dict): metadata of input request

        Returns:
            FailResult|PassResult: result for validator
        """
        # logger.info(f"Formatted LLM response: {response['kwargs']['content']}")
        try:
            formatted_resp = LlmOutputModel.model_validate_json(response["kwargs"]["content"])
            token_usage = response["kwargs"]["response_metadata"]["token_usage"]
            counter_add(validator_llm_input_token, token_usage["prompt_tokens"])
            counter_add(validator_llm_output_token, token_usage["completion_tokens"])
        except Exception as e:
            counter_add(validator_llm_response_format_error, 1)
            return FailResult(
                metadata=metadata,
                error_message=(
                    f"_format_response: the following error has been found: \n\n{str(e)}"
                ),
                fix_value="",
                error_spans=[],
            )
        if formatted_resp.error_found:
            counter_add(validator_failresult, 1)
            if formatted_resp.corrected_text:
                counter_add(validator_makefix, 1)
            return FailResult(
                metadata=metadata,
                error_message=(
                    "The following text in your response was found to have "
                    f"{len(formatted_resp.error_keys)} grammatical errors:\n"
                    f"\n{[x.word for x in formatted_resp.error_keys]}"
                ),
                fix_value=formatted_resp.corrected_text,
                error_spans=[
                    ErrorSpan(start=x.start, end=x.end, reason=x.reason)
                    for x in formatted_resp.error_keys
                ],
            )
        else:
            counter_add(validator_passresult, 1)
            updateMedata = {
                "response": formatted_resp,
                "response_metadata": response["kwargs"]["response_metadata"],
                "type": response["kwargs"]["type"],
                "run_id": response["kwargs"]["id"],
                **metadata,
            }
            return PassResult(metadata=updateMedata)

    @tracer.start_as_current_span("run_apply_validator_execution")
    def _apply_validator_execution(self, results, metadata):
        """Validator formatting

        Args:
            results (FailResult|PassResult): result type from execution
            metadata (dict): metadata of input request

        Returns:
            ValidatorExecutionModel: model result for validation
        """
        if isinstance(results, FailResult):
            self.validator_execution.end_time = datetime.now(UTC)
            self.validator_execution.execution_status = ValidatorExecutionStatusEnum.ERROR
            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_execution.error_message = str(results)
            self.validator_execution.response = ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.SECUREGPT_ERROR,
                details={"Result": results.to_dict()},
                have_fix=False,
                error_message=self.validator_execution.error_message,
            )
            return self.validator_execution
        # format final response: PassResult | FailResult
        response = self._format_response(results, metadata)
        # apply change on model
        error_message = response.error_message if isinstance(response, FailResult) else None
        self.validator_execution.end_time = datetime.now(UTC)
        self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
        self.validator_execution.last_update = datetime.now(UTC)
        self.validator_execution.error_message = error_message
        self.validator_execution.response = ValidatorResponseModel(
            status=response.outcome,
            details={"Result": response.to_dict()},
            have_fix=True if isinstance(response, FailResult) else False,
            error_message=error_message,
        )
        return self.validator_execution

    @tracer.start_as_current_span("run_validate_with_corpus_process")
    def _validate_with_corpus(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with corpus service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from corpus service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                "The Corpus validation process is not implemented yet\n"
                f"\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        )

    @tracer.start_as_current_span("run_validate_with_ml_process")
    def _validate_with_ml(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with ml service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from ml service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                "The ML validation process is not implemented yet\n"
                f"\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        )
