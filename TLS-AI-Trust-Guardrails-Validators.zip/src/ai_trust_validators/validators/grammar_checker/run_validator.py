import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorMethodEnum,
    ValidatorPriorityEnum,
    ValidatorRequestModel,
)

# import nest_asyncio
from ai_trust_validators.validators.grammar_checker import GrammarValidator
from ai_trust_validators.validators.grammar_checker.src.models.input_output import (
    ValidateMetadataModel,
)

# nest_asyncio.apply()

# input_request = "bjr, j'ai eu un accident avec ma voiture et j'aimer savoir si mon contrat couvre le scharg associé. Je suis seul sans enfant et j'ai besoin d'argent"
# input_request = "j'ai un accident ma voiture"
# input_request ="Can my wif claim for medical expenses for an eyye infection she needs treatment for in Israel (Insurefor idol standard) "
input_request = "CM's return flight from Prague got cancelled and no alternative was provided. They had to book a Taxi from Prague to Vienna and a new flight from Vienna to Gatwick. Can they claim for add costs? "

# input_request = "Hello"
metadata = {
    "content_type": "text",
}

# Config parameters
config_parameters =  ValidateMetadataModel(
    threshold=0.4,
    devise="cpu",
    sensibility=2,
    language="french",
    **metadata
)

# Validator config
validator_configuration= ValidatorConfig(
    name="grammar_checker",
    validator_type="event_based",
    endpoint_url="validator/grammar_checker",
    priority= ValidatorPriorityEnum.P1,
)

# Initialize the ValidatorRequestModel
validator_request = ValidatorRequestModel(
    request_id=uuid4(),
    pipeline_execution_id=uuid4(),
    scope="DEV",
    country_name="France",
    partner_name="PUFFIN",
    project_name="Travel General Enquiries",
    conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
    validator_execution_id=uuid4(),
    validator_config=validator_configuration,
    validation_method=ValidatorMethodEnum.LLM,
    user_payload=None,
    config_parameters=config_parameters.model_dump(),
)

async def validate_grammar():
    grammar = GrammarValidator(validator_request)
    results = await grammar.validate(input_request, metadata)
    return results


data = asyncio.run(validate_grammar())
print(data)
# print(json.loads(data["kwargs"]["content"]))
# print(data["kwargs"]["response_metadata"])
