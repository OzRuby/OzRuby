import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorMethodEnum,
    ValidatorPriorityEnum,
    ValidatorRequestModel,
)
from ai_trust_validators.validators.language_checker.src.libs.process import LanguageChecker
from ai_trust_validators.validators.language_checker.src.models.input_output import (
    ValidateMetadataModel,
)


async def main():
    # Example user query
    user_query = "Can you explain the different types of insurance policies available?"
    # user_query = "ciao"

    # Metadata
    metadata = {
        "content_type": "text",
        "client_language": "fr",
    }
    # config parameters
    config_parameters = ValidateMetadataModel(devise="cpu", **metadata)

    # Validator config
    validator_configuration = ValidatorConfig(
        name="language_checker",
        validator_type="http_based",
        endpoint_url="validator/language_checker",
        priority=ValidatorPriorityEnum.P1,
    )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        project_name="Travel General Enquiries",
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.ML,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    # Initialize the LanguageChecker validator
    language_checker = LanguageChecker(validator_request)

    validation_result = await language_checker.validate(user_query, metadata)

    # Print the validation results
    print("Validation Execution Status:", validation_result)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())
