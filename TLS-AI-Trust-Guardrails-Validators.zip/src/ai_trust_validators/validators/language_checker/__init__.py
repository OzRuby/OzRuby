import argparse
import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import ValidatorRequestModel, ValidatorMethodEnum, ValidatorPriorityEnum, ValidatorConfig
from ai_trust_validators.validators.language_checker.src.libs.process import LanguageChecker
from ai_trust_validators.validators.language_checker.src.models.input_output import ValidateMetadataModel

__all__ = ["LanguageChecker", "start_app"]


def start_app():
  parser = argparse.ArgumentParser(description="Start the app")
  parser.add_argument("--input", type=str, help="input")
  parser.add_argument("--client_language", type=str, help="Response language desired by the customer")
  parser.add_argument("--validation_method", default="ml", type=str, help="validation_method of validator")
  parser.add_argument("--project_name", default="Travel General Enquieries", type=str, help="Project name")
  parser.add_argument("--partner_name", default="PUFFIN", type=str, help="Contract name")
  parser.add_argument("--country_name", default="France", type=str, help="Country name")


  args = parser.parse_args()

  # Metadata
  metadata = {
      "content_type": "text",
      "client_language": args.client_language,
  }
  # config parameters
  config_parameters = ValidateMetadataModel(devise=args.devise, **metadata)

  # Validator config
  validator_configuration= ValidatorConfig(
          name="language_checker", validator_type="http_based", endpoint_url="validator/language_checker", priority= ValidatorPriorityEnum.P1,
      )

 # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name=args.country_name,
      partner_name=args.partner_name,
      project_name=args.project_name,
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.ML,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )

  async def validate_language(input_request, metadata):
    # Initialize LanguageChecker validator
    language_checker = LanguageChecker(validator_request)
    results = await language_checker.validate(input_request, metadata=metadata)
    return results

  results = asyncio.run(validate_language, args.input, {})

  print(f"\n\nValidator started with config: {args} \n Results: {results}")
