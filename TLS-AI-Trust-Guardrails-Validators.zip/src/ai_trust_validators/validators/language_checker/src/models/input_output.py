from enum import Enum

from pydantic import BaseModel, Field


class DeviseEnum(str, Enum):
  """
  Devise type used to process
  """

  CPU = "cpu"
  GPU = "gpu"


class LanguageEnum(str, Enum):
  """
  Devise type used to process
  """

  FRENCH = "french"
  ENGLISH = "english"
  SPANISH = "spanish"
  MULTILINGUAL = "multilingual"


class MlOutputModel(BaseModel):
  detected_language: str = Field(description="language detected")


class ValidateMetadataModel(BaseModel):
  content_type: str = Field(default="text", description="Input type format")
  client_language: str | None = Field(default=None, description="Response language desired by the customer")
  devise: DeviseEnum = Field(default=DeviseEnum.CPU, description="Type of devise used")
