from pydantic import BaseModel, Field, SecretStr

from ai_trust_validators.share_models.settings import (
  HttpSettingsModel,
  RepositoriesModel,
  TenacityModel,
  UsageModel,
)


class AzureTranslationConnexion(BaseModel, frozen=True):
  subscription_key: SecretStr
  endpoint: SecretStr

class MlModel(BaseModel, frozen=True):
  connexion: AzureTranslationConnexion

class DependenciesModel(BaseModel, frozen=True):
  ml: MlModel
  aiohttp: HttpSettingsModel = Field(default=HttpSettingsModel())
  tenacity: TenacityModel = Field(default=TenacityModel())

class SettingsModel(BaseModel, frozen=True):
  usage: UsageModel
  target_language: list[str]
  repositories: list[RepositoriesModel]
  dependencies: DependenciesModel
