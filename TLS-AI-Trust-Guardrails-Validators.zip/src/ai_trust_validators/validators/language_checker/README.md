# Overview

**Language_checker Validator** is a validator designed to determine if the chatbot response is in the expected language. It uses fast-langdetect library to detect the language of the chatbot response. After completing the assessment, it provides a PASS or FAIL output based on the identified errors.

# Development environment

- Activate your environnement

```sh

uv

.venv\Scripts\activate.ps1
```

- Install dependencies

```sh

uv sync
```

- Run tests

```sh

uv run pytest
```

- Run tests coverage

```sh

uv run coverage run -m pytest
uv run coverage report
```

- Run code formatting quality (linting with ruff)

```sh

uv run ruff check
```

# Validator architecture

It will be include later !

# How to use ?

- To test the validator with sample of code

```bash

uv run .\src\ai_trust_validators\validators\language_checker\run_validator.py

```

- Reproduce with sdk code

```python
import asyncio
from uuid import uuid4

from ai_trust_validators.validators.language_checker.src.libs.process import LanguageChecker
from ai_trust_validators.validators.language_checker.src.models.input_output import (
    ValidateMetadataModel,
)
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorPriorityEnum,
    ValidatorMethodEnum, 
    ValidatorRequestModel)



async def main():
    # Example user query
    user_query = "Can you explain the different types of insurance policies available?"

    # Metadata
    metadata = {
        "content_type": "text",
        "client_language": "fr",
    }
    # config parameters
    config_parameters = ValidateMetadataModel(devise="cpu", **metadata)

    # Validator config
    validator_configuration= ValidatorConfig(
            name="language_checker", validator_type="http_based", endpoint_url="validator/language_checker", priority= ValidatorPriorityEnum.P1,
        )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        project_name="Travel General Enquiries",
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.ML,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    # Initialize the LanguageChecker validator
    language_checker = LanguageChecker(validator_request)

    validation_result = await language_checker.validate(user_query, metadata)

    # Print the validation results
    print("Validation Execution Status:", validation_result)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())

```

# Use config file to configure this validator

```yaml
version:
  package: "0.1.0"
  git_tag: v-0.1.0

informations:
  id: language_checker-validator-axap-001
  name: LanguageChecker
  author_info:
    name: ABOUBAKAR Moussa (Devoteam)
    email: moussa.aboubakar.devoteam@axapartners.com
    affiliation: AXA Partners
  use_llm: true
  use_ml: false
  description: This validator is used to validate if the chatbot response is in the expected language.
  docs_url: ./docs

monitoring:
  logging:
    logger_name: aitrust-language-checker
    system_level: WARNING
    app_level: INFO
    scope: PROD

settings:
  usage:
    constraint:
      - UserInput
      - SearchOutput
  target_language:
    - fr
  repositories:
    - type: python-package-manager
      name: nexus
      url: z-aas-raap-shre-dva-ew1-rgp01
    - type: git
      name: azure-devops
      url: TLS-AI-Trust-Guardrails-Validators
  dependencies:
    ml:
      connexion:
        subscription_key: "YOUR_AZURE_SUBSCRIPTION_KEY"
        endpoint: "YOUR_AZURE_ENDPOINT"

```
