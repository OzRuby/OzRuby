from os import environ
from pathlib import Path

import yaml
from dotenv import find_dotenv
from pydantic import ValidationError  # type: ignore

from ai_trust_validators.monitoring.telemetry import SpanAttributeEnum, counter_add, validator_config_error
from ai_trust_validators.utils import default_env, find_base_path  # noqa: F401

from ..models.root import MainConfigModel
from .exceptions import ConfigNotFound

# For exception
SpanAttributeEnum.VALIDATOR_NAME.attribute("query_topic_checker")


def load_global_config():
  config: MainConfigModel | None = None
  config_env = "QUERY_TOPIC_CONFIG_JSON"
  app_config_path = environ.get("QUERY_TOPIC_CONFIG")
  if app_config_path:
    config_file = Path(app_config_path)
  else:
    base_path = Path(__file__).parent.parent.parent
    config_file = base_path / "configs" / f"settings.{default_env()}.yaml"

  if config_env in environ:
    config = MainConfigModel.model_validate_json(environ[config_env])
    return config

  config_path = find_dotenv(filename=config_file)
  if not config_path:
    raise ConfigNotFound(f"Cannot find settings file {config_file}")

  try:
    with open(encoding="utf-8", file=config_path) as r:
      config = MainConfigModel.model_validate(yaml.safe_load(r))
      return config
  except ValidationError as e:
    counter_add(validator_config_error, 1)
    raise e
  except Exception as e:
    print(str(e))
    raise e


CONFIG = load_global_config()
