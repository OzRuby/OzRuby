from enum import Enum

from pydantic import BaseModel, Field


class DeviseEnum(str, Enum):
  """
  Devise type used to process
  """

  CPU = "cpu"
  GPU = "gpu"


class LanguageEnum(str, Enum):
  """
  Devise type used to process
  """

  FRENCH = "french"
  ENGLISH = "english"
  SPANISH = "spanish"
  MULTILINGUAL = "multilingual"


class LlmOutputModel(BaseModel):
  match_found: bool = Field(description="True or False")
  matching_topic: str = Field(description="accepted topic found")
  similarity: float = Field(description="The value of the similarity")


class ValidateMetadataModel(BaseModel):
  content_type: str = Field(default="text", description="Input type format")
  threshold: float = Field(default=0.5, le=1, description="Threshold for similarity search")
  devise: DeviseEnum = Field(default=DeviseEnum.CPU, description="Type of devise used")
