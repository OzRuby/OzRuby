import time  # Importing the time module for measuring execution time
from collections.abc import Callable
from datetime import UTC, datetime
from functools import lru_cache
from typing import Any

import numpy as np
from guardrails.validators import (
    FailResult,
    PassResult,
    Validator,
    register_validator,
)
from pydantic import ValidationError

from ai_trust_validators.base_validator import AiTrustValidatorBase
from ai_trust_validators.monitoring.telemetry import (
    SpanAttributeEnum,
    counter_add,
    # g_securegpt_latency,
    # g_validator_execution_latency,
    # gauge_set,
    h_securegpt_latency,
    h_validator_execution_latency,
    histogram_record,
    tracer,
    validator_call,
    validator_exception,
    validator_failresult,
    validator_llm_execution_error,
    # validator_llm_input_token,
    # validator_llm_output_token,
    validator_llm_response_format_error,
    # validator_makefix,
    validator_passresult,
)
from ai_trust_validators.secure_gpt_langchain.v2.secure_gpt import SecureGPT
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorMethodEnum,
    ValidatorRequestModel,
    ValidatorResponseModel,
    ValidatorResponseStatusEnum,
)
from ai_trust_validators.utils import ignore_unhashable, is_greeting, sanitize_input

from ...src import init_logging
from ..models.input_output import LlmOutputModel, ValidateMetadataModel
from ..utils.config import CONFIG

logger = init_logging(CONFIG)


@register_validator(name="aitrust/query_topics", data_type="string")
class QueryTopics(Validator, AiTrustValidatorBase):
    """A Validator class to determine if a user query is related to predefined accepted topics.

    This validator  such as LLM (Language Model) to assess the relevance of the input query. It computes
    cosine similarity between the embeddings of the user query and the accepted topics to
    assert if the query aligns with any of the topics.

    Parameters:
        request_params (ValidatorRequestModel): Validator parameters
        on_fail (Optional[Callable]): Callback function to invoke on failure.
        **kwargs: Additional keyword arguments for the base class.
    """

    def __init__(
        self, request_params: ValidatorRequestModel, on_fail: Callable | None = None, **kwargs
    ):
        """
        Initializes the ChunksRelevance validator validator.

        Parameters:
            validation_method (str): The validation method to use (default is 'llm').
            on_fail (Optional[Callable]): Callback function to invoke on failure.
            **kwargs: Additional keyword arguments for the base class.
        """
        super().__init__(
            on_fail=on_fail,
            threshold=request_params.config_parameters["threshold"],
            validation_method=request_params.validation_method,
            **kwargs,
        )

        # Load keywords from CONFIG
        self.accepted_topics = CONFIG.settings.accepted_topics
        self._threshold = float(request_params.config_parameters["threshold"])

        self._validation_method = request_params.validation_method
        if self.use_local:
            self._model = ""  # type: ignore
        self.validator_request = request_params

        self.properties = {
            "custom_dimensions": {
                "validator": CONFIG.informations.name,
                "project_name": request_params.project_name,
                "conversation_id": request_params.conversation_id,
                "logging.scope": CONFIG.monitoring.logging.scope,
                "request_id": request_params.request_id,
                "validation_method": request_params.validation_method,
                "validator_execution_id": request_params.validator_execution_id,
                "pipeline_execution_id": request_params.pipeline_execution_id,
                "country_name": request_params.country_name,
                "partner_name": request_params.partner_name,
            }
        }

        self.validator_execution = None
        self.execution_status = ValidatorExecutionStatusEnum.NOT_STARTED
        self.validator_config = ValidatorConfig(
            name=CONFIG.informations.name,
            validator_type="event_based",
            endpoint_url="validator/query_topic_checker",
        )
        logger.info(" Validation initialization", extra=self.properties)
        # logging attributes: AppInsights
        SpanAttributeEnum.VALIDATOR_NAME.attribute(CONFIG.informations.name)
        SpanAttributeEnum.CONVERSATION_ID.attribute(str(request_params.conversation_id))
        SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(str(request_params.pipeline_execution_id))
        SpanAttributeEnum.VALIDATION_METHOD.attribute(request_params.validation_method)
        SpanAttributeEnum.REQUEST_ID.attribute(str(request_params.request_id))
        SpanAttributeEnum.VALIDATOR_EXECUTION_ID.attribute(
            str(request_params.validator_execution_id)
        )
        SpanAttributeEnum.PROJECT_NAME.attribute(request_params.project_name)
        SpanAttributeEnum.PROJECT_SCOPE.attribute(CONFIG.monitoring.logging.scope)
        SpanAttributeEnum.PARTNER_NAME.attribute(request_params.partner_name)
        SpanAttributeEnum.COUNTRY_NAME.attribute(request_params.country_name)

    @tracer.start_as_current_span("run_cosine_similarity")
    def cosine_similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """
        Calculate the cosine similarity between two vectors.

        Args:
            vec1 (List[float]): The first vector.
            vec2 (List[float]): The second vector.

        Returns:
            float: The cosine similarity value.
        """
        # Ensure that the embeddings are NumPy arrays
        embedding1 = np.array(embedding1)
        embedding2 = np.array(embedding2)
        # Calculate the dot product
        dot_product = np.dot(embedding1, embedding2)

        # Calculate the norms (magnitudes) of the embeddings
        norm1 = np.linalg.norm(embedding1)
        norm2 = np.linalg.norm(embedding2)

        # Handle the case where one or both embeddings are zero
        if norm1 == 0 or norm2 == 0:
            return 0.0  # Return 0 similarity if either embedding is zero

        # Calculate the cosine similarity
        similarity = dot_product / (norm1 * norm2)

        return similarity

    @tracer.start_as_current_span("run_validate_with_embbedings")
    async def _validate_with_embbedings(self, value: str, metadata: dict) -> dict[str, Any]:
        """Check if the given user query is about any of the accepted topics.

        Args:
            value(str): The user query to analyze.
            metadata (dict): metadata of input request

        Returns:
            Dict[str, Any]: A dictionary containing the results of the validation:
                - "match_found" (bool): Indicates whether a relevant topic was found.
                - "matching_topic" (Optional[str]): The matching topic if found, else None.
                - "similarity" (float): The average cosine similarity score across all topics evaluated.

        """
        start_time = datetime.now(UTC)
        logger.info(f" Getting user request: {value}", extra=self.properties)
        embedding_api = SecureGPT(prompt_type="EMBEDDINGS")
        llm_config = CONFIG.settings.dependencies.llm
        http_config = CONFIG.settings.dependencies.aiohttp
        http_tenacity = CONFIG.settings.dependencies.tenacity
        embedding_api.one_login_base_url = (
            llm_config.connexion.one_login_base_url.get_secret_value()
        )
        embedding_api.one_login_url = llm_config.connexion.one_login_url.get_secret_value()
        embedding_api.client_id = llm_config.connexion.client_id.get_secret_value()
        embedding_api.client_secret = llm_config.connexion.client_secret.get_secret_value()
        embedding_api.api_base_url = llm_config.connexion.api_base_url.get_secret_value()
        embedding_api.api_version = llm_config.connexion.api_version
        embedding_api.deployment_id = llm_config.connexion.deployment_id
        embedding_api.provider_name = llm_config.connexion.provider_name
        embedding_api.api_type = llm_config.connexion.api_type
        embedding_api.external_securegpt_token = self.validator_request.securegpt_token
        # aiohttp config
        embedding_api.http_total_seconds = http_config.timeouts.total_seconds
        embedding_api.http_connect_seconds = http_config.timeouts.connect_seconds
        embedding_api.http_pool_limit_per_host = http_config.pool_limit_per_host
        # retry config
        embedding_api.nb_attempt = http_tenacity.stop_after_attempts
        embedding_api.min_wait = http_tenacity.wait_exponential.min_wait
        embedding_api.max_wait = http_tenacity.wait_exponential.max_wait
        embedding_api.multiplier = http_tenacity.wait_exponential.multiplier

        logger.info(
            " Getting embeddings for the user query and accepted topics from llm service ",
            extra=self.properties,
        )
        try:
            # Generate embeddings for the user query and topics
            query_embedding = await embedding_api.aembed_query(value)
            topic_embeddings = await embedding_api.aembed_documents(self.accepted_topics)

            list_similarity = []
            # Check cosine similarity with each topic
            for topic, topic_embedding in zip(self.accepted_topics, topic_embeddings, strict=False):
                similarity = self.cosine_similarity(query_embedding, topic_embedding)
                list_similarity.append(similarity)

                if similarity > self._threshold:
                    avg = sum(list_similarity) / len(list_similarity)
                    logger.info(
                        f"The input is related to accepted topics. Similarity found: {avg}",
                        extra=self.properties,
                    )
                    results = {
                        "match_found": True,
                        "matching_topic": topic,
                        "similarity": similarity,
                    }
                    final_time = datetime.now(UTC) - start_time
                    histogram_record(h_securegpt_latency, final_time.total_seconds())
                    return results
            avg_similarity = sum(list_similarity) / len(list_similarity)
            logger.info(
                f"The input is not related to list of chatbot accepted topics. Average similarity: {avg_similarity}",
                extra=self.properties,
            )
            results = {"match_found": False, "matching_topic": None, "similarity": avg_similarity}
            final_time = datetime.now(UTC) - start_time
            histogram_record(h_securegpt_latency, final_time.total_seconds())
            return results
        except Exception as e:
            logger.error(f"{str(e)}", extra=self.properties)
            counter_add(validator_llm_execution_error, 1)
            return FailResult(
                metadata=metadata,
                error_message=(f"The following error has been found: \n\n{str(e)}"),
                fix_value="",
                error_spans=[],
            )

    @tracer.start_as_current_span("run_format_response")
    def _format_response(self, response, metadata):
        """Format final response

        Args:
            response (dict): result for service execution
            metadata (dict): metadata of input request

        Returns:
            FailResult|PassResult: result for validator
        """
        pass

    @tracer.start_as_current_span("run_system_prompt_template")
    def _system_prompt_template(self):
        """Get system from config

        Returns:
            str: system prompt
        """
        pass

    @tracer.start_as_current_span("run_user_prompt_template")
    def _user_prompt_template(self, user_query):
        """Get user prompt from config

        Args:
            user_query (str): input text from user

        Returns:
            str: prompt template formatted
        """
        pass

    @tracer.start_as_current_span("run_apply_validator_execution")
    def _apply_validator_execution(self, results, metadata):
        """Validator formatting

        Args:
            results (FailResult|PassResult): result type from execution
            metadata (dict): metadata of input request

        Returns:
            ValidatorExecutionModel: model result for validation
        """
        pass

    @tracer.start_as_current_span("run_validate_with_corpus_process")
    def _validate_with_corpus(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with corpus service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from corpus service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                f"The Corpus validation process is not implemented yet\n\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        ).to_dict()

    @tracer.start_as_current_span("run_validate_with_llm_process")
    async def _validate_with_llm(
        self, value: Any, metadata: dict[str, Any] | ValidateMetadataModel
    ) -> dict[str, Any] | FailResult:
        """Validation of execution with llm service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from llm service
        """
        pass

    @tracer.start_as_current_span("run_validate_with_ml_process")
    def _validate_with_ml(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with ml service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from ml service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                f"The ML validation process is not implemented yet\n\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        ).to_dict()

    @tracer.start_as_current_span("run_format_response")
    def _format_response(self, response, metadata):
        """Format final response

        Args:
            response (dict): result for service execution
            metadata (dict): metadata of input request

        Returns:
            FailResult|PassResult: result for validator
        """
        pass

    @tracer.start_as_current_span("run_apply_validator_execution")
    def _apply_validator_execution(self, results, metadata):
        """Validator formatting

        Args:
            results (FailResult|PassResult): result type from execution
            metadata (dict): metadata of input request

        Returns:
            ValidatorExecutionModel: model result for validation
        """
        pass

    @tracer.start_as_current_span("run_validate")
    @ignore_unhashable
    @lru_cache(maxsize=128, typed=True)
    async def validate(
        self, value: str = None, metadata: dict[str, Any] | ValidateMetadataModel = None
    ) -> ValidatorExecutionModel:
        """
        This asynchronous method performs a validation process to determine
        whether user query is related to chatbot accepted topics. It utilizes embedding to perform the verification
        and logs the validation rocess. The method captures execution details, including timestamps,
        errors, and validation results.

        Parameters:
            value (str): The user query .
            metadata (Dict): A dictionary containing additional data
                            related to the validation context, such as user session data and chunks.

        Returns:
            ValidatorExecutionModel: An instance containing the results of
                                    the validation process, including the execution
                                    status, response details, and any error messages.
        """
        counter_add(validator_call, 1)
        self.validator_config.parameters = self.validator_request.config_parameters
        self.validator_execution = ValidatorExecutionModel()

        if isinstance(metadata, ValidateMetadataModel):
            self.validator_request.config_parameters = metadata.model_dump()
        self.validator_execution.start_time = datetime.now(UTC)

        if not self.validator_request.user_payload:
            try:
                self.validator_request.user_payload = {
                    "content_type": "text",
                    "value": sanitize_input(value),
                    "method": self._validation_method,
                    "metadata": metadata,
                }
            except Exception as e:
                counter_add(validator_exception, 1)
                error_message = f"Value parameter cannot be empty or len(value) <= 1: {str(e)}"
                self.validator_execution.execution_status = (
                    ValidatorExecutionStatusEnum.PARAMS_ERROR
                )
                self.validator_execution.error_message = error_message
                self.validator_execution.end_time = datetime.now(UTC)
                self.validator_execution.last_update = datetime.now(UTC)
                self.validator_execution.response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.PARAMS_ERROR,
                    details=FailResult(metadata=metadata, error_message=error_message).to_dict(),
                    error_message=self.validator_execution.error_message,
                )
                self.properties["custom_dimensions"]["error_message"] = str(error_message)
                logger.error(error_message, extra=self.properties)
                return self.validator_execution
        else:
            logger.info(
                f"Try to sanitize input value: {self.validator_request.user_payload.value}",
                extra=self.properties,
            )
            self.validator_request.user_payload.value = sanitize_input(
                self.validator_request.user_payload.value
            )
        # Get user request to validate
        value_to_validate = self.validator_request.user_payload.value
        metadata_to_validate = self.validator_request.user_payload.metadata
        metadata_to_validate.update(metadata if metadata else {})

        self.validator_execution.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS
        self.validator_execution.request = self.validator_request.model_dump()
        logger.info(
            f" Starting validation process with status: {self.validator_execution.execution_status}",
            extra=self.properties,
        )

        # Check if the value_to_validate is a greeting
        if is_greeting(value_to_validate):
            counter_add(validator_passresult, 1)
            self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
            self.validator_execution.end_time = datetime.now(UTC)
            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_response = ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.PASS,
                details={"Result": PassResult(metadata=metadata).to_dict()},
                error_message="None",
            )
            self.validator_execution.response = self.validator_response
            logger.info("Greeting has been detected.", extra=self.properties)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time
            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
            self.properties["custom_dimensions"]["Explanation"] = "Greeting has been detected"
            logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)
            return self.validator_execution

        if self._validation_method == ValidatorMethodEnum.LLM:
            logger.info(
                f" Initiate the validation with: {value_to_validate}", extra=self.properties
            )
            # validate with embedding
            results = await self._validate_with_embbedings(value_to_validate, metadata_to_validate)
            if isinstance(results, FailResult):
                counter_add(validator_llm_execution_error, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["error_message"] = str(results.error_message)
                logger.error(
                    f"Validation failed with error: {results.error_message}", extra=self.properties
                )
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.SECUREGPT_ERROR,
                    details={"Result": results},
                    error_message=results.error_message,
                )
                self.validator_execution.response = self.validator_response
                self.validator_execution.end_time = datetime.now(UTC)
                return self.validator_execution

            try:
                validated_results = LlmOutputModel.model_validate(results)
                logger.info(f"Data results validated: {validated_results}", extra=self.properties)
            except ValidationError as e:
                counter_add(validator_llm_response_format_error, 1)
                error_message = f"Data results is not valid: {e}"
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["error_message"] = str(error_message)
                logger.error(f"Data results is not valid: {e}", extra=self.properties)

            matching_topic = results["matching_topic"]
            similarity = results["similarity"]

            if results["match_found"]:
                counter_add(validator_passresult, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["Explanation"] = (
                    f"Similarity found : {similarity}"
                )
                logger.info(
                    f" The user query is about accepted topic.  Matching topic: {matching_topic}, Similarity found : {similarity}"
                )
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.PASS,
                    details={
                        "Result": PassResult(metadata=metadata).to_dict(),
                        "Matching topic": matching_topic,
                        "Similarity": similarity,
                    },
                    error_message="",
                )
                self.validator_execution.response = self.validator_response
                self.validator_execution.end_time = time.time()
                self.validator_execution.last_update = datetime.now(UTC)  # time.time()
                logger.info(
                    " Validation passed with status: {self.validator_execution.execution_status}",
                    extra=self.properties,
                )

            else:
                counter_add(validator_failresult, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["Explanation"] = f"""
                The average similarity found ({similarity}) is under predifined validation threshold"""
                logger.warning(
                    f" Validation failed: the user query do no match with accepted topics."
                    f" Average similarity found : {similarity}",
                    extra=self.properties,  # noqa: E501
                )
                error_message = "Unfortunately, no matching topic found."
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.FAILED,
                    details={
                        "Result": FailResult(
                            metadata=metadata, error_message=error_message
                        ).to_dict(),
                        "Avg_similarity": similarity,
                        "Reason": "The average similarity is under predifined validation threshold",
                    },
                    error_message=error_message,
                )
                self.validator_execution.response = self.validator_response

            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_execution.end_time = datetime.now(UTC)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time
            logger.info(f" Ending validation in: {time_passed} seconds", extra=self.properties)
            self.validator_execution.last_update = datetime.now(UTC)
            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            return self.validator_execution
