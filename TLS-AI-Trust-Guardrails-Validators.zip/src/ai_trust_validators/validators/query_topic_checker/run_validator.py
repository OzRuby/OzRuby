import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorMethodEnum,
    ValidatorPriorityEnum,
    ValidatorRequestModel,
)
from ai_trust_validators.validators.query_topic_checker.src.libs.process import QueryTopics
from ai_trust_validators.validators.query_topic_checker.src.models.input_output import (
    ValidateMetadataModel,
)


async def main():
    # Example user query
    # user_query = "Can you explain the different types of insurance policies available?"
    # user_query = "Afternoon, I have been waiting on a reply for my travel insurance claim and havent had anything and its been over 10 days. Claim Reference number: GB1-25-018179"
    # user_query = " Hello, I just wanted to check the status of my claim and check you received all documents you need from me"
    # user_query = "I need help setting up a new claim"
    # user_query = "My multi trip policy is about to expire tomorrow. Please confirm it will not auto renew!"
    # user_query = "I need to insure my pram which we are taking with us on a flight"
    # user_query = "I have purchased Europe for cover but it should be world wide as I need to include Tunisia"
    # user_query = " Silver MSM policy, CM wants to cancel their policy how do they do this? "
    user_query = "Hi there. My daughter is in New Zealand. She decided to extend her stay. Her Policy is expiring tomorrow. She has email and has been unsuccessful in trying to get hold of someone via telephone. How does she extend her policy"
    # user_query = "ciao"

    # Metadata
    metadata = {
        "content_type": "text",
    }
    # config parameters
    config_parameters = ValidateMetadataModel(
        threshold=0.6, devise="cpu", sensibility=2, **metadata
    )

    # Validator config
    validator_configuration = ValidatorConfig(
        name="query_topic_checker",
        validator_type="event_based",
        endpoint_url="validator/query_topic_checker",
        priority=ValidatorPriorityEnum.P1,
    )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        project_name="Travel General Enquiries",
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.LLM,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    # Initialize the QueryTopics validator
    query_topic = QueryTopics(validator_request)

    validation_result = await query_topic.validate(user_query, metadata)

    # Print the validation results
    print("Validation Execution Status:", validation_result)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())
