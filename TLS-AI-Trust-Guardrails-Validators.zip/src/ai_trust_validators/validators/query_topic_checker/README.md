# Overview

**QueryTopics Validator** is a validator designed to assess if the user query is related to chatbot accepted topic. After completing the assessment, it provides a PASS or FAIL output based on the identified errors.

# Development environment

- Activate your environnement

```sh

uv

.venv\Scripts\activate.ps1
```

- Install dependencies

```sh

uv sync
```

- Run tests

```sh

uv run pytest
```

- Run tests coverage

```sh

uv run coverage run -m pytest
uv run coverage report
```

- Run code formatting quality (linting with ruff)

```sh

uv run ruff check
```

# Validator architecture

It will be include later !

# How to use ?

- To test the validator with sample of code

```bash

uv run .\src\ai_trust_validators\validators\query_topic_checker\run_validator.py

```

- Reproduce with sdk code

```python
import asyncio
from uuid import uuid4


from ai_trust_validators.validators.query_topic_checker.src.libs.process import QueryTopics
from ai_trust_validators.validators.query_topic_checker.src.models.input_output import (
    ValidateMetadataModel,
)
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorPriorityEnum,
    ValidatorMethodEnum, 
    ValidatorRequestModel)


async def main():
    # Example user query
    user_query = "Hi there. My daughter is in New Zealand. She decided to extend her stay. Her Policy is expiring tomorrow. She has email and has been unsuccessful in trying to get hold of someone via telephone. How does she extend her policy"


    # Metadata
    metadata = {
        "content_type": "text",
    }
    #config parameters
    config_parameters = ValidateMetadataModel(threshold=0.6, devise="cpu", sensibility=2, **metadata)

    # Validator config
    validator_configuration= ValidatorConfig(
            name="query_topic_checker", validator_type="event_based", endpoint_url="validator/query_topic_checker", priority= ValidatorPriorityEnum.P1,
        )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        project_name="Travel General Enquiries",
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.LLM,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )
    
    # Initialize the QueryTopics validator
    query_topic = QueryTopics(validator_request)

    validation_result = await query_topic.validate(user_query, metadata)

    # Print the validation results
    print("Validation Execution Status:", validation_result)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())

```

# Use config file to configure this validator

```yaml
version:
  package: "0.1.0"
  git_tag: v-0.1.0

informations:
  id: query_topic-validator-axap-001
  name: QueryTopicChecker
  author_info:
    name: ABOUBAKAR Moussa (Devoteam)
    email: moussa.aboubakar.devoteam@axapartners.com
    affiliation: AXA Partners
  use_llm: true
  use_ml: false
  description: This validator is used to validate topic of a given input of a user
  docs_url: ./docs

monitoring:
  logging:
    logger_name: aitrust-query-topic-filtering
    system_level: WARNING
    app_level: INFO
    scope: PROD

settings:
  usage:
    constraint:
      - UserInput
      - SearchOutput
  accepted_topics:
    - insurance
    - claims
    - policy information
    - customer support
    - coverage options
    - billing
    - account management
  repositories:
    - type: python-package-manager
      name: nexus
      url: z-aas-raap-shre-dva-ew1-rgp01
    - type: git
      name: azure-devops
      url: TLS-AI-Trust-Guardrails-Validators
  dependencies:
    llm:
      connexion:
        grant_type: client_credentials
        client_id: <client_id>
        client_secret: <client_secret>
        scope: urn:grp:chatgpt
        one_login_base_url: "https://onelogin.axa.com"
        one_login_url: "/as/token.oauth2"
        api_base_url: "https://api.se.axa-go.applications.services.axa-tech.intraxa/ago-m365-securegpt-bapi-v1-vrs"
        #api_base_url: "https://api-pp.se.axa-go.applications.services.axa-tech.intraxa/ago-m365-securegpt-hub-v1-vrs"
        deployment_id: text-embedding-ada-002-2  #gpt-35-turbo-0301
        api_version: "2024-08-06"
        provider_name: openai
        api_type: bapi
        #api_type: modelhub


```
