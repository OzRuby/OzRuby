from pathlib import Path

# get from secureGPT langchain libs

def find_base_path(file_name: Path | str = "pyproject.toml") -> Path:
  """Searches for the base path of the project based on the presence of a unique file.

  Args:
    file_name (Path | str, optional): The name of the file to search for.
    Defaults to "pyproject.toml".

  Returns:
    Path | None: The base path of the project, or None if not found.
  """

  current_path = Path(__file__).resolve().parent
  # Stop when reaching the root directory
  while current_path != current_path.parent:
    if (current_path / file_name).is_file():
      return current_path
    current_path = current_path.parent

  return current_path
