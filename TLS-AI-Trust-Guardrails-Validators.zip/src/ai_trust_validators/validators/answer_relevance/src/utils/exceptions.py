class ConfigNotFound(Exception):
    pass


class ConfigBadFormat(Exception):
    pass
