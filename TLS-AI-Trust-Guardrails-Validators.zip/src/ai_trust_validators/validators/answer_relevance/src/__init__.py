from ai_trust_validators.monitoring.logs import init_logging

from .utils.config import CONFIG

# initialization of logging
init_logging(CONFIG)
