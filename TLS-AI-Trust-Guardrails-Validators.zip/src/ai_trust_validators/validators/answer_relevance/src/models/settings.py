from pydantic import BaseModel, Field

from ai_trust_validators.share_models.settings import (
  HttpSettingsModel,
  LlmModel,
  RepositoriesModel,
  TenacityModel,
  UsageModel,
)


class DependenciesModel(BaseModel, frozen=True):
  llm: LlmModel
  aiohttp: HttpSettingsModel = Field(default=HttpSettingsModel())
  tenacity: TenacityModel = Field(default=TenacityModel())

class SettingsModel(BaseModel, frozen=True):
    usage: UsageModel
    repositories: list[RepositoriesModel]
    dependencies: DependenciesModel
