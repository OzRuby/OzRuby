from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

from ai_trust_validators.share_models.infos import InformationsModel
from ai_trust_validators.share_models.monitoring import MonitoringModel
from ai_trust_validators.share_models.version import VersionModel

from .settings import SettingsModel


class MainConfigModel(BaseSettings):
    model_config = SettingsConfigDict(
        env_ignore_empty=True, env_nested_delimiter="__", env_prefix="AITRUST_ANSWER_RELEVANCE_"
    )

    version: VersionModel

    informations: InformationsModel

    monitoring: MonitoringModel

    settings: SettingsModel

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ):
        return (
            env_settings,
            dotenv_settings,
            file_secret_settings,
            init_settings,
        )
