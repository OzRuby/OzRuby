
from enum import Enum

from pydantic import BaseModel, Field


class DeviseEnum(str, Enum):
    """
    Devise type used to process
    """
    CPU = "cpu"
    GPU = "gpu"

class LanguageEnum(str, Enum):
    """
    Devise type used to process
    """
    FRENCH = "french"
    ENGLISH = "english"
    SPANISH = "spanish"
    MULTILINGUAL = "multilingual"


class LlmOutputModel(BaseModel):
    Relevancy: str = Field(description="Relevant or Not Relevant")
    Confidence: float = Field(description="numeric value between 0 and 1, where 1 indicates absolute confidence")
    Explanation: str = Field(description="this field provides provides a clear rationale for llm assessment")
    Fix: str = Field(description="this field provides provides a fix value when chatbot response is not relevant")

class ValidateMetadataModel(BaseModel):
    content_type: str = Field(default="text", description="Input type format")
    #threshold: float = Field(default=0.5, le=1, description="Threshold of sensibility")
    devise: DeviseEnum = Field(default=DeviseEnum.CPU, description="Type of devise used")
    #sensibility: int = Field(default=2, le=5, description="Sensibility of LLM during thier analysis")
    language: LanguageEnum = Field(default=LanguageEnum.MULTILINGUAL, description="Language used")
