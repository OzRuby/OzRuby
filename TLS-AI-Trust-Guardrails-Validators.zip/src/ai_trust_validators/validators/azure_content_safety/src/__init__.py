from logging import Logger

from structlog import (
  get_logger as structlog_get_logger,
)

from ai_trust_validators.monitoring.logs import init_logging

from .utils.config import CONFIG

# initialization of logging
init_logging(CONFIG)

# Framework does not exactly expose Logger, but that's easier to work with
logger: Logger = structlog_get_logger(CONFIG.monitoring.logging.logger_name)
