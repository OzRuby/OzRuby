from pydantic import BaseModel, Field
from typing import List, Dict, Optional


class ContentModerationModel(BaseModel):
  active: bool = Field(description="Indicates if content safety is active")
  blocklists: List[str] | None = Field(default=None, description="Optional list of blocklists")
  reject_thresholds: Optional[Dict[str, int]] = Field(
    default=None, description="Optional thresholds for rejection based on categories"
  )


class PromptShieldModel(BaseModel):
  active: bool = Field(description="Indicates if prompt shield is active")
  documents: Optional[List[str]] = Field(default=None, description="Documents to check in prompt shield")


class ProtectedMaterialsModel(BaseModel):
  active: bool = Field(description="Indicates if protected materials are active")


class GroundednessModel(BaseModel):
  active: bool = Field(description="Indicates if groundedness validation is active")
  answer: Optional[str] = Field(default=None, description="Answer for groundedness validation")
  documents: Optional[List[str]] = Field(default=None, description="Supporting documents for groundedness")
  threshold: Optional[float] = Field(default=None, description="Threshold for groundedness validation")


class ValidateMetadataModel(BaseModel):
  content_type: str = Field(default="text", description="Input type format")
  user_id: int = Field(description="User ID")
  session_id: str = Field(description="Session ID")

  content_moderation: ContentModerationModel = Field(description="Content moderation configuration")
  prompt_shield: PromptShieldModel = Field(description="Prompt shield configuration")
  protected_materials: ProtectedMaterialsModel = Field(description="Protected materials configuration")
  groundedness: GroundednessModel = Field(description="Groundedness validation configuration")
