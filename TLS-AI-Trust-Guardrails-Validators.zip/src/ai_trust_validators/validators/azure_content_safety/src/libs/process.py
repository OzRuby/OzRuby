from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import UTC, datetime
from typing import Any

from guardrails.validators import (
    FailResult,
    PassResult,
    Validator,
    register_validator,
)

from ai_trust_validators.base_validator import AiTrustValidatorBase
from ai_trust_validators.monitoring.telemetry import (
    SpanAttributeEnum,
    counter_add,
    h_ml_latency,
    h_validator_execution_latency,
    histogram_record,
    tracer,
    validator_call,
    validator_exception,
    validator_failresult,
    validator_passresult,
)
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorRequestModel,
    ValidatorResponseModel,
    ValidatorResponseStatusEnum,
)
from ai_trust_validators.utils import sanitize_input

from ...src import init_logging
from ...src.libs.content_safety import (
    Action,
    Category,
    ContentSafety,
    ContentSafetyDecision,
    MediaType,
)
from ..models.input_output import ValidateMetadataModel
from ..utils.config import CONFIG

logger = init_logging(CONFIG)


@register_validator(
    name="aitrust/azure_content_safety", data_type="string", has_guardrails_endpoint=True
)
class AzureContentSafety(Validator, AiTrustValidatorBase):
    """This validator implements ."""

    def __init__(
        self,
        request_params: ValidatorRequestModel,
        on_fail: Callable[..., Any] | None = None,
        **kwargs,
    ):
        super().__init__(
            on_fail=on_fail,
            # threshold=request_params.config_parameters["threshold"],
            validation_method=request_params.validation_method,
            **kwargs,
        )
        # self._threshold = float(request_params.config_parameters["threshold"])
        self._validation_method = request_params.validation_method
        self.properties = {
            "custom_dimensions": {
                "validator": CONFIG.informations.name,
                "project_name": request_params.project_name,
                "conversation_id": request_params.conversation_id,
                "logging.scope": CONFIG.monitoring.logging.scope,
                "request_id": request_params.request_id,
                "validation_method": request_params.validation_method,
                "validator_execution_id": request_params.validator_execution_id,
                "pipeline_execution_id": request_params.pipeline_execution_id,
                "country_name": request_params.country_name,
                "partner_name": request_params.partner_name,
            }
        }

        if self.use_local:
            self._model = ""  # type: ignore
        self.validator_request = request_params
        self.validator_execution = None
        self.execution_status = "not_started"
        self.content_safety = None
        self.cs_decision = ContentSafetyDecision()
        self.validator_config = ValidatorConfig(
            name=CONFIG.informations.name,
            validator_type="http_based",
            endpoint_url="validator/azure_content_safety",
        )
        logger.info("Azure content safety: initialization")
        # logging attributes: AppInsights
        SpanAttributeEnum.VALIDATOR_NAME.attribute(CONFIG.informations.name)
        SpanAttributeEnum.CONVERSATION_ID.attribute(request_params.conversation_id)
        SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(request_params.pipeline_execution_id)
        SpanAttributeEnum.VALIDATION_METHOD.attribute(request_params.validation_method)
        SpanAttributeEnum.REQUEST_ID.attribute(request_params.request_id)
        SpanAttributeEnum.VALIDATOR_EXECUTION_ID.attribute(request_params.validator_execution_id)
        SpanAttributeEnum.PROJECT_NAME.attribute(request_params.project_name)
        SpanAttributeEnum.PROJECT_SCOPE.attribute(CONFIG.monitoring.logging.scope)
        SpanAttributeEnum.PARTNER_NAME.attribute(request_params.partner_name)
        SpanAttributeEnum.COUNTRY_NAME.attribute(request_params.country_name)

    def _system_prompt_template(self):
        pass

    def _user_prompt_template(self):
        pass

    def _validate_with_corpus(self):
        pass

    def _validate_with_llm(self):
        pass

    async def _validate_with_ml(self, value_to_validate, metadata):
        start_time = datetime.now(UTC)

        # Define tasks for parallel execution
        tasks = []
        with ThreadPoolExecutor() as executor:
            if metadata.content_moderation.active:
                tasks.append(executor.submit(
                    self.run_content_moderation,
                    self.content_safety,
                    value_to_validate,
                    metadata.content_moderation
                ))

            if metadata.prompt_shield.active:
                tasks.append(executor.submit(
                    self.content_safety.run_shield_prompt,
                    user_prompt=value_to_validate,
                    documents=metadata.prompt_shield.documents
                ))

            if metadata.protected_materials.active:
                tasks.append(executor.submit(
                    self.content_safety.detect_protected_materials,
                    user_prompt=value_to_validate
                ))

            if metadata.groundedness.active:
                tasks.append(executor.submit(
                    self.content_safety.detect_groundness,
                    user_prompt=value_to_validate,
                    answer=metadata.groundedness.answer,
                    documents=metadata.groundedness.documents,
                    threshold=metadata.groundedness.threshold
                ))

            # Collect results
            for future in as_completed(tasks):
                try:
                    result = future.result()
                    # Combine or process results (e.g., update self.cs_decision)
                    self.cs_decision = await result  # Update based on your logic
                except Exception as e:
                    # Handle exceptions if needed
                    print(f"Validation task failed: {e}")

        # Create the validator response
        self.validator_response = await self.create_validator_response(self.cs_decision)
        final_time = datetime.now(UTC) - start_time
        histogram_record(h_ml_latency, final_time.total_seconds())

    def _format_response(self):
        pass

    def _apply_validator_execution(self):
        pass

    def initialize_content_safety(self, config):
        """Initialize the ContentSafety object."""
        return ContentSafety(
            config.settings.dependencies.azure_content_safety.connexion.endpoint,
            config.settings.dependencies.azure_content_safety.connexion.subscription_key,
            config.settings.dependencies.azure_content_safety.connexion.api_version,
        )

    @tracer.start_as_current_span("run_create_validator_response")
    async def create_validator_response(
        self,
        content_safety_decision: ContentSafetyDecision,
    ):
        """Create the validator response based on the different endpoints."""
        self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
        if all(
            action == Action.Accept
            for action in [
                content_safety_decision.groundness_suggested_action,
                content_safety_decision.content_moderation_suggested_action,
                content_safety_decision.prompt_shield_suggested_action,
                content_safety_decision.protected_materials_suggested_action,
            ]
            if action is not None
        ):
            return ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.PASS,
                details={
                    "groundness": content_safety_decision.groundness_detailed_decision,
                    "content_moderation": content_safety_decision.content_moderation_detailed_decision,
                    "prompt_shield": content_safety_decision.prompt_shield_detailed_decision,
                    "protected_materials": content_safety_decision.protected_materials_detailed_decision,
                },
            )
        else:
            return ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.FAILED,
                details={
                    "groundness": content_safety_decision.groundness_detailed_decision,
                    "content_moderation": content_safety_decision.content_moderation_detailed_decision,
                    "prompt_shield": content_safety_decision.prompt_shield_detailed_decision,
                    "protected_materials": content_safety_decision.protected_materials_detailed_decision,
                },
            )

    @tracer.start_as_current_span("run_record_execution_metrics")
    def record_execution_metrics(self, validator_execution):
        """Record execution metrics and log the time taken."""
        self.validator_execution.end_time = datetime.now(UTC)
        self.validator_execution.last_update = datetime.now(UTC)
        time_passed = validator_execution.end_time - validator_execution.start_time
        histogram_record(h_validator_execution_latency, time_passed.total_seconds())
        logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)

    @tracer.start_as_current_span("run_content_moderation")
    async def run_content_moderation(
        self, content_safety, value: str, metadata: dict[str, Any] | ValidateMetadataModel
    ) -> dict[str, Any]:
        """Run the validation process."""
        # Initialize the ContentSafety object
        media_type = MediaType.Text  # Images are not supported in the validator
        blocklists = metadata.blocklists
        detection_result = await content_safety.detect(media_type, value, blocklists)
        reject_thresholds = metadata.reject_thresholds
        # Convert JSON keys to Category enum
        reject_thresholds = {
            Category[category_name]: threshold
            for category_name, threshold in reject_thresholds.items()
        }

        # Make a decision based on the detection result and reject thresholds
        decision_result = content_safety.make_decision(detection_result, reject_thresholds)

        return decision_result

    @tracer.start_as_current_span("run_initialize_validator")
    def initialize_validator(self, value, metadata):
        """
        Processes the validation request by initializing the validator execution,
        sanitizing input, and handling potential errors.

        Args:
            self: The instance of the class containing the validator configuration,
                  request, and execution models.
            value (str): The input value to be validated.
            metadata (ValidateMetadataModel or dict): Metadata associated with the
                  validation request. Can be a model or a dictionary.

        Returns:
            ValidatorExecutionModel: The execution model containing the status,
            response, and error details (if any).

        Workflow:
            1. Increment the validator call counter.
            2. Initialize the validator execution model with the current configuration.
            3. Update configuration parameters if metadata is provided as a model.
            4. Attempt to sanitize and assign the input value to the user payload.
            5. Handle exceptions if the input value is invalid or empty.
            6. Update the execution status and log the start of the validation process.

        Returns:
            str: The sanitized value to be validated.

        """

        counter_add(validator_call, 1)
        self.validator_config.parameters = self.validator_request.config_parameters
        self.validator_execution = ValidatorExecutionModel(validator_config=self.validator_config)
        if isinstance(metadata, ValidateMetadataModel):
            self.validator_request.config_parameters = metadata.model_dump()
        self.validator_execution.start_time = datetime.now(UTC)

        if not self.validator_request.user_payload:
            try:
                self.validator_request.user_payload = {
                    "content_type": "text",
                    "value": sanitize_input(value),
                    "method": self._validation_method,
                    "metadata": metadata,
                }
            except Exception as e:
                counter_add(validator_exception, 1)
                error_message = f"Value parameter cannot be empty or len(value) <= 2: {str(e)}"
                self.validator_execution.execution_status = "params_error"
                self.validator_execution.error_message = error_message
                self.validator_execution.end_time = datetime.now(UTC)
                self.validator_execution.last_update = datetime.now(UTC)
                fail_obj = FailResult(metadata=metadata, error_message=error_message)
                self.validator_execution.response = ValidatorResponseModel(
                    status=self.validator_execution.execution_status,
                    details=fail_obj.to_dict(),  # Flatten FailResult
                    error_message=self.validator_execution.error_message,
                )
                logger.error(f"{error_message} : {str(e)}", extra=self.properties)
                return self.validator_execution
        else:
            logger.info(
                f"Try to sanitize input value: {self.validator_request.user_payload.value}",
                extra=self.properties,
            )
            self.validator_request.user_payload.value = sanitize_input(
                self.validator_request.user_payload.value
            )

        value_to_validate = self.validator_request.user_payload.value
        metadata_to_validate = self.validator_request.user_payload.metadata
        metadata_to_validate.update(metadata if metadata else {})

        self.validator_execution.execution_status = "in_progress"
        self.validator_execution.request = self.validator_request.model_dump()

        return value_to_validate

    @tracer.start_as_current_span("run_validate_process")
    async def validate(
        self, value: str, metadata: dict[str, Any] | ValidateMetadataModel
    ) -> ValidatorExecutionModel:
        validator_start_time = datetime.now(UTC)

        value_to_validate = self.initialize_validator(value, metadata)
        logger.info(
            f"Starting validation process with status: {self.validator_execution.execution_status}",
            extra=self.properties,
        )
        self.content_safety = self.initialize_content_safety(CONFIG)
        metadata = ValidateMetadataModel(**metadata)

        # Validate the input value using the ML method
        await self._validate_with_ml(value_to_validate, metadata)

        if self.validator_response.status == ValidatorResponseStatusEnum.FAILED:
            counter_add(validator_failresult, 1)

            self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
            self.properties["custom_dimensions"][
                "reason"
            ] = f"""Azure content Safety Validation failed due to:
            {f"Groundness: Rejected" if self.cs_decision.groundness_suggested_action == Action.Reject else ""}
            {f"Content Moderation: Rejected," if self.cs_decision.content_moderation_suggested_action == Action.Reject else ""}
            {f"Prompt Shield: Rejected," if self.cs_decision.prompt_shield_suggested_action == Action.Reject else ""}
            {f"Protected Materials: Rejected" if self.cs_decision.protected_materials_suggested_action == Action.Reject else ""}
            """
            logger.info("Validation failed", extra=self.properties)

        elif self.validator_response.status == ValidatorResponseStatusEnum.PASS:
            counter_add(validator_passresult, 1)

        final_time = datetime.now(UTC) - validator_start_time
        # Execution time
        histogram_record(h_validator_execution_latency, final_time.total_seconds())

        # Update the validator execution response
        self.validator_execution.response = self.validator_response
        logger.info(
            "Validation passed with status: %s.",
            self.validator_execution.execution_status,
            extra=self.properties,
        )

        # Record execution metrics
        self.record_execution_metrics(self.validator_execution)

        return self.validator_execution
