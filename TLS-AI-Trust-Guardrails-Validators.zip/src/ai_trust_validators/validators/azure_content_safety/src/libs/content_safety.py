import enum
from http import HTTPStatus
from typing import Any  # noqa: UP035

from tenacity import retry, stop_after_attempt, stop_after_delay, wait_exponential

from ai_trust_validators.secure_gpt_langchain.v2.base_aiohttp import async_aiohttp_session

from ..utils.config import CONFIG


class MediaType(enum.Enum):
    Text = 1
    # Image = 2

class Category(enum.Enum):
    Hate = 1
    SelfHarm = 2
    Sexual = 3
    Violence = 4

class Action(enum.Enum):
    Accept = 1
    Reject = 2


class DetectionError(Exception):
    def __init__(self, code: str, message: str) -> None:
        """
        Exception raised when there is an error in detecting the content.

        Args:
        - code (str): The error code.
        - message (str): The error message.
        """
        self.code = code
        self.message = message

    def __repr__(self) -> str:
        return f"DetectionError(code={self.code}, message={self.message})"


class ContentSafetyDecision:
    def __init__(
        self,
        groundness_suggested_action: Action = None,
        groundness_detailed_decision: dict = None,
        content_moderation_suggested_action: Action = None,
        content_moderation_detailed_decision: dict = None,
        prompt_shield_suggested_action: Action = None,
        prompt_shield_detailed_decision: dict = None,
        protected_materials_suggested_action: Action = None,
        protected_materials_detailed_decision: dict = None,
    ):
        self.groundness_suggested_action = groundness_suggested_action
        self.groundness_detailed_decision = groundness_detailed_decision

        self.content_moderation_suggested_action = content_moderation_suggested_action
        self.content_moderation_detailed_decision = content_moderation_detailed_decision

        self.prompt_shield_suggested_action = prompt_shield_suggested_action
        self.prompt_shield_detailed_decision = prompt_shield_detailed_decision

        self.protected_materials_suggested_action = protected_materials_suggested_action
        self.protected_materials_detailed_decision = protected_materials_detailed_decision


class ContentSafety:
    def __init__(self, endpoint: str, subscription_key: str, api_version: str) -> None:
        """
        Creates a new ContentSafety instance.

        Args:
        - endpoint (str): The endpoint URL for the Content Safety API.
        - subscription_key (str): The subscription key for the Content Safety API.
        - api_version (str): The version of the Content Safety API to use.
        """
        self.endpoint = endpoint
        self.subscription_key = subscription_key
        self.api_version = api_version

    def build_url(self, media_type: MediaType) -> str:
        """
        Builds the URL for the Content Safety API based on the media type.

        Args:
        - media_type (MediaType): The type of media to analyze.

        Returns:
        - str: The URL for the Content Safety API.
        """
        if media_type == MediaType.Text:
            return f"{self.endpoint}/contentsafety/text:analyze?api-version={self.api_version}"
        elif media_type == MediaType.Image:
            return f"{self.endpoint}/contentsafety/image:analyze?api-version={self.api_version}"
        else:
            raise ValueError(f"Invalid Media Type {media_type}")

    def build_headers(self) -> dict[str, str]:
        """
        Builds the headers for the Content Safety API request.

        Returns:
        - dict[str, str]: The headers for the Content Safety API request.
        """
        return {
            "Ocp-Apim-Subscription-Key": self.subscription_key,
            "Content-Type": "application/json",
        }

    def build_request_body(
        self,
        media_type: MediaType,
        content: str,
        blocklists: list[str],
    ) -> dict:
        """
        Builds the request body for the Content Safety API request.

        Args:
        - media_type (MediaType): The type of media to analyze.
        - content (str): The content to analyze.
        - blocklists (list[str]): The blocklists to use for text analysis.

        Returns:
        - dict: The request body for the Content Safety API request.
        """
        if media_type == MediaType.Text:
            return {
                "text": content,
                "blocklistNames": blocklists,
            }
        elif media_type == MediaType.Image:
            return {"image": {"content": content}}
        else:
            raise ValueError(f"Invalid Media Type {media_type}")

    @retry(
        wait=wait_exponential(
            multiplier=CONFIG.settings.dependencies.tenacity.wait_exponential.multiplier,
            min=CONFIG.settings.dependencies.tenacity.wait_exponential.min_wait,
            max=CONFIG.settings.dependencies.tenacity.wait_exponential.max_wait,
        ),
        stop=(
            stop_after_delay(CONFIG.settings.dependencies.tenacity.stop_after_delay)
            | stop_after_attempt(CONFIG.settings.dependencies.tenacity.stop_after_attempts)
        ),
    )
    async def detect(
        self,
        media_type: MediaType,
        content: str,
        blocklists: list[str] = None,
    ) -> dict:
        """
        Detects unsafe content using the Content Safety API.

        Args:
        - media_type (MediaType): The type of media to analyze.
        - content (str): The content to analyze.
        - blocklists (list[str]): The blocklists to use for text analysis.

        Returns:
        - dict: The response from the Content Safety API.
        """
        if blocklists is None:
            blocklists = []
        url = self.build_url(media_type)
        headers = self.build_headers()
        request_body = self.build_request_body(media_type, content, blocklists)
        client_session = await async_aiohttp_session(
            http_total_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.total_seconds,
            http_connect_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.connect_seconds,
            http_pool_limit_per_host = CONFIG.settings.dependencies.aiohttp.pool_limit_per_host
        )
        async with client_session.post(url, headers=headers, json=request_body) as response:
            #response.raise_for_status()
            res_content = await response.json()
            if res_content.status_code != HTTPStatus.OK:
                raise DetectionError(res_content["error"]["code"], res_content["error"]["message"])
            return res_content

    def get_detect_result_by_category(
        self, category: Category, detect_result: dict
    ) -> int | None:
        """
        Gets the detection result for the given category from the Content Safety API response.

        Args:
        - category (Category): The category to get the detection result for.
        - detect_result (dict): The Content Safety API response.

        Returns:
        - Union[int, None]: The detection result for the given category, or None if it is not found.
        """
        category_res = detect_result.get("categoriesAnalysis", None)
        for res in category_res:
            if category.name == res.get("category", None):
                return res
        raise ValueError(f"Invalid Category {category}")

    def make_decision(
        self,
        detection_result: dict,
        reject_thresholds: dict[Category, int],
    ) -> ContentSafetyDecision:
        """
        Makes a decision based on the Content Safety API response and the specified reject thresholds.
        Users can customize their decision-making method.

        Args:
        - detection_result (dict): The Content Safety API response.
        - reject_thresholds (dict[Category, int]): The reject thresholds for each category.

        Returns:
        - Decision: The decision based on the Content Safety API response and the specified reject thresholds.
        """
        action_result = {}
        final_action = Action.Accept
        for category, threshold in reject_thresholds.items():
            if threshold not in (-1, 0, 2, 4, 6):
                raise ValueError("RejectThreshold can only be in (-1, 0, 2, 4, 6)")

            cate_detect_res = self.get_detect_result_by_category(category, detection_result)
            if cate_detect_res is None or "severity" not in cate_detect_res:
                raise ValueError(f"Can not find detection result for {category}")

            severity = cate_detect_res["severity"]
            action = Action.Reject if threshold != -1 and severity >= threshold else Action.Accept
            action_result[category] = action
            if action.value > final_action.value:
                final_action = action

        if (
            "blocklistsMatch" in detection_result
            and detection_result["blocklistsMatch"]
            and len(detection_result["blocklistsMatch"]) > 0
        ):
            final_action = Action.Reject

        return ContentSafetyDecision(
            groundness_suggested_action=final_action, groundness_detailed_decision=action_result
        )

    ## Endpoint 2: PROMPT SHIELD ##
    @retry(
        wait=wait_exponential(
            multiplier=CONFIG.settings.dependencies.tenacity.wait_exponential.multiplier,
            min=CONFIG.settings.dependencies.tenacity.wait_exponential.min_wait,
            max=CONFIG.settings.dependencies.tenacity.wait_exponential.max_wait,
        ),
        stop=(
            stop_after_delay(CONFIG.settings.dependencies.tenacity.stop_after_delay)
            | stop_after_attempt(CONFIG.settings.dependencies.tenacity.stop_after_attempts)
        ),
    )
    async def run_shield_prompt(self, user_prompt: str, documents: list[str]) -> ContentSafetyDecision:
        """
        Sends a shieldPrompt request to the Content Safety API.

        Args:
        - user_prompt (str): The user prompt to analyze.
        - documents (List[str]): A list of documents to analyze.

        Returns:
        - dict: The response from the Content Safety API.
        """
        url = f"{self.endpoint}/contentsafety/text:shieldPrompt?api-version={self.api_version}"
        headers = self.build_headers()

        data = {"userPrompt": user_prompt, "documents": documents}
        client_session = await async_aiohttp_session(
            http_total_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.total_seconds,
            http_connect_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.connect_seconds,
            http_pool_limit_per_host = CONFIG.settings.dependencies.aiohttp.pool_limit_per_host
        )
        async with client_session.post(url, headers=headers, json=data) as response:
            response.raise_for_status()
            response_json = await response.json()
            return ContentSafetyDecision(
                prompt_shield_suggested_action=self.is_attack_detected(response_json),
                prompt_shield_detailed_decision=response_json,
            )


    def is_attack_detected(self, data: dict[str, Any]) -> Action:
        """Aggregate the attack detection results from userPromptAnalysis and documentsAnalysis.
        If any of them detects an attack, return Action.Reject.
        If none of them detects an attack, return Action.Accept.

        Args:
            data (_type_): _description_

        Returns:
            _type_: _description_
        """
        # Check userPromptAnalysis
        if data.get("userPromptAnalysis", {}).get("attackDetected", False):
            return Action.Reject
        # Check documentsAnalysis
        for document in data.get("documentsAnalysis", []):
            if document.get("attackDetected", False):
                return Action.Reject
        # If no attack detected
        return Action.Accept

    ## Endpoint 3: Protected Materials ##
    @retry(
        wait=wait_exponential(
            multiplier=CONFIG.settings.dependencies.tenacity.wait_exponential.multiplier,
            min=CONFIG.settings.dependencies.tenacity.wait_exponential.min_wait,
            max=CONFIG.settings.dependencies.tenacity.wait_exponential.max_wait,
        ),
        stop=(
            stop_after_delay(CONFIG.settings.dependencies.tenacity.stop_after_delay)
            | stop_after_attempt(CONFIG.settings.dependencies.tenacity.stop_after_attempts)
        ),
    )
    async def detect_protected_materials(self, user_prompt: str) -> ContentSafetyDecision:
        """

        Args:
        - user_prompt (str): The user prompt to analyze.

        Returns:
        - dict: The response from the Content Safety API.

        Raises:
          HTTPError: If the API request fails with a non-200 status code.
        """
        url = f"{self.endpoint}/contentsafety/text:detectProtectedMaterial?api-version={self.api_version}"

        headers = self.build_headers()
        data = {"text": user_prompt}
        client_session = await async_aiohttp_session(
            http_total_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.total_seconds,
            http_connect_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.connect_seconds,
            http_pool_limit_per_host = CONFIG.settings.dependencies.aiohttp.pool_limit_per_host
        )
        async with client_session.post(url, headers=headers, json=data) as response:
            response.raise_for_status()
            response_json = await response.json()
            if response_json.get("protectedMaterialAnalysis", {}).get("detected", False):
                return ContentSafetyDecision(
                    protected_materials_suggested_action=Action.Reject,
                    protected_materials_detailed_decision=response_json,
                )
            else:
                return ContentSafetyDecision(
                    protected_materials_suggested_action=Action.Accept,
                    protected_materials_detailed_decision=response_json,
                )


    # # endpoint 4 : Groundness
    @retry(
        wait=wait_exponential(
            multiplier=CONFIG.settings.dependencies.tenacity.wait_exponential.multiplier,
            min=CONFIG.settings.dependencies.tenacity.wait_exponential.min_wait,
            max=CONFIG.settings.dependencies.tenacity.wait_exponential.max_wait,
        ),
        stop=(
            stop_after_delay(CONFIG.settings.dependencies.tenacity.stop_after_delay)
            | stop_after_attempt(CONFIG.settings.dependencies.tenacity.stop_after_attempts)
        ),
    )
    async def detect_groundness(
        self, user_prompt: str, answer: str, documents: list[str], threshold=0.5
    ) -> ContentSafetyDecision:
        """
        Detects the groundedness of a given answer based on the user prompt and a set
        of reference documents.

        This function sends a request to the content safety API to determine whether
        the provided answer is grounded in the given documents. If the answer is deemed
        ungrounded, it suggests rejecting the response; otherwise, it suggests accepting it.

        Args:
            user_prompt (str): The user's input or query that the answer is responding to.
            answer (str): The generated answer to be evaluated for groundedness.
            documents (List[str]): A list of reference documents to check the answer
            against for grounding.

        Returns:
            Decision: A decision object containing the suggested action
            (Accept or Reject) and additional information categorized by the API response.

        Raises:
            HTTPError: If the API request fails with a non-200 status code.
        """

        url = (
            f"{self.endpoint}/contentsafety/text:detectGroundedness?api-version={self.api_version}"
        )

        headers = self.build_headers()
        data = {
            "domain": "Generic",
            "task": "QnA",
            "qna": {"query": user_prompt},
            "text": answer,
            "groundingSources": documents,
        }
        client_session = await async_aiohttp_session(
            http_total_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.total_seconds,
            http_connect_seconds = CONFIG.settings.dependencies.aiohttp.timeouts.connect_seconds,
            http_pool_limit_per_host = CONFIG.settings.dependencies.aiohttp.pool_limit_per_host
        )
        async with client_session.post(url, headers=headers, json=data) as response:
            response.raise_for_status()
            response_json = await response.json()
            if float(response_json.get("ungroundedPercentage")) >= threshold:
                return ContentSafetyDecision(
                    groundness_suggested_action=Action.Reject,
                    groundness_detailed_decision=response_json,
                )
            else:
                return ContentSafetyDecision(
                    groundness_suggested_action=Action.Accept,
                    groundness_detailed_decision=response_json,
                )
