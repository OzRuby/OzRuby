import argparse
import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import ValidatorRequestModel, ValidatorMethodEnum, ValidatorPriorityEnum, ValidatorConfig
from ai_trust_validators.validators.keywords_filtering.src.libs.process import KeywordFiltering
from ai_trust_validators.validators.keywords_filtering.src.models.input_output import ValidateMetadataModel

__all__ = ["KeywordFiltering", "start_app"]


def start_app():
    """
    Starts the application and sets up command-line argument parsing.

    This function initializes an argument parser for the application, allowing users to specify
    input values and parameters from the command line. It then creates an instance of the
    KeywordFiltering validator and executes the validation process based on the provided input.
    """
    parser = argparse.ArgumentParser(description="Start the app")
    parser.add_argument("--input", type=str, help="Input value to validate")
    parser.add_argument("--keywords", type=str, help="List of keywords")
    parser.add_argument("--params", type=str, help="Additional parameters for the validator")
    parser.add_argument("--validation_method", default="regex", type=str, help="validation_method ")
    parser.add_argument("--project_name", default="Travel General Enquieries", type=str, help="Project name")
    parser.add_argument("--partner_name", default="PUFFIN", type=str, help="Contract name")
    parser.add_argument("--country_name", default="France", type=str, help="Country name")

    args = parser.parse_args()

    # Validate the input
    if not args.input:
      print("Error: Input value is required.")
      return

    metadata = {"additional_info": args.params}  # Example of using params as metadata
    
    #config parameters
    config_parameters = ValidateMetadataModel(
        content_type="text",
        keywords_filtering=args.keywords,
         **metadata
    )

    # Validator config
    validator_configuration= ValidatorConfig(
            name="keywords_filtering", validator_type="event_based", endpoint_url="validator/keywords_filtering", priority= ValidatorPriorityEnum.P1,
        )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name=args.country_name,
        partner_name=args.partner_name,
        project_name=args.project_name,
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.REGEX,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    async def validate_keywords(input_request, metadata):
      # Initialize the KeywordFiltering validator
      filter = KeywordFiltering(validator_request)
      results = await filter.validate(input_request, metadata=metadata)
      return results

    results = asyncio.run(validate_keywords, args.input, {})

    print(f"\n\nValidator started with config: {args} \n Results: {results}")
