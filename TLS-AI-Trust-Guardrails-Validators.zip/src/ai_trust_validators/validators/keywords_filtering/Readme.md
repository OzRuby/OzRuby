# Overview

**KeywordFiltering Validator** identifies keywords in user queries using specified validation methods. It provides the PASS or FAIL based on error found.

# Development environment

- Activate your environnement

```sh

uv

.venv\Scripts\activate.ps1
```

- Install dependencies

```sh

uv sync
```

- Run tests

```sh

uv run pytest
```

- Run tests coverage

```sh

uv run coverage run -m pytest
uv run coverage report
```

- Run code formatting quality (linting with ruff)

```sh

uv run ruff check
```

# Validator architecture

It will be include later !

# How to use ?

- To test the validator with sample of code

```bash

uv run .\src\ai_trust_validators\validators\keywords_filtering_checker\run_validator.py

```

- Reproduce with sdk code

```python
import asyncio
from uuid import uuid4


from ai_trust_validators.validators.keywords_filtering.src.libs.process import KeywordFiltering
from ai_trust_validators.validators.keywords_filtering.src.models.input_output import (
    ValidateMetadataModel,
)
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorPriorityEnum,
    ValidatorMethodEnum, 
    ValidatorRequestModel)



async def main():
   
    user_query = "Hi, I need emergency assistance. My hotel room door doesn't lock and is accessible from the outside to anyone. I have raised with the agency who are pursuing a refund but i now have no hotel or means to pay for a new one until the refund is issued."
    #config parameters
    config_parameters = ValidateMetadataModel(
        content_type="text",
        keywords_filtering=["Bereavement",
                            "Death",
                            "Death of a close relative",
                            "Pregnancy with complications",
                            "Victims of assault",
                            "sexual assault",
                            "violence",
                            "violence while abroad"
                            "terrorism",
                            "Emergency",
                            "Emergency Assistance"]
    )

    # Validator config
    validator_configuration= ValidatorConfig(
            name="keywords_filtering", validator_type="event_based", endpoint_url="validator/keywords_filtering", priority= ValidatorPriorityEnum.P1,
        )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        project_name="Travel General Enquiries",
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.REGEX,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    keyword_filter = KeywordFiltering(validator_request)

    # Call the validate method
    metadata = {"user_id": 1, "session_id": "session_1"}
    validation_result = await keyword_filter.validate(user_query, metadata)

    # Print the validation results
    print("Validation Execution Status:", validation_result)
    print("Validation Response Status:", validation_result.response.status)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())


```

# Use config file to configure this validator

```yaml
version:
  package: "0.1.0"
  git_tag: v-0.1.0

informations:
  id: keyword_filtering-validator-axap-001
  name: KeywordsFiltering
  author_info:
    name: ABOUBAKAR Moussa (Devoteam)
    email: moussa.aboubakar.devoteam@axapartners.com
    affiliation: AXA Partners
  use_llm: false
  use_ml: false
  description: This validator is used to check the presence of keywords in a user query
  docs_url: ./docs

monitoring:
  logging:
    logger_name: aitrust-keywords-filtering
    system_level: WARNING
    app_level: INFO
    scope: PROD

settings:
  usage:
    constraint:
      - UserInput
      - SearchOutput
  keywords_filtering:
    - insurance
    - policies
    - claim
    - support
  repositories:
    - type: python-package-manager
      name: nexus
      url: z-aas-raap-shre-dva-ew1-rgp01
    - type: git
      name: azure-devops
      url: TLS-AI-Trust-Guardrails-Validators

```
