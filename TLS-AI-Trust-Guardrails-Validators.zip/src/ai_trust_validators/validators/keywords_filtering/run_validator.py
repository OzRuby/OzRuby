import asyncio
from uuid import uuid4

from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorMethodEnum,
    ValidatorPriorityEnum,
    ValidatorRequestModel,
)
from ai_trust_validators.validators.keywords_filtering.src.libs.process import KeywordFiltering
from ai_trust_validators.validators.keywords_filtering.src.models.input_output import (
    ValidateMetadataModel,
)


async def main():
    # Example user query and text chunks
    # user_query = "Can you explain the different types of insurance policies available?"
    # user_query = "cm has a the Puffin Gold. cm cut their trip due to his grandmother in law who passed way. They bought new tickets and they did not go back to uk they went back to italy as that is where his grandmother in law resides. Would they be covered?"
    # user_query = "Puffin GOLD - cm called to find out what she needs to make a claim for her mum having terminal cancer?"
    # user_query = " puffin gold policy is cm covered for cancelation of travel companion death? "
    # user_query = "cm has silver policy, she bebn attcked by someone and had an injury, cm asking would she be covered fro attack happended"
    # user_query = "CM Step dad involved in car accident on motor way - cm step dad is in critical care in ICU. cm looking to cancel holiday-is he covered on silver policy"
    # user_query = "How much Will an insured be able to claim if one insured died in and accident and the other suffered permanent disablement? Puffin Platinum"
    # user_query = "Hi, I need emergency assistance. My hotel room door doesn't lock and is accessible from the outside to anyone. I have raised with the agency who are pursuing a refund but i now have no hotel or means to pay for a new one until the refund is issued."
    user_query = "How do I report a demand for compensation?"
    # user_query = "ciao"
    # config parameters
    config_parameters = ValidateMetadataModel(
        content_type="text",
        keywords_filtering=[
            "Bereavement",
            "Death",
            "Death of a close relative",
            "Pregnancy with complications",
            "Victims of assault",
            "sexual assault",
            "violence",
            "violence while abroadterrorism",
            "Emergency",
            "Emergency Assistance",
        ],
    )

    # Validator config
    validator_configuration = ValidatorConfig(
        name="keywords_filtering",
        validator_type="event_based",
        endpoint_url="validator/keywords_filtering",
        priority=ValidatorPriorityEnum.P1,
    )

    # Initialize the ValidatorRequestModel
    validator_request = ValidatorRequestModel(
        request_id=uuid4(),
        pipeline_execution_id=uuid4(),
        scope="DEV",
        country_name="France",
        partner_name="PUFFIN",
        project_name="Travel General Enquiries",
        conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
        validator_execution_id=uuid4(),
        validator_config=validator_configuration,
        validation_method=ValidatorMethodEnum.REGEX,
        user_payload=None,
        config_parameters=config_parameters.model_dump(),
    )

    keyword_filter = KeywordFiltering(validator_request)

    # Call the validate method
    metadata = {"user_id": 1, "session_id": "session_1"}
    validation_result = await keyword_filter.validate(user_query, metadata)

    # Print the validation results
    print("Validation Execution Status:", validation_result)
    print("Validation Response Status:", validation_result.response.status)


# Run the main function
if __name__ == "__main__":
    asyncio.run(main())
