import re
import time  # Importing the time module for measuring execution time
from collections.abc import Callable
from datetime import UTC, datetime
from functools import lru_cache
from typing import Any

import nltk
from guardrails.validators import (
    FailResult,
    PassResult,
    Validator,
    register_validator,
)

# Check if WordNet is already downloaded
try:
    nltk.data.find("corpora/wordnet.zip")
except LookupError:
    nltk.download("wordnet")  # Download WordNet only if it is not present

from nltk.corpus import wordnet

from ai_trust_validators.base_validator import AiTrustValidatorBase
from ai_trust_validators.monitoring.telemetry import (
    SpanAttributeEnum,
    counter_add,
    # g_regex_latency,
    # g_validator_execution_latency,
    # gauge_set,
    h_regex_latency,
    h_validator_execution_latency,
    histogram_record,
    tracer,
    validator_call,
    validator_exception,
    validator_failresult,
    validator_passresult,
)
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorExecutionModel,
    ValidatorExecutionStatusEnum,
    ValidatorMethodEnum,
    ValidatorRequestModel,
    ValidatorResponseModel,
    ValidatorResponseStatusEnum,
)
from ai_trust_validators.utils import ignore_unhashable, is_greeting, sanitize_input

from ...src import init_logging
from ..models.input_output import ValidateMetadataModel
from ..utils.config import CONFIG

logger = init_logging(CONFIG)


@register_validator(
    name="aitrust/keyword_filtering",
    data_type="string",
)
class KeywordFiltering(Validator, AiTrustValidatorBase):
    """
    A validator that identifies keywords in user queries using specified validation methods.

    This class is designed to validate user input by searching for predefined keywords.
    It supports various validation methods, including regular expressions and machine learning-based approaches.

    Parameters:
        request_params (ValidatorRequestModel): Validator parameters
        on_fail (Optional[Callable]): Callback function to invoke on failure.
        **kwargs: Additional keyword arguments for the base class.
    """

    def __init__(
        self, request_params: ValidatorRequestModel, on_fail: Callable | None = None, **kwargs
    ):
        """
        Initializes the KeywordFiltering validator.

        Parameters:
            validation_method (str): The validation method to use (default is 'llm').
            on_fail (Optional[Callable]): Callback function to invoke on failure.
            **kwargs: Additional keyword arguments for the base class.
        """
        super().__init__(
            on_fail=on_fail, validation_method=request_params.validation_method, **kwargs
        )

        self._validation_method = request_params.validation_method
        self.keywords = request_params.config_parameters["keywords_filtering"]
        # Get synonyms for each keyword
        self.synonyms = {}
        for keyword in self.keywords:
            # self.synonyms[keyword] = self._get_synonyms(keyword)
            self.synonyms[keyword] = KeywordFiltering.get_synonyms(keyword)

        # Create a list including keywords and their synonyms
        self.all_keywords = self.keywords + [
            syn for sublist in self.synonyms.values() for syn in sublist
        ]

        # Create a list including keywords and their synonyms
        self.all_keywords = self.keywords + [
            syn for sublist in self.synonyms.values() for syn in sublist
        ]
        self.pattern = re.compile(
            r"\b(" + "|".join(re.escape(keyword) for keyword in self.all_keywords) + r")\b",
            re.IGNORECASE,
        )

        if self.use_local:
            self._model = ""  # type: ignore
        self.validator_request = request_params
        self.properties = {
            "custom_dimensions": {
                "validator": CONFIG.informations.name,
                "project_name": request_params.project_name,
                "conversation_id": request_params.conversation_id,
                "logging.scope": CONFIG.monitoring.logging.scope,
                "request_id": request_params.request_id,
                "validation_method": request_params.validation_method,
                "validator_execution_id": request_params.validator_execution_id,
                "pipeline_execution_id": request_params.pipeline_execution_id,
                "country_name": request_params.country_name,
                "partner_name": request_params.partner_name,
            }
        }

        self.validator_execution = None
        self.execution_status = ValidatorExecutionStatusEnum.NOT_STARTED
        self.validator_config = ValidatorConfig(
            name=CONFIG.informations.name,
            validator_type="http_based",
            endpoint_url="validation/keywords_filtering",
        )
        logger.info("Validation initialization", extra=self.properties)

        # logging attribute
        SpanAttributeEnum.VALIDATOR_NAME.attribute(CONFIG.informations.name)
        SpanAttributeEnum.CONVERSATION_ID.attribute(str(request_params.conversation_id))
        SpanAttributeEnum.PIPELINE_EXECUTION_ID.attribute(str(request_params.pipeline_execution_id))
        SpanAttributeEnum.VALIDATION_METHOD.attribute(request_params.validation_method)
        SpanAttributeEnum.REQUEST_ID.attribute(str(request_params.request_id))
        SpanAttributeEnum.VALIDATOR_EXECUTION_ID.attribute(
            str(request_params.validator_execution_id)
        )
        SpanAttributeEnum.PROJECT_NAME.attribute(request_params.project_name)
        SpanAttributeEnum.PROJECT_SCOPE.attribute(CONFIG.monitoring.logging.scope)
        SpanAttributeEnum.PARTNER_NAME.attribute(request_params.partner_name)
        SpanAttributeEnum.COUNTRY_NAME.attribute(request_params.country_name)

    @tracer.start_as_current_span("run_keywords_identification")
    async def keywords_identification(self, user_query: str) -> tuple[bool, list[str]]:
        """
        Identify the presence of keywords in a user query using regular expressions.

        Parameters:
        - user_query (str): The user query to search within.

        Returns:
        - Tuple[bool, List[str]]: A tuple where the first element indicates if any keywords were found
        and the second element is a list of keywords found in the sentence.
        """
        start_time = datetime.now(UTC)

        # Find all matches in the user query using the compiled pattern
        found_keywords = self.pattern.findall(user_query)
        # Remove duplicates by converting to a set and then back to a list
        unique_found_keywords = list(set(found_keywords))
        # Return whether any keywords were found and the list of found keywords
        final_time = datetime.now(UTC) - start_time

        histogram_record(h_regex_latency, final_time.total_seconds())
        # gauge_set(g_regex_latency, final_time.total_seconds())
        return len(unique_found_keywords) > 0, unique_found_keywords

    @staticmethod
    @tracer.start_as_current_span("get_synonyms")
    def get_synonyms(keyword: str) -> list[str]:
        """Fetches synonyms for a given keyword using WordNet."""
        synonyms = set()
        for syn in wordnet.synsets(keyword):
            for lemma in syn.lemmas():
                synonyms.add(lemma.name())  # Adding the synonym
        return list(synonyms)

    @tracer.start_as_current_span("run_format_response")
    def _format_response(self, response, metadata):
        """Format final response

        Args:
            response (dict): result for service execution
            metadata (dict): metadata of input request

        Returns:
            FailResult|PassResult: result for validator
        """
        pass

    @tracer.start_as_current_span("run_apply_validator_execution")
    def _apply_validator_execution(self, results, metadata):
        """Validator formatting

        Args:
            results (FailResult|PassResult): result type from execution
            metadata (dict): metadata of input request

        Returns:
            ValidatorExecutionModel: model result for validation
        """
        pass

    @tracer.start_as_current_span("run_validate_with_ml_process")
    def _validate_with_ml(self, value: Any, metadata: dict[str, Any]):
        """
        Validation of execution with ml service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from ml service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                f"The ML validation process is not implemented yet\n\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        )

    @tracer.start_as_current_span("run_validate_with_corpus_process")
    def _validate_with_corpus(self, value: Any, metadata: dict[str, Any]):
        """Validation of execution with corpus service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from corpus service
        """
        return FailResult(
            metadata=metadata,
            error_message=(
                f"The Corpus validation process is not implemented yet\n\nCan't process this input: {value}"
            ),
            fix_value="To be implemented later!",
            error_spans=[],
        )

    @tracer.start_as_current_span("run_system_prompt_template")
    def _system_prompt_template(self):
        """Get system from config

        Returns:
            str: system prompt
        """
        pass

    @tracer.start_as_current_span("run_user_prompt_template")
    def _user_prompt_template(self, user_query, chunks, answer):
        """Get user prompt from config

        Args:
            user_query (str): input text from user
            chunks (str): A list of text chunks relevant to the query.
            answer (str): The answer provided by an LLM.

        Returns:
            str: prompt template formatted
        """
        pass

    @tracer.start_as_current_span("run_validate_with_llm_process")
    async def _validate_with_llm(
        self, value: Any, metadata: dict[str, Any] | ValidateMetadataModel
    ):
        """Validation of execution with llm service

        Args:
            value (Any): input text
            metadata (dict[str, Any]): metadata of the input text

        Returns:
            dict|FailResult: Result from llm service
        """
        pass

    @tracer.start_as_current_span("run_custom_validate")
    @ignore_unhashable
    @lru_cache(maxsize=128, typed=True)
    async def validate(
        self, value: str = None, metadata: dict[str, Any] | ValidateMetadataModel = None
    ) -> ValidatorExecutionModel:
        """Validates the provided value against configured keywords
        and updates the execution model accordingly.

        Parameters:
            value (str): The input value to validate.
            metadata (Dict): Additional metadata related to the validation.

        Returns:
            ValidatorExecutionModel: The model containing the execution state, status,
                                    and response of the validation.
        """
        counter_add(validator_call, 1)
        self.validator_config.parameters = self.validator_request.config_parameters
        self.validator_execution = ValidatorExecutionModel()

        if isinstance(metadata, ValidateMetadataModel):
            self.validator_request.config_parameters = metadata.model_dump()

        self.validator_execution.start_time = datetime.now(UTC)
        if not self.validator_request.user_payload:
            try:
                self.validator_request.user_payload = {
                    "content_type": "text",
                    "value": sanitize_input(value),
                    "method": self._validation_method,
                    "metadata": metadata,
                }
            except Exception as e:
                counter_add(validator_exception, 1)
                error_message = f"Value parameter cannot be empty or len(value) <= 1: {str(e)}"
                self.validator_execution.execution_status = (
                    ValidatorExecutionStatusEnum.PARAMS_ERROR
                )
                self.validator_execution.error_message = error_message
                self.validator_execution.end_time = datetime.now(UTC)
                self.validator_execution.last_update = datetime.now(UTC)
                self.validator_execution.response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.PARAMS_ERROR,
                    details=FailResult(metadata=metadata, error_message=error_message),
                    error_message=self.validator_execution.error_message,
                )
                self.properties["custom_dimensions"]["error_message"] = str(error_message)
                logger.error(error_message, extra=self.properties)
                return self.validator_execution
        else:
            logger.info(
                f"Try to sanitize input value: {self.validator_request.user_payload.value}",
                extra=self.properties,
            )
            self.validator_request.user_payload.value = sanitize_input(
                self.validator_request.user_payload.value
            )
        # Get user request to validate
        value_to_validate = self.validator_request.user_payload.value
        metadata_to_validate = self.validator_request.user_payload.metadata
        metadata_to_validate.update(metadata if metadata else {})

        self.validator_execution.execution_status = ValidatorExecutionStatusEnum.IN_PROGRESS
        self.validator_execution.request = self.validator_request.model_dump()
        logger.info(
            f"Starting validation process with status: {self.validator_execution.execution_status}",
            extra=self.properties,
        )
        # Check if the value_to_validate is a greeting
        if is_greeting(value_to_validate):
            counter_add(validator_passresult, 1)
            self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
            self.validator_execution.end_time = datetime.now(UTC)
            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_response = ValidatorResponseModel(
                status=ValidatorResponseStatusEnum.PASS,
                details={"Result": PassResult(metadata=metadata).to_dict()},
                error_message="None",
            )
            self.validator_execution.response = self.validator_response
            logger.info("Greeting has been detected.", extra=self.properties)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time
            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
            self.properties["custom_dimensions"]["Explanation"] = "Greeting has been detected"
            logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)
            return self.validator_execution

        if self._validation_method == ValidatorMethodEnum.REGEX:
            logger.info(f"Initiate the validation with: {value_to_validate}", extra=self.properties)
            is_present, keywordFound = await self.keywords_identification(value_to_validate)

            if is_present:
                counter_add(validator_failresult, 1)
                error_message = "Please hold on while we connect you to an agent."
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["Explanation"] = str(error_message)
                logger.warning(
                    "Validation failed: a special keyword was detected in your query.",
                    extra=self.properties,
                )

                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.FAILED,
                    details={
                        "Result": FailResult(
                            metadata=metadata_to_validate, error_message=error_message
                        ).to_dict()
                    },
                    error_message=error_message,
                )
                self.validator_execution.response = self.validator_response
            else:
                counter_add(validator_passresult, 1)
                self.properties["custom_dimensions"]["user_query"] = str(value_to_validate)
                self.properties["custom_dimensions"]["Explanation"] = "No keywords filtered"
                logger.info(f"Keywords identified: {keywordFound}", extra=self.properties)
                self.validator_execution.execution_status = ValidatorExecutionStatusEnum.COMPLETED
                self.validator_response = ValidatorResponseModel(
                    status=ValidatorResponseStatusEnum.PASS,
                    details={
                        "Result": PassResult(metadata=metadata_to_validate).to_dict(),
                        "Keywords_found": keywordFound,
                    },
                    error_message="",
                )
                self.validator_execution.response = self.validator_response
                self.validator_execution.end_time = time.time()
                self.validator_execution.last_update = datetime.now(UTC)  # time.time()
                logger.info(
                    " Validation passed with status: %s.", self.validator_execution.execution_status
                )

            self.validator_execution.last_update = datetime.now(UTC)
            self.validator_execution.end_time = datetime.now(UTC)
            time_passed = self.validator_execution.end_time - self.validator_execution.start_time

            histogram_record(h_validator_execution_latency, time_passed.total_seconds())
            # gauge_set(g_validator_execution_latency, time_passed)
            self.validator_execution.last_update = datetime.now(UTC)
            logger.info(f"Ending validation in: {time_passed} seconds", extra=self.properties)

            return self.validator_execution
