

from pydantic import BaseModel, Field

from ai_trust_validators.share_models.settings import RepositoriesModel, ZoneEnums


class UsageModel(BaseModel, frozen=True):
    constraint: list[ZoneEnums | None]
    input_format: dict | None = Field(default={})
    output_format: dict | None = Field(default={})


class SettingsModel(BaseModel, frozen=True):
    usage: UsageModel
    keywords_filtering: list[str]
    repositories: list[RepositoriesModel]
