
from enum import Enum

from pydantic import BaseModel, Field


class DeviseEnum(str, Enum):
    """
    Devise type used to process
    """
    CPU = "cpu"
    GPU = "gpu"

class LanguageEnum(str, Enum):
    """
    Devise type used to process
    """
    FRENCH = "french"
    ENGLISH = "english"
    SPANISH = "spanish"
    MULTILINGUAL = "multilingual"

class ValidateMetadataModel(BaseModel):
    content_type: str = Field(default="text", description="Input type format")
    keywords_filtering :list[str] = Field(description="list of keywords to filter")
    #threshold: float = Field(default=0.5, le=1, description="Threshold of sensibility")
    #devise: DeviseEnum = Field(default=DeviseEnum.CPU, description="Type of devise used")
    #sensibility: int = Field(default=2, le=5, description="Sensibility of LLM during thier analysis")
    #language: LanguageEnum = Field(default=LanguageEnum.MULTILINGUAL, description="Language used")
