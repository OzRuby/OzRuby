from abc import ABC, abstractmethod

from ai_trust_validators.monitoring.telemetry import tracer


class AiTrustValidatorBase(ABC):
    """Ai Trust validator base class

    Args:
        ABC (ABC): Abstract class
    """

    @tracer.start_as_current_span("run_validate_with_llm_process")
    @abstractmethod
    async def _validate_with_llm(self, value, metadata):
      """Validation of execution with llm service

      Args:
          value (Any): input text
          metadata (dict[str, Any]): metadata of the input text

      Returns:
          dict|FailResult: Result from llm service
      """
      pass

    @tracer.start_as_current_span("run_user_prompt_template")
    @abstractmethod
    def _user_prompt_template(self, question):
      """Get user prompt from config

      Args:
          question (str): input text from user

      Returns:
          str: prompt template formatted
      """
      pass

    @tracer.start_as_current_span("run_system_prompt_template")
    @abstractmethod
    def _system_prompt_template(self):
      """Get system from config

      Returns:
          str: system prompt
      """
      pass

    @tracer.start_as_current_span("run_format_response")
    @abstractmethod
    def _format_response(self, response, metadata):
      """Format final response

      Args:
          response (dict): result for service execution
          metadata (dict): metadata of input request

      Returns:
          FailResult|PassResult: result for validator
      """
      pass

    @tracer.start_as_current_span("run_apply_validator_execution")
    @abstractmethod
    def _apply_validator_execution(self, results, metadata):
      """Validator formatting

      Args:
          results (FailResult|PassResult): result type from execution
          metadata (dict): metadata of input request

      Returns:
          ValidatorExecutionModel: model result for validation
      """
      pass

    @tracer.start_as_current_span("run_validate_with_corpus_process")
    @abstractmethod
    def _validate_with_corpus(self, value, metadata):
      """Validation of execution with corpus service

      Args:
          value (Any): input text
          metadata (dict[str, Any]): metadata of the input text

      Returns:
          dict|FailResult: Result from corpus service
      """
      pass

    @abstractmethod
    def _validate_with_ml(self, value, metadata):
      pass
