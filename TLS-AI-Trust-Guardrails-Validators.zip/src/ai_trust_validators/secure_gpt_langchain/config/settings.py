from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from .utils import find_base_path

ROOT = find_base_path()

# print("---------------", ROOT)


class EnvBaseSettings(BaseSettings):
  """Class with config for all models."""

  model_config = SettingsConfigDict(
    env_prefix="",
    env_file=f"{ROOT}\\.env",
    env_file_encoding="utf-8",
    env_nested_delimiter="__",
    case_sensitive=False,
    extra="ignore",
  )


class HttpSettings(EnvBaseSettings):
  basic_headers: dict[str, str] = {"Content-Type": "application/json", "Accept": "application/json"}
  timeout: float = Field(default=30, gt=0, validation_alias="HTTP_TIMEOUT")
  max_retries: int = Field(default=2, validation_alias="HTTP_MAX_RETRIES")


class AppSettings(EnvBaseSettings):
  """Application Settings"""

  root_path: Path = ROOT
  jwt_expiration: int = Field(default=86400, validation_alias="JWT_EXPIRATION")  # one day seconds
  jwt_algorithms: list = Field(default=["RS256"], validation_alias="JWT_ALGORITHMS")
  secure_gpt_url: str = Field(
    default="https://api.se.axa-go.applications.services.axa-tech.intraxa/ago-m365-securegpt-bapi-v1-vrs",
    validation_alias="SECURE_GPT_URL",
  )
  deployment_id: str = Field(default="gpt-35-turbo-0301", validation_alias="DEPLOYMENT_ID")
  client_id: str | None = Field(None, validation_alias="CLIENT_ID")
  client_secret: str | None = Field(None, validation_alias="CLIENT_SECRET")
  access_token: str | None = Field(None, validation_alias="ACCESS_TOKEN")
  one_account: str | None = Field(None, validation_alias="ONE_ACCOUNT")
  credentials_scope: str = Field(default="urn:grp:chatgpt", validation_alias="CREDENTIALS_SCOPE")

  no_proxy: str = Field(default="localhost,127.0.0.0/8", validation_alias="NO_PROXY")
  http: HttpSettings = HttpSettings()


@lru_cache
def get_settings():
  return AppSettings()


settings = get_settings()
# print("******************", settings)
