# libs/common/http_service.py

from __future__ import annotations

import asyncio
from typing import Any

from aiohttp import (
    ClientSession,
    ClientTimeout,
    DummyCookieJar,
    TCPConnector,
    TraceConfig,
)
from loguru import logger

from .cache import lru_acache

# ---------------------------------------------------------------------------- #
# Helpers                                                                      #
# ---------------------------------------------------------------------------- #

async def on_request_start(session: ClientSession, trace_config_ctx: Any, params: Any):
    trace_config_ctx.start = asyncio.get_event_loop().time()
    logger.info(f"Starting request {params.method}, {params.url}")

async def on_request_end(session: ClientSession, trace_config_ctx: Any, params: Any):
    elapsed = asyncio.get_event_loop().time() - trace_config_ctx.start
    logger.info(f"Request took {elapsed}s {params.method}, {params.url}")

trace_config = TraceConfig()
trace_config.on_request_start.append(on_request_start)
trace_config.on_request_end.append(on_request_end)

@lru_acache()
def aiohttp_session(
    http_total_seconds:int=1.5,
    http_connect_seconds:int=3,
    http_pool_limit_per_host:int=3
) -> ClientSession:
    """
    Return a singleton aiohttp.ClientSession configured
    from CONFIG.settings.http.
    """
    logger.info(
        f"Created global aiohttp ClientSession(total={http_connect_seconds}s"
        f"connect={http_total_seconds}s pool={http_pool_limit_per_host}s)"
    )
    return ClientSession(
        auto_decompress=True,
        cookie_jar=DummyCookieJar(),
        timeout=ClientTimeout(
            total=http_total_seconds,
            connect=http_connect_seconds,
        ),
        connector=TCPConnector(limit_per_host=http_pool_limit_per_host),
        trust_env=False,
        trace_configs=[trace_config]
    )


@lru_acache()
async def async_aiohttp_session(
    http_total_seconds:int=1.5,
    http_connect_seconds:int=3,
    http_pool_limit_per_host:int=3
) -> ClientSession:
    """
    Return a singleton aiohttp.ClientSession configured
    from properties
    """
    logger.info(
        f"Created global aiohttp ClientSession(total={http_connect_seconds}s"
        f" connect={http_total_seconds}s pool={http_pool_limit_per_host}s)"
    )
    return ClientSession(
        auto_decompress=True,
        cookie_jar=DummyCookieJar(),
        timeout=ClientTimeout(
            total=http_total_seconds,
            connect=http_connect_seconds,
        ),
        connector=TCPConnector(
            limit_per_host=http_pool_limit_per_host
        ),
        trust_env=True,
        trace_configs=[trace_config]
    )
