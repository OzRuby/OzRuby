import os
from contextlib import AbstractAsyncContextManager
from datetime import UTC, datetime
from http import HTTPStatus
from typing import Annotated, Any, Literal

from aiohttp import ClientResponseError
from httpx_sse import EventSource, aconnect_sse, connect_sse
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
  AIMessage,
  BaseMessage,
  ChatMessage,
  HumanMessage,
  SystemMessage,
)
from langchain_core.outputs import ChatGeneration
from loguru import logger
from pydantic import SecretStr
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from .base_aiohttp import aiohttp_session, async_aiohttp_session

# Define the type for PromptType
PromptType = Annotated[str, Literal["CHAT_COMPLETIONS", "STREAM_CHAT_COMPLETIONS", "EMBEDDINGS"]]

access_token = None
token_expiration = datetime.now(UTC)


class BaseBAPI(BaseChatModel):
  """
  Base class for BAPI operations, handling authentication and configuration.

  BAPI (Secure GPT Business API) is a secure API used for various business-related
  operations with GPT, including chat completions, streaming chat completions, and embeddings.

  Attributes:
    one_login_base_url (str): The base URL for OneLogin, retrieved from environment variables.
    one_login_url (str): The URL endpoint for token authentication.
    client_id (str): The client ID for authentication, retrieved from environment variables.
    client_secret (str): The client secret for authentication, retrieved from environment variables.
    api_base_url (str): The base URL for BAPI, retrieved from environment variables.
    api_timeout (float): The timeout setting for BAPI, retrieved from environment variables.
    access_token (str): The current access token for authentication.
    provider_name (str): provider name
    api_version (str): api version
    api_type (str): api type
    deployment_id (str | None): The deployment ID, defaulting to "gpt-35-turbo-0301".
    prompt_type (PromptType): The type of prompt, defaulting to "CHAT_COMPLETIONS".
    external_securegpt_token (SecretStr): External OneAccount Token from app source
    nb_attempt (int): number of attempt
    multiplier (int): number of multiplier
    min_wait (int): min wait
    max_wait (int): max wait
    http_total_seconds (int): http total seconds
    http_connect_seconds (int): http connect seconds
    http_pool_limit_per_host (int): http pool limit per host
  """

  one_login_base_url: str = os.environ.get("ONE_LOGIN_URL")
  one_login_url: str = "/as/token.oauth2"
  client_id: str = os.environ.get("CLIENT_ID")
  client_secret: str = os.environ.get("CLIENT_SECRET")
  api_base_url: str = os.environ.get("BAPI_URL")
  api_timeout: float = float(os.environ.get("api_timeout", 10.0))  # Default to 10.0 if not set
  api_type: str = os.environ.get("API_TYPE")
  access_token: str = ""
  provider_name: str = os.environ.get("BAPI_PROVIDER_NAME")
  api_version: str = os.environ.get("BAPI_VERSION")
  deployment_id: str = "gpt-35-turbo-0301"
  prompt_type: PromptType = "CHAT_COMPLETIONS"
  external_securegpt_token: SecretStr = None
  # retry config
  nb_attempt: int = 5  # Number of retry attempts
  multiplier: int = 1  # Initial wait time in seconds
  min_wait: int = 2    # Minimum wait time in seconds
  max_wait: int = 10   # Maximum wait time in seconds
  # aiohttp config
  http_total_seconds: int = 1.5
  http_connect_seconds: int = 3
  http_pool_limit_per_host: int = 3

  def read_local_token(self, retry: bool = False) -> list:
    """Read temporary local token

    Args:
      retry (bool): Whether to force retry for a new access token.

    Returns:
      list: token, expiration date
    """
    if retry:
      return None, None  # noqa: E701

    try:
      with open(".tk") as wr:
        token_form = wr.read()
        if len(token_form) > 10:
          access_token, date_expiration = token_form.split("\t")
          format = "%Y-%m-%dT%H:%M:%S.%f"
          datetime_str = datetime.strptime(date_expiration, format)
          return access_token, datetime_str
        else:
          logger.info("Bad oauth2 token format in memory")
          return None, None
    except Exception as e:
      logger.info(f"Cannot get oauth2 token from memory: {str(e)}")
      return None, None

  def write_local_token(self, token, expiration) -> None:
    """Write local token

    Args:
      token (str): secure GPT oauth2 token
      expiration (datetime): expiration starting date
    """
    with open(".tk", "w") as wr:
      expiration = expiration.strftime("%Y-%m-%dT%H:%M:%S.%f")
      wr.write(f"{token}\t{expiration}")
      logger.info("Successfully write local oauth2 token.")

  @retry(
    retry=retry_if_exception_type(ClientResponseError),
    stop=stop_after_attempt(nb_attempt),
    reraise=True,
    wait=wait_exponential(multiplier=multiplier, min=min_wait, max=max_wait),
  )
  def sync_access_token(self, retry: bool = False) -> str:
    """
    Synchronously retrieves a new access token if not present or retry is True.

    Args:
      retry (bool): Whether to force retry for a new access token.

    Returns:
       str: The new access token.
    """
    access_token, token_expiration = self.read_local_token()
    if access_token and token_expiration:
      delta_token_expiration = datetime.now(UTC).replace(tzinfo=None) - token_expiration
      if delta_token_expiration.total_seconds() < 300:  # to fix later with config
        self.access_token = access_token
        logger.info(f"Successfully get oauth2 token from memory: - [token={self.access_token[:19]}...]")
        return self.access_token

    if retry or not self.access_token:
      payload, headers = self._get_one_login_payload()
      client_session =  aiohttp_session(
        http_total_seconds = self.http_total_seconds,
        http_connect_seconds = self.http_connect_seconds,
        http_pool_limit_per_host = self.http_pool_limit_per_host
      )
      req_url = self.one_login_base_url + self.one_login_url
      with client_session.post(req_url, data=payload, headers=headers) as response:
        response.raise_for_status()
        self.access_token = response.json().get("access_token")
        token_expiration = datetime.now(UTC)
        self.write_local_token(self.access_token, token_expiration)
        logger.info("Successfully called one-login oauth2.")

    logger.info(f"Successfully obtained access token - [token={self.access_token[:19]}...]")
    return self.access_token

  @retry(
    retry=retry_if_exception_type(ClientResponseError),
    stop=stop_after_attempt(nb_attempt),
    reraise=True,
    wait=wait_exponential(multiplier=multiplier, min=min_wait, max=max_wait),
  )
  async def async_access_token(self, retry: bool = False) -> str:
    """
    Asynchronously retrieves a new access token if not present or retry is True.

    Args:
      retry (bool): Whether to force retry for a new access token.

    Returns:
      str: The new access token.
    """
    access_token, token_expiration = self.read_local_token()
    if access_token and token_expiration:
      delta_token_expiration = datetime.now(UTC).replace(tzinfo=None) - token_expiration
      if delta_token_expiration.total_seconds() < 300:
        self.access_token = access_token
        logger.info(f"Successfully get oauth2 token from memory: - [token={self.access_token[:19]}...]")
        return self.access_token

    if retry or not self.access_token:
      payload, headers = self._get_one_login_payload()
      async_client_session = await async_aiohttp_session(
        http_total_seconds = self.http_total_seconds,
        http_connect_seconds = self.http_connect_seconds,
        http_pool_limit_per_host = self.http_pool_limit_per_host
      )
      req_url = self.one_login_base_url + self.one_login_url
      async with async_client_session.post(req_url, data=payload, headers=headers) as response:
        response.raise_for_status()
        resp_json = await response.json()
        self.access_token = resp_json.get("access_token")
        access_token = self.access_token
        token_expiration = datetime.now(UTC)
        self.write_local_token(self.access_token, token_expiration)
        logger.info("Successfully called one-login oauth2.")

    logger.info(f"Successfully obtained access token - [token={self.access_token[:19]}...]")
    return self.access_token

  @retry(
      retry=retry_if_exception_type(ClientResponseError),
      stop=stop_after_attempt(nb_attempt),
      reraise=True,
      wait=wait_exponential(multiplier=multiplier, min=min_wait, max=max_wait),
  )
  def sync_bapi_call(self, payload: Any, access_token_retry: bool = False) -> dict:
    """
    Synchronously makes a BAPI call.

    Args:
        payload (Any): The payload for the BAPI call.
        access_token_retry (bool): Whether to retry fetching the access token if the call fails.

    Returns:
        dict: The response from the BAPI call.
    """
    if self.external_securegpt_token:
      logger.info("------ Using external Aouth token")
      access_token = self.external_securegpt_token.get_secret_value()
    else:
      access_token = self.sync_access_token(retry=access_token_retry)
    url, headers, _payload = self._get_bapi_headers_and_url(access_token, payload)
    try:
      #logger.info(f"------ {url}, {headers}, {_payload} {self.api_base_url}")
      client_session = aiohttp_session(
        http_total_seconds = self.http_total_seconds,
        http_connect_seconds = self.http_connect_seconds,
        http_pool_limit_per_host = self.http_pool_limit_per_host
      )
      req_url = self.api_base_url + url
      response = client_session.post(req_url, json=_payload, headers=headers, ssl=False)
      response.raise_for_status()
      logger.info("Successfully called BAPI endpoint.")
      return response.json()
    except ClientResponseError as err:
      if err.response.status_code in [HTTPStatus.FORBIDDEN, HTTPStatus.UNAUTHORIZED] and not access_token_retry:
        return self.sync_bapi_call(payload, access_token_retry=True)
      logger.error(f"Error occurred in BAPI call - [error={err.response}]")
      raise err

  @retry(
      retry=retry_if_exception_type(ClientResponseError),
      stop=stop_after_attempt(nb_attempt),
      reraise=True,
      wait=wait_exponential(multiplier=multiplier, min=min_wait, max=max_wait),
  )
  async def async_bapi_call(self, payload: Any, access_token_retry: bool = False) -> dict:
    """
    Asynchronously makes a BAPI call.

    Args:
        payload (Any): The payload for the BAPI call.
        access_token_retry (bool): Whether to retry fetching the access token if the call fails.

    Returns:
        dict: The response from the BAPI call.
    """
    access_token = None
    if self.external_securegpt_token:
      logger.info("------ Using external Aouth token")
      access_token = str(self.external_securegpt_token.get_secret_value())
    else:
      access_token = await self.async_access_token(retry=access_token_retry)
    url, headers, _payload = self._get_bapi_headers_and_url(access_token, payload)
    #logger.info(f"------ {url}, {headers}, {_payload} {self.api_base_url}")
    async_client_session = await async_aiohttp_session(
      http_total_seconds = self.http_total_seconds,
      http_connect_seconds = self.http_connect_seconds,
      http_pool_limit_per_host = self.http_pool_limit_per_host,
    )
    req_url = self.api_base_url + url
    async with async_client_session.post(req_url, json=_payload, headers=headers) as response:
      response.raise_for_status()
      logger.info(f"Successfully called BAPI endpoint with status {response.status}.")
      json_response = await response.json()
      return json_response

  @retry(
      retry=retry_if_exception_type(Exception),
      stop=stop_after_attempt(nb_attempt),
      reraise=True,
      wait=wait_exponential(multiplier=multiplier, min=min_wait, max=max_wait),
  )
  def sync_bapi_stream(self, payload: list[dict]):
    """
    Synchronously makes a streaming BAPI call.

    Args:
        payload (list[dict]): The payload for the BAPI call.

    Yields:
        dict: The streaming response from the BAPI call.
    """
    access_token = self.sync_access_token(retry=False)
    url, headers, _payload = self._get_bapi_headers_and_url(access_token, payload)

    def handle(event_source: EventSource):
      for event in event_source.iter_sse():
        if event.data == "":
          continue
        if event.data == "[DONE]":
          return
        yield event.json()

    client_session = aiohttp_session(
      http_total_seconds = self.http_total_seconds,
      http_connect_seconds = self.http_connect_seconds,
      http_pool_limit_per_host = self.http_pool_limit_per_host
    )
    #with Client(base_url=self.one_login_base_url, verify=False) as client:
    req_url = self.api_base_url + url
    #with Client(base_url=self.api_base_url, headers=headers, timeout=self.api_timeout, verify=False) as client:
    with connect_sse(client_session, "POST", req_url, json=_payload) as event_source:
      yield handle(event_source)

  @retry(
      retry=retry_if_exception_type(Exception),
      stop=stop_after_attempt(nb_attempt),
      reraise=True,
      wait=wait_exponential(multiplier=multiplier, min=min_wait, max=max_wait),
  )
  async def async_bapi_stream(self, payload: list[dict]):
    """
    Asynchronously makes a streaming BAPI call.

    Args:
        payload (list[dict]): The payload for the BAPI call.

    Yields:
        dict: The streaming response from the BAPI call.
    """
    access_token = await self.async_access_token(retry=False)
    url, headers, _payload = self._get_bapi_headers_and_url(access_token, payload)

    async def handle(event_source_cm: AbstractAsyncContextManager[EventSource]):
      async with event_source_cm as event_source:
        async for sse in event_source.aiter_sse():
          if sse.data == "[DONE]":
            return
          if sse.data == "":
            continue
          yield sse.json()

    async_client_session = await async_aiohttp_session(
      http_total_seconds = self.http_total_seconds,
      http_connect_seconds = self.http_connect_seconds,
      http_pool_limit_per_host = self.http_pool_limit_per_host
    )
    req_url = self.api_base_url + url
    event_source = await aconnect_sse(async_client_session, "POST", req_url, json=_payload)

    return handle(event_source)

  def _get_one_login_payload(self) -> tuple[dict, dict]:
    """
    Creates the payload and headers for OneLogin token request.

    Returns:
        tuple[dict, dict]: The payload and headers for the request.
    """
    payload = {
      "client_id": self.client_id,
      "client_secret": self.client_secret,
      "scope": "urn:grp:chatgpt",
      "grant_type": "client_credentials",
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    return payload, headers

  @classmethod
  def _parse_bapi_message(cls, message: BaseMessage) -> dict:
    """
    Parses a message object into a dictionary suitable for the BAPI.

    Args:
        message (BaseMessage): The message object to parse.

    Returns:
        dict: The parsed message.
    """
    if isinstance(message, ChatMessage):
      return {"role": message.role, "content": message.content}
    if isinstance(message, HumanMessage):
      return {"role": "user", "content": message.content}
    if isinstance(message, AIMessage):
      return {"role": "assistant", "content": message.content}
    if isinstance(message, SystemMessage):
      return {"role": "system", "content": message.content}
    raise TypeError(f"Got unknown type {message}")

  def _parse_bapi_chat_generations(self, response: dict[str, Any]) -> list[ChatGeneration]:
    """
    Parses the BAPI response into a list of chat generations.

    Args:
        response (dict[str, Any]): The response from the BAPI call.

    Returns:
        list[ChatGeneration]: A list of chat generations parsed from the response.
    """
    def base_message(message: dict[str, Any]) -> BaseMessage:
      role = message.get("role")
      content = message.get("content", "")

      if role == "user":
        return HumanMessage(content=content)
      if role == "assistant":
        return AIMessage(content=content)
      if role == "system":
        return SystemMessage(content=content)
      return ChatMessage(content=content, role=role)

    return [
      ChatGeneration(
        message=base_message(ch.get("message")),
        generation_info={"finish_reason": ch.get("finish_reason")},
      )
      for ch in response.get("choices", [])
    ]

  def _get_bapi_headers_and_url(self, access_token: str, payload: Any) -> tuple[str, dict, dict]:
    """
    Generates the URL, headers, and payload for a BAPI request.

    Args:
        access_token (str): The access token for authorization.
        payload (Any): The payload for the BAPI request.

    Returns:
        tuple[str, dict, dict]: The URL, headers, and formatted payload for the request.
    """
    if self.api_type == "modelhub":
      base_url = f"/providers/{self.provider_name}/deployments/{self.deployment_id}"
      url = f"{base_url}/completions?api-version={self.api_version}"
    else:  # Handle "bapi" or other types
      base_url = f"/deployments/{self.deployment_id}"
      url = f"{base_url}/chat/completions"

    # Adjust URL and payload based on prompt_type
    _payload = {"messages": payload}
    if self.prompt_type == "STREAM_CHAT_COMPLETIONS":
      url = f"{base_url}/stream/chat/completions"
    elif self.prompt_type == "EMBEDDINGS":
      url = f"{base_url}/embeddings"
      _payload = {"input": payload}

    headers = {
      "content-type": "application/json",
      "Authorization": f"Bearer {access_token}",
    }
    return url, headers, _payload
