import asyncio
import os

from langchain_core.embeddings import Embeddings

from .base_bapi import BaseBAPI


class EmbeddingBAPI(BaseBAPI, Embeddings):
  """
  A class for generating embeddings using the SecureGPT BAPI.

  This class provides both synchronous and asynchronous methods for generating
  embeddings for documents and queries.
  """

  def _sync_bapi_call(self, input: str | list[str | int | list[int]]) -> list[float]:
    """
    Make a synchronous BAPI call to generate embeddings.

    Args:
        input (str | list[str | int | list[int]]): The input text or list of texts to embed.

    Returns:
        List[float]: The generated embedding.

    Notes:
        - Replaces newlines in the input text to avoid performance issues.
    """
    if isinstance(input, str):
      input = input.replace(os.linesep, " ")

    response = self.sync_bapi_call(input)
    return response.get("data")[0].get("embedding")  # type: ignore

  async def _async_bapi_call(self, input: str | list[str | int | list[int]]) -> list[float]:
    """
    Make an asynchronous BAPI call to generate embeddings.

    Args:
        input (str | list[str | int | list[int]]): The input text or list of texts to embed.

    Returns:
        List[float]: The generated embedding.

    Notes:
        - Replaces newlines in the input text to avoid performance issues.
    """
    if isinstance(input, str):
      input = input.replace(os.linesep, " ")

    response = await self.async_bapi_call(input)
    return response.get("data")[0].get("embedding")  # type: ignore

  def embed_documents(self, texts: list[str]) -> list[list[float]]:
    """
    Generate embeddings for a list of documents synchronously.

    Args:
        texts (List[str]): A list of documents to embed.

    Returns:
        List[List[float]]: A list of embeddings for each document.
    """
    embeddings = [self._sync_bapi_call(text) for text in texts]
    return embeddings

  def embed_query(self, input: str | list[str | int | list[int]]) -> list[float]:
    """
    Generate an embedding for a query synchronously.

    Args:
        input (str | list[str | int | list[int]]): The input query to embed.

    Returns:
        List[float]: The generated embedding.
    """
    return self._sync_bapi_call(input)

  async def aembed_query(self, input: str | list[str | int | list[int]]) -> list[float]:
    """
    Generate an embedding for a query asynchronously.

    Args:
        input (str | list[str | int | list[int]]): The input query to embed.

    Returns:
        List[float]: The generated embedding.
    """
    return await self._async_bapi_call(input)

  async def aembed_documents(self, texts: list[str]) -> list[list[float]]:
    """
    Generate embeddings for a list of documents asynchronously.

    Args:
        texts (List[str]): A list of documents to embed.

    Returns:
        List[List[float]]: A list of embeddings for each document.
    """
    result = await asyncio.gather(*[self.aembed_query(text) for text in texts])
    return list(result)
