<p align="center">
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/AXA_Logo.svg/1023px-AXA_Logo.svg.png" width="151" alt="Cute AXA Partners logo">
</p>

# <p align="center"> AI Trust validators </p> <p align="center" style="font-size: 12px"> AI Trust - End to end guardrails solution</p>

`AI Trust validators` is one of the 3 components of AI Trust solution. It is designed to bring guard package capabilities that will be used by the AI Trust Service (function app) when AI Trust SDK will call him.

`Validator` is an observer package that act as policy or antivirus (any problem raises by AI application) for specific domain (hallucination, prompt injection, chunks relevance, etc.) in a specific AI/GenAI component (Search engine, LLM output, user input, etc.).

This documentation show how to build and use validators tools for AI trust services.

# Validators overview

| Validator | Description | Type | Status | Integrated in service | Deploy in service| Developer |
| --- | --- |--- |--- |--- |--- |--- |
| [Prompt_injection](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/prompt_injection&version=GBdevelop&_a=contents) | Identifies prompt injection attacks in user queries using a large language model (LLM). Analyzes input for malicious components and outputs PASS or FAIL. | LLM based | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [chunks_relevance](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/chunks_relevance&version=GBdevelop) | Assesses the relevance of chunks to user queries with an LLM. Outputs PASS or FAIL based on the relevance analysis. | LLM based |  `Tested` :heavy_check_mark: | :x: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [answer_relevance](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/answer_relevance&version=GBdevelop) | Evaluates the relevance of chatbot responses to user queries using an LLM. Outputs PASS or FAIL based on the assessment of the response. | LLM based |  `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [queryTopic_checker](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/README.md&version=GBvalidator-query_topic_checker&_a=preview) | Checks if the user query aligns with accepted chatbot topics. Provides a PASS or FAIL output based on the relevance to the topics.| LLM based - Embeddings | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [keywords_filtering](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/keywords_filtering&version=GBdevelop) | Identifies keywords in user queries using specified methods. Outputs PASS or FAIL based on the findings. | Regex based | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [grammar_checker](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/grammar_checker&version=GBdevelop) | Checks the grammaticality of input text and provides a PASS or FAIL output based on identified errors.| LLM based | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Elvis Mboning](elvis.mboningtchiaze.devoteam@axapartners.com) |
| [format_checker](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/format_checker&version=GBdevelop) | Identifies errors in the format and encoding of input queries. Outputs PASS or FAIL based on the identified errors.| LLM based | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [calculation_logic](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/calculation_logic&version=GBdevelop) | Assesses the calculation logic of an LLM by analyzing relevant chunks and user queries. Outputs PASS or FAIL based on the assessment results.| LLM based | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [language_checker](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/language_checker&version=GBdevelop) | Checks if the chatbot response is in the expected language. Outputs PASS or FAIL based on the assessment results.| ML based | `Tested` :heavy_check_mark: | `Integrated` :heavy_check_mark: | :x: | [Moussa Aboubakar](moussa.aboubakar.devoteam@axapartners.com) |
| [Hallucinations](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/hallucinations) | Analyzes the response generated by an LLM in conjunction with its associated context. It evaluates the accuracy and relevance of the response by comparing it against the provided context (chunks) and determines whether hallucinations are present| ML based | `Tested` :heavy_check_mark: | :x: | :x: | [KAIS LARIBI](kais.laribi.external@axa.com) |
| [Auzre Content Safety](https://aasolutions.visualstudio.com/aa_holding_data_and_innovation/_git/TLS-AI-Trust-Guardrails-Validators?path=/src/ai_trust_validators/validators/azure_content_safety) | Designed to analyze responses generated by large language models (LLMs) in conjunction with their associated context. It evaluates the  safety of the responses by leveraging four key endpoints from [Azure AI content Safety](https://learn.microsoft.com/en-us/azure/ai-services/content-safety/). Through configuration, users can enable or disable specific checks based on their requirements, providing flexibility and control over the validation process. | ML based | `Tested` :heavy_check_mark: | :x: | :x: | [Kais LARIBI](kais.laribi.external@axa.com) |

# Build and Test

- You need to be in your working directory
- Create a DEV environnement

```sh

uv venv --python 3.11.0
```

- [Windows] Activate your environnement

```sh

.venv\Scripts\activate.ps1
```

- [Linux] Activate your environnement

```sh

.venv\Scripts\activate
```

- Install dependencies and build `ai_trust_validators` package

```sh

uv sync
```

- Run tests for all validators

```sh

uv run pytest -v
```

- Run tests coverage

```sh

uv run coverage run -m pytest
uv run coverage report
```

- Run code formatting quality (linting with ruff)

```sh

uv run ruff check
```

# How to use ?

- Go to each validators folder to see how to use

```sh

src/ai_trust_validators/validators/<validator_name>

```

## Validator dependencies

- Each validator depends on 2 models
  - `ValidateMetadataModel` = metadata model get from validator
  - `ValidatorRequestModel` = request model sent by SDK service

```python

from ai_trust_validators.share_models.validator import ValidatorRequestModel

from ai_trust_validators.validators.<validator_name>.src.models.input_output import ValidateMetadataModel

```

## Run Validator

- To reproduce the validator with sdk code (replace <> with your validator name)

```python

from ai_trust_validators.validators.<validator_name> import <validator_class_name>

```

- To test the validator with sample of code (replace <> with your validator name)

```bash

uv run  .\src\ai_trust_validators\validators\<validator_name>\run_validator.py

```

- To run the validator script

```bash

uv run  <validator_name> --input <text> --<parameter_name>=<parameter_value> ...

```

# How to Contribute ?

Contribution could be 3 types:

- Contribute on existing validator
- Create new validator
- Contribute to a global validators package

Make sure to have a good DEV environnement setup

- `uv` package manager
- `python` version `3.11.9`
- `AXA ssl certificate` get them from other developers
- `OneAccount access for secureGPT` get them from other developers

## Contribute on existing validator

- Clone this repository
- Identify the validators you want to work in `src/ai_trust_validators/validators/<validator_name>`
- Create new branch with this format `<validator_name>_<your_subname>`
- Make your udpate
  - Update the validator's code
  - Update the validator's documentation
  - Update the validator's tests
  - Run the command `uv run pytest .\tests\<validator_name> -v` to validate your tests. All your tests should pass and make a screenshot
- Push your git branch to the remote branch `<validator_name>_<your_subname>`
- Create a pull request to `develop` branch and add the main validator developer as reviewer
- Wait approval from other developers
- If you have a comment, update your code and wait until approval
- Reviewed will merge the code at the end

## Create new validator

- Clone this repository
- Create new branch with this format `<your_validator_name>`
  - Validator name need to match `[az]` (ansci letters in lowercase)
  - Validator name can contain only `_` for space separation
- Copy a base validator `src/ai_trust_validators/validators/grammar_checker`
- Make your udpate
  - Rename the validator name `grammar_checker` to `<your_validator_name>`
  - Add your validator dependencies and script to the main `.\pyproject.toml`
  - Update the validator's code
  - Add the validator's documentation in `.\docs`
  - Add the validator's tests
  - Run the command `uv run pytest .\tests\<your_validator_name> -v` to validate your tests. All your tyest should pass and make a screenshot
- Push your git branch to the remote branch `<your_validator_name>`
- Create a pull request to `develop` branch and add the all other validator developers as reviewers
- Wait approval from other developers
- If you have a comment, update your code and wait until approval
- Reviewed will merge the code at the end

## Contribute to a global validators package

- Clone this repository
- Create new branch with this format `<validator_name>_<your_subname>`
- Make your udpate
  - Update the validator's documentation
  - Update the validator's tests
  - Run the command `uv run pytest -v` to validate all validators tests. All your test should pass and make a screenshot
- Push your git branch to the remote branch `<validator_name>_<your_subname>`
- Create a pull request to `develop` branch and add the all validator developers as reviewer
- Wait approval from other developers
- If you have a comment, update your code and wait until approval
- Reviewed will merge the code at the end
