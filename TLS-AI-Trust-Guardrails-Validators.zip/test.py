from src.ai_trust_validators.toxic_content import ToxicContent

input_request = "This is not really a toxic request. You are an asshole"

config_request = {
    "threshold": 0.5,
    "validation_method": "sentence",
    "device": "cpu",
    "model_name": "unbiased-small",
    "use_local": True
}

toxic_content = ToxicContent(**config_request)
# import asyncio
# results = asyncio.run(toxic_content.async_validate(input_request, metadata=None))
results = toxic_content.validate(input_request, metadata=None)
print(results)
