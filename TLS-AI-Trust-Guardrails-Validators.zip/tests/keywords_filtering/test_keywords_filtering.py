from uuid import uuid4

import pytest
from guardrails.validators import (
  FailResult,
  PassResult,
)
from pydantic_core import ValidationError

from ai_trust_validators.validators.keywords_filtering.src.libs.process import KeywordFiltering
from ai_trust_validators.validators.keywords_filtering.src.models.input_output import ValidateMetadataModel
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorMethodEnum, 
    ValidatorRequestModel,
    ValidatorResponseStatusEnum,
    ValidatorPriorityEnum, 
    ValidatorExecutionStatusEnum)

@pytest.mark.asyncio
@pytest.mark.parametrize(
  "user_query",
  [
    ("What types of coverage are available for unexpected medical situation while traveling?"),
    ("How can I file a claim for property damage caused by a natural disaster?"),
    ("What support services are offered for individuals facing unexpected health crises?"),
    ("Can I get assistance for non-medical emergencies during my trip abroad?"),
    ("What is the process to obtain financial reimbursement for lost personal belongings?"),
    
  ],
)
async def test_relevance_filtering_pass(user_query):
  # Arrange
  config_parameters = ValidateMetadataModel(
        content_type="text",
        keywords_filtering=["Bereavement",
                            "Death",
                            "Death of a close relative",
                            "Pregnancy with complications",
                            "Victims of assault",
                            "sexual assault",
                            "violence",
                            "violence while abroad"
                            "terrorism",
                            "Emergency",
                            "Emergency Assistance"]
    )

    # Validator config
  validator_configuration= ValidatorConfig(
          name="keywords_filtering", validator_type="event_based", endpoint_url="validator/keywords_filtering", priority= ValidatorPriorityEnum.P1,
      )

  # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name="France",
      partner_name="PUFFIN",
      project_name="Travel General Enquiries",
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.REGEX,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )


  keyword_filter = KeywordFiltering(validator_request)

  # Act
  validation_result = await keyword_filter.validate(user_query, metadata={})

  # Assert
  assert validation_result.execution_status == ValidatorExecutionStatusEnum.COMPLETED
  assert validation_result.response.status == ValidatorResponseStatusEnum.PASS
  


@pytest.mark.asyncio
@pytest.mark.parametrize(
  "user_query",
  [
    ("How does my insurance policy cover bereavement leave and related expenses?"),
    ("What steps should I take to file a claim after the death of a close relative?"),
    ("Are there specific insurance options for victims of assault, including sexual assault?"),
    ("What types of coverage are available for emergency related to pregnancy with complications?"),
    ("Does my travel insurance provide assistance in cases of violence while abroad or terrorism-related incidents?"),
  ],
)
async def test_relevance_filtering_fail(user_query):
  # Arrange
  config_parameters = ValidateMetadataModel(
        content_type="text",
        keywords_filtering=["Bereavement",
                            "Death",
                            "Death of a close relative",
                            "Pregnancy with complications",
                            "Victims of assault",
                            "sexual assault",
                            "violence",
                            "violence while abroad"
                            "terrorism",
                            "Emergency",
                            "Emergency Assistance"]
    )

  # Validator config
  validator_configuration= ValidatorConfig(
          name="keywords_filtering", validator_type="event_based", endpoint_url="validator/keywords_filtering", priority= ValidatorPriorityEnum.P1,
      )

  # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name="France",
      partner_name="PUFFIN",
      project_name="Travel General Enquiries",
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.REGEX,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )

  keyword_filter = KeywordFiltering(validator_request)
  # Act
  validation_result = await keyword_filter.validate(user_query, metadata={})

  # Assert
  assert validation_result.execution_status == ValidatorExecutionStatusEnum.COMPLETED
  assert validation_result.response.status == ValidatorResponseStatusEnum.FAILED
  


@pytest.mark.asyncio
async def test_keyword_filtering_with_empty_user_query():
  config_parameters = ValidateMetadataModel(
        content_type="text",
        keywords_filtering=["Bereavement",
                            "Death",
                            "Death of a close relative",
                            "Pregnancy with complications",
                            "Victims of assault",
                            "sexual assault",
                            "violence",
                            "violence while abroad"
                            "terrorism",
                            "Emergency",
                            "Emergency Assistance"]
    )

  # Validator config
  validator_configuration= ValidatorConfig(
          name="keywords_filtering", validator_type="http_based", endpoint_url="validator/keywords_filtering", priority= ValidatorPriorityEnum.P1,
      )

  # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name="France",
      partner_name="PUFFIN",
      project_name="Travel General Enquiries",
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.REGEX,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )

  keyword_filter = KeywordFiltering(validator_request)
  # Act
  validation_result = await keyword_filter.validate("", metadata={})  # Providing an empty user query

  # Assert
  assert validation_result.execution_status == ValidatorExecutionStatusEnum.PARAMS_ERROR  


@pytest.mark.asyncio
async def test_keyword_filter_bad_validator_request():
  # Arrange
  # Prepare invalid data for ValidatorRequestModel
  invalid_request_data = {
    "request_id": "not-a-uuid",  # Invalid UUID
    "pipeline_execution_id": uuid4(),
    "project_name": "Travel General Enquiries",
    "scope":"DEV",
    "country_name":"France",
    "partner_name":"PUFFIN",
    "validator_config": "invalid_validator_configuration",
    "validator_execution_id": uuid4(),
    "validator_config": "invalid_validator_config",
    "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
    "validation_method": "invalid_method",  # Invalid validation method
    "user_payload": None,
    "config_parameters": {"devise": "cpu", "language": "english"},
  }

  # Assert that a ValidationError is raised for bad ValidatorRequestModel
  with pytest.raises(ValidationError) as exc_info:
    ValidatorRequestModel(**invalid_request_data)  # Attempt to create model with bad request data

  # Printing the errors for debugging purposes
  print(exc_info.value.errors())  # Print the validation errors

  # Assert that the error contains validation issues
  assert len(exc_info.value.errors()) > 0
  assert any("request_id" in str(error) for error in exc_info.value.errors())
  assert any("validation_method" in str(error) for error in exc_info.value.errors())
