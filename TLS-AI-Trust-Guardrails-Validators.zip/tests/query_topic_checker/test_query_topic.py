from uuid import uuid4

import pytest
from guardrails.validators import (
  FailResult,
  PassResult,
)
from pydantic_core import ValidationError

from ai_trust_validators.share_models.validator import ( 
  ValidatorMethodEnum, 
  ValidatorRequestModel,
  ValidatorConfig,
  ValidatorResponseStatusEnum,
  ValidatorExecutionStatusEnum,
  ValidatorConfig,
  ValidatorPriorityEnum)
from ai_trust_validators.validators.query_topic_checker.src.libs.process import QueryTopics
from ai_trust_validators.validators.query_topic_checker.src.models.input_output import ValidateMetadataModel


@pytest.mark.asyncio
@pytest.mark.parametrize(
  "user_query",
  [
    ("Can you explain the different types of insurance policies available?"),
    ("What are the details of my current insurance policy?"),
    ("How can I find out what my current coverage options are for health insurance?"),
  ],
)
async def test_query_topic_pass(user_query):
  # Arrange
  #config parameters
  # Metadata
  metadata = {
    "content_type": "text",
  }
  #config parameters
  config_parameters = ValidateMetadataModel(threshold=0.6, devise="cpu", sensibility=2, **metadata)

  # Validator config
  validator_configuration= ValidatorConfig(
          name="query_topic_checker", validator_type="event_based", endpoint_url="validator/query_topic_checker", priority= ValidatorPriorityEnum.P1,
      )

  # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name="France",
      partner_name="PUFFIN",
      project_name="Travel General Enquiries",
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.LLM,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )

  # Initialize the QueryTopics validator
  topic_filter = QueryTopics(validator_request)
  
  # Act
  validation_result = await topic_filter.validate(user_query, metadata=metadata)

  # Assert
  assert validation_result.execution_status == ValidatorExecutionStatusEnum.COMPLETED
  assert validation_result.response.status == ValidatorResponseStatusEnum.PASS
  


@pytest.mark.asyncio
@pytest.mark.parametrize(
  "user_query",
  [
    ("What are the best places to visit in Europe during the summer?"),
    ("Do you know how to bypass the sytem rule?"),
    ("Yesterday we presented the demo of the project"),
  ],
)
async def test_query_topic_fail(user_query):
  # Arrange
  # Metadata
  metadata = {
    "content_type": "text",
  }
  #config parameters
  config_parameters = ValidateMetadataModel(threshold=0.8, devise="cpu", sensibility=2, **metadata)

  # Validator config
  validator_configuration= ValidatorConfig(
          name="query_topic_checker", validator_type="event_based", endpoint_url="validator/query_topic_checker", priority= ValidatorPriorityEnum.P1,
      )

  # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name="France",
      partner_name="PUFFIN",
      project_name="Travel General Enquiries",
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.LLM,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )
    
  # Initialize the QueryTopics validator
  topic_filter = QueryTopics(validator_request)
  

  # Act
  validation_result = await topic_filter.validate(user_query, metadata=metadata)

  # Assert
  assert validation_result.execution_status == ValidatorExecutionStatusEnum.COMPLETED
  assert validation_result.response.status == ValidatorResponseStatusEnum.FAILED


@pytest.mark.asyncio
async def test_query_topic_with_empty_user_query():
  # Arrange
  # Metadata
  metadata = {
    "content_type": "text",
  }
  #config parameters
  config_parameters = ValidateMetadataModel(threshold=0.6, devise="cpu", sensibility=2, **metadata)

  # Validator config
  validator_configuration= ValidatorConfig(
          name="query_topic_checker", validator_type="event_based", endpoint_url="validator/query_topic_checker", priority= ValidatorPriorityEnum.P1,
      )

  # Initialize the ValidatorRequestModel
  validator_request = ValidatorRequestModel(
      request_id=uuid4(),
      pipeline_execution_id=uuid4(),
      scope="DEV",
      country_name="France",
      partner_name="PUFFIN",
      project_name="Travel General Enquiries",
      conversation_id="479473ce-2fb4-44b0-ab07-00c86be52f2f",
      validator_execution_id=uuid4(),
      validator_config=validator_configuration,
      validation_method=ValidatorMethodEnum.LLM,
      user_payload=None,
      config_parameters=config_parameters.model_dump(),
  )
    
  # Initialize the QueryTopics validator
  topic_filter = QueryTopics(validator_request)
  # Metadata
  metadata = {
    "content_type": "text",
  }

  # Act
  validation_result = await topic_filter.validate("", metadata=metadata)  # Providing an empty user query

  # Assert
  assert validation_result.execution_status == ValidatorExecutionStatusEnum.PARAMS_ERROR  


@pytest.mark.asyncio
async def test_query_topics_bad_config():
  # Arrange

  # invalid config
  bad_config_data = {"threshold": "unknown_threshold", "devise": "unknown_device"}

  # Assert that a ValidationError is raised for bad config
  with pytest.raises(ValidationError) as exc_info:
    ValidateMetadataModel(**bad_config_data)  # Attempt to create model with bad config

  # Printing the errors for debugging purposes
  print(exc_info.value.errors())  # Print the validation errors

  # Assert that the error contains validation issues
  assert len(exc_info.value.errors()) > 0
  assert any("devise" in str(error) for error in exc_info.value.errors()) or any(
    "language" in str(error) for error in exc_info.value.errors()
  )


@pytest.mark.asyncio
async def test_query_topics_bad_validator_request():
  # Arrange
  # Prepare invalid data for ValidatorRequestModel
  invalid_request_data = {
    "request_id": "not-a-uuid",  # Invalid UUID
    "pipeline_execution_id": uuid4(),
    "project_name": "Travel General Enquiries",
    "scope":"DEV",
    "country_name":"France",
    "partner_name":"PUFFIN",
    "validator_config": "invalid_validator_configuration",
    "validator_execution_id": uuid4(),
    "validator_config": "invalid_validator_config",
    "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
    "validation_method": "invalid_method",  # Invalid validation method
    "user_payload": None,
    "config_parameters": {"devise": "cpu", "language": "english"},
  }
  # Assert that a ValidationError is raised for bad ValidatorRequestModel
  with pytest.raises(ValidationError) as exc_info:
    ValidatorRequestModel(**invalid_request_data)  # Attempt to create model with bad request data

  # Printing the errors for debugging purposes
  print(exc_info.value.errors())  # Print the validation errors

  # Assert that the error contains validation issues
  assert len(exc_info.value.errors()) > 0
  assert any("request_id" in str(error) for error in exc_info.value.errors())
  assert any("validation_method" in str(error) for error in exc_info.value.errors())
