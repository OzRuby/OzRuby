import asyncio
from uuid import uuid4

import nest_asyncio
import pytest
from guardrails.validator_base import FailResult, PassResult  # type: ignore
from pydantic_core import ValidationError

nest_asyncio.apply()

from ai_trust_validators.share_models.validator import (  # type: ignore  # noqa: E402
  ValidatorExecutionModel,
  ValidatorRequestModel,
  ValidatorResponseStatusEnum,
)
from ai_trust_validators.validators.format_checker.src.models.input_output import ValidateMetadataModel


from .common_fixtures import *  # noqa: F403


def test_config_good_method(good_check_method_config):
  # run config test
  configs = ValidatorRequestModel.model_validate_json(good_check_method_config)
  assert isinstance(configs, ValidatorRequestModel) is True
  assert configs.user_payload is None


@pytest.mark.asyncio(loop_scope="session")
async def test_good_input_good_uuid(
  good_check_uuid_config, make_validate_format, good_check_input_request, check_metadata
):
  # run config test
  configs = ValidatorRequestModel.model_validate_json(good_check_uuid_config)
  data = await make_validate_format.validate_format(configs, good_check_input_request, check_metadata)

  # Assert
  assert isinstance(data, ValidatorExecutionModel) is True
  assert data.execution_status == "completed"
  assert data.response.details["Result"]["outcome"] == ValidatorResponseStatusEnum.PASS



@pytest.mark.asyncio
async def test_chunks_relevance_bad_config():
  # Arrange

  # invalid config
  bad_config_data = {"devise": "unknown_device", "language": "unknown_language"}

  # Assert that a ValidationError is raised for bad config
  with pytest.raises(ValidationError) as exc_info:
    ValidateMetadataModel(**bad_config_data)  # Attempt to create model with bad config

  # Printing the errors for debugging purposes
  print(exc_info.value.errors())  # Print the validation errors

  # Assert that the error contains validation issues
  assert len(exc_info.value.errors()) > 0
  assert any("devise" in str(error) for error in exc_info.value.errors()) or any(
    "language" in str(error) for error in exc_info.value.errors()
  )


@pytest.mark.asyncio
async def test_chunks_relevance_bad_validator_request():
  # Arrange
  # Prepare invalid data for ValidatorRequestModel
  invalid_request_data = {
    "request_id": "not-a-uuid",  # Invalid UUID
    "pipeline_execution_id": uuid4(),
    "scope": "DEV",
    "country_name":"France",
    "partner_name":"PUFFIN",
    "project_name": "Travel General Enquiries",
    "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
    "validator_config":"invalid_validator_configuration",
    "validation_method": "invalid_method",  # Invalid validation method
    "user_payload": None,
    "config_parameters": {"devise": "cpu", "language": "english"},
  }

  # Assert that a ValidationError is raised for bad ValidatorRequestModel
  with pytest.raises(ValidationError) as exc_info:
    ValidatorRequestModel(**invalid_request_data)  # Attempt to create model with bad request data

  # Printing the errors for debugging purposes
  print(exc_info.value.errors())  # Print the validation errors

  # Assert that the error contains validation issues
  assert len(exc_info.value.errors()) > 0
  assert any("request_id" in str(error) for error in exc_info.value.errors())
  assert any("validation_method" in str(error) for error in exc_info.value.errors())
