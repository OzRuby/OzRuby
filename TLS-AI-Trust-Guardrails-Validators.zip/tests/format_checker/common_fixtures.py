import json
from uuid import uuid4

import pytest
import pytest_asyncio

from ai_trust_validators.validators.format_checker import FormatValidator
from ai_trust_validators.validators.format_checker.src.models.input_output import ValidateMetadataModel
from ai_trust_validators.share_models.validator import (
    ValidatorConfig,
    ValidatorPriorityEnum)

__all__ = [
  "make_validate_format",
  "good_check_method_config",
  "good_check_uuid_config",
  "good_check_input_request",
  "bad_check_method_config",
  "check_metadata",
  "bad_check_uuid_config",
  "bad_check_input_request",
]

metadata = {
  "content_type": "text",
}



#config parameters
config_parameters =  ValidateMetadataModel(
      threshold=0.4, devise="cpu", sensibility=2, language="english", **metadata
  )

# Validator config
validator_configuration= ValidatorConfig(
        name="validator_name", validator_type="event_based", endpoint_url="validator/format_checker", priority= ValidatorPriorityEnum.P1,
    )

def validator_config_to_dict(validator_config):
    return {
        "name": validator_config.name,
        "validator_type": validator_config.validator_type,
        # Add other attributes as needed
    }

class FormatTest:
  async def validate_format(self, validator_config, input_request, metadata):
    format = FormatValidator(validator_config)
    results = await format.validate(input_request, metadata)
    return results


@pytest_asyncio.fixture(scope="session")
def make_validate_format():
  return FormatTest()


@pytest.fixture(scope="session", params=["llm", "ml", "regex"])
def good_check_method_config(request):
  return json.dumps(
    {
      "pipeline_execution_id": str(uuid4()),
      "request_id": str(uuid4()),
      "validation_method": request.param,
      "project_name": "Travel General Enquiries",
      "scope":"DEV",
      "country_name":"France",
      "contract_name":"PUFFIN",
      "validator_execution_id": uuid4(),
      "validator_config": validator_config_to_dict(validator_configuration),
      "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
      "user_payload": None,
      "config_parameters": config_parameters.model_dump(),
    }
  )


@pytest.fixture(scope="session", params=["mlops", "data"])
def bad_check_method_config(request):
  return json.dumps(
    {
      "pipeline_execution_id": str(uuid4()),
      "validation_method": request.param,
      "user_payload": None,
      "config_parameters": config_parameters.model_dump(),
    }
  )


@pytest.fixture(scope="session", params=[str(uuid4()), "da05cf61-5c96-43bf-815b-3555144449c8"])
def good_check_uuid_config(request):
  return json.dumps(
    {
      "pipeline_execution_id": request.param,
      "request_id": request.param,
      "validation_method": "llm",
      "scope":"DEV",
      "country_name":"France",
      "contract_name":"PUFFIN",
      "project_name": "Travel General Enquiries",
      "validator_execution_id": uuid4(),
      "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
      "user_payload": None,
      "validator_config":validator_config_to_dict(validator_configuration),
      "config_parameters": config_parameters.model_dump(),
    }
  )


@pytest.fixture(scope="session", params=["d23effe-1dsg-dqsd-dade-ohiiih", "deffe-1dqd-dqae-dadekio8fe"])
def bad_check_uuid_config(request):
  return json.dumps(
    {
      "pipeline_execution_id": request.param,
      "request_id": request.param,
      "validation_method": "llm",
      "scope":"DEV",
      "country_name":"France",
      "contract_name":"PUFFIN",
      "project_name": "Travel General Enquiries",
      "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
      "user_payload": None,
      "validator_config":validator_config_to_dict(validator_configuration),
      "config_parameters": config_parameters.model_dump(),
    }
  )


@pytest.fixture(
  scope="session",
  params=[
    "What are the key differences between term life insurance and whole life insurance?",
    "What factors affect the premium rates for car insurance?",
    "Can you explain the benefits of having health insurance coverage?",

  ],
)
def good_check_input_request(request):
  return request.param


@pytest.fixture(
  scope="session",
  params=[
    "The meeting is scheduled for 2023/10/15, which is not the correct date format for our records",
    "Please send your feedback to feedback@company@domain.com, but the email address is incorrectly formatted.",
    "The product code is 1234-ABCD&%$, which contains invalid characters and should only include letters and numbers.",
    "I received the report on 10-15-2023, but the expected format is YYYY-MM-DD.",
    "The user's name is Jöhn Dœ, where special characters are not supported in our system.",
  ],
)
def bad_check_input_request(request):
  return request.param


@pytest.fixture(scope="session")
def check_metadata():
  return {}
