import json
from uuid import uuid4

import pytest
import pytest_asyncio

from ai_trust_validators.share_models.validator import ValidatorConfig
from ai_trust_validators.validators.grammar_checker import GrammarValidator
from ai_trust_validators.validators.grammar_checker.src.models.input_output import ValidateMetadataModel

__all__ = ["make_validate_grammar", "good_check_method_config",
            "good_check_uuid_config", "good_check_input_request",
            "bad_check_method_config", "check_metadata",
            "bad_check_uuid_config", "bad_check_input_request",
            "bad_check_input_param_error_request"]

metadata = {
    "content_type": "text"
}

config_parameters = ValidateMetadataModel(
    threshold = 0.6,
    devise = "cpu",
    sensibility = 2,
    language = "multilingual",
    **metadata
)

# Validator config
validator_configuration= ValidatorConfig(
    name="validator_name",
    validator_type="event_based"
)

def validator_config_to_dict(validator_config):
    return {
        "name": validator_config.name,
        "validator_type": validator_config.validator_type,
        # Add other attributes as needed
    }

class GrammarTest:
    async def validate_grammar(self, validator_config, input_request, metadata):
        grammar = GrammarValidator(validator_config)
        results = await grammar.validate(input_request, metadata)
        return results

@pytest_asyncio.fixture(scope="session")
def make_validate_grammar():
    return GrammarTest()

@pytest.fixture(scope="session", params=["llm", "ml", "regex"])
def good_check_method_config(request):
    return json.dumps({
        "pipeline_execution_id": str(uuid4()),
        "request_id": str(uuid4()),
        "scope":"DEV",
        "country_name":"France",
        "contract_name":"PUFFIN",
        "validator_config": validator_config_to_dict(validator_configuration),
        "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
        "project_name": "Travel General Enquieries",
        "validation_method": request.param,
        "user_payload": None,
        "config_parameters": config_parameters.model_dump()
    })

@pytest.fixture(scope="session", params=["mlops", "data"])
def bad_check_method_config(request):
    return json.dumps({
        "pipeline_execution_id": str(uuid4()),
        "validation_method": request.param,
        "scope":"DEV",
        "country_name":"France",
        "contract_name":"PUFFIN",
        "validator_config": validator_config_to_dict(validator_configuration),
        "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
        "project_name": "Travel General Enquieries",
        "user_payload": None,
        "config_parameters": config_parameters.model_dump()
    })

@pytest.fixture(scope="session", params=[str(uuid4()), "da05cf61-5c96-43bf-815b-3555144449c8"])
def good_check_uuid_config(request):
    return json.dumps({
        "pipeline_execution_id": request.param,
        "request_id": request.param,
        "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
        "scope":"DEV",
        "country_name":"France",
        "contract_name":"PUFFIN",
        "validator_config": validator_config_to_dict(validator_configuration),
        "project_name": "Travel General Enquieries",
        "validation_method": "llm",
        "user_payload": None,
        "config_parameters": config_parameters.model_dump()
    })

@pytest.fixture(scope="session", params=["d23effe-1dsg-dqsd-dade-ohiiih", "deffe-1dqd-dqae-dadekio8fe"])
def bad_check_uuid_config(request):
    return json.dumps({
        "pipeline_execution_id": request.param,
        "request_id": request.param,
        "conversation_id": "479473ce-2fb4-44b0-ab07-00c86be52f2f",
        "scope":"DEV",
        "country_name":"France",
        "contract_name":"PUFFIN",
        "validator_config": validator_config_to_dict(validator_configuration),
        "project_name": "Travel General Enquieries",
        "validation_method": "llm",
        "user_payload": None,
        "config_parameters": config_parameters.model_dump()
    })

@pytest.fixture(scope="session", params=[
    "j'ai eu un accident avec ma voiture.",
    "mon assurance",
    #"تأميني مكسور",
    #"我的车坏了我应该得到多少",
    "I have a car breakdown. How much compensation should I be paid?",
])
def good_check_input_request(request):
    return request.param

@pytest.fixture(scope="session", params=[
    "j'aimer savoir si mon contrat couvre le scharg associé. Je suis seul sans enfant et j'ai besoin d'argent",
    "i have a car breakdown, How much compensation should I be pair?",
    "Tengo una avería en el coche. ¿Cuánto debería recibir como compensación?",
])
def bad_check_input_request(request):
    return request.param

@pytest.fixture(scope="session", params=[
    "i",
    "تأميني مكر ",
    "",
])
def bad_check_input_param_error_request(request):
    return request.param

@pytest.fixture(scope="session")
def check_metadata():
    return { }
