import nest_asyncio
import pytest
from guardrails.validator_base import FailResult, PassResult  # type: ignore
from pydantic_core import ValidationError

nest_asyncio.apply()

from ai_trust_validators.share_models.validator import (  # type: ignore  # noqa: E402
    ValidatorExecutionModel,
    ValidatorRequestModel,
)

from .common_fixtures import *  # noqa: E402, F403


def test_config_bad_uuid(
        bad_check_uuid_config
    ):
    # run config test
    with pytest.raises((ValueError, ValidationError)):
        ValidatorRequestModel.model_validate_json(
            bad_check_uuid_config
        )

def test_config_bad_method(
        bad_check_method_config
    ):
    # run config test
    with pytest.raises((ValueError, ValidationError)):
        ValidatorRequestModel.model_validate_json(
            bad_check_method_config
        )

def test_config_good_uuid(
        good_check_uuid_config
    ):
    # run config test
    configs = ValidatorRequestModel.model_validate_json(
        good_check_uuid_config
    )
    assert isinstance(configs, ValidatorRequestModel) is True
    assert configs.validation_method == "llm"
    assert configs.user_payload is None

def test_config_good_method(
        good_check_method_config
    ):
    # run config test
    configs = ValidatorRequestModel.model_validate_json(
        good_check_method_config
    )
    assert isinstance(configs, ValidatorRequestModel) is True
    assert configs.user_payload is None


@pytest.mark.asyncio(loop_scope="session")
async def test_good_input_good_uuid(
    good_check_uuid_config,
    make_validate_grammar,
    good_check_input_request,
    check_metadata
    ):
    # run config test
    configs = ValidatorRequestModel.model_validate_json(
        good_check_uuid_config
    )
    data = await make_validate_grammar.validate_grammar(
        configs,
        good_check_input_request,
        check_metadata
    )

    # Assert
    assert isinstance(data, ValidatorExecutionModel) is True
    assert data.execution_status == "completed"
    assert isinstance(data.response.details, PassResult) is True

@pytest.mark.asyncio(loop_scope="session")
async def test_bad_input_good_uuid(
    good_check_uuid_config,
    make_validate_grammar,
    bad_check_input_request,
    check_metadata
    ):
    # run config test
    configs = ValidatorRequestModel.model_validate_json(
        good_check_uuid_config
    )
    data = await make_validate_grammar.validate_grammar(
        configs,
        bad_check_input_request,
        check_metadata
    )

    # Assert
    assert isinstance(data, ValidatorExecutionModel) is True
    assert data.execution_status == "completed"
    assert isinstance(data.response.details, FailResult) is True

@pytest.mark.asyncio(loop_scope="session")
async def test_bad_input_good_uuid_params(
    good_check_uuid_config,
    make_validate_grammar,
    bad_check_input_param_error_request,
    check_metadata
    ):
    # run config test
    configs = ValidatorRequestModel.model_validate_json(
        good_check_uuid_config
    )
    data = await make_validate_grammar.validate_grammar(
        configs,
        bad_check_input_param_error_request,
        check_metadata
    )

    # Assert
    assert isinstance(data, ValidatorExecutionModel) is True
    assert data.execution_status == "params_error"
    assert isinstance(data.response.details, FailResult) is True
